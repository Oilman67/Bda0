import React, { useState, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput,
  ActivityIndicator, ScrollView, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';
import SegmentPicker from '../components/SegmentPicker';

interface Prospect {
  name: string;
  domain: string;
  description: string;
  fitReason: string;
  headquarters: string;
  estimatedSize: string;
}

// Define a GeoZone interface for geographic filtering
interface GeoZone {
  region: string;
  country?: string;
  stateProvince?: string;
  city?: string;
}

// Function to format GeoZone into a string
function formatZone(z: GeoZone): string {
  const parts = [z.region];
  if (z.country) parts.push(z.country);
  if (z.stateProvince) parts.push(z.stateProvince);
  if (z.city) parts.push(z.city);
  return parts.join(' > ');
}

export default function CompaniesScreen({ navigation }: any) {
  const companies = useQuery(api.companies.list);
  const orgSettings = useQuery(api.orgSettings.get);
  const allSegments = useQuery(api.segments.list);
  const [search, setSearch] = useState('');

  // Research AI state
  const [researchExpanded, setResearchExpanded] = useState(true);
  const [researchSegmentId, setResearchSegmentId] = useState<any>(undefined);
  const [researchSegmentPath, setResearchSegmentPath] = useState<string | undefined>(undefined);
  const [researching, setResearching] = useState(false);
  const [prospects, setProspects] = useState<Prospect[]>([]);
  const [selectedProspects, setSelectedProspects] = useState<Set<number>>(new Set());
  const [researchDone, setResearchDone] = useState(false);

  // Geography filter state
  const [researchGeo, setResearchGeo] = useState<string>('');
  const [customGeo, setCustomGeo] = useState('');
  const [savedZones, setSavedZones] = useState<GeoZone[]>([]);

  // Parse saved zones from business context
  const parsedZones = React.useMemo(() => {
    if (!orgSettings?.businessContext) return [];
    try {
      const ctx = JSON.parse(orgSettings.businessContext);
      if (ctx.geoZones && ctx.geoZones.length > 0) return ctx.geoZones as GeoZone[];
      if (ctx.regions && ctx.regions.length > 0) return ctx.regions.map((r: string) => ({ region: r })) as GeoZone[];
    } catch {}
    return [];
  }, [orgSettings]);

  React.useEffect(() => { setSavedZones(parsedZones); }, [parsedZones]);

  const filtered = companies?.filter((c: any) =>
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  // Build segment path from ID
  const getSegmentPath = useCallback((segId: any): string | undefined => {
    if (!segId || !allSegments) return undefined;
    const path: string[] = [];
    let cur = allSegments.find((s: any) => s._id === segId);
    while (cur) {
      path.unshift(cur.name);
      cur = cur.parentId ? allSegments.find((s: any) => s._id === cur!.parentId) : undefined;
    }
    return path.length > 0 ? path.join(' > ') : undefined;
  }, [allSegments]);

  // Parse business context JSON for geographic info
  const getBusinessContext = useCallback(() => {
    if (!orgSettings) return null;
    let contextData: any = {};
    if (orgSettings.businessContext) {
      try {
        contextData = JSON.parse(orgSettings.businessContext);
      } catch (_e) { }
    }
    return {
      companyName: orgSettings.companyName,
      companyUrl: orgSettings.companyUrl,
      interests: orgSettings.interests,
      ...contextData,
    };
  }, [orgSettings]);

  // Function to handle research logic
  const handleResearch = useCallback(async () => {
    if (!researchSegmentPath) {
      Alert.alert('Select Segment', 'Please select a market segment to research prospects for.');
      return;
    }

    const ctx = getBusinessContext();
    if (!ctx) {
      Alert.alert('Profile Required', 'Set up your company profile in Settings first to enable AI research.');
      return;
    }

    setResearching(true);
    setProspects([]);
    setSelectedProspects(new Set());
    setResearchDone(false);

    try {
      // Build list of existing company names to exclude
      const existingNames = (companies || []).map((c: any) => c.name);

      // Extract geographic info — prefer explicit research filter, fallback to business context
      let geoStr = '';
      if (customGeo.trim()) {
        geoStr = customGeo.trim();
      } else if (researchGeo) {
        geoStr = researchGeo;
      } else {
        // Fallback to all saved zones
        const ctxZones = savedZones.length > 0 ? savedZones.map(formatZone).join('; ') : '';
        const fallbackGeo = [
          ctx.geographicFocus,
          ctx.primaryMarkets,
          ctx.regions,
          ctx.region,
        ].filter(Boolean);
        geoStr = ctxZones || (Array.isArray(fallbackGeo[0]) ? (fallbackGeo[0] as string[]).join(', ') : fallbackGeo.filter(g => typeof g === 'string').join(', '));
      }

      const targetIndustries = ctx.targetIndustries || ctx.targetSectors || [];
      const clientTypes = ctx.clientTypes || [];

      const systemPrompt = `You are a Business Development Research AI. Your job is to identify REAL companies that are strong business development prospects.

TASK: Find 6-10 real companies in the "${researchSegmentPath}" segment that would be strong candidates for B2B outreach.

OUR COMPANY:
- Name: "${ctx.companyName}"${ctx.companyUrl ? `\n- Website: ${ctx.companyUrl}` : ''}
- Services/Offers: "${ctx.interests || 'Not specified'}"
${targetIndustries.length > 0 ? `- Target industries: ${targetIndustries.join(', ')}` : ''}
${clientTypes.length > 0 ? `- Target client types: ${clientTypes.join(', ')}` : ''}
${geoStr ? `- Geographic focus: ${geoStr}` : '- Geographic focus: global'}
${ctx.valueProposition ? `- Value proposition: ${ctx.valueProposition}` : ''}

RULES:
1. ONLY return REAL, verifiable companies — no fictional ones
2. Companies must operate in or be closely related to "${researchSegmentPath}"
3. Focus on the geographic regions specified above
4. These should be potential CLIENTS or PARTNERS who need our services
5. EXCLUDE these companies (already in our database): ${existingNames.slice(0, 40).join(', ') || 'none yet'}
6. For each prospect, explain specifically WHY they'd want our services
7. Include their actual website domain

You MUST respond with ONLY valid JSON in this exact format — no markdown, no explanation, just JSON:
{"prospects": [{"name": "Company Name", "domain": "company.com", "description": "What this company does (2-3 sentences)", "fitReason": "Why they would want our services specifically", "headquarters": "City, Country", "estimatedSize": "Small|Medium|Large|Enterprise"}]}`;

      const userMsg = `Find 6-10 real prospect companies in "${researchSegmentPath}" that would be good BD targets for ${ctx.companyName}. Our offering: "${ctx.interests}"${geoStr ? `. Focus on: ${geoStr}` : ''}`;

      console.log('[Research] Sending request...');
      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userMsg },
          ],
        }),
      });
      const data = await res.json();
      console.log('[Research] Status:', res.status);
      console.log('[Research] Completion preview:', data.completion?.substring(0, 300));

      let result: Prospect[] = [];

      if (data.completion) {
        try {
          // Strip markdown code fences if present
          const cleaned = data.completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
          const parsed = JSON.parse(cleaned);
          result = parsed.prospects || parsed;
        } catch (_e) {
          // Try extracting JSON from mixed content
          const firstBrace = data.completion.indexOf('{');
          const lastBrace = data.completion.lastIndexOf('}');
          if (firstBrace !== -1 && lastBrace > firstBrace) {
            try {
              const parsed = JSON.parse(data.completion.substring(firstBrace, lastBrace + 1));
              result = parsed.prospects || [];
            } catch (_e2) {
              console.log('[Research] Failed to parse response');
            }
          }
        }
      }

      if (!Array.isArray(result)) result = [];
      console.log('[Research] Parsed prospects count:', result.length);

      // Filter out companies already in database
      const existingLower = existingNames.map((n: string) => n.toLowerCase().trim());
      result = result.filter((p: Prospect) =>
        p.name && !existingLower.includes(p.name.toLowerCase().trim())
      );

      console.log('[Research] After duplicate filter:', result.length);

      setProspects(result);
      setResearchDone(true);

      if (result.length === 0) {
        Alert.alert('No Results', 'No new prospect companies found. Try a different segment or broaden your search.');
      }
    } catch (err: any) {
      console.log('[Research] Error:', err?.message);
      Alert.alert('Research Failed', 'Failed to research prospects. Please try again.');
    } finally {
      setResearching(false);
    }
  }, [researchSegmentPath, companies, getBusinessContext, customGeo, researchGeo, savedZones]);

  const toggleProspect = (index: number) => {
    setSelectedProspects((prev: Set<number>) => {
      const next = new Set(prev);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  };

  const handleAddProspect = (prospect: Prospect) => {
    navigation.navigate('AddCompany', { initialName: prospect.name });
  };

  const handleAddSelected = () => {
    if (selectedProspects.size === 0) {
      Alert.alert('Select Companies', 'Please select at least one company to add.');
      return;
    }
    // Navigate to AddCompany for the first selected
    const indices = Array.from(selectedProspects) as number[];
    indices.sort((a, b) => a - b);
    const first = prospects[indices[0]];
    if (first) {
      // Remove from selection so user sees progress when they come back
      setSelectedProspects((prev: Set<number>) => {
        const next = new Set(prev);
        next.delete(indices[0]);
        return next;
      });
      navigation.navigate('AddCompany', { initialName: first.name });
    }
  };

  const selectAll = () => {
    if (selectedProspects.size === prospects.length) {
      setSelectedProspects(new Set());
    } else {
      setSelectedProspects(new Set(prospects.map((_: Prospect, i: number) => i)));
    }
  };

  const hasProfile = !!orgSettings?.companyName;

  const renderResearchPanel = () => (
    <View style={styles.researchPanel}>
      <TouchableOpacity
        style={styles.researchHeader}
        onPress={() => setResearchExpanded(!researchExpanded)}
        activeOpacity={0.7}
      >
        <View style={styles.researchHeaderLeft}>
          <View style={styles.researchIconWrap}>
            <Ionicons name="search" size={16} color={colors.white} />
          </View>
          <View>
            <Text style={styles.researchTitle}>Prospect Research AI</Text>
            <Text style={styles.researchSubtitle}>Find prospect companies by segment</Text>
          </View>
        </View>
        <Ionicons
          name={researchExpanded ? 'chevron-up' : 'chevron-down'}
          size={20}
          color={colors.textTertiary}
        />
      </TouchableOpacity>

      {researchExpanded && (
        <View style={styles.researchBody}>
          {!hasProfile ? (
            <View style={styles.profilePrompt}>
              <Ionicons name="information-circle" size={16} color={colors.info} />
              <Text style={styles.profilePromptText}>
                Set up your company profile in Settings to enable AI prospect research.
              </Text>
            </View>
          ) : (
            <>
              {/* Segment Picker */}
              <Text style={styles.researchLabel}>Target Segment</Text>
              <SegmentPicker
                value={researchSegmentId}
                valuePath={researchSegmentPath}
                onChange={(segId: any) => {
                  setResearchSegmentId(segId);
                  setResearchSegmentPath(getSegmentPath(segId));
                  // Clear previous results when segment changes
                  setProspects([]);
                  setSelectedProspects(new Set());
                  setResearchDone(false);
                }}
              />

              {/* Geography Filter */}
              <Text style={[styles.researchLabel, { marginTop: spacing.sm }]}>Geography</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 6 }}>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  <TouchableOpacity
                    style={[styles.geoChip, !researchGeo && !customGeo && styles.geoChipActive]}
                    onPress={() => { setResearchGeo(''); setCustomGeo(''); }}
                  >
                    <Text style={[styles.geoChipText, !researchGeo && !customGeo && styles.geoChipTextActive]}>
                      {savedZones.length > 0 ? 'All saved zones' : 'Global'}
                    </Text>
                  </TouchableOpacity>
                  {savedZones.map((z: GeoZone, i: number) => {
                    const label = formatZone(z);
                    const isActive = researchGeo === label;
                    return (
                      <TouchableOpacity
                        key={i}
                        style={[styles.geoChip, isActive && styles.geoChipActive]}
                        onPress={() => { setResearchGeo(isActive ? '' : label); setCustomGeo(''); }}
                      >
                        <Ionicons name="location" size={10} color={isActive ? colors.white : colors.textTertiary} />
                        <Text style={[styles.geoChipText, isActive && styles.geoChipTextActive]} numberOfLines={1}>{label}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>
              <TextInput
                style={styles.geoCustomInput}
                placeholder="Or type a specific location (e.g. Montreal, Quebec)"
                placeholderTextColor={colors.textTertiary}
                value={customGeo}
                onChangeText={(t: string) => { setCustomGeo(t); if (t) setResearchGeo(''); }}
              />

              {/* Research Button */}
              <TouchableOpacity
                style={[styles.researchBtn, (!researchSegmentId || researching) && styles.researchBtnDisabled]}
                onPress={handleResearch}
                disabled={!researchSegmentId || researching}
              >
                {researching ? (
                  <>
                    <ActivityIndicator size="small" color={colors.white} />
                    <Text style={styles.researchBtnText}>Researching prospects...</Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="sparkles" size={16} color={colors.white} />
                    <Text style={styles.researchBtnText}>Research Prospects</Text>
                  </>
                )}
              </TouchableOpacity>

              {/* Time estimate */}
              {researching && (
                <Text style={styles.timeEstimate}>
                  AI is researching real companies — this typically takes 15-30 seconds
                </Text>
              )}
              {!researching && !researchDone && researchSegmentId && (
                <Text style={styles.timeHint}>
                  Estimated time: ~20 seconds
                </Text>
              )}

              {/* Results */}
              {prospects.length > 0 && (
                <View style={styles.resultsSection}>
                  <View style={styles.resultsHeader}>
                    <Text style={styles.resultsTitle}>
                      {prospects.length} Prospect{prospects.length !== 1 ? 's' : ''} Found
                    </Text>
                    <TouchableOpacity onPress={selectAll} style={styles.selectAllBtn}>
                      <Ionicons
                        name={selectedProspects.size === prospects.length ? 'checkbox' : 'square-outline'}
                        size={18}
                        color={colors.primary}
                      />
                      <Text style={styles.selectAllText}>
                        {selectedProspects.size === prospects.length ? 'Deselect All' : 'Select All'}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {prospects.map((prospect: Prospect, index: number) => {
                    const isSelected = selectedProspects.has(index);
                    return (
                      <View key={index} style={[styles.prospectCard, isSelected && styles.prospectCardSelected]}>
                        <TouchableOpacity
                          style={styles.prospectCheckArea}
                          onPress={() => toggleProspect(index)}
                        >
                          <Ionicons
                            name={isSelected ? 'checkbox' : 'square-outline'}
                            size={22}
                            color={isSelected ? colors.primary : colors.textTertiary}
                          />
                        </TouchableOpacity>

                        <View style={styles.prospectBody}>
                          <View style={styles.prospectTopRow}>
                            <Text style={styles.prospectName}>{prospect.name}</Text>
                            <View style={styles.sizeBadge}>
                              <Text style={styles.sizeText}>{prospect.estimatedSize}</Text>
                            </View>
                          </View>

                          <View style={styles.prospectMeta}>
                            <Ionicons name="globe-outline" size={11} color={colors.textTertiary} />
                            <Text style={styles.prospectDomain}>{prospect.domain}</Text>
                            {prospect.headquarters ? (
                              <>
                                <Text style={styles.prospectMetaDot}>·</Text>
                                <Ionicons name="location-outline" size={11} color={colors.textTertiary} />
                                <Text style={styles.prospectHq}>{prospect.headquarters}</Text>
                              </>
                            ) : null}
                          </View>

                          <Text style={styles.prospectDesc} numberOfLines={2}>
                            {prospect.description}
                          </Text>

                          <View style={styles.fitReasonWrap}>
                            <Ionicons name="bulb-outline" size={12} color={colors.accent} />
                            <Text style={styles.fitReasonText} numberOfLines={2}>
                              {prospect.fitReason}
                            </Text>
                          </View>

                          <TouchableOpacity
                            style={styles.addOneBtn}
                            onPress={() => handleAddProspect(prospect)}
                          >
                            <Ionicons name="add-circle-outline" size={14} color={colors.primary} />
                            <Text style={styles.addOneBtnText}>Add to Companies</Text>
                          </TouchableOpacity>
                        </View>
                      </View>
                    );
                  })}

                  {/* Batch Add Button */}
                  {selectedProspects.size > 0 && (
                    <TouchableOpacity style={styles.batchAddBtn} onPress={handleAddSelected}>
                      <Ionicons name="add" size={18} color={colors.white} />
                      <Text style={styles.batchAddBtnText}>
                        Add Selected ({selectedProspects.size})
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}

              {researchDone && prospects.length === 0 && !researching && (
                <View style={styles.noResults}>
                  <Ionicons name="search-outline" size={24} color={colors.textTertiary} />
                  <Text style={styles.noResultsText}>No new prospects found for this segment.</Text>
                  <Text style={styles.noResultsHint}>Try selecting a different segment.</Text>
                </View>
              )}
            </>
          )}
        </View>
      )}
    </View>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Companies</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('AddCompany')}>
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchWrap}>
        <Ionicons name="search" size={18} color={colors.textTertiary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search companies..."
          placeholderTextColor={colors.textTertiary}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {!companies ? (
        <View style={styles.loading}><Text style={styles.loadingText}>Loading...</Text></View>
      ) : filtered && filtered.length === 0 && !search ? (
        <ScrollView>
          {renderResearchPanel()}
          <EmptyState icon="business" title="No companies yet" subtitle="Add your first company to get started" actionLabel="Add Company" onAction={() => navigation.navigate('AddCompany')} />
        </ScrollView>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item: any) => item._id}
          contentContainerStyle={styles.list}
          ListHeaderComponent={renderResearchPanel()}
          renderItem={({ item }: any) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate('CompanyDetail', { id: item._id })}
            >
              <View style={styles.cardIcon}>
                <Text style={styles.cardInitial}>{item.name[0]?.toUpperCase()}</Text>
              </View>
              <View style={styles.cardBody}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                {item.segmentPath && (
                  <View style={styles.segmentTag}>
                    <Ionicons name="layers-outline" size={11} color={colors.primary} />
                    <Text style={styles.segmentText} numberOfLines={1}>{item.segmentPath}</Text>
                  </View>
                )}
                {item.industry && !item.segmentPath && <Text style={styles.cardSub}>{item.industry}</Text>}
                {item.email && <Text style={styles.cardMeta}>{item.email}</Text>}
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </TouchableOpacity>
          )}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    marginHorizontal: spacing.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.md,
  },
  searchInput: { flex: 1, marginLeft: spacing.sm, fontSize: fontSize.md, color: colors.textPrimary },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    padding: spacing.lg, borderRadius: radius.lg, marginBottom: spacing.sm, ...shadow.sm,
  },
  cardIcon: {
    width: 44, height: 44, borderRadius: radius.lg, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center',
  },
  cardInitial: { fontSize: fontSize.lg, fontWeight: '700', color: colors.primary },
  cardBody: { flex: 1, marginLeft: spacing.md },
  cardTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  cardSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  cardMeta: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 2 },
  segmentTag: {
    flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 3,
    backgroundColor: colors.primaryLight, paddingHorizontal: 6, paddingVertical: 2,
    borderRadius: 6, alignSelf: 'flex-start',
  },
  segmentText: { fontSize: 11, color: colors.primary, fontWeight: '500', maxWidth: 200 },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: colors.textSecondary },

  // Research Panel
  researchPanel: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.accent + '40',
    ...shadow.sm,
    overflow: 'hidden',
  },
  researchHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  researchHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flex: 1,
  },
  researchIconWrap: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
  },
  researchTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  researchSubtitle: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
    marginTop: 1,
  },
  researchBody: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },
  researchLabel: {
    fontSize: fontSize.xs,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  researchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.accent,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    marginTop: spacing.xs,
  },
  researchBtnDisabled: { opacity: 0.5 },
  researchBtnText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: fontSize.md,
  },
  timeEstimate: {
    fontSize: fontSize.xs,
    color: colors.accent,
    textAlign: 'center',
    marginTop: spacing.sm,
    fontStyle: 'italic',
  },
  timeHint: {
    fontSize: 10,
    color: colors.textTertiary,
    textAlign: 'center',
    marginTop: 4,
  },
  geoChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 14,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white,
  },
  geoChipActive: {
    backgroundColor: colors.accent, borderColor: colors.accent,
  },
  geoChipText: { fontSize: 11, color: colors.textSecondary },
  geoChipTextActive: { color: colors.white, fontWeight: '600' },
  geoCustomInput: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.borderLight,
    borderRadius: radius.sm, paddingHorizontal: 10, paddingVertical: 7,
    fontSize: 12, color: colors.textPrimary, marginBottom: spacing.xs,
  },
  profilePrompt: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: colors.infoLight,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  profilePromptText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.info,
  },

  // Results
  resultsSection: {
    marginTop: spacing.md,
  },
  resultsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  resultsTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  selectAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  selectAllText: {
    fontSize: fontSize.xs,
    color: colors.primary,
    fontWeight: '600',
  },
  prospectCard: {
    flexDirection: 'row',
    backgroundColor: colors.bg,
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  prospectCardSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight + '30',
  },
  prospectCheckArea: {
    paddingRight: spacing.sm,
    paddingTop: 2,
    justifyContent: 'flex-start',
  },
  prospectBody: {
    flex: 1,
  },
  prospectTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 3,
  },
  prospectName: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
    flex: 1,
    marginRight: spacing.sm,
  },
  sizeBadge: {
    backgroundColor: colors.primaryLight,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
  },
  sizeText: {
    fontSize: 9,
    fontWeight: '600',
    color: colors.primary,
  },
  prospectMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginBottom: 4,
  },
  prospectDomain: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  prospectMetaDot: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  prospectHq: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  prospectDesc: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    lineHeight: 16,
    marginBottom: 4,
  },
  fitReasonWrap: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 4,
    backgroundColor: colors.accentLight,
    padding: spacing.xs,
    borderRadius: radius.sm,
    marginBottom: spacing.sm,
  },
  fitReasonText: {
    flex: 1,
    fontSize: 10,
    color: colors.accent,
    fontWeight: '500',
    lineHeight: 14,
  },
  addOneBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
  },
  addOneBtnText: {
    fontSize: fontSize.xs,
    color: colors.primary,
    fontWeight: '600',
  },
  batchAddBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    marginTop: spacing.xs,
  },
  batchAddBtnText: {
    color: colors.white,
    fontWeight: '700',
    fontSize: fontSize.md,
  },
  noResults: {
    alignItems: 'center',
    paddingVertical: spacing.xl,
    gap: spacing.xs,
  },
  noResultsText: {
    fontSize: fontSize.sm,
    color: colors.textSecondary,
    fontWeight: '500',
  },
  noResultsHint: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
  },
});
