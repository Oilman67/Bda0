import React, { useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import FormModal from '../components/FormModal';
import ActionFormModal from '../components/ActionFormModal';
import NbaCard from '../components/NbaCard';
import ContextualEntry from '../components/ContextualEntry';
import SegmentPicker from '../components/SegmentPicker';

export default function CompanyDetailScreen({ route, navigation }: any) {
  const { id } = route.params;
  const company = useQuery(api.companies.get, { id });
  const contacts = useQuery(api.contacts.list, { companyId: id });
  const opportunities = useQuery(api.opportunities.listByCompany, { companyId: id });
  const interactions = useQuery(api.interactions.listByEntity, { entityType: 'company', entityId: id });
  const tasks = useQuery(api.actions.listByEntity, { entityType: 'company', entityId: id });
  const nbas = useQuery(api.nba.getNextActions, { entryType: 'company', entryId: id });
  const orgSettings = useQuery(api.orgSettings.get);
  const updateCompany = useMutation(api.companies.update);
  const removeCompany = useMutation(api.companies.remove);
  const createInteraction = useMutation(api.interactions.create);
  const createTask = useMutation(api.actions.create);
  const saveInsights = useMutation(api.companies.saveInsights);
  const dismissNba = useMutation(api.nbaActions.dismiss);
  const executeNba = useMutation(api.nbaActions.execute);
  const requestRefresh = useMutation(api.nbaActions.requestRefresh);
  const [showEdit, setShowEdit] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showAddAction, setShowAddAction] = useState(false);
  const [showContext, setShowContext] = useState(false);
  const [editSegmentId, setEditSegmentId] = useState<any>(undefined);
  const [editSegmentPath, setEditSegmentPath] = useState<string | undefined>(undefined);
  const [analyzing, setAnalyzing] = useState(false);
  const [insightsExpanded, setInsightsExpanded] = useState(false);
  const [selectedActions, setSelectedActions] = useState<Set<number>>(new Set());
  const [pushingActions, setPushingActions] = useState(false);
  const [selectedNbaIds, setSelectedNbaIds] = useState<Set<string>>(new Set());

  // Initialize edit segment when company loads
  const allSegments = useQuery(api.segments.list);

  // Parse stored insights
  const storedInsights = useMemo(() => {
    if (!company?.insightsReport) return null;
    try { return JSON.parse(company.insightsReport); } catch { return null; }
  }, [company?.insightsReport]);

  const hasProfile = !!orgSettings?.companyName;

  const handleAnalyze = async (mode: 'generate' | 'regenerate' | 'build') => {
    if (!orgSettings) {
      Alert.alert('Profile Required', 'Set up your company profile in Settings first.');
      return;
    }
    if (!company) return;
    setAnalyzing(true);
    try {
      const companyMeta = [
        company.domain && `Website: ${company.domain}`,
        company.industry && `Industry: ${company.industry}`,
        company.segmentPath && `Segment: ${company.segmentPath}`,
        company.notes && `Notes: ${company.notes?.slice(0, 200)}`,
      ].filter(Boolean).join(', ');

      const sysPrompt = `You are a BD Intelligence Officer. Identify concrete, actionable BD opportunities for a B2B company. Be extremely concise — no generic consulting language. Think like a senior BD exec under pressure to generate pipeline in 30 days. Every field must be short: titles under 8 words, descriptions under 2 sentences, all other text fields under 15 words. Return at most 3 opportunities.${mode === 'build' && storedInsights ? `\n\nPREVIOUS ANALYSIS (enhance, don't repeat):\n${JSON.stringify(storedInsights).slice(0, 1000)}` : ''}`;

      const userContent = `Our company: ${orgSettings.companyName}${orgSettings.companyUrl ? ` (${orgSettings.companyUrl})` : ''}. We offer: ${orgSettings.interests}.\nTarget: ${company.name}. Segment: ${company.segmentPath || 'Not classified'}. ${companyMeta}\n${mode === 'build' ? 'Build upon previous analysis with new insights.' : 'Identify top BD opportunities.'}`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 45000);
      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          messages: [
            { role: 'system', content: sysPrompt },
            { role: 'user', content: userContent },
          ],
          schema: {
            type: 'object',
            properties: {
              opportunity_summary: {
                type: 'array', description: 'Top 3 opportunities max', maxItems: 3,
                items: {
                  type: 'object',
                  properties: {
                    title: { type: 'string', description: 'Short name, max 8 words' },
                    description: { type: 'string', description: '1-2 sentences max' },
                    bd_focus_area: { type: 'string', description: 'Max 6 words' },
                    trigger: { type: 'string', description: 'Why now, max 10 words' },
                    stakeholders: { type: 'array', items: { type: 'string' }, maxItems: 3, description: 'Max 3 role titles' },
                    entry_strategy: { type: 'string', description: 'Max 1 sentence' },
                    likely_competitors: { type: 'array', items: { type: 'string' }, maxItems: 2, description: 'Max 2 competitor names' },
                    differentiation: { type: 'string', description: 'Max 1 sentence' },
                    priority_score: {
                      type: 'object',
                      properties: { likelihood: { type: 'number' }, speed: { type: 'number' }, strategic_value: { type: 'number' } },
                      required: ['likelihood', 'speed', 'strategic_value'],
                    },
                  },
                  required: ['title', 'description', 'bd_focus_area', 'trigger', 'stakeholders', 'entry_strategy', 'priority_score'],
                },
              },
              segment_insights: { type: 'array', items: { type: 'string' }, maxItems: 3, description: 'Max 3 key insights, each max 1 sentence' },
              recommended_next_actions: {
                type: 'array', description: 'Max 4 actions', maxItems: 4,
                items: {
                  type: 'object',
                  properties: {
                    title: { type: 'string', description: 'Max 8 words' },
                    details: { type: 'string', description: 'Max 1 sentence' },
                  },
                  required: ['title', 'details'],
                },
              },
            },
            required: ['opportunity_summary', 'segment_insights', 'recommended_next_actions'],
          },
        }),
      });
      clearTimeout(timeout);

      if (!res.ok) {
        Alert.alert('Analysis Failed', `API error ${res.status}. Try again.`);
        return;
      }

      const data = await res.json();
      let result: any = data.schema_data || null;
      if (!result && data.completion) {
        try { result = JSON.parse(data.completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim()); } catch {}
        if (!result) {
          try {
            const f = data.completion.indexOf('{');
            const l = data.completion.lastIndexOf('}');
            if (f !== -1 && l > f) result = JSON.parse(data.completion.substring(f, l + 1));
          } catch {}
        }
      }

      // Retry without schema if structured output failed
      if (!result) {
        try {
          const ctrl2 = new AbortController();
          const t2 = setTimeout(() => ctrl2.abort(), 45000);
          const res2 = await fetch('https://api.a0.dev/ai/llm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: ctrl2.signal,
            body: JSON.stringify({
              messages: [
                { role: 'system', content: sysPrompt + '\n\nReturn ONLY valid JSON (no markdown, no code fences, no explanation). Keys: opportunity_summary (array of max 3 objects with: title, description, bd_focus_area, trigger, stakeholders, entry_strategy, likely_competitors, differentiation, priority_score), segment_insights (array of max 3 strings), recommended_next_actions (array of max 4 {title, details}). Be extremely concise.' },
                { role: 'user', content: userContent },
              ],
            }),
          });
          clearTimeout(t2);
          if (res2.ok) {
            const d2 = await res2.json();
            const raw = (d2.completion || '').replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
            try { result = JSON.parse(raw); } catch {}
            if (!result) {
              try {
                const f = raw.indexOf('{');
                const l = raw.lastIndexOf('}');
                if (f !== -1 && l > f) result = JSON.parse(raw.substring(f, l + 1));
              } catch {}
            }
          }
        } catch { /* retry failed, continue */ }
      }

      if (result) {
        if (!Array.isArray(result.opportunity_summary)) result.opportunity_summary = [];
        if (!Array.isArray(result.segment_insights)) result.segment_insights = [];
        if (!Array.isArray(result.recommended_next_actions)) result.recommended_next_actions = [];
        result.recommended_next_actions = result.recommended_next_actions.map((a: any) => {
          if (typeof a === 'string') return { title: a.length > 60 ? a.substring(0, 57) + '...' : a, details: a };
          return { title: a.title || 'Untitled Action', details: a.details || a.description || '' };
        });
        result.opportunity_summary = result.opportunity_summary.map((opp: any) => ({
          title: opp.title || 'Untitled Opportunity',
          description: opp.description || '',
          bd_focus_area: opp.bd_focus_area || opp.focus_area || 'General',
          trigger: opp.trigger || 'Market opportunity',
          stakeholders: Array.isArray(opp.stakeholders) ? opp.stakeholders : [],
          entry_strategy: opp.entry_strategy || opp.strategy || '',
          competitive_context: {
            likely_competitors: Array.isArray(opp.likely_competitors) ? opp.likely_competitors
              : Array.isArray(opp.competitive_context?.likely_competitors) ? opp.competitive_context.likely_competitors : [],
            differentiation: opp.differentiation || opp.competitive_context?.differentiation || '',
          },
          priority_score: {
            likelihood: Number(opp.priority_score?.likelihood) || 3,
            speed: Number(opp.priority_score?.speed) || 3,
            strategic_value: Number(opp.priority_score?.strategic_value) || 3,
          },
        }));
        await saveInsights({ id, insightsReport: JSON.stringify(result) });
        setInsightsExpanded(true);
        setSelectedActions(new Set());
        Alert.alert('Success', mode === 'build' ? 'Insights updated.' : 'BD Intelligence report generated.');
      } else {
        Alert.alert('Analysis Failed', 'Could not parse AI response. Please try again.');
      }
    } catch (e: any) {
      if (e?.name === 'AbortError') {
        Alert.alert('Timeout', 'Analysis took too long. Try again.');
      } else {
        Alert.alert('Error', 'Failed to analyze. Please try again.');
      }
    } finally {
      setAnalyzing(false);
    }
  };

  const handlePushActions = async () => {
    if (!storedInsights || selectedActions.size === 0) return;
    setPushingActions(true);
    try {
      const actions = storedInsights.recommended_next_actions || [];
      let count = 0;
      for (const idx of selectedActions) {
        const action = actions[idx];
        if (action) {
          const title = typeof action === 'string' ? action : (action.title || 'Untitled Action');
          const details = typeof action === 'string' ? '' : (action.details || '');
          await createTask({
            title,
            description: details || `From BD Intelligence report for ${company?.name || 'company'}`,
            companyId: id,
            priority: 'medium',
          });
          count++;
        }
      }
      setSelectedActions(new Set());
      Alert.alert('Actions Created', `${count} action${count > 1 ? 's' : ''} pushed to your Actions list.`);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create actions.');
    } finally {
      setPushingActions(false);
    }
  };

  const toggleAction = (idx: number) => {
    setSelectedActions(prev => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  };

  const toggleNbaId = (nbaId: string) => {
    setSelectedNbaIds((prev: Set<string>) => {
      const next = new Set(prev);
      next.has(nbaId) ? next.delete(nbaId) : next.add(nbaId);
      return next;
    });
  };

  const handlePushNbas = async () => {
    if (!nbas || selectedNbaIds.size === 0) return;
    setPushingActions(true);
    try {
      let count = 0;
      for (const nbaId of selectedNbaIds) {
        const nba = nbas.find((n: any) => n._id === nbaId);
        if (nba) {
          await createTask({
            title: nba.title,
            description: nba.description || `From NBA for ${company?.name}`,
            companyId: id,
            priority: nba.score >= 70 ? 'high' : nba.score >= 40 ? 'medium' : 'low',
          });
          await executeNba({ id: nba._id });
          count++;
        }
      }
      setSelectedNbaIds(new Set());
      Alert.alert('Actions Created', `${count} action${count > 1 ? 's' : ''} pushed to your Actions list.`);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create actions.');
    } finally {
      setPushingActions(false);
    }
  };

  const renderPriorityDots = (score: number) => (
    <View style={{ flexDirection: 'row', gap: 2 }}>
      {[1, 2, 3, 4, 5].map(n => (
        <View key={n} style={{
          width: 6, height: 6, borderRadius: 3,
          backgroundColor: n <= score ? colors.primary : colors.borderLight,
        }} />
      ))}
    </View>
  );

  if (!company) return (
    <SafeAreaView style={styles.container}>
      <View style={styles.loading}><Text>Loading...</Text></View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.navActions}>
          <TouchableOpacity onPress={() => setShowEdit(true)} style={styles.navBtn}>
            <Ionicons name="pencil" size={18} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => Alert.alert('Delete Company?', 'This cannot be undone.', [
              { text: 'Cancel' },
              { text: 'Delete', style: 'destructive', onPress: () => { removeCompany({ id }); navigation.goBack(); } },
            ])}
            style={styles.navBtn}
          >
            <Ionicons name="trash" size={18} color={colors.danger} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.heroCard}>
          <View style={styles.heroIcon}>
            <Text style={styles.heroInitial}>{company.name[0]?.toUpperCase()}</Text>
          </View>
          <Text style={styles.heroName}>{company.name}</Text>
          {company.industry && <Text style={styles.heroSub}>{company.industry}</Text>}
          {company.segmentPath && (
            <View style={styles.segmentRow}>
              <Ionicons name="layers" size={14} color={colors.primary} />
              <Text style={styles.segmentPathText}>{company.segmentPath}</Text>
            </View>
          )}
          <View style={styles.infoRow}>
            {company.email && <InfoChip icon="mail" text={company.email} />}
            {company.phone && <InfoChip icon="call" text={company.phone} />}
            {company.domain && <InfoChip icon="globe" text={company.domain} />}
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <QuickBtn icon="chatbubble" label="Note" onPress={() => setShowAddNote(true)} />
          <QuickBtn icon="checkmark-circle" label="Action" onPress={() => setShowAddAction(true)} />
          <QuickBtn icon="sparkles" label="Context" onPress={() => setShowContext(true)} />
        </View>

        {/* BD Intelligence Section */}
        <View style={styles.section}>
          <View style={bdStyles.header}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <Ionicons name="bulb" size={18} color={colors.accent} />
              <Text style={[styles.sectionTitle, { marginBottom: 0 }]}>BD Intelligence</Text>
            </View>
            {storedInsights && (
              <TouchableOpacity onPress={() => setInsightsExpanded(!insightsExpanded)}>
                <Ionicons name={insightsExpanded ? 'chevron-up' : 'chevron-down'} size={20} color={colors.textSecondary} />
              </TouchableOpacity>
            )}
          </View>

          {company.insightsGeneratedAt && (
            <Text style={bdStyles.timestamp}>
              Last generated: {new Date(company.insightsGeneratedAt).toLocaleDateString()} at {new Date(company.insightsGeneratedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </Text>
          )}

          {analyzing && (
            <View style={bdStyles.analyzingBox}>
              <ActivityIndicator size="small" color={colors.accent} />
              <Text style={bdStyles.analyzingText}>BD Intelligence Officer analyzing {company.name}...</Text>
            </View>
          )}

          {!storedInsights && !analyzing && (
            <View style={bdStyles.emptyState}>
              {hasProfile ? (
                <TouchableOpacity style={bdStyles.generateBtn} onPress={() => handleAnalyze('generate')}>
                  <Ionicons name="sparkles" size={16} color={colors.white} />
                  <Text style={bdStyles.generateBtnText}>Generate BD Intelligence</Text>
                </TouchableOpacity>
              ) : (
                <Text style={bdStyles.noProfile}>Set up your company profile in Settings to enable BD Intelligence.</Text>
              )}
            </View>
          )}

          {storedInsights && insightsExpanded && (
            <View style={bdStyles.reportContainer}>
              {/* Segment Insights */}
              {storedInsights.segment_insights?.length > 0 && (
                <View style={bdStyles.card}>
                  <Text style={bdStyles.cardLabel}>SEGMENT INSIGHTS</Text>
                  {storedInsights.segment_insights.map((insight: string, i: number) => (
                    <View key={i} style={bdStyles.insightRow}>
                      <Ionicons name="analytics" size={12} color={colors.primary} />
                      <Text style={bdStyles.insightText}>{insight}</Text>
                    </View>
                  ))}
                </View>
              )}

              {/* Opportunities */}
              {storedInsights.opportunity_summary?.length > 0 && (
                <View>
                  <Text style={bdStyles.cardLabel}>OPPORTUNITIES ({storedInsights.opportunity_summary.length})</Text>
                  {[...storedInsights.opportunity_summary]
                    .sort((a: any, b: any) => {
                      const sA = (a.priority_score?.likelihood || 0) + (a.priority_score?.speed || 0) + (a.priority_score?.strategic_value || 0);
                      const sB = (b.priority_score?.likelihood || 0) + (b.priority_score?.speed || 0) + (b.priority_score?.strategic_value || 0);
                      return sB - sA;
                    })
                    .map((opp: any, i: number) => (
                    <View key={i} style={bdStyles.oppCard}>
                      <View style={bdStyles.oppHeader}>
                        <View style={bdStyles.oppRank}><Text style={bdStyles.oppRankText}>{i + 1}</Text></View>
                        <Text style={bdStyles.oppTitle}>{opp.title}</Text>
                      </View>
                      <Text style={bdStyles.oppDesc}>{opp.description}</Text>

                      <View style={bdStyles.metaRow}>
                        <Ionicons name="locate" size={11} color={colors.primary} />
                        <Text style={bdStyles.metaLabel}>Focus:</Text>
                        <Text style={bdStyles.metaValue}>{opp.bd_focus_area}</Text>
                      </View>
                      <View style={bdStyles.metaRow}>
                        <Ionicons name="flash" size={11} color={colors.warning} />
                        <Text style={bdStyles.metaLabel}>Trigger:</Text>
                        <Text style={bdStyles.metaValue}>{opp.trigger}</Text>
                      </View>

                      {opp.stakeholders?.length > 0 && (
                        <View style={bdStyles.stakeholders}>
                          <Ionicons name="people" size={11} color={colors.textTertiary} />
                          {opp.stakeholders.map((s: string, j: number) => (
                            <View key={j} style={bdStyles.stakeholderChip}>
                              <Text style={bdStyles.stakeholderText}>{s}</Text>
                            </View>
                          ))}
                        </View>
                      )}

                      <View style={bdStyles.entryRow}>
                        <Ionicons name="arrow-forward-circle" size={13} color={colors.success} />
                        <Text style={bdStyles.entryText}>{opp.entry_strategy}</Text>
                      </View>

                      {opp.likely_competitors?.length > 0 && (
                        <View style={bdStyles.compCtx}>
                          <Text style={bdStyles.compTitle}>Competitive Context</Text>
                          {opp.likely_competitors.map((c: string, j: number) => (
                            <View key={j} style={bdStyles.competitorChip}>
                              <Text style={bdStyles.competitorText}>{c}</Text>
                            </View>
                          ))}
                        </View>
                      )}

                      {opp.differentiation && (
                        <Text style={bdStyles.diffText}>
                          <Text style={{ fontWeight: '600' }}>Differentiate: </Text>
                          {opp.differentiation}
                        </Text>
                      )}

                      <View style={bdStyles.priorityRow}>
                        <View style={bdStyles.priorityItem}>
                          <Text style={bdStyles.priorityLabel}>Likelihood</Text>
                          {renderPriorityDots(opp.priority_score?.likelihood || 0)}
                        </View>
                        <View style={bdStyles.priorityItem}>
                          <Text style={bdStyles.priorityLabel}>Speed</Text>
                          {renderPriorityDots(opp.priority_score?.speed || 0)}
                        </View>
                        <View style={bdStyles.priorityItem}>
                          <Text style={bdStyles.priorityLabel}>Value</Text>
                          {renderPriorityDots(opp.priority_score?.strategic_value || 0)}
                        </View>
                      </View>
                    </View>
                  ))}
                </View>
              )}

              {/* Recommended Actions (selectable) */}
              {storedInsights.recommended_next_actions?.length > 0 && (
                <View style={bdStyles.card}>
                  <Text style={bdStyles.cardLabel}>RECOMMENDED ACTIONS</Text>
                  <Text style={bdStyles.selectHint}>Select actions to push to your Actions list</Text>
                  {storedInsights.recommended_next_actions.map((action: any, i: number) => (
                    <TouchableOpacity key={i} style={bdStyles.actionRow} onPress={() => toggleAction(i)}>
                      <View style={[bdStyles.checkbox, selectedActions.has(i) && bdStyles.checkboxActive]}>
                        {selectedActions.has(i) && <Ionicons name="checkmark" size={12} color={colors.white} />}
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={bdStyles.actionTitle}>{typeof action === 'string' ? action : action.title}</Text>
                        {typeof action !== 'string' && action.details ? (
                          <Text style={bdStyles.actionDetails}>{action.details}</Text>
                        ) : null}
                      </View>
                    </TouchableOpacity>
                  ))}
                  {selectedActions.size > 0 && (
                    <TouchableOpacity
                      style={bdStyles.pushBtn}
                      onPress={handlePushActions}
                      disabled={pushingActions}
                    >
                      {pushingActions ? (
                        <ActivityIndicator size="small" color={colors.white} />
                      ) : (
                        <>
                          <Ionicons name="arrow-forward" size={14} color={colors.white} />
                          <Text style={bdStyles.pushBtnText}>
                            Push {selectedActions.size} Action{selectedActions.size > 1 ? 's' : ''} to List
                          </Text>
                        </>
                      )}
                    </TouchableOpacity>
                  )}
                </View>
              )}

              {/* Regenerate / Build Upon buttons */}
              {hasProfile && !analyzing && (
                <View style={bdStyles.btnRow}>
                  <TouchableOpacity style={bdStyles.secondaryBtn} onPress={() => handleAnalyze('regenerate')}>
                    <Ionicons name="refresh" size={14} color={colors.primary} />
                    <Text style={bdStyles.secondaryBtnText}>Regenerate</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={bdStyles.secondaryBtn} onPress={() => handleAnalyze('build')}>
                    <Ionicons name="layers" size={14} color={colors.primary} />
                    <Text style={bdStyles.secondaryBtnText}>Build Upon</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}

          {storedInsights && !insightsExpanded && (
            <TouchableOpacity style={bdStyles.collapsedPreview} onPress={() => setInsightsExpanded(true)}>
              <Text style={bdStyles.collapsedText}>
                {storedInsights.opportunity_summary?.length || 0} opportunities, {storedInsights.recommended_next_actions?.length || 0} actions identified
              </Text>
              <Text style={bdStyles.tapToExpand}>Tap to expand</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* NBAs */}
        {nbas && nbas.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Next Best Actions</Text>
            <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary, fontStyle: 'italic', marginBottom: spacing.sm }}>
              Select actions to push to your Actions list
            </Text>
            {nbas.map((n: any) => (
              <NbaCard
                key={n._id}
                actionType={n.actionType}
                title={n.title}
                description={n.description}
                score={n.score}
                engine={n.engine}
                reasoning={n.reasoning}
                selectable
                selected={selectedNbaIds.has(n._id)}
                onToggle={() => toggleNbaId(n._id)}
                onExecute={() => executeNba({ id: n._id })}
                onDismiss={() => dismissNba({ id: n._id })}
              />
            ))}
            {selectedNbaIds.size > 0 && (
              <TouchableOpacity
                style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: colors.primary, paddingVertical: 10, borderRadius: radius.md, marginTop: spacing.sm }}
                onPress={handlePushNbas}
                disabled={pushingActions}
              >
                {pushingActions ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <>
                    <Ionicons name="arrow-forward" size={14} color={colors.white} />
                    <Text style={{ color: colors.white, fontWeight: '600', fontSize: fontSize.sm }}>
                      Push {selectedNbaIds.size} Action{selectedNbaIds.size > 1 ? 's' : ''} to List
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Contacts */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Contacts ({contacts?.length || 0})</Text>
          {contacts?.map((c) => (
            <TouchableOpacity key={c._id} style={styles.listItem} onPress={() => navigation.navigate('ContactDetail', { id: c._id })}>
              <Text style={styles.listItemText}>{c.firstName} {c.lastName}</Text>
              {c.title && <Text style={styles.listItemSub}>{c.title}</Text>}
            </TouchableOpacity>
          ))}
        </View>

        {/* Opportunities */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Opportunities ({opportunities?.length || 0})</Text>
          {opportunities?.map((o) => (
            <TouchableOpacity key={o._id} style={styles.listItem} onPress={() => navigation.navigate('OpportunityDetail', { id: o._id })}>
              <View style={{ flex: 1 }}>
                <Text style={styles.listItemText}>{o.title}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 2 }}>
                  {o.stageName && <Text style={[styles.listItemSub, { color: colors.primary }]}>{o.stageName}</Text>}
                  {o.value != null && (
                    <Text style={[styles.listItemSub, { color: colors.success, fontWeight: '600' }]}>
                      ${o.value.toLocaleString()}
                    </Text>
                  )}
                </View>
              </View>
              <View style={[styles.statusDot, { backgroundColor: o.status === 'won' ? colors.success : o.status === 'lost' ? colors.danger : colors.warning }]} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Timeline */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Timeline ({interactions?.length || 0})</Text>
          {interactions?.map((i) => (
            <View key={i._id} style={styles.timelineItem}>
              <View style={[styles.timelineDot, { backgroundColor: i.type === 'note' ? colors.primary : colors.accent }]} />
              <View style={{ flex: 1 }}>
                <Text style={styles.timelineType}>{i.type.toUpperCase()}</Text>
                {i.subject && <Text style={styles.timelineSubject}>{i.subject}</Text>}
                {i.body && <Text style={styles.timelineBody} numberOfLines={2}>{i.body}</Text>}
                <Text style={styles.timelineDate}>{new Date(i.date).toLocaleDateString()}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions ({tasks?.length || 0})</Text>
          {tasks?.map((t) => (
            <View key={t._id} style={styles.listItem}>
              <View style={[styles.statusDot, { backgroundColor: t.status === 'done' ? colors.success : colors.warning }]} />
              <View style={{ flex: 1 }}>
                <Text style={styles.listItemText}>{t.title}</Text>
                {t.dueDate && <Text style={styles.listItemSub}>Due: {new Date(t.dueDate).toLocaleDateString()}</Text>}
              </View>
            </View>
          ))}
        </View>
        <View style={{ height: 40 }} />
      </ScrollView>

      <FormModal
        visible={showEdit}
        title="Edit Company"
        fields={[
          { key: 'name', label: 'Name', required: true },
          { key: 'domain', label: 'Website' },
          { key: 'industry', label: 'Industry' },
          { key: 'email', label: 'Email' },
          { key: 'phone', label: 'Phone' },
          { key: 'notes', label: 'Notes', type: 'multiline' },
        ]}
        initialValues={{
          name: company.name || '',
          domain: company.domain || '',
          industry: company.industry || '',
          email: company.email || '',
          phone: company.phone || '',
          notes: company.notes || '',
        }}
        onClose={() => setShowEdit(false)}
        onSubmit={async (vals) => {
          await updateCompany({
            id,
            name: vals.name || undefined,
            domain: vals.domain || undefined,
            industry: vals.industry || undefined,
            email: vals.email || undefined,
            phone: vals.phone || undefined,
            notes: vals.notes || undefined,
            segmentId: editSegmentId || undefined,
          });
          setShowEdit(false);
        }}
        renderExtra={() => (
          <View style={{ marginBottom: 8 }}>
            <Text style={{ fontSize: 14, fontWeight: '500', color: colors.textPrimary, marginBottom: 6 }}>
              Market Segment
            </Text>
            <SegmentPicker
              value={editSegmentId ?? company.segmentId}
              valuePath={editSegmentPath ?? company.segmentPath}
              onChange={(segId: any) => {
                setEditSegmentId(segId);
                if (segId && allSegments) {
                  // Build path from allSegments
                  const path: string[] = [];
                  let cur = allSegments.find((s: any) => s._id === segId);
                  while (cur) {
                    path.unshift(cur.name);
                    cur = cur.parentId ? allSegments.find((s: any) => s._id === cur!.parentId) : undefined;
                  }
                  setEditSegmentPath(path.join(' > '));
                } else {
                  setEditSegmentPath(undefined);
                }
              }}
            />
          </View>
        )}
      />

      <FormModal
        visible={showAddNote}
        title="Add Note"
        fields={[
          { key: 'subject', label: 'Subject' },
          { key: 'body', label: 'Note', type: 'multiline', required: true },
        ]}
        onClose={() => setShowAddNote(false)}
        onSubmit={async (vals) => {
          await createInteraction({
            type: 'note',
            subject: vals.subject || undefined,
            body: vals.body,
            companyId: id,
          });
          setShowAddNote(false);
        }}
      />

      <ActionFormModal
        visible={showAddAction}
        onClose={() => setShowAddAction(false)}
        preLinkedType="company"
        preLinkedId={id}
        preLinkedLabel={`Company: ${company.name}`}
      />

      <ContextualEntry
        visible={showContext}
        onClose={() => setShowContext(false)}
        entryType="company"
        entryId={id}
        entityContext={JSON.stringify({ name: company.name, industry: company.industry, domain: company.domain, notes: company.notes?.slice(0, 300), companyRoleNotes: (company as any).companyRoleNotes?.slice(0, 200) })}
      />
    </SafeAreaView>
  );
}

function InfoChip({ icon, text }: { icon: string; text: string }) {
  return (
    <View style={styles.chip}>
      <Ionicons name={icon as any} size={14} color={colors.textSecondary} />
      <Text style={styles.chipText} numberOfLines={1}>{text}</Text>
    </View>
  );
}

function QuickBtn({ icon, label, onPress }: { icon: string; label: string; onPress: () => void }) {
  return (
    <TouchableOpacity style={styles.quickBtn} onPress={onPress}>
      <View style={styles.quickBtnIcon}>
        <Ionicons name={icon as any} size={20} color={colors.primary} />
      </View>
      <Text style={styles.quickBtnLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  navBar: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.sm,
  },
  navActions: { flexDirection: 'row', gap: spacing.md },
  navBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.white,
    justifyContent: 'center', alignItems: 'center', ...shadow.sm,
  },
  scroll: { paddingHorizontal: spacing.lg },
  heroCard: {
    backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.xl,
    alignItems: 'center', ...shadow.md,
  },
  heroIcon: {
    width: 64, height: 64, borderRadius: 16, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center',
  },
  heroInitial: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.primary },
  heroName: { fontSize: fontSize.xl, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.md },
  heroSub: { fontSize: fontSize.md, color: colors.textSecondary, marginTop: spacing.xs },
  segmentRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.sm,
    backgroundColor: colors.primaryLight, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8,
  },
  segmentPathText: { fontSize: 13, color: colors.primary, fontWeight: '500' },
  infoRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg, justifyContent: 'center' },
  chip: {
    flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.bg,
    paddingHorizontal: spacing.sm, paddingVertical: 4, borderRadius: radius.sm,
  },
  chipText: { fontSize: fontSize.xs, color: colors.textSecondary, maxWidth: 120 },
  quickActions: {
    flexDirection: 'row', justifyContent: 'space-around', marginVertical: spacing.lg,
  },
  quickBtn: { alignItems: 'center', gap: spacing.xs },
  quickBtnIcon: {
    width: 48, height: 48, borderRadius: radius.lg, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center',
  },
  quickBtnLabel: { fontSize: fontSize.xs, color: colors.textSecondary, fontWeight: '500' },
  section: { marginTop: spacing.lg },
  sectionTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  listItem: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    padding: spacing.md, borderRadius: radius.md, marginBottom: spacing.sm, ...shadow.sm,
  },
  listItemText: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  listItemSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  timelineItem: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md,
    paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  timelineDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  timelineType: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary, letterSpacing: 0.5 },
  timelineSubject: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  timelineBody: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  timelineDate: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginRight: spacing.sm, marginTop: 6 },
});

const bdStyles = StyleSheet.create({
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4,
  },
  timestamp: {
    fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: spacing.sm,
  },
  analyzingBox: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, padding: spacing.md, borderRadius: radius.md, ...shadow.sm,
  },
  analyzingText: {
    fontSize: fontSize.sm, color: colors.accent, fontStyle: 'italic', flex: 1,
  },
  emptyState: { marginTop: spacing.xs },
  generateBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8,
    backgroundColor: colors.accent, paddingVertical: 12, borderRadius: radius.md,
  },
  generateBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.md },
  noProfile: { fontSize: fontSize.sm, color: colors.textTertiary, fontStyle: 'italic' },
  reportContainer: { marginTop: spacing.sm },
  card: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md,
    marginBottom: spacing.sm, ...shadow.sm,
  },
  cardLabel: {
    fontSize: 11, fontWeight: '700', color: colors.textTertiary, letterSpacing: 0.8,
    marginBottom: spacing.sm,
  },
  insightRow: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 6,
  },
  insightText: { fontSize: fontSize.sm, color: colors.textSecondary, flex: 1 },
  oppCard: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md,
    marginBottom: spacing.sm, ...shadow.sm, borderLeftWidth: 3, borderLeftColor: colors.primary,
  },
  oppHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 },
  oppRank: {
    width: 22, height: 22, borderRadius: 11, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  oppRankText: { fontSize: 11, fontWeight: '700', color: colors.white },
  oppTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary, flex: 1 },
  oppDesc: { fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: 8, lineHeight: 18 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 4 },
  metaLabel: { fontSize: 11, fontWeight: '600', color: colors.textTertiary },
  metaValue: { fontSize: 12, color: colors.textSecondary, flex: 1 },
  stakeholders: {
    flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 4,
    marginTop: 4, marginBottom: 4,
  },
  stakeholderChip: {
    backgroundColor: colors.primaryLight, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4,
  },
  stakeholderText: { fontSize: 10, color: colors.primary, fontWeight: '500' },
  entryRow: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginTop: 6,
    backgroundColor: '#f0fdf4', padding: 8, borderRadius: 6,
  },
  entryText: { fontSize: 12, color: colors.success, flex: 1 },
  compCtx: {
    marginTop: 8, padding: 8, backgroundColor: colors.bg, borderRadius: 6,
  },
  compTitle: { fontSize: 11, fontWeight: '600', color: colors.textTertiary, marginBottom: 4 },
  competitorChip: {
    backgroundColor: '#fef3c7', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4,
  },
  competitorText: { fontSize: 10, color: '#92400e', fontWeight: '500' },
  diffText: { fontSize: 12, color: colors.textSecondary },
  priorityRow: {
    flexDirection: 'row', justifyContent: 'space-around', marginTop: 10,
    paddingTop: 8, borderTopWidth: 1, borderTopColor: colors.borderLight,
  },
  priorityItem: { alignItems: 'center', gap: 3 },
  priorityLabel: { fontSize: 10, color: colors.textTertiary, fontWeight: '500' },
  selectHint: {
    fontSize: fontSize.xs, color: colors.textTertiary, fontStyle: 'italic', marginBottom: spacing.sm,
  },
  actionRow: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 10, paddingVertical: 8,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  checkbox: {
    width: 20, height: 20, borderRadius: 4, borderWidth: 2, borderColor: colors.borderLight,
    justifyContent: 'center', alignItems: 'center', marginTop: 1,
  },
  checkboxActive: {
    backgroundColor: colors.primary, borderColor: colors.primary,
  },
  actionTitle: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500' },
  actionDetails: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  actionText: { fontSize: fontSize.sm, color: colors.textPrimary, flex: 1, lineHeight: 20 },
  pushBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: colors.primary, paddingVertical: 10, borderRadius: radius.md, marginTop: spacing.md,
  },
  pushBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.sm },
  btnRow: {
    flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm,
  },
  secondaryBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: colors.white, paddingVertical: 10, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.primary, ...shadow.sm,
  },
  secondaryBtnText: { color: colors.primary, fontWeight: '600', fontSize: fontSize.sm },
  collapsedPreview: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md,
    ...shadow.sm, alignItems: 'center',
  },
  collapsedText: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500' },
  tapToExpand: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
});
