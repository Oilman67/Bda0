import React, { useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator, Alert, Share } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

type GroupBy = 'stage' | 'owner';
type RangeField = 'created' | 'close';

export default function ReportsScreen() {
  const defaultPipeline = useQuery(api.pipelines.getDefaultPipeline);
  const [groupBy, setGroupBy] = useState<GroupBy>('stage');
  const [rangeField, setRangeField] = useState<RangeField>('created');
  const [selectedCurrency, setSelectedCurrency] = useState<string | undefined>();
  const [showShares, setShowShares] = useState(false);

  const pipelineId = defaultPipeline?._id;
  const report = useQuery(
    api.reports.pipelineReport,
    pipelineId
      ? { pipelineId, groupBy, rangeField, currency: selectedCurrency }
      : 'skip'
  );

  const shares = useQuery(api.reports.listShares);
  const createShareLink = useMutation(api.reports.createShareLink);
  const revokeShare = useMutation(api.reports.revokeShare);

  const maxVal = useMemo(() => {
    if (!report?.breakdown) return 1;
    return Math.max(...report.breakdown.map(b => b.value), 1);
  }, [report]);

  const formatValue = (val: number) => {
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val}`;
  };

  const handleShare = async () => {
    try {
      const { token } = await createShareLink({
        pipelineId: pipelineId || undefined,
        groupBy,
        rangeField,
        currency: selectedCurrency,
      });
      await Share.share({
        message: `Pipeline Report\nShare token: ${token}\n(Valid for 7 days)`,
      });
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create share link');
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Pipeline Report</Text>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={() => setShowShares(!showShares)} style={styles.headerBtn}>
            <Ionicons name="list" size={18} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleShare} style={styles.shareBtn}>
            <Ionicons name="share-outline" size={16} color={colors.white} />
            <Text style={styles.shareBtnText}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        <View style={styles.controlGroup}>
          <Text style={styles.controlLabel}>Group by</Text>
          <View style={styles.segmented}>
            {(['stage', 'owner'] as GroupBy[]).map((g) => (
              <TouchableOpacity
                key={g}
                style={[styles.seg, groupBy === g && styles.segActive]}
                onPress={() => setGroupBy(g)}
              >
                <Text style={[styles.segText, groupBy === g && styles.segTextActive]}>
                  {g.charAt(0).toUpperCase() + g.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
        <View style={styles.controlGroup}>
          <Text style={styles.controlLabel}>Date field</Text>
          <View style={styles.segmented}>
            {(['created', 'close'] as RangeField[]).map((r) => (
              <TouchableOpacity
                key={r}
                style={[styles.seg, rangeField === r && styles.segActive]}
                onPress={() => setRangeField(r)}
              >
                <Text style={[styles.segText, rangeField === r && styles.segTextActive]}>
                  {r.charAt(0).toUpperCase() + r.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </View>

      {/* Share links panel */}
      {showShares && shares && shares.length > 0 && (
        <View style={styles.sharesPanel}>
          <Text style={styles.sharesPanelTitle}>Active Share Links</Text>
          {shares.map((s) => (
            <View key={s._id} style={styles.shareRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.shareToken} numberOfLines={1}>...{s.token.slice(-8)}</Text>
                <Text style={styles.shareExpiry}>
                  Expires: {new Date(s.expiresAt).toLocaleDateString()}
                  {s.lastAccessedAt ? ` | Last viewed: ${new Date(s.lastAccessedAt).toLocaleDateString()}` : ''}
                </Text>
              </View>
              <TouchableOpacity onPress={() => revokeShare({ id: s._id })}>
                <Ionicons name="trash-outline" size={16} color={colors.danger} />
              </TouchableOpacity>
            </View>
          ))}
        </View>
      )}

      {!report ? (
        <View style={styles.loading}><ActivityIndicator color={colors.primary} /></View>
      ) : report.hasMixedCurrency ? (
        <View style={styles.errorCard}>
          <Ionicons name="warning" size={32} color={colors.warning} />
          <Text style={styles.errorTitle}>Mixed Currencies</Text>
          <Text style={styles.errorText}>
            Your pipeline has opportunities in: {report.currencies.join(', ')}
          </Text>
          <Text style={styles.errorHint}>Select a currency to view the report:</Text>
          <View style={styles.currencyRow}>
            {report.currencies.map((c) => (
              <TouchableOpacity
                key={c}
                style={styles.currencyBtn}
                onPress={() => setSelectedCurrency(c)}
              >
                <Text style={styles.currencyBtnText}>{c}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.reportBody}>
          {/* Currency filter indicator */}
          {selectedCurrency && (
            <TouchableOpacity
              style={styles.currencyFilter}
              onPress={() => setSelectedCurrency(undefined)}
            >
              <Text style={styles.currencyFilterText}>Filtered: {selectedCurrency}</Text>
              <Ionicons name="close-circle" size={16} color={colors.primary} />
            </TouchableOpacity>
          )}

          {/* Summary Cards */}
          <View style={styles.summaryRow}>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryValue}>{report.totalCount}</Text>
              <Text style={styles.summaryLabel}>Opportunities</Text>
            </View>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryValue}>{formatValue(report.totalValue)}</Text>
              <Text style={styles.summaryLabel}>Total Value</Text>
            </View>
            {report.currencies.length > 0 && (
              <View style={styles.summaryCard}>
                <Text style={styles.summaryValue}>{report.currencies.join(', ')}</Text>
                <Text style={styles.summaryLabel}>Currency</Text>
              </View>
            )}
          </View>

          {/* Breakdown */}
          <View style={styles.breakdownSection}>
            <Text style={styles.sectionTitle}>
              By {groupBy === 'stage' ? 'Stage' : 'Owner'}
            </Text>
            {report.breakdown.length === 0 ? (
              <View style={styles.emptyBreakdown}>
                <Ionicons name="bar-chart-outline" size={32} color={colors.textTertiary} />
                <Text style={styles.emptyText}>No data for selected filters</Text>
              </View>
            ) : (
              report.breakdown.map((b, idx) => (
                <View key={idx} style={styles.breakdownRow}>
                  <View style={styles.breakdownHeader}>
                    {b.color && <View style={[styles.breakdownDot, { backgroundColor: b.color }]} />}
                    <Text style={styles.breakdownLabel}>{b.label}</Text>
                    <Text style={styles.breakdownCount}>{b.count} opportunities</Text>
                  </View>
                  <View style={styles.barBg}>
                    <View style={[
                      styles.bar,
                      {
                        width: `${Math.max((b.value / maxVal) * 100, 2)}%`,
                        backgroundColor: b.color || colors.primary,
                      }
                    ]} />
                  </View>
                  <Text style={styles.breakdownValue}>{formatValue(b.value)}</Text>
                </View>
              ))
            )}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  headerActions: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  headerBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.white,
    justifyContent: 'center', alignItems: 'center', ...shadow.sm,
  },
  shareBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md,
  },
  shareBtnText: { color: colors.white, fontSize: fontSize.sm, fontWeight: '600' },
  controls: {
    paddingHorizontal: spacing.lg, paddingBottom: spacing.md,
    flexDirection: 'row', gap: spacing.lg,
  },
  controlGroup: { flex: 1 },
  controlLabel: { fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: spacing.xs, fontWeight: '600' },
  segmented: {
    flexDirection: 'row', backgroundColor: colors.white, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  seg: { flex: 1, paddingVertical: spacing.sm, alignItems: 'center' },
  segActive: { backgroundColor: colors.primary },
  segText: { fontSize: fontSize.sm, color: colors.textSecondary },
  segTextActive: { color: colors.white, fontWeight: '600' },
  sharesPanel: {
    marginHorizontal: spacing.lg, backgroundColor: colors.white, borderRadius: radius.lg,
    padding: spacing.md, marginBottom: spacing.md, ...shadow.sm,
  },
  sharesPanelTitle: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.sm },
  shareRow: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  shareToken: { fontSize: fontSize.sm, fontWeight: '500', color: colors.textPrimary, fontFamily: 'monospace' },
  shareExpiry: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 2 },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorCard: {
    margin: spacing.lg, backgroundColor: colors.warningLight, borderRadius: radius.lg,
    padding: spacing.xl, alignItems: 'center',
  },
  errorTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.warning, marginTop: spacing.md },
  errorText: { fontSize: fontSize.sm, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.sm },
  errorHint: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500', marginTop: spacing.lg },
  currencyRow: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.md },
  currencyBtn: {
    backgroundColor: colors.white, paddingHorizontal: spacing.xl, paddingVertical: spacing.md,
    borderRadius: radius.md, ...shadow.sm,
  },
  currencyBtnText: { fontSize: fontSize.md, fontWeight: '700', color: colors.primary },
  currencyFilter: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.xs,
    alignSelf: 'flex-start', backgroundColor: colors.primaryLight,
    paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.full,
    marginBottom: spacing.md,
  },
  currencyFilterText: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '500' },
  reportBody: { padding: spacing.lg },
  summaryRow: { flexDirection: 'row', gap: spacing.md, marginBottom: spacing.xl },
  summaryCard: {
    flex: 1, backgroundColor: colors.white, borderRadius: radius.lg,
    padding: spacing.md, alignItems: 'center', ...shadow.sm,
  },
  summaryValue: { fontSize: fontSize.lg, fontWeight: '800', color: colors.textPrimary },
  summaryLabel: { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: spacing.xs },
  breakdownSection: {},
  sectionTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.lg },
  emptyBreakdown: { alignItems: 'center', paddingVertical: spacing.xxxl },
  emptyText: { fontSize: fontSize.md, color: colors.textTertiary, marginTop: spacing.md },
  breakdownRow: { marginBottom: spacing.lg },
  breakdownHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs },
  breakdownDot: { width: 10, height: 10, borderRadius: 5, marginRight: spacing.sm },
  breakdownLabel: { flex: 1, fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  breakdownCount: { fontSize: fontSize.sm, color: colors.textTertiary },
  barBg: { height: 8, backgroundColor: colors.borderLight, borderRadius: 4, overflow: 'hidden' },
  bar: { height: 8, borderRadius: 4 },
  breakdownValue: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, marginTop: 4 },
});
