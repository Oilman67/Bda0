import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert, Linking, Modal, TextInput, FlatList, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import FormModal from '../components/FormModal';
import ActionFormModal from '../components/ActionFormModal';
import NbaCard from '../components/NbaCard';
import ContextualEntry from '../components/ContextualEntry';

export default function ContactDetailScreen({ route, navigation }: any) {
  const { id } = route.params;
  const contact = useQuery(api.contacts.get, { id });
  const companies = useQuery(api.companies.list);
  const companyDetail = useQuery(api.companies.get, contact?.companyId ? { id: contact.companyId } : "skip");
  const opportunities = useQuery(api.opportunities.listByCompany,
    contact?.companyId ? { companyId: contact.companyId } : "skip"
  );
  const interactions = useQuery(api.interactions.listByEntity, { entityType: 'contact', entityId: id });
  const tasks = useQuery(api.actions.listByEntity, { entityType: 'contact', entityId: id });
  const nbas = useQuery(api.nba.getNextActions, { entryType: 'contact', entryId: id });
  const assessments = useQuery(api.relationshipIntelligence.listByContact, { contactId: id });
  const orgSettings = useQuery(api.orgSettings.get);
  const updateContact = useMutation(api.contacts.update);
  const removeContact = useMutation(api.contacts.remove);
  const createInteraction = useMutation(api.interactions.create);
  const dismissNba = useMutation(api.nbaActions.dismiss);
  const executeNba = useMutation(api.nbaActions.execute);
  const requestRefresh = useMutation(api.nbaActions.requestRefresh);
  const saveAssessment = useMutation(api.relationshipIntelligence.save);
  const createTask = useMutation(api.actions.create);
  const [showEdit, setShowEdit] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showAddAction, setShowAddAction] = useState(false);
  const [showContext, setShowContext] = useState(false);
  const [showCompanyPicker, setShowCompanyPicker] = useState(false);
  const [companySearch, setCompanySearch] = useState('');
  const [riAnalyzing, setRiAnalyzing] = useState<string | null>(null);
  const [riExpanded, setRiExpanded] = useState<string | null>(null);
  const [selectedNbas, setSelectedNbas] = useState<Set<string>>(new Set());
  const [pushingActions, setPushingActions] = useState(false);

  const toggleNba = (id: string) => {
    setSelectedNbas((prev: Set<string>) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handlePushNbas = async () => {
    if (!nbas || selectedNbas.size === 0) return;
    setPushingActions(true);
    try {
      let count = 0;
      for (const nbaId of selectedNbas) {
        const nba = nbas.find((n: any) => n._id === nbaId);
        if (nba) {
          await createTask({
            title: nba.title,
            description: nba.description || `From NBA for ${contact?.firstName} ${contact?.lastName}`,
            contactId: id,
            companyId: contact?.companyId || undefined,
            priority: nba.score >= 70 ? 'high' : nba.score >= 40 ? 'medium' : 'low',
          });
          await executeNba({ id: nba._id });
          count++;
        }
      }
      setSelectedNbas(new Set());
      Alert.alert('Actions Created', `${count} action${count > 1 ? 's' : ''} pushed to your Actions list.`);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create actions.');
    } finally {
      setPushingActions(false);
    }
  };

  // Relationship Intelligence helpers
  const stanceLabel = (v: number) => ({ [-2]: 'Opposed', [-1]: 'Skeptical', 0: 'Neutral', 1: 'Supportive', 2: 'Champion' }[v] || 'Neutral');
  const influenceLabel = (v: number) => ({ 1: 'Low', 2: 'Medium', 3: 'High' }[v] || 'Medium');
  const impactColor = (score: number) => {
    if (score >= 4) return '#16a34a';
    if (score >= 1) return '#65a30d';
    if (score === 0) return '#9ca3af';
    if (score >= -3) return '#ea580c';
    return '#dc2626';
  };
  const stanceColor = (v: number) => {
    if (v >= 2) return '#16a34a';
    if (v >= 1) return '#65a30d';
    if (v === 0) return '#9ca3af';
    if (v >= -1) return '#ea580c';
    return '#dc2626';
  };

  const handleAnalyzeRelationship = async (opp: any) => {
    if (!contact) return;
    setRiAnalyzing(opp._id);
    try {
      const contextBundle = {
        contact: {
          firstName: contact.firstName,
          lastName: contact.lastName,
          email: contact.email,
          phone: contact.phone,
          linkedin: contact.linkedin,
          jobTitle: contact.title,
        },
        opportunity: {
          title: opp.title,
          reference: opp.reference,
          status: opp.status,
          value: opp.value,
          probability: opp.probability,
          closeDate: opp.closeDate ? new Date(opp.closeDate).toISOString() : undefined,
          notes: opp.notes,
        },
        company: companyDetail ? {
          name: companyDetail.name,
          domain: companyDetail.domain,
          industry: companyDetail.industry,
          size: companyDetail.size,
          insightsReport: companyDetail.insightsReport ? companyDetail.insightsReport.substring(0, 2000) : undefined,
        } : undefined,
        interactions: (interactions || []).slice(0, 20).map((i: any) => ({
          type: i.type,
          subject: i.subject,
          body: i.body?.substring(0, 300),
          date: new Date(i.date).toISOString(),
        })),
        orgContext: orgSettings ? {
          companyName: orgSettings.companyName,
          url: orgSettings.companyUrl,
          interests: orgSettings.interests,
        } : undefined,
      };

      const systemPrompt = `You are a Relationship Intelligence Analyst for B2B business development.

Assess this contact in the context of the given opportunity.

Classify across these dimensions:
- stance: -2 (Opposed), -1 (Skeptical), 0 (Neutral), +1 (Supportive), +2 (Champion)
- role: Decision Maker | Economic Buyer | Technical Evaluator | Operational Owner | Influencer | Gatekeeper | Blocker
- influence: 1 (Low), 2 (Medium), 3 (High)
- confidence: Low | Medium | High
- relationshipStrength: Weak | Medium | Strong

Rules:
- Base conclusions on behavior and evidence, not title alone
- Use interaction history as primary evidence
- Infer role from both job title and behavior
- Keep reasoning brief and concrete
- Recommend one next relationship move
- Flag risks if this person could materially harm the deal
- Flag opportunities if this person could become a stronger ally

Return ONLY valid JSON:
{
  "stance": { "value": number, "label": "string" },
  "role": { "value": "string", "confidence": "string" },
  "influence": { "value": number, "label": "string" },
  "confidence": "Low|Medium|High",
  "relationshipStrength": "Weak|Medium|Strong",
  "aiReasoning": "string",
  "signals": ["string"],
  "risks": [{ "type": "string", "severity": "Low|Medium|High", "details": "string" }],
  "opportunities": [{ "type": "string", "details": "string" }],
  "nextRelationshipMove": { "title": "string (max 8 words)", "details": "string", "priority": "High|Medium|Low", "suggestedDeadline": "YYYY-MM-DD" }
}`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 90000);

      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: `Analyze this contact-opportunity relationship. Return ONLY valid JSON.\n\n${JSON.stringify(contextBundle)}` },
          ],
        }),
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      const completion = data.completion || '';
      const cleaned = completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
      const result = JSON.parse(cleaned);

      await saveAssessment({
        opportunityId: opp._id,
        contactId: id,
        stance: Number(result.stance?.value) || 0,
        role: result.role?.value || 'Influencer',
        roleConfidence: result.role?.confidence || result.confidence || 'Medium',
        influence: Number(result.influence?.value) || 2,
        confidence: result.confidence || 'Medium',
        relationshipStrength: result.relationshipStrength || 'Medium',
        aiReasoning: typeof result.aiReasoning === 'string' ? result.aiReasoning : JSON.stringify(result.aiReasoning || ''),
        signals: JSON.stringify(result.signals || []),
        risks: JSON.stringify(result.risks || []),
        opportunities: JSON.stringify(result.opportunities || []),
        nextMoveTitle: result.nextRelationshipMove?.title || '',
        nextMoveDetails: result.nextRelationshipMove?.details || '',
        nextMovePriority: result.nextRelationshipMove?.priority || 'Medium',
        nextMoveDeadline: result.nextRelationshipMove?.suggestedDeadline || '',
      });

      setRiExpanded(opp._id);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        Alert.alert('Analysis Failed', err.message || 'Could not analyze relationship.');
      }
    } finally {
      setRiAnalyzing(null);
    }
  };

  const handleOverride = (assessment: any, field: string) => {
    if (field === 'stance') {
      Alert.alert('Adjust Stance', 'Select the correct stance:', [
        { text: 'Opposed (-2)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: -2, role: assessment.role, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Skeptical (-1)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: -1, role: assessment.role, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Neutral (0)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: 0, role: assessment.role, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Supportive (+1)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: 1, role: assessment.role, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Champion (+2)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: 2, role: assessment.role, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Cancel', style: 'cancel' },
      ]);
    } else if (field === 'influence') {
      Alert.alert('Adjust Influence', 'Select the correct influence level:', [
        { text: 'Low (1)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: assessment.stance, role: assessment.role, influence: 1, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Medium (2)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: assessment.stance, role: assessment.role, influence: 2, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'High (3)', onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: assessment.stance, role: assessment.role, influence: 3, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }) },
        { text: 'Cancel', style: 'cancel' },
      ]);
    } else if (field === 'role') {
      Alert.alert('Adjust Role', 'Select the correct role:', [
        ...['Decision Maker', 'Economic Buyer', 'Technical Evaluator', 'Operational Owner', 'Influencer', 'Gatekeeper', 'Blocker'].map(r => ({
          text: r,
          onPress: () => saveAssessment({ opportunityId: assessment.opportunityId, contactId: id, stance: assessment.stance, role: r, influence: assessment.influence, confidence: assessment.confidence, relationshipStrength: assessment.relationshipStrength, isUserOverride: true }),
        })),
        { text: 'Cancel', style: 'cancel' },
      ]);
    }
  };

  // Auto-link company when returning from AddCompany
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      if (!contact?.pendingCompanyName || contact?.companyId) return;
      const match = companies?.find(
        (c: any) => c.name.toLowerCase() === contact.pendingCompanyName!.toLowerCase()
      );
      if (match) {
        updateContact({ id, companyId: match._id });
      }
    });
    return unsubscribe;
  }, [navigation, contact?.pendingCompanyName, contact?.companyId, companies, id, updateContact]);

  const linkCompany = useCallback((companyId: any) => {
    updateContact({ id, companyId });
    setShowCompanyPicker(false);
    setCompanySearch('');
  }, [id, updateContact]);

  const filteredCompanies = companies?.filter((c: any) =>
    !companySearch || c.name.toLowerCase().includes(companySearch.toLowerCase())
  ) || [];

  if (!contact) return (
    <SafeAreaView style={styles.container}>
      <View style={styles.loading}><Text>Loading...</Text></View>
    </SafeAreaView>
  );

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.navActions}>
          <TouchableOpacity onPress={() => setShowEdit(true)} style={styles.navBtn}>
            <Ionicons name="pencil" size={18} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Alert.alert('Delete?', 'This cannot be undone.', [
            { text: 'Cancel' },
            { text: 'Delete', style: 'destructive', onPress: () => { removeContact({ id }); navigation.goBack(); } },
          ])} style={styles.navBtn}>
            <Ionicons name="trash" size={18} color={colors.danger} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.heroCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>{contact.firstName[0]}{contact.lastName[0]}</Text>
          </View>
          <Text style={styles.heroName}>{contact.firstName} {contact.lastName}</Text>
          {contact.title && <Text style={styles.heroSub}>{contact.title}</Text>}
          {contact.companyName && (
            <TouchableOpacity
              onPress={() => contact.companyId && navigation.navigate('CompanyDetail', { id: contact.companyId })}
            >
              <Text style={styles.companyChip}>{contact.companyName}</Text>
            </TouchableOpacity>
          )}
          {!contact.companyId && contact.pendingCompanyName && (
            <View style={styles.pendingCompanySection}>
              <View style={styles.pendingCompanyBadge}>
                <Ionicons name="warning" size={14} color={colors.warning} />
                <Text style={styles.pendingCompanyText}>{contact.pendingCompanyName}</Text>
              </View>
              <View style={styles.pendingCompanyActions}>
                <TouchableOpacity
                  style={styles.pendingCreateBtn}
                  onPress={() => navigation.navigate('AddCompany', { initialName: contact.pendingCompanyName })}
                >
                  <Ionicons name="add-circle" size={16} color={colors.white} />
                  <Text style={styles.pendingCreateBtnText}>Create Company</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.pendingLinkBtn}
                  onPress={() => setShowCompanyPicker(true)}
                >
                  <Ionicons name="link" size={16} color={colors.primary} />
                  <Text style={styles.pendingLinkBtnText}>Link Existing</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
          <View style={styles.infoRow}>
            {contact.email && (
              <View style={styles.chip}><Ionicons name="mail" size={14} color={colors.textSecondary} /><Text style={styles.chipText}>{contact.email}</Text></View>
            )}
            {contact.phone && (
              <View style={styles.chip}><Ionicons name="call" size={14} color={colors.textSecondary} /><Text style={styles.chipText}>{contact.phone}</Text></View>
            )}
            {contact.linkedin && (
              <TouchableOpacity
                style={styles.chip}
                onPress={() => {
                  let url = contact.linkedin || '';
                  if (!url.startsWith('http')) url = 'https://' + url;
                  Linking.openURL(url).catch(() => {});
                }}
              >
                <Ionicons name="logo-linkedin" size={14} color="#0A66C2" />
                <Text style={[styles.chipText, { color: '#0A66C2' }]}>LinkedIn</Text>
              </TouchableOpacity>
            )}
            {!contact.linkedin && (
              <TouchableOpacity
                style={[styles.chip, { backgroundColor: '#0A66C2' }]}
                onPress={() => {
                  const name = `${contact.firstName} ${contact.lastName}`.trim();
                  const url = `https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(name)}&origin=GLOBAL_SEARCH_HEADER`;
                  Linking.openURL(url);
                }}
              >
                <Ionicons name="search" size={14} color="#fff" />
                <Text style={[styles.chipText, { color: '#fff' }]}>Find on LinkedIn</Text>
              </TouchableOpacity>
            )}
          </View>
          {contact.lastInteraction && (
            <View style={styles.lastInteraction}>
              <Ionicons name="time" size={14} color={colors.textTertiary} />
              <Text style={styles.lastInteractionText}>
                Last {contact.lastInteraction.type}: {new Date(contact.lastInteraction.date).toLocaleDateString()}
                {contact.lastInteraction.subject ? ` — ${contact.lastInteraction.subject}` : ''}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.quickActions}>
          <TouchableOpacity style={styles.quickBtn} onPress={() => setShowAddNote(true)}>
            <View style={styles.quickBtnIcon}><Ionicons name="chatbubble" size={20} color={colors.primary} /></View>
            <Text style={styles.quickBtnLabel}>Note</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.quickBtn} onPress={() => setShowAddAction(true)}>
            <View style={styles.quickBtnIcon}><Ionicons name="checkmark-circle" size={20} color={colors.primary} /></View>
            <Text style={styles.quickBtnLabel}>Action</Text>
          </TouchableOpacity>
          {!contact.companyId && (
            <TouchableOpacity style={styles.quickBtn} onPress={() => setShowCompanyPicker(true)}>
              <View style={[styles.quickBtnIcon, { backgroundColor: colors.warningLight }]}>
                <Ionicons name="business" size={20} color={colors.warning} />
              </View>
              <Text style={styles.quickBtnLabel}>Company</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={styles.quickBtn} onPress={() => setShowContext(true)}>
            <View style={styles.quickBtnIcon}><Ionicons name="sparkles" size={20} color={colors.primary} /></View>
            <Text style={styles.quickBtnLabel}>Context</Text>
          </TouchableOpacity>
        </View>

        {/* Relationship Intelligence Section */}
        {(opportunities && opportunities.length > 0) && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Relationship Intelligence</Text>
            {opportunities.map((opp: any) => {
              const a = assessments?.find((x: any) => x.opportunityId === opp._id);
              const impact = a ? a.stance * a.influence : 0;
              const isExpanded = riExpanded === opp._id;
              const isAnalyzing = riAnalyzing === opp._id;
              const signals: string[] = a?.signals ? (() => { try { return JSON.parse(a.signals); } catch { return []; } })() : [];
              const risks: any[] = a?.risks ? (() => { try { return JSON.parse(a.risks); } catch { return []; } })() : [];
              const opps: any[] = a?.opportunities ? (() => { try { return JSON.parse(a.opportunities); } catch { return []; } })() : [];

              return (
                <View key={opp._id} style={riStyles.card}>
                  <TouchableOpacity
                    style={riStyles.cardHeader}
                    onPress={() => a && setRiExpanded(isExpanded ? null : opp._id)}
                    activeOpacity={a ? 0.7 : 1}
                  >
                    {a ? (
                      <View style={[riStyles.impactBadge, { backgroundColor: impactColor(impact) }]}>
                        <Text style={riStyles.impactText}>{impact > 0 ? `+${impact}` : impact}</Text>
                      </View>
                    ) : (
                      <View style={[riStyles.impactBadge, { backgroundColor: colors.borderLight }]}>
                        <Ionicons name="help" size={14} color={colors.textTertiary} />
                      </View>
                    )}
                    <View style={{ flex: 1 }}>
                      <Text style={riStyles.oppTitle} numberOfLines={1}>{opp.title}</Text>
                      <Text style={riStyles.oppStatus}>{opp.status?.replace(/_/g, ' ')}</Text>
                    </View>
                    {isAnalyzing ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : a ? (
                      <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
                    ) : (
                      <TouchableOpacity style={riStyles.analyzeBtn} onPress={() => handleAnalyzeRelationship(opp)}>
                        <Ionicons name="sparkles" size={14} color={colors.white} />
                        <Text style={riStyles.analyzeBtnText}>Analyze</Text>
                      </TouchableOpacity>
                    )}
                  </TouchableOpacity>

                  {a && (
                    <View style={riStyles.badgeRow}>
                      <TouchableOpacity onPress={() => handleOverride(a, 'stance')} style={[riStyles.badge, { borderColor: stanceColor(a.stance) }]}>
                        <Text style={[riStyles.badgeText, { color: stanceColor(a.stance) }]}>{stanceLabel(a.stance)}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleOverride(a, 'role')} style={[riStyles.badge, { borderColor: colors.primary }]}>
                        <Text style={[riStyles.badgeText, { color: colors.primary }]}>{a.role}</Text>
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleOverride(a, 'influence')} style={[riStyles.badge, { borderColor: colors.accent }]}>
                        <Text style={[riStyles.badgeText, { color: colors.accent }]}>{influenceLabel(a.influence)} Inf.</Text>
                      </TouchableOpacity>
                      <View style={[riStyles.badge, { borderColor: colors.textTertiary }]}>
                        <Text style={[riStyles.badgeText, { color: colors.textTertiary }]}>{a.relationshipStrength}</Text>
                      </View>
                    </View>
                  )}

                  {a && isExpanded && (
                    <View style={riStyles.expandedContent}>
                      {a.isUserOverride && (
                        <View style={riStyles.overrideBanner}>
                          <Ionicons name="person" size={12} color={colors.primary} />
                          <Text style={riStyles.overrideText}>User override applied</Text>
                        </View>
                      )}
                      {a.aiReasoning && (
                        <View style={riStyles.detailBlock}>
                          <Text style={riStyles.detailLabel}>AI Reasoning</Text>
                          <Text style={riStyles.detailText}>{a.aiReasoning}</Text>
                        </View>
                      )}
                      {signals.length > 0 && (
                        <View style={riStyles.detailBlock}>
                          <Text style={riStyles.detailLabel}>Signals</Text>
                          {signals.map((s: string, i: number) => (
                            <View key={i} style={riStyles.signalRow}>
                              <Text style={riStyles.signalDot}>•</Text>
                              <Text style={riStyles.signalText}>{s}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {risks.length > 0 && (
                        <View style={riStyles.detailBlock}>
                          <Text style={riStyles.detailLabel}>Risks</Text>
                          {risks.map((r: any, i: number) => (
                            <View key={i} style={riStyles.riskItem}>
                              <View style={[riStyles.severityBadge, { backgroundColor: r.severity === 'High' ? '#fecaca' : r.severity === 'Medium' ? '#fed7aa' : '#d1fae5' }]}>
                                <Text style={{ fontSize: 10, fontWeight: '600', color: r.severity === 'High' ? '#dc2626' : r.severity === 'Medium' ? '#ea580c' : '#16a34a' }}>{r.severity}</Text>
                              </View>
                              <Text style={riStyles.riskText}>{r.type}{r.details ? `: ${r.details}` : ''}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {opps.length > 0 && (
                        <View style={riStyles.detailBlock}>
                          <Text style={riStyles.detailLabel}>Opportunities</Text>
                          {opps.map((o: any, i: number) => (
                            <View key={i} style={riStyles.signalRow}>
                              <Text style={riStyles.signalDot}>★</Text>
                              <Text style={riStyles.signalText}>{o.type}{o.details ? `: ${o.details}` : ''}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {a.nextMoveTitle && (
                        <View style={[riStyles.detailBlock, riStyles.nextMoveCard]}>
                          <Text style={riStyles.detailLabel}>Next Move</Text>
                          <Text style={riStyles.nextMoveTitle}>{a.nextMoveTitle}</Text>
                          {a.nextMoveDetails && <Text style={riStyles.detailText}>{a.nextMoveDetails}</Text>}
                          <View style={{ flexDirection: 'row', gap: spacing.sm, marginTop: spacing.xs }}>
                            {a.nextMovePriority && (
                              <View style={[riStyles.severityBadge, { backgroundColor: a.nextMovePriority === 'High' ? '#fecaca' : '#e0e7ff' }]}>
                                <Text style={{ fontSize: 10, fontWeight: '600', color: a.nextMovePriority === 'High' ? '#dc2626' : '#4f46e5' }}>{a.nextMovePriority}</Text>
                              </View>
                            )}
                            {a.nextMoveDeadline && <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary }}>{a.nextMoveDeadline}</Text>}
                          </View>
                        </View>
                      )}
                      {a.lastAnalyzedAt && (
                        <Text style={riStyles.analyzedAt}>Analyzed {new Date(a.lastAnalyzedAt).toLocaleDateString()}</Text>
                      )}
                      <TouchableOpacity style={riStyles.reanalyzeBtn} onPress={() => handleAnalyzeRelationship(opp)}>
                        <Ionicons name="refresh" size={14} color={colors.primary} />
                        <Text style={riStyles.reanalyzeBtnText}>Re-analyze</Text>
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              );
            })}
            {(!opportunities || opportunities.length === 0) && (
              <Text style={{ fontSize: fontSize.sm, color: colors.textTertiary, textAlign: 'center', paddingVertical: spacing.lg }}>
                Link this contact to a company with opportunities to analyze relationships.
              </Text>
            )}
          </View>
        )}

        {nbas && nbas.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Next Best Actions</Text>
            <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary, fontStyle: 'italic', marginBottom: spacing.sm }}>
              Select actions to push to your Actions list
            </Text>
            {nbas.map((n: any) => (
              <NbaCard
                key={n._id}
                actionType={n.actionType}
                title={n.title}
                description={n.description}
                score={n.score}
                engine={n.engine}
                reasoning={n.reasoning}
                selectable
                selected={selectedNbas.has(n._id)}
                onToggle={() => toggleNba(n._id)}
                onExecute={() => executeNba({ id: n._id })}
                onDismiss={() => dismissNba({ id: n._id })}
              />
            ))}
            {selectedNbas.size > 0 && (
              <TouchableOpacity
                style={styles.pushBtn}
                onPress={handlePushNbas}
                disabled={pushingActions}
              >
                {pushingActions ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <>
                    <Ionicons name="arrow-forward" size={14} color={colors.white} />
                    <Text style={styles.pushBtnText}>
                      Push {selectedNbas.size} Action{selectedNbas.size > 1 ? 's' : ''} to List
                    </Text>
                  </>
                )}
              </TouchableOpacity>
            )}
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Timeline ({interactions?.length || 0})</Text>
          {interactions?.map((i) => (
            <View key={i._id} style={styles.timelineItem}>
              <View style={[styles.timelineDot, { backgroundColor: colors.primary }]} />
              <View style={{ flex: 1 }}>
                {i.subject && <Text style={styles.tlSubject}>{i.subject}</Text>}
                {i.body && <Text style={styles.tlBody} numberOfLines={2}>{i.body}</Text>}
                <Text style={styles.tlDate}>{new Date(i.date).toLocaleDateString()}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions ({tasks?.length || 0})</Text>
          {tasks?.map((t) => (
            <View key={t._id} style={styles.taskItem}>
              <View style={[styles.statusDot, { backgroundColor: t.status === 'done' ? colors.success : colors.warning }]} />
              <Text style={styles.taskText}>{t.title}</Text>
            </View>
          ))}
        </View>
        <View style={{ height: 40 }} />
      </ScrollView>

      <FormModal
        visible={showEdit}
        title="Edit Contact"
        fields={[
          { key: 'firstName', label: 'First Name', required: true },
          { key: 'lastName', label: 'Last Name', required: true },
          { key: 'email', label: 'Email' },
          { key: 'phone', label: 'Phone' },
          { key: 'linkedin', label: 'LinkedIn Profile', action: {
            icon: 'logo-linkedin',
            label: 'Search',
            onPress: (vals: Record<string, string>) => {
              const name = `${vals.firstName || ''} ${vals.lastName || ''}`.trim();
              if (!name) return;
              const url = `https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(name)}&origin=GLOBAL_SEARCH_HEADER`;
              Linking.openURL(url);
            },
          }},
          { key: 'title', label: 'Title' },
          { key: 'notes', label: 'Notes', type: 'multiline' },
        ]}
        initialValues={{
          firstName: contact.firstName,
          lastName: contact.lastName,
          email: contact.email || '',
          phone: contact.phone || '',
          linkedin: contact.linkedin || '',
          title: contact.title || '',
          notes: contact.notes || '',
        }}
        onClose={() => setShowEdit(false)}
        onSubmit={async (vals) => {
          await updateContact({
            id,
            firstName: vals.firstName || undefined,
            lastName: vals.lastName || undefined,
            email: vals.email || undefined,
            phone: vals.phone || undefined,
            linkedin: vals.linkedin || undefined,
            title: vals.title || undefined,
            notes: vals.notes || undefined,
          });
          setShowEdit(false);
        }}
      />

      <FormModal
        visible={showAddNote}
        title="Add Note"
        fields={[
          { key: 'subject', label: 'Subject' },
          { key: 'body', label: 'Note', type: 'multiline', required: true },
        ]}
        onClose={() => setShowAddNote(false)}
        onSubmit={async (vals) => {
          await createInteraction({
            type: 'note',
            subject: vals.subject || undefined,
            body: vals.body,
            contactId: id,
          });
          setShowAddNote(false);
        }}
      />

      <ActionFormModal
        visible={showAddAction}
        onClose={() => setShowAddAction(false)}
        preLinkedType="contact"
        preLinkedId={id}
        preLinkedLabel={`Contact: ${contact.firstName} ${contact.lastName}`}
      />

      <ContextualEntry
        visible={showContext}
        onClose={() => setShowContext(false)}
        entryType="contact"
        entryId={id}
        entityContext={JSON.stringify({
          name: `${contact.firstName} ${contact.lastName}`,
          title: contact.title,
          company: contact.companyName,
          notes: contact.notes?.slice(0, 300),
        })}
      />

      {/* Company Picker Modal */}
      <Modal visible={showCompanyPicker} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.container}>
          <View style={styles.pickerHeader}>
            <TouchableOpacity onPress={() => { setShowCompanyPicker(false); setCompanySearch(''); }}>
              <Text style={{ fontSize: fontSize.md, color: colors.primary }}>Cancel</Text>
            </TouchableOpacity>
            <Text style={{ fontSize: fontSize.lg, fontWeight: '700' }}>Link Company</Text>
            <View style={{ width: 50 }} />
          </View>
          <View style={styles.pickerSearchBox}>
            <Ionicons name="search" size={18} color={colors.textTertiary} />
            <TextInput
              style={styles.pickerSearchInput}
              placeholder="Search companies..."
              value={companySearch}
              onChangeText={setCompanySearch}
              autoFocus
            />
          </View>
          <FlatList
            data={filteredCompanies}
            keyExtractor={(item: any) => item._id}
            contentContainerStyle={{ paddingHorizontal: spacing.lg }}
            renderItem={({ item }: any) => (
              <TouchableOpacity
                style={styles.pickerItem}
                onPress={() => linkCompany(item._id)}
              >
                <View style={styles.pickerItemIcon}>
                  <Ionicons name="business" size={18} color={colors.primary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.pickerItemName}>{item.name}</Text>
                  {item.industry && <Text style={styles.pickerItemSub}>{item.industry}</Text>}
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
              </TouchableOpacity>
            )}
            ListEmptyComponent={
              <View style={{ padding: spacing.xl, alignItems: 'center' }}>
                <Text style={{ color: colors.textTertiary }}>No companies found</Text>
                <TouchableOpacity
                  style={[styles.pendingCreateBtn, { marginTop: spacing.md }]}
                  onPress={() => {
                    setShowCompanyPicker(false);
                    setCompanySearch('');
                    navigation.navigate('AddCompany', { initialName: contact.pendingCompanyName || companySearch || '' });
                  }}
                >
                  <Ionicons name="add-circle" size={16} color={colors.white} />
                  <Text style={styles.pendingCreateBtnText}>Create New Company</Text>
                </TouchableOpacity>
              </View>
            }
          />
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  navActions: { flexDirection: 'row', gap: spacing.md },
  navBtn: { width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.white, justifyContent: 'center', alignItems: 'center', ...shadow.sm },
  scroll: { paddingHorizontal: spacing.lg },
  heroCard: { backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.xl, alignItems: 'center', ...shadow.md },
  avatar: { width: 64, height: 64, borderRadius: radius.full, backgroundColor: colors.accentLight, justifyContent: 'center', alignItems: 'center' },
  avatarText: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.accent },
  heroName: { fontSize: fontSize.xl, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.md },
  heroSub: { fontSize: fontSize.md, color: colors.textSecondary, marginTop: spacing.xs },
  companyChip: { fontSize: fontSize.sm, color: colors.primary, backgroundColor: colors.primaryLight, paddingHorizontal: spacing.md, paddingVertical: 2, borderRadius: radius.sm, marginTop: spacing.sm },
  pendingCompanySection: { alignItems: 'center', marginTop: spacing.sm, gap: spacing.sm },
  pendingCompanyBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.warningLight, paddingHorizontal: spacing.md, paddingVertical: 4, borderRadius: radius.sm },
  pendingCompanyText: { fontSize: fontSize.sm, color: colors.warning, fontWeight: '600' },
  pendingCompanyActions: { flexDirection: 'row', gap: spacing.sm },
  pendingCreateBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.sm },
  pendingCreateBtnText: { fontSize: fontSize.xs, color: colors.white, fontWeight: '600' },
  pendingLinkBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.primaryLight, paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.sm },
  pendingLinkBtnText: { fontSize: fontSize.xs, color: colors.primary, fontWeight: '600' },
  infoRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: spacing.lg, justifyContent: 'center' },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.bg, paddingHorizontal: spacing.sm, paddingVertical: 4, borderRadius: radius.sm },
  chipText: { fontSize: fontSize.xs, color: colors.textSecondary },
  lastInteraction: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    marginTop: spacing.md, paddingTop: spacing.sm,
    borderTopWidth: 1, borderTopColor: colors.borderLight,
  },
  lastInteractionText: { fontSize: fontSize.xs, color: colors.textTertiary, flex: 1 },
  quickActions: { flexDirection: 'row', justifyContent: 'center', gap: spacing.xxxl, marginVertical: spacing.lg },
  quickBtn: { alignItems: 'center', gap: spacing.xs },
  quickBtnIcon: { width: 48, height: 48, borderRadius: radius.lg, backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center' },
  quickBtnLabel: { fontSize: fontSize.xs, color: colors.textSecondary, fontWeight: '500' },
  section: { marginTop: spacing.lg },
  sectionTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  timelineItem: { flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  timelineDot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  tlSubject: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  tlBody: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  tlDate: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  taskItem: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.sm },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  taskText: { fontSize: fontSize.md, color: colors.textPrimary },
  pickerHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  pickerSearchBox: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, margin: spacing.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, backgroundColor: colors.white, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.borderLight },
  pickerSearchInput: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary },
  pickerItem: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  pickerItemIcon: { width: 36, height: 36, borderRadius: radius.md, backgroundColor: colors.primaryLight, justifyContent: 'center', alignItems: 'center' },
  pickerItemName: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  pickerItemSub: { fontSize: fontSize.xs, color: colors.textSecondary, marginTop: 2 },
  pushBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: colors.primary, paddingVertical: 10, borderRadius: radius.md, marginTop: spacing.sm,
  },
  pushBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.sm },
});

const riStyles = StyleSheet.create({
  card: { backgroundColor: colors.white, borderRadius: radius.lg, marginBottom: spacing.md, ...shadow.sm, overflow: 'hidden' },
  cardHeader: { flexDirection: 'row', alignItems: 'center', padding: spacing.md, gap: spacing.sm },
  impactBadge: { width: 32, height: 32, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center' },
  impactText: { fontSize: fontSize.xs, fontWeight: '800', color: colors.white },
  oppTitle: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary },
  oppStatus: { fontSize: fontSize.xs, color: colors.textTertiary, textTransform: 'capitalize' },
  analyzeBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.sm },
  analyzeBtnText: { fontSize: fontSize.xs, color: colors.white, fontWeight: '600' },
  badgeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, paddingHorizontal: spacing.md, paddingBottom: spacing.md },
  badge: { borderWidth: 1, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 2 },
  badgeText: { fontSize: 11, fontWeight: '600' },
  expandedContent: { padding: spacing.md, paddingTop: 0, borderTopWidth: 1, borderTopColor: colors.borderLight },
  overrideBanner: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.primaryLight, padding: spacing.xs, borderRadius: radius.sm, marginBottom: spacing.sm },
  overrideText: { fontSize: fontSize.xs, color: colors.primary, fontWeight: '500' },
  detailBlock: { marginTop: spacing.sm },
  detailLabel: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textSecondary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  detailText: { fontSize: fontSize.sm, color: colors.textPrimary, lineHeight: 20 },
  signalRow: { flexDirection: 'row', gap: 6, marginTop: 2 },
  signalDot: { fontSize: fontSize.sm, color: colors.textTertiary },
  signalText: { fontSize: fontSize.sm, color: colors.textPrimary, flex: 1 },
  riskItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginTop: 4 },
  severityBadge: { paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4 },
  riskText: { fontSize: fontSize.sm, color: colors.textPrimary, flex: 1 },
  nextMoveCard: { backgroundColor: colors.primaryLight, padding: spacing.sm, borderRadius: radius.sm },
  nextMoveTitle: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary },
  analyzedAt: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: spacing.sm, textAlign: 'center' },
  reanalyzeBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4, marginTop: spacing.sm, paddingVertical: spacing.sm },
  reanalyzeBtnText: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '600' },
});