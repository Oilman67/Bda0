import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert, TextInput, ActivityIndicator, Share } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { useAuthActions } from '@convex-dev/auth/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import { SECTOR_NAMES, COMPANY_ROLES } from '../lib/taxonomyData';

interface GeoZone {
  region: string;
  country?: string;
  stateProvince?: string;
  city?: string;
}

function formatZone(z: GeoZone): string {
  const parts = [z.region];
  if (z.country) parts.push(z.country);
  if (z.stateProvince) parts.push(z.stateProvince);
  if (z.city) parts.push(z.city);
  return parts.join(' > ');
}

const CLIENT_TYPES = [
  'Large Enterprise (Fortune 500)',
  'Mid-market (500-5000 employees)',
  'Small / Growth (<500)',
  'Government / Public Sector',
  'Non-profit / Institutional',
  'Publicly Traded',
  'Privately Owned',
  'Private Equity Backed',
];

const REGIONS = [
  'North America', 'Latin America', 'Western Europe', 'Eastern Europe',
  'Middle East', 'Africa', 'South Asia', 'East Asia', 'Southeast Asia', 'Oceania',
];

export default function SettingsScreen() {
  const orgInfo = useQuery(api.onboarding.getMyOrg);
  const orgSettings = useQuery(api.orgSettings.get);
  const upsertSettings = useMutation(api.orgSettings.upsert);
  const saveBusinessCtx = useMutation(api.orgSettings.saveBusinessContext);
  const createTeamAccount = useMutation(api.onboarding.createTeamAccount);
  const joinTeamAccount = useMutation(api.onboarding.joinTeamAccount);
  const { signOut } = useAuthActions();

  const [companyName, setCompanyName] = useState('');
  const [companyUrl, setCompanyUrl] = useState('');
  const [interests, setInterests] = useState('');
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState(false);

  // Team account state
  const [teamCodeInput, setTeamCodeInput] = useState('');
  const [teamActionLoading, setTeamActionLoading] = useState(false);

  // Business context state
  const [showContext, setShowContext] = useState(false);
  const [targetSectors, setTargetSectors] = useState<string[]>([]);
  const [clientTypes, setClientTypes] = useState<string[]>([]);
  const [geoZones, setGeoZones] = useState<GeoZone[]>([]);
  const [multiPartyDeals, setMultiPartyDeals] = useState(false);
  const [companyRoles, setCompanyRoles] = useState<string[]>(['primary_target']);
  const [ctxDirty, setCtxDirty] = useState(false);
  const [ctxSaving, setCtxSaving] = useState(false);

  // Zone builder state
  const [addingZone, setAddingZone] = useState(false);
  const [zoneRegion, setZoneRegion] = useState('');
  const [zoneCountry, setZoneCountry] = useState('');
  const [zoneState, setZoneState] = useState('');
  const [zoneCity, setZoneCity] = useState('');

  useEffect(() => {
    if (orgSettings) {
      setCompanyName(orgSettings.companyName || '');
      setCompanyUrl(orgSettings.companyUrl || '');
      setInterests(orgSettings.interests || '');
      if (orgSettings.businessContext) {
        try {
          const ctx = JSON.parse(orgSettings.businessContext);
          setTargetSectors(ctx.targetSectors || []);
          setClientTypes(ctx.clientTypes || []);
          // Backward compat: convert old regions[] to geoZones[]
          if (ctx.geoZones && ctx.geoZones.length > 0) {
            setGeoZones(ctx.geoZones);
          } else if (ctx.regions && ctx.regions.length > 0) {
            setGeoZones(ctx.regions.map((r: string) => ({ region: r })));
          }
          setMultiPartyDeals(ctx.multiPartyDeals || false);
          setCompanyRoles(ctx.companyRoles || ['primary_target']);
        } catch {}
      }
    }
  }, [orgSettings]);

  const handleSaveProfile = async () => {
    if (!companyName.trim()) {
      Alert.alert('Required', 'Please enter your company name.');
      return;
    }
    if (!interests.trim()) {
      Alert.alert('Required', 'Please describe the types of opportunities or services you pursue.');
      return;
    }
    setSaving(true);
    try {
      await upsertSettings({
        companyName: companyName.trim(),
        companyUrl: companyUrl.trim() || undefined,
        interests: interests.trim(),
      });
      setDirty(false);
      Alert.alert('Saved', 'Your company profile has been updated.');
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleSaveContext = async () => {
    setCtxSaving(true);
    try {
      await saveBusinessCtx({
        businessContext: JSON.stringify({
          targetSectors,
          clientTypes,
          geoZones,
          // Keep flat regions for backward compat with LLM prompts
          regions: geoZones.map((z: GeoZone) => z.region),
          multiPartyDeals,
          companyRoles,
        }),
      });
      setCtxDirty(false);
      Alert.alert('Saved', 'Business context updated. This will improve AI classification.');
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setCtxSaving(false);
    }
  };

  const toggleArrayItem = (arr: string[], item: string, setter: (v: string[]) => void) => {
    setter(arr.includes(item) ? arr.filter(x => x !== item) : [...arr, item]);
    setCtxDirty(true);
  };

  const addBroadRegion = (region: string) => {
    // Toggle: if a broad zone for this region exists, remove it; otherwise add it
    const existing = geoZones.findIndex((z: GeoZone) => z.region === region && !z.country);
    if (existing >= 0) {
      setGeoZones(geoZones.filter((_: GeoZone, i: number) => i !== existing));
    } else {
      setGeoZones([...geoZones, { region }]);
    }
    setCtxDirty(true);
  };

  const removeZone = (index: number) => {
    setGeoZones(geoZones.filter((_: GeoZone, i: number) => i !== index));
    setCtxDirty(true);
  };

  const addSpecificZone = () => {
    if (!zoneRegion) {
      Alert.alert('Required', 'Please select a region.');
      return;
    }
    const zone: GeoZone = { region: zoneRegion };
    if (zoneCountry.trim()) zone.country = zoneCountry.trim();
    if (zoneState.trim()) zone.stateProvince = zoneState.trim();
    if (zoneCity.trim()) zone.city = zoneCity.trim();
    setGeoZones([...geoZones, zone]);
    // Reset form
    setZoneRegion('');
    setZoneCountry('');
    setZoneState('');
    setZoneCity('');
    setAddingZone(false);
    setCtxDirty(true);
  };

  const isProfileConfigured = !!orgSettings?.companyName;
  const accountType = orgInfo?.accountType || 'solo';
  const teamCode = orgInfo?.teamCode;

  const handleCreateTeam = async () => {
    setTeamActionLoading(true);
    try {
      const result = await createTeamAccount();
      await Share.share({ message: `Join my BDBuddy team with code: ${result.teamCode}` });
      Alert.alert('Team Created', `Your team code is ${result.teamCode}. Share it with your team members.`);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Unable to create team code.');
    } finally {
      setTeamActionLoading(false);
    }
  };

  const handleJoinTeam = async () => {
    const code = teamCodeInput.trim();
    if (!code) {
      Alert.alert('Required', 'Please enter a team code.');
      return;
    }
    setTeamActionLoading(true);
    try {
      await joinTeamAccount({ teamCode: code });
      setTeamCodeInput('');
      Alert.alert('Joined Team', 'You are now part of the shared team workspace.');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Unable to join team.');
    } finally {
      setTeamActionLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Settings</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        {/* Account & Team */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Account & Team</Text>
          <View style={styles.card}>
            <View style={styles.row}>
              <Ionicons name="person-circle" size={20} color={colors.textSecondary} />
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle}>{accountType === 'team' ? 'Team Account' : 'Solo Account'}</Text>
                <Text style={styles.rowSub}>
                  {accountType === 'team'
                    ? 'Shared workspace for multiple members'
                    : 'Single-user workspace with the existing solo experience'}
                </Text>
              </View>
            </View>

            {accountType === 'team' ? (
              <View style={{ padding: spacing.lg, paddingTop: 0 }}>
                <Text style={styles.profileLabel}>Team Code</Text>
                <View style={styles.teamCodeRow}>
                  <Text style={styles.teamCode}>{teamCode || 'Generating...'}</Text>
                  <TouchableOpacity
                    style={styles.teamShareBtn}
                    onPress={() => teamCode ? Share.share({ message: `Join my BDBuddy team with code: ${teamCode}` }) : undefined}
                    disabled={!teamCode}
                  >
                    <Ionicons name="share-social" size={16} color={colors.white} />
                    <Text style={styles.teamShareText}>Share</Text>
                  </TouchableOpacity>
                </View>
                <Text style={styles.profileHint}>
                  Share this code with teammates. They can use it to join your shared workspace.
                </Text>
              </View>
            ) : (
              <View style={{ padding: spacing.lg, paddingTop: 0, gap: spacing.md }}>
                <TouchableOpacity
                  style={[styles.saveProfileBtn, { marginTop: 0 }]}
                  onPress={handleCreateTeam}
                  disabled={teamActionLoading}
                >
                  {teamActionLoading ? (
                    <ActivityIndicator size="small" color={colors.white} />
                  ) : (
                    <>
                      <Ionicons name="people" size={18} color={colors.white} />
                      <Text style={styles.saveProfileText}>Create Team Code</Text>
                    </>
                  )}
                </TouchableOpacity>

                <TextInput
                  style={styles.profileInput}
                  placeholder="Enter team code to join"
                  placeholderTextColor={colors.textTertiary}
                  value={teamCodeInput}
                  onChangeText={setTeamCodeInput}
                  autoCapitalize="characters"
                />
                <TouchableOpacity
                  style={[styles.teamJoinBtn, teamActionLoading && { opacity: 0.7 }]}
                  onPress={handleJoinTeam}
                  disabled={teamActionLoading}
                >
                  <Text style={styles.teamJoinText}>Join Team with Code</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>

        {/* My Company Profile */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionLabel}>My Company Profile</Text>
            {!isProfileConfigured && (
              <View style={styles.setupBadge}>
                <Text style={styles.setupBadgeText}>Setup Required</Text>
              </View>
            )}
          </View>
          <View style={styles.card}>
            <View style={{ padding: spacing.lg }}>
              <View style={styles.profileField}>
                <Text style={styles.profileLabel}>Company Name *</Text>
                <TextInput
                  style={styles.profileInput}
                  placeholder="e.g. ACME Chemicals"
                  placeholderTextColor={colors.textTertiary}
                  value={companyName}
                  onChangeText={(t: string) => { setCompanyName(t); setDirty(true); }}
                />
              </View>
              <View style={styles.profileField}>
                <Text style={styles.profileLabel}>Company Website</Text>
                <TextInput
                  style={styles.profileInput}
                  placeholder="e.g. acmechemicals.com"
                  placeholderTextColor={colors.textTertiary}
                  value={companyUrl}
                  onChangeText={(t: string) => { setCompanyUrl(t); setDirty(true); }}
                  autoCapitalize="none"
                  keyboardType="url"
                />
              </View>
              <View style={[styles.profileField, { marginBottom: 0 }]}>
                <Text style={styles.profileLabel}>Opportunities / Services Focus *</Text>
                <TextInput
                  style={[styles.profileInput, styles.profileMultiline]}
                  placeholder="e.g. Selling janitorial cleaning products to retail and service providers"
                  placeholderTextColor={colors.textTertiary}
                  value={interests}
                  onChangeText={(t: string) => { setInterests(t); setDirty(true); }}
                  multiline
                  numberOfLines={3}
                />
              </View>
            </View>
            {dirty && (
              <TouchableOpacity
                style={styles.saveProfileBtn}
                onPress={handleSaveProfile}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <>
                    <Ionicons name="checkmark" size={18} color={colors.white} />
                    <Text style={styles.saveProfileText}>Save Profile</Text>
                  </>
                )}
              </TouchableOpacity>
            )}
          </View>
          {!isProfileConfigured && (
            <Text style={styles.profileHint}>
              Configure your company profile to enable AI-powered opportunity insights when adding new target companies.
            </Text>
          )}
        </View>

        {/* Business Context */}
        <View style={styles.section}>
          <TouchableOpacity style={styles.sectionHeader} onPress={() => setShowContext(!showContext)}>
            <Text style={styles.sectionLabel}>Business Context (AI Tuning)</Text>
            <Ionicons name={showContext ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
          </TouchableOpacity>

          {!showContext && (
            <Text style={{ fontSize: fontSize.sm, color: colors.textTertiary, marginTop: -4 }}>
              {targetSectors.length > 0
                ? `${targetSectors.length} sectors, ${clientTypes.length} client types, ${geoZones.length} zone${geoZones.length !== 1 ? 's' : ''}`
                : 'Tap to configure target industries, client types, and regions'}
            </Text>
          )}

          {showContext && (
            <View style={styles.card}>
              <View style={{ padding: spacing.lg }}>
                {/* Target Industries */}
                <Text style={styles.profileLabel}>Target Industries</Text>
                <Text style={styles.chipHint}>Select industries your clients operate in</Text>
                <View style={styles.chipWrap}>
                  {SECTOR_NAMES.map(s => (
                    <TouchableOpacity
                      key={s}
                      style={[styles.chip, targetSectors.includes(s) && styles.chipActive]}
                      onPress={() => toggleArrayItem(targetSectors, s, setTargetSectors)}
                    >
                      <Text style={[styles.chipText, targetSectors.includes(s) && styles.chipTextActive]}>{s}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Client Types */}
                <Text style={[styles.profileLabel, { marginTop: spacing.lg }]}>Client Types</Text>
                <View style={styles.chipWrap}>
                  {CLIENT_TYPES.map(t => (
                    <TouchableOpacity
                      key={t}
                      style={[styles.chip, clientTypes.includes(t) && styles.chipActive]}
                      onPress={() => toggleArrayItem(clientTypes, t, setClientTypes)}
                    >
                      <Text style={[styles.chipText, clientTypes.includes(t) && styles.chipTextActive]}>{t}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Geographic Zones */}
                <Text style={[styles.profileLabel, { marginTop: spacing.lg }]}>Geographic Zones</Text>
                <Text style={styles.chipHint}>
                  Select broad regions, then optionally narrow to specific countries, provinces, or cities.
                </Text>

                {/* Quick-add region chips */}
                <View style={styles.chipWrap}>
                  {REGIONS.map(r => {
                    const hasBroad = geoZones.some((z: GeoZone) => z.region === r && !z.country);
                    const hasAny = geoZones.some((z: GeoZone) => z.region === r);
                    return (
                      <TouchableOpacity
                        key={r}
                        style={[styles.chip, hasBroad && styles.chipActive, hasAny && !hasBroad && styles.chipPartial]}
                        onPress={() => addBroadRegion(r)}
                      >
                        <Text style={[styles.chipText, (hasBroad || hasAny) && styles.chipTextActive]}>{r}</Text>
                        {hasAny && !hasBroad && (
                          <Ionicons name="ellipsis-horizontal" size={10} color={colors.primary} style={{ marginLeft: 2 }} />
                        )}
                      </TouchableOpacity>
                    );
                  })}
                </View>

                {/* Configured zones list */}
                {geoZones.length > 0 && (
                  <View style={styles.zoneList}>
                    {geoZones.map((z: GeoZone, i: number) => (
                      <View key={i} style={styles.zoneTag}>
                        <Ionicons name="location" size={12} color={colors.primary} />
                        <Text style={styles.zoneTagText} numberOfLines={1}>{formatZone(z)}</Text>
                        <TouchableOpacity onPress={() => removeZone(i)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                          <Ionicons name="close-circle" size={16} color={colors.textTertiary} />
                        </TouchableOpacity>
                      </View>
                    ))}
                  </View>
                )}

                {/* Add specific zone */}
                {!addingZone ? (
                  <TouchableOpacity
                    style={styles.addZoneBtn}
                    onPress={() => setAddingZone(true)}
                  >
                    <Ionicons name="add-circle-outline" size={16} color={colors.primary} />
                    <Text style={styles.addZoneBtnText}>Add specific zone (country, province, city)</Text>
                  </TouchableOpacity>
                ) : (
                  <View style={styles.zoneForm}>
                    <Text style={[styles.chipHint, { marginBottom: 4 }]}>Region *</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
                      <View style={{ flexDirection: 'row', gap: 6 }}>
                        {REGIONS.map(r => (
                          <TouchableOpacity
                            key={r}
                            style={[styles.chip, zoneRegion === r && styles.chipActive, { paddingVertical: 4, paddingHorizontal: 10 }]}
                            onPress={() => setZoneRegion(r)}
                          >
                            <Text style={[styles.chipText, { fontSize: 12 }, zoneRegion === r && styles.chipTextActive]}>{r}</Text>
                          </TouchableOpacity>
                        ))}
                      </View>
                    </ScrollView>
                    <TextInput
                      style={styles.zoneInput}
                      placeholder="Country (e.g. Canada)"
                      placeholderTextColor={colors.textTertiary}
                      value={zoneCountry}
                      onChangeText={setZoneCountry}
                    />
                    <TextInput
                      style={styles.zoneInput}
                      placeholder="State / Province (e.g. Quebec) — optional"
                      placeholderTextColor={colors.textTertiary}
                      value={zoneState}
                      onChangeText={setZoneState}
                    />
                    <TextInput
                      style={styles.zoneInput}
                      placeholder="City / Metro area (e.g. Montreal) — optional"
                      placeholderTextColor={colors.textTertiary}
                      value={zoneCity}
                      onChangeText={setZoneCity}
                    />
                    <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                      <TouchableOpacity
                        style={[styles.zoneFormBtn, { backgroundColor: colors.primary, flex: 1 }]}
                        onPress={addSpecificZone}
                      >
                        <Text style={{ color: colors.white, fontWeight: '600', fontSize: 13 }}>Add Zone</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.zoneFormBtn, { backgroundColor: colors.bg, flex: 0.5 }]}
                        onPress={() => { setAddingZone(false); setZoneRegion(''); setZoneCountry(''); setZoneState(''); setZoneCity(''); }}
                      >
                        <Text style={{ color: colors.textSecondary, fontWeight: '500', fontSize: 13 }}>Cancel</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}

                {/* Multi-party deals */}
                <TouchableOpacity
                  style={[styles.toggleRow, { marginTop: spacing.lg }]}
                  onPress={() => { setMultiPartyDeals(!multiPartyDeals); setCtxDirty(true); }}
                >
                  <Ionicons
                    name={multiPartyDeals ? 'checkbox' : 'square-outline'}
                    size={22}
                    color={multiPartyDeals ? colors.primary : colors.textTertiary}
                  />
                  <View style={{ flex: 1, marginLeft: spacing.sm }}>
                    <Text style={styles.profileLabel}>Multi-party Deals</Text>
                    <Text style={styles.chipHint}>Your deals involve multiple stakeholder companies (utilities, regulators, partners, etc.)</Text>
                  </View>
                </TouchableOpacity>

                {/* Company roles */}
                {multiPartyDeals && (
                  <>
                    <Text style={[styles.profileLabel, { marginTop: spacing.lg }]}>Company Roles in Your Deals</Text>
                    <View style={styles.chipWrap}>
                      {COMPANY_ROLES.map(r => (
                        <TouchableOpacity
                          key={r.value}
                          style={[styles.chip, companyRoles.includes(r.value) && styles.chipActive]}
                          onPress={() => toggleArrayItem(companyRoles, r.value, setCompanyRoles)}
                        >
                          <Text style={[styles.chipText, companyRoles.includes(r.value) && styles.chipTextActive]}>{r.label}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </>
                )}
              </View>

              {ctxDirty && (
                <TouchableOpacity
                  style={styles.saveProfileBtn}
                  onPress={handleSaveContext}
                  disabled={ctxSaving}
                >
                  {ctxSaving ? (
                    <ActivityIndicator size="small" color={colors.white} />
                  ) : (
                    <>
                      <Ionicons name="checkmark" size={18} color={colors.white} />
                      <Text style={styles.saveProfileText}>Save Business Context</Text>
                    </>
                  )}
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>

        {/* Organization */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Organization</Text>
          <View style={styles.card}>
            <View style={styles.row}>
              <Ionicons name="business" size={20} color={colors.textSecondary} />
              <View style={styles.rowBody}>
                <Text style={styles.rowTitle}>{orgInfo?.orgName || 'Loading...'}</Text>
                <Text style={styles.rowSub}>Role: {orgInfo?.role || '-'}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Placeholders for future features */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Manage</Text>
          <View style={styles.card}>
            <SettingRow icon="people" label="Team Members" badge="Coming Soon" />
            <SettingRow icon="key" label="API Keys" badge="Coming Soon" />
            <SettingRow icon="cloud-upload" label="Import / Export" badge="Coming Soon" />
            <SettingRow icon="notifications" label="Notifications" badge="Coming Soon" />
            <SettingRow icon="card" label="Billing" badge="Coming Soon" />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionLabel}>About</Text>
          <View style={styles.card}>
            <SettingRow icon="information-circle" label="BDBuddy v1.0" />
            <SettingRow icon="shield-checkmark" label="Privacy Policy" />
            <SettingRow icon="document-text" label="Terms of Service" />
          </View>
        </View>

        <TouchableOpacity
          style={styles.signOutBtn}
          onPress={() => Alert.alert('Sign Out', 'Are you sure?', [
            { text: 'Cancel' },
            { text: 'Sign Out', style: 'destructive', onPress: () => signOut() },
          ])}
        >
          <Ionicons name="log-out" size={20} color={colors.danger} />
          <Text style={styles.signOutText}>Sign Out</Text>
        </TouchableOpacity>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

function SettingRow({ icon, label, badge }: { icon: string; label: string; badge?: string }) {
  return (
    <View style={styles.row}>
      <Ionicons name={icon as any} size={20} color={colors.textSecondary} />
      <Text style={styles.rowTitle}>{label}</Text>
      {badge && (
        <View style={styles.badge}><Text style={styles.badgeText}>{badge}</Text></View>
      )}
      <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: { paddingHorizontal: spacing.lg, paddingVertical: spacing.md },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  scroll: { padding: spacing.lg },
  section: { marginBottom: spacing.xl },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionLabel: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary, textTransform: 'uppercase', letterSpacing: 1, marginBottom: spacing.sm },
  setupBadge: { backgroundColor: colors.primaryLight, paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  setupBadgeText: { fontSize: fontSize.xs, color: colors.primary, fontWeight: '600' },
  card: { backgroundColor: colors.white, borderRadius: radius.lg, ...shadow.sm, overflow: 'hidden' },
  profileField: { marginBottom: spacing.lg },
  profileLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, marginBottom: spacing.sm },
  profileInput: { borderWidth: 1, borderColor: colors.borderLight, borderRadius: radius.sm, padding: spacing.sm, fontSize: fontSize.md, backgroundColor: colors.white },
  profileMultiline: { height: 100, textAlignVertical: 'top' },
  profileHint: { fontSize: fontSize.sm, color: colors.textTertiary, textAlign: 'center', marginTop: spacing.lg },
  saveProfileBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    padding: spacing.lg, backgroundColor: colors.primary, borderRadius: radius.lg,
    ...shadow.sm, marginTop: spacing.lg,
  },
  saveProfileText: { fontSize: fontSize.md, fontWeight: '600', color: colors.white },
  row: {
    flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  rowBody: { flex: 1 },
  rowTitle: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary },
  rowSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  badge: { backgroundColor: colors.primaryLight, paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  badgeText: { fontSize: fontSize.xs, color: colors.primary, fontWeight: '600' },
  signOutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    padding: spacing.lg, backgroundColor: colors.white, borderRadius: radius.lg,
    ...shadow.sm, marginTop: spacing.lg,
  },
  signOutText: { fontSize: fontSize.md, fontWeight: '600', color: colors.danger },
  // Business context styles
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chipHint: { fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: 8 },
  chip: {
    paddingHorizontal: 12, paddingVertical: 6, borderRadius: 16,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.bg,
  },
  chipActive: { backgroundColor: colors.primaryLight, borderColor: colors.primary },
  chipText: { fontSize: fontSize.sm, color: colors.textSecondary },
  chipTextActive: { color: colors.primary, fontWeight: '600' },
  toggleRow: { flexDirection: 'row', alignItems: 'flex-start' },
  // Zone builder styles
  chipPartial: { borderColor: colors.primary, backgroundColor: colors.bg },
  zoneList: { marginTop: 10, gap: 6 },
  zoneTag: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.primaryLight, paddingHorizontal: 10, paddingVertical: 6,
    borderRadius: 20, alignSelf: 'flex-start',
  },
  zoneTagText: { fontSize: 12, color: colors.primary, fontWeight: '500', flexShrink: 1 },
  addZoneBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10, paddingVertical: 6,
  },
  addZoneBtnText: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '500' },
  zoneForm: {
    marginTop: 10, padding: 12, backgroundColor: colors.bg,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
  },
  zoneInput: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.borderLight,
    borderRadius: radius.sm, padding: 8, fontSize: 13, color: colors.textPrimary,
    marginBottom: 6,
  },
  zoneFormBtn: {
    paddingVertical: 8, borderRadius: radius.sm, alignItems: 'center',
  },
  teamCodeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  teamCode: { flex: 1, fontSize: fontSize.lg, fontWeight: '800', color: colors.primary, letterSpacing: 2 },
  teamShareBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md,
  },
  teamShareText: { color: colors.white, fontSize: fontSize.sm, fontWeight: '700' },
  teamJoinBtn: {
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.primary,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  teamJoinText: { color: colors.primary, fontSize: fontSize.md, fontWeight: '700' },
  chipTextPartial: { color: colors.primary, fontWeight: '600' },
});