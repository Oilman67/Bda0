import React, { useState, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput, Modal, ScrollView, Alert,
  KeyboardAvoidingView, Platform, Keyboard, TouchableWithoutFeedback, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useAction } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';

type BreadcrumbItem = { _id: any; name: string; level: number };

export default function SegmentsScreen({ navigation }: any) {
  const [currentParentId, setCurrentParentId] = useState<any>(undefined);
  const [breadcrumb, setBreadcrumb] = useState<BreadcrumbItem[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [search, setSearch] = useState('');
  const [selectedParentId, setSelectedParentId] = useState<any>(null);
  const [expandedSectors, setExpandedSectors] = useState<Set<string>>(new Set());
  const [generating, setGenerating] = useState(false);

  const segments = useQuery(api.segments.getChildren, { parentId: currentParentId });
  const allSegments = useQuery(api.segments.list);
  const createSegment = useMutation(api.segments.create);
  const removeSegment = useMutation(api.segments.remove);
  const regenerateSegments = useMutation(api.segments.regenerate);
  const orgSettings = useQuery(api.orgSettings.get);
  const generateTaxonomy = useAction(api.ai.generateTaxonomy);

  // Build hierarchy for the parent picker
  const segmentTree = useMemo(() => {
    if (!allSegments) return { l1: [], l2Map: new Map() };
    const l1 = allSegments.filter((s: any) => s.level === 1).sort((a: any, b: any) => a.name.localeCompare(b.name));
    const l2Map = new Map<string, any[]>();
    const l2All = allSegments.filter((s: any) => s.level === 2).sort((a: any, b: any) => a.name.localeCompare(b.name));
    for (const s of l2All) {
      if (s.parentId) {
        const list = l2Map.get(s.parentId) || [];
        list.push(s);
        l2Map.set(s.parentId, list);
      }
    }
    return { l1, l2Map };
  }, [allSegments]);

  // Compute what level the new segment will be
  const getNewLevel = (): number => {
    if (!selectedParentId) return 1;
    const parent = allSegments?.find((s: any) => s._id === selectedParentId);
    if (!parent) return 1;
    return parent.level + 1;
  };

  const getParentPath = (): string => {
    if (!selectedParentId || !allSegments) return '';
    const parts: string[] = [];
    let cur = allSegments.find((s: any) => s._id === selectedParentId);
    while (cur) {
      parts.unshift(cur.name);
      cur = cur.parentId ? allSegments.find((s: any) => s._id === cur.parentId) : undefined;
    }
    return parts.join(' > ');
  };

  const newLevel = getNewLevel();
  const levelNames: Record<number, string> = { 1: 'Sector', 2: 'Industry', 3: 'Sub-Industry' };

  const openCreateModal = () => {
    // Default parent to current breadcrumb position
    if (breadcrumb.length > 0) {
      const last = breadcrumb[breadcrumb.length - 1];
      if (last.level < 3) {
        setSelectedParentId(last._id);
        // Auto-expand the sector so user can see context
        if (last.level === 2 && last._id) {
          const parent = allSegments?.find((s: any) => s._id === last._id);
          if (parent?.parentId) {
            setExpandedSectors(new Set([parent.parentId]));
          }
        } else if (last.level === 1) {
          setExpandedSectors(new Set([last._id]));
        }
      } else {
        setSelectedParentId(currentParentId);
      }
    } else {
      setSelectedParentId(null);
      setExpandedSectors(new Set());
    }
    setNewName('');
    setShowCreate(true);
  };

  const navigateToSegment = (seg: any) => {
    if (seg.level < 3) {
      setBreadcrumb([...breadcrumb, { _id: seg._id, name: seg.name, level: seg.level }]);
      setCurrentParentId(seg._id);
      setSearch('');
    } else {
      navigation.navigate('SegmentCompanies', { segmentId: seg._id, segmentName: seg.name });
    }
  };

  const navigateUp = (index?: number) => {
    if (index === undefined || index < 0) {
      setBreadcrumb([]);
      setCurrentParentId(undefined);
    } else {
      const target = breadcrumb[index];
      setBreadcrumb(breadcrumb.slice(0, index + 1));
      setCurrentParentId(target._id);
    }
    setSearch('');
  };

  const handleCreate = async () => {
    if (!newName.trim()) return;
    const level = getNewLevel();
    if (level > 3) {
      Alert.alert('Cannot create', 'Maximum segment depth is 3 levels (Sector > Industry > Sub-Industry).');
      return;
    }
    await createSegment({
      name: newName.trim(),
      level,
      parentId: selectedParentId || undefined,
    });
    setNewName('');
    setShowCreate(false);
  };

  const handleDelete = (seg: any) => {
    const isLeaf = seg.level === 3;
    const hasChildren = (seg.childCount ?? 0) > 0;
    const message = isLeaf
      ? `Delete "${seg.name}"?`
      : hasChildren
        ? `Delete "${seg.name}" and all its sub-segments?`
        : `Delete "${seg.name}"?`;

    Alert.alert('Delete Segment', message, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: () => removeSegment({ id: seg._id }),
      },
    ]);
  };

  // Search across all segments
  const searchResults = useMemo(() => {
    if (!search.trim() || !allSegments) return null;
    const q = search.toLowerCase();
    return allSegments.filter((s: any) => s.name.toLowerCase().includes(q));
  }, [search, allSegments]);

  const displayData = searchResults || segments || [];
  const currentLevel = breadcrumb.length + 1;
  const levelLabels: Record<number, string> = { 1: 'Sectors', 2: 'Industries', 3: 'Sub-Industries' };

  const getSegmentColor = (seg: any): string => {
    if (seg.color) return seg.color;
    if (seg.parentId && allSegments) {
      let parent: any = allSegments.find((s: any) => s._id === seg.parentId);
      while (parent?.parentId) {
        parent = allSegments.find((s: any) => s._id === parent.parentId);
      }
      if (parent?.color) return parent.color;
    }
    return colors.primary;
  };

  // Build full path for search results
  const getFullPath = (seg: any): string => {
    if (!allSegments) return seg.name;
    const path: string[] = [seg.name];
    let current = seg;
    while (current.parentId) {
      const parent = allSegments.find((s: any) => s._id === current.parentId);
      if (parent) {
        path.unshift(parent.name);
        current = parent;
      } else break;
    }
    return path.join(' > ');
  };

  const toggleSectorExpand = (sectorId: string) => {
    setExpandedSectors(prev => {
      const next = new Set(prev);
      if (next.has(sectorId)) next.delete(sectorId);
      else next.add(sectorId);
      return next;
    });
  };

  const handleGenerateTaxonomy = async () => {
    if (!orgSettings?.companyName) {
      Alert.alert('Profile Required', 'Please configure your company profile in Settings first.');
      return;
    }

    Alert.alert(
      'Generate Taxonomy',
      'This will analyze your business and create a personalized segment taxonomy. Existing segments will be replaced.\n\nCompanies will need to be re-classified.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Generate',
          onPress: async () => {
            setGenerating(true);
            try {
              const result = await generateTaxonomy({
                companyName: orgSettings.companyName,
                companyUrl: orgSettings.companyUrl,
                interests: orgSettings.interests,
              });
              if (result.segments && result.segments.length > 0) {
                await regenerateSegments({
                  taxonomy: result.segments.map((s: any) => ({
                    sector: s.sector,
                    sectorColor: s.sectorColor,
                    subSectors: s.subSectors.map((sub: any) => ({
                      name: sub.name,
                      niches: sub.niches,
                    })),
                  })),
                });
                // Reset navigation
                setBreadcrumb([]);
                setCurrentParentId(undefined);
                Alert.alert('Done', `Generated ${result.segments.length} sectors with ${result.confidence} confidence.`);
              }
            } catch (e: any) {
              Alert.alert('Error', e.message);
            } finally {
              setGenerating(false);
            }
          },
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
        <View style={{ flex: 1 }}>
          {/* Header */}
          <View style={styles.header}>
            <View>
              <Text style={styles.title}>Segments</Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              {generating ? (
                <View style={[styles.addBtn, { backgroundColor: colors.primaryLight, width: 'auto', paddingHorizontal: 12 }]}>
                  <ActivityIndicator size="small" color={colors.primary} />
                  <Text style={{ fontSize: fontSize.xs, color: colors.primary, marginLeft: 4 }}>Generating...</Text>
                </View>
              ) : (
                <TouchableOpacity
                  style={[styles.addBtn, { backgroundColor: colors.primaryLight, width: 'auto', paddingHorizontal: 12 }]}
                  onPress={handleGenerateTaxonomy}
                >
                  <Ionicons name="sparkles" size={16} color={colors.primary} />
                  <Text style={{ fontSize: fontSize.xs, fontWeight: '600', color: colors.primary, marginLeft: 4 }}>Generate</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity style={styles.addBtn} onPress={openCreateModal}>
                <Ionicons name="add" size={22} color={colors.white} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Search */}
          <View style={styles.searchWrap}>
            <Ionicons name="search" size={18} color={colors.textTertiary} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search all segments..."
              placeholderTextColor={colors.textTertiary}
              value={search}
              onChangeText={setSearch}
              returnKeyType="search"
              blurOnSubmit
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch('')}>
                <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
              </TouchableOpacity>
            )}
          </View>

          {/* Breadcrumb */}
          {!searchResults && breadcrumb.length > 0 && (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.breadcrumbRow}>
              <TouchableOpacity onPress={() => navigateUp(-1)} style={styles.breadcrumbItem}>
                <Ionicons name="home" size={14} color={colors.primary} />
                <Text style={styles.breadcrumbText}>All</Text>
              </TouchableOpacity>
              {breadcrumb.map((item, idx) => (
                <View key={item._id} style={styles.breadcrumbItem}>
                  <Ionicons name="chevron-forward" size={12} color={colors.textTertiary} />
                  <TouchableOpacity onPress={() => idx < breadcrumb.length - 1 ? navigateUp(idx) : null}>
                    <Text style={[
                      styles.breadcrumbText,
                      idx === breadcrumb.length - 1 && styles.breadcrumbActive,
                    ]}>{item.name}</Text>
                  </TouchableOpacity>
                </View>
              ))}
            </ScrollView>
          )}

          {/* Level label */}
          {!searchResults && (
            <Text style={styles.levelLabel}>
              {levelLabels[currentLevel] || 'Segments'}
              {segments ? ` (${segments.length})` : ''}
            </Text>
          )}
          {searchResults && (
            <Text style={styles.levelLabel}>
              Search results ({searchResults.length})
            </Text>
          )}

          {/* Segment list */}
          <FlatList
            data={displayData}
            keyExtractor={(item: any) => item._id}
            contentContainerStyle={styles.listContent}
            keyboardShouldPersistTaps="handled"
            keyboardDismissMode="on-drag"
            renderItem={({ item }: any) => {
              const segColor = getSegmentColor(item);
              const isLeaf = searchResults ? item.level === 3 : currentLevel === 3;
              return (
                <TouchableOpacity
                  style={styles.card}
                  onPress={() => {
                    if (searchResults) {
                      if (item.level === 3) {
                        navigation.navigate('SegmentCompanies', { segmentId: item._id, segmentName: item.name });
                      } else {
                        const path: BreadcrumbItem[] = [];
                        let cur = item;
                        while (cur.parentId && allSegments) {
                          const parent = allSegments.find((s: any) => s._id === cur.parentId);
                          if (parent) {
                            path.unshift({ _id: parent._id, name: parent.name, level: parent.level });
                            cur = parent;
                          } else break;
                        }
                        path.push({ _id: item._id, name: item.name, level: item.level });
                        setBreadcrumb(path);
                        setCurrentParentId(item._id);
                        setSearch('');
                      }
                    } else {
                      navigateToSegment(item);
                    }
                  }}
                  activeOpacity={0.7}
                >
                  <View style={[styles.colorBar, { backgroundColor: segColor }]} />
                  <View style={styles.cardBody}>
                    <View style={styles.cardTop}>
                      <Text style={styles.cardName}>{item.name}</Text>
                      {!isLeaf && (
                        <View style={styles.badge}>
                          <Text style={styles.badgeText}>
                            {item.childCount ?? '?'} sub
                          </Text>
                        </View>
                      )}
                    </View>
                    {searchResults && (
                      <Text style={styles.cardPath}>{getFullPath(item)}</Text>
                    )}
                    {item.companyCount > 0 && (
                      <Text style={styles.cardMeta}>
                        {item.companyCount} {item.companyCount === 1 ? 'company' : 'companies'}
                      </Text>
                    )}
                    {item.description && (
                      <Text style={styles.cardDesc} numberOfLines={1}>{item.description}</Text>
                    )}
                  </View>
                  <TouchableOpacity
                    style={styles.deleteBtn}
                    onPress={() => handleDelete(item)}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Ionicons name="trash-outline" size={18} color={colors.danger} />
                  </TouchableOpacity>
                  <Ionicons
                    name={isLeaf ? 'business-outline' : 'chevron-forward'}
                    size={18}
                    color={colors.textTertiary}
                    style={{ marginRight: 12 }}
                  />
                </TouchableOpacity>
              );
            }}
            ListEmptyComponent={
              segments !== undefined ? (
                <EmptyState
                  icon="layers-outline"
                  title={breadcrumb.length > 0 ? 'No sub-segments' : 'No segments yet'}
                  subtitle={breadcrumb.length > 0 ? 'Add a new sub-segment to categorize further' : 'Tap + above to create your first segment'}
                  actionLabel="Add Segment"
                  onAction={openCreateModal}
                />
              ) : null
            }
          />
        </View>
      </TouchableWithoutFeedback>

      {/* Create segment modal with parent picker */}
      <Modal visible={showCreate} transparent animationType="slide">
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
          <TouchableWithoutFeedback onPress={() => { setShowCreate(false); setNewName(''); }}>
            <View style={styles.modalOverlay}>
              <TouchableWithoutFeedback onPress={(e) => e.stopPropagation()}>
                <View style={styles.modalContent}>
                  <View style={styles.modalHeader}>
                    <Text style={styles.modalTitle}>Add Segment</Text>
                    <TouchableOpacity onPress={() => { setShowCreate(false); setNewName(''); }}>
                      <Ionicons name="close" size={24} color={colors.textSecondary} />
                    </TouchableOpacity>
                  </View>

                  {/* Place under label */}
                  <Text style={styles.pickerLabel}>Place under</Text>

                  {/* Parent picker tree */}
                  <ScrollView style={styles.parentPicker} nestedScrollEnabled>
                    {/* Top level option */}
                    <TouchableOpacity
                      style={[
                        styles.parentOption,
                        !selectedParentId && styles.parentOptionSelected,
                      ]}
                      onPress={() => setSelectedParentId(null)}
                    >
                      <Ionicons
                        name={!selectedParentId ? 'radio-button-on' : 'radio-button-off'}
                        size={18}
                        color={!selectedParentId ? colors.primary : colors.textTertiary}
                      />
                      <Text style={[
                        styles.parentOptionText,
                        !selectedParentId && styles.parentOptionTextSelected,
                      ]}>
                        Top level (new Sector)
                      </Text>
                    </TouchableOpacity>

                    {/* L1 sectors */}
                    {segmentTree.l1.map((sector: any) => {
                      const isExpanded = expandedSectors.has(sector._id);
                      const l2Children = segmentTree.l2Map.get(sector._id) || [];
                      const isSectorSelected = selectedParentId === sector._id;

                      return (
                        <View key={sector._id}>
                          <View style={styles.sectorRow}>
                            <TouchableOpacity
                              style={[
                                styles.parentOption,
                                styles.sectorOption,
                                isSectorSelected && styles.parentOptionSelected,
                              ]}
                              onPress={() => setSelectedParentId(sector._id)}
                            >
                              <Ionicons
                                name={isSectorSelected ? 'radio-button-on' : 'radio-button-off'}
                                size={18}
                                color={isSectorSelected ? colors.primary : colors.textTertiary}
                              />
                              <View style={[styles.sectorDot, { backgroundColor: sector.color || colors.primary }]} />
                              <Text style={[
                                styles.parentOptionText,
                                isSectorSelected && styles.parentOptionTextSelected,
                              ]} numberOfLines={1}>
                                {sector.name}
                              </Text>
                            </TouchableOpacity>
                            {l2Children.length > 0 && (
                              <TouchableOpacity
                                style={styles.expandBtn}
                                onPress={() => toggleSectorExpand(sector._id)}
                              >
                                <Ionicons
                                  name={isExpanded ? 'chevron-up' : 'chevron-down'}
                                  size={16}
                                  color={colors.textTertiary}
                                />
                              </TouchableOpacity>
                            )}
                          </View>

                          {/* L2 sub-sectors (when expanded) */}
                          {isExpanded && l2Children.map((sub: any) => {
                            const isSubSelected = selectedParentId === sub._id;
                            return (
                              <TouchableOpacity
                                key={sub._id}
                                style={[
                                  styles.parentOption,
                                  styles.subOption,
                                  isSubSelected && styles.parentOptionSelected,
                                ]}
                                onPress={() => setSelectedParentId(sub._id)}
                              >
                                <Ionicons
                                  name={isSubSelected ? 'radio-button-on' : 'radio-button-off'}
                                  size={16}
                                  color={isSubSelected ? colors.primary : colors.textTertiary}
                                />
                                <Text style={[
                                  styles.subOptionText,
                                  isSubSelected && styles.parentOptionTextSelected,
                                ]} numberOfLines={1}>
                                  {sub.name}
                                </Text>
                              </TouchableOpacity>
                            );
                          })}
                        </View>
                      );
                    })}
                  </ScrollView>

                  {/* Selected path indicator */}
                  <View style={styles.selectedInfo}>
                    <Ionicons name="location-outline" size={14} color={colors.textSecondary} />
                    <Text style={styles.selectedInfoText}>
                      Creating: {levelNames[newLevel] || 'Segment'}
                      {selectedParentId ? ` under ${getParentPath()}` : ' (top level)'}
                    </Text>
                  </View>

                  {/* Name input */}
                  <TextInput
                    style={styles.modalInput}
                    placeholder={`${levelNames[newLevel] || 'Segment'} name`}
                    placeholderTextColor={colors.textTertiary}
                    value={newName}
                    onChangeText={setNewName}
                    autoFocus={false}
                    returnKeyType="done"
                    onSubmitEditing={handleCreate}
                  />

                  <TouchableOpacity
                    style={[styles.modalBtn, (!newName.trim() || newLevel > 3) && styles.modalBtnDisabled]}
                    onPress={handleCreate}
                    disabled={!newName.trim() || newLevel > 3}
                  >
                    <Text style={styles.modalBtnText}>
                      Create {levelNames[newLevel] || 'Segment'}
                    </Text>
                  </TouchableOpacity>

                  {newLevel > 3 && (
                    <Text style={styles.depthWarning}>
                      Maximum depth reached (3 levels). Pick a higher-level parent.
                    </Text>
                  )}
                </View>
              </TouchableWithoutFeedback>
            </View>
          </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 16, marginTop: 8, marginBottom: 12,
  },
  title: { fontSize: 28, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: 18, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center', flexDirection: 'row',
  },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderRadius: radius.md, paddingHorizontal: 12, marginHorizontal: 16, marginBottom: 8,
    height: 40, ...shadow.sm,
  },
  searchInput: { flex: 1, marginLeft: 8, fontSize: fontSize.sm, color: colors.textPrimary },
  breadcrumbRow: {
    flexDirection: 'row', paddingHorizontal: 16, marginBottom: 4, maxHeight: 32,
  },
  breadcrumbItem: { flexDirection: 'row', alignItems: 'center', marginRight: 4 },
  breadcrumbText: { fontSize: 13, color: colors.primary, marginLeft: 4 },
  breadcrumbActive: { fontWeight: '700', color: colors.textPrimary },
  levelLabel: {
    fontSize: 13, fontWeight: '600', color: colors.textSecondary, textTransform: 'uppercase',
    paddingHorizontal: 16, marginBottom: 8, marginTop: 4, letterSpacing: 0.5,
  },
  listContent: { paddingHorizontal: 16, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderRadius: radius.md, marginBottom: 8, overflow: 'hidden',
    ...shadow.sm,
  },
  colorBar: { width: 4, alignSelf: 'stretch' },
  cardBody: { flex: 1, paddingVertical: 14, paddingHorizontal: 12 },
  cardTop: { flexDirection: 'row', alignItems: 'center' },
  cardName: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary, flex: 1 },
  badge: {
    backgroundColor: colors.primaryLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10,
    marginLeft: 8,
  },
  badgeText: { fontSize: 11, fontWeight: '600', color: colors.primary },
  cardPath: { fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  cardMeta: { fontSize: 12, color: colors.textSecondary, marginTop: 3 },
  cardDesc: { fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  deleteBtn: { padding: 8, marginRight: 2 },
  // Modal styles
  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: colors.white, borderTopLeftRadius: 20, borderTopRightRadius: 20,
    padding: 24, paddingBottom: 40, maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16,
  },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  // Parent picker
  pickerLabel: {
    fontSize: 13, fontWeight: '600', color: colors.textSecondary, textTransform: 'uppercase',
    letterSpacing: 0.5, marginBottom: 8,
  },
  parentPicker: {
    maxHeight: 220, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    marginBottom: 12, backgroundColor: colors.bg,
  },
  parentOption: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: 10, paddingHorizontal: 12,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border,
  },
  parentOptionSelected: {
    backgroundColor: colors.primaryLight,
  },
  parentOptionText: {
    fontSize: fontSize.sm, color: colors.textPrimary, marginLeft: 8, flex: 1,
  },
  parentOptionTextSelected: {
    fontWeight: '700', color: colors.primary,
  },
  sectorRow: {
    flexDirection: 'row', alignItems: 'center',
  },
  sectorOption: {
    flex: 1,
  },
  sectorDot: {
    width: 10, height: 10, borderRadius: 5, marginLeft: 8,
  },
  expandBtn: {
    paddingHorizontal: 14, paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.border,
  },
  subOption: {
    paddingLeft: 44, backgroundColor: colors.white,
  },
  subOptionText: {
    fontSize: 13, color: colors.textSecondary, marginLeft: 8, flex: 1,
  },
  // Selected info
  selectedInfo: {
    flexDirection: 'row', alignItems: 'center', marginBottom: 12,
    backgroundColor: colors.bg, borderRadius: radius.sm, padding: 8,
  },
  selectedInfoText: {
    fontSize: 12, color: colors.textSecondary, marginLeft: 6, flex: 1,
  },
  depthWarning: {
    fontSize: 12, color: colors.danger, textAlign: 'center', marginTop: 8,
  },
  modalInput: {
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    padding: 12, fontSize: fontSize.md, color: colors.textPrimary, marginBottom: 16,
  },
  modalBtn: {
    backgroundColor: colors.primary, borderRadius: radius.md, padding: 14, alignItems: 'center',
  },
  modalBtnDisabled: { opacity: 0.5 },
  modalBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: '600' },
});