import React, { useState, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput,
  Modal, ScrollView, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';

const typeIcons: Record<string, string> = {
  note: 'document-text',
  email: 'mail',
  call: 'call',
  meeting: 'people',
};

const typeColors: Record<string, string> = {
  note: colors.info,
  email: colors.primary,
  call: colors.success,
  meeting: colors.accent,
};

const typeFilters = ['all', 'note', 'email', 'call', 'meeting'] as const;

export default function InteractionsScreen({ navigation }: any) {
  const interactions = useQuery(api.interactions.listAll);
  const contacts = useQuery(api.contacts.list, {});
  const opportunities = useQuery(api.opportunities.list, {});
  const createInteraction = useMutation(api.interactions.create);

  const [showForm, setShowForm] = useState(false);
  const [filter, setFilter] = useState<string>('all');

  // Form state
  const [newType, setNewType] = useState<string>('note');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [contactId, setContactId] = useState<any>(null);
  const [opportunityId, setOpportunityId] = useState<any>(null);
  const [contactPickerOpen, setContactPickerOpen] = useState(false);
  const [oppPickerOpen, setOppPickerOpen] = useState(false);
  const [contactSearch, setContactSearch] = useState('');
  const [oppSearch, setOppSearch] = useState('');

  const filtered = interactions?.filter(
    (i: any) => filter === 'all' || i.type === filter
  );

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays}d ago`;
    return d.toLocaleDateString();
  };

  // Filtered contacts for picker
  const filteredContacts = useMemo(() => {
    if (!contacts) return [];
    if (!contactSearch.trim()) return contacts;
    const q = contactSearch.toLowerCase();
    return contacts.filter((c: any) =>
      `${c.firstName} ${c.lastName}`.toLowerCase().includes(q)
      || (c.companyName || '').toLowerCase().includes(q)
      || (c.email || '').toLowerCase().includes(q)
    );
  }, [contacts, contactSearch]);

  // Filtered opportunities for picker
  const filteredOpps = useMemo(() => {
    if (!opportunities) return [];
    if (!oppSearch.trim()) return opportunities;
    const q = oppSearch.toLowerCase();
    return opportunities.filter((o: any) =>
      o.title.toLowerCase().includes(q)
      || (o.companyName || '').toLowerCase().includes(q)
    );
  }, [opportunities, oppSearch]);

  const selectedContact = useMemo(() => {
    if (!contactId || !contacts) return null;
    return contacts.find((c: any) => c._id === contactId);
  }, [contactId, contacts]);

  const selectedOpp = useMemo(() => {
    if (!opportunityId || !opportunities) return null;
    return opportunities.find((o: any) => o._id === opportunityId);
  }, [opportunityId, opportunities]);

  const resetForm = () => {
    setNewType('note');
    setSubject('');
    setBody('');
    setContactId(null);
    setOpportunityId(null);
    setContactPickerOpen(false);
    setOppPickerOpen(false);
    setContactSearch('');
    setOppSearch('');
  };

  const handleSubmit = async () => {
    if (!subject.trim()) {
      Alert.alert('Required', 'Please enter a subject.');
      return;
    }
    if (!contactId && !opportunityId) {
      Alert.alert('Required', 'Please select at least a contact or an opportunity.');
      return;
    }
    try {
      // Resolve companyId from contact if available
      let companyId: any = undefined;
      if (contactId && selectedContact?.companyId) {
        companyId = selectedContact.companyId;
      }
      await createInteraction({
        type: newType,
        subject: subject.trim(),
        body: body.trim() || undefined,
        contactId: contactId || undefined,
        opportunityId: opportunityId || undefined,
        companyId: companyId || undefined,
      });
      resetForm();
      setShowForm(false);
    } catch (e) {
      console.error(e);
      Alert.alert('Error', 'Failed to log interaction.');
    }
  };

  const hasEntitySelected = !!contactId || !!opportunityId;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Interactions</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowForm(true)}>
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      <View style={styles.filterRow}>
        {typeFilters.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
          >
            {f !== 'all' && (
              <Ionicons
                name={(typeIcons[f] || 'chatbubble') as any}
                size={14}
                color={filter === f ? colors.white : typeColors[f] || colors.textTertiary}
                style={{ marginRight: 4 }}
              />
            )}
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'all' ? 'All' : f.charAt(0).toUpperCase() + f.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {!filtered ? (
        <View style={styles.loading}><Text>Loading...</Text></View>
      ) : filtered.length === 0 ? (
        <EmptyState
          icon="chatbubbles"
          title="No interactions"
          subtitle="Log calls, emails, meetings and notes"
          actionLabel="Log Interaction"
          onAction={() => setShowForm(true)}
        />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item: any) => item._id}
          contentContainerStyle={styles.list}
          renderItem={({ item }: any) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() => {
                if (item.companyId) {
                  navigation.navigate('CompanyDetail', { id: item.companyId });
                } else if (item.contactId) {
                  navigation.navigate('ContactDetail', { id: item.contactId });
                }
              }}
              activeOpacity={item.companyId || item.contactId ? 0.7 : 1}
            >
              <View style={[styles.typeIcon, { backgroundColor: (typeColors[item.type] || colors.info) + '15' }]}>
                <Ionicons
                  name={(typeIcons[item.type] || 'chatbubble') as any}
                  size={18}
                  color={typeColors[item.type] || colors.info}
                />
              </View>
              <View style={styles.cardBody}>
                <Text style={styles.cardSubject} numberOfLines={1}>
                  {item.subject || `${item.type.charAt(0).toUpperCase() + item.type.slice(1)}`}
                </Text>
                {item.body ? (
                  <Text style={styles.cardBodyText} numberOfLines={2}>{item.body}</Text>
                ) : null}
                <View style={styles.cardMeta}>
                  {item.companyName ? (
                    <View style={styles.metaChip}>
                      <Ionicons name="business" size={10} color={colors.primary} />
                      <Text style={styles.metaChipText}>{item.companyName}</Text>
                    </View>
                  ) : null}
                  {item.contactName ? (
                    <View style={styles.metaChip}>
                      <Ionicons name="person" size={10} color={colors.accent} />
                      <Text style={styles.metaChipText}>{item.contactName}</Text>
                    </View>
                  ) : null}
                  <Text style={styles.dateText}>{formatDate(item.date)}</Text>
                </View>
              </View>
            </TouchableOpacity>
          )}
        />
      )}

      {/* Custom Form Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => { resetForm(); setShowForm(false); }}>
              <Text style={styles.modalCancel}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Log Interaction</Text>
            <TouchableOpacity
              onPress={handleSubmit}
              disabled={!subject.trim() || !hasEntitySelected}
            >
              <Text style={[styles.modalSave, (!subject.trim() || !hasEntitySelected) && { opacity: 0.4 }]}>Save</Text>
            </TouchableOpacity>
          </View>

          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={styles.formScroll} keyboardShouldPersistTaps="handled">
              {/* Type Selector */}
              <View style={styles.typeSelector}>
                <Text style={styles.formLabel}>Type</Text>
                <View style={styles.typeSelectorRow}>
                  {(['note', 'email', 'call', 'meeting'] as const).map((t) => (
                    <TouchableOpacity
                      key={t}
                      style={[styles.typeOption, newType === t && styles.typeOptionActive]}
                      onPress={() => setNewType(t)}
                    >
                      <Ionicons
                        name={(typeIcons[t] || 'chatbubble') as any}
                        size={16}
                        color={newType === t ? colors.white : typeColors[t]}
                      />
                      <Text style={[styles.typeOptionText, newType === t && styles.typeOptionTextActive]}>
                        {t.charAt(0).toUpperCase() + t.slice(1)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              {/* Subject */}
              <Text style={styles.formLabel}>Subject *</Text>
              <TextInput
                style={styles.formInput}
                placeholder="Subject"
                placeholderTextColor={colors.textTertiary}
                value={subject}
                onChangeText={setSubject}
              />

              {/* Contact Picker */}
              <Text style={styles.formLabel}>Contact</Text>
              <TouchableOpacity
                style={[styles.formInput, styles.pickerTouchable]}
                onPress={() => { setContactPickerOpen(!contactPickerOpen); setOppPickerOpen(false); }}
              >
                <Ionicons name="person-outline" size={16} color={selectedContact ? colors.accent : colors.textTertiary} />
                <Text style={selectedContact ? styles.pickerValueText : styles.pickerPlaceholderText} numberOfLines={1}>
                  {selectedContact ? `${selectedContact.firstName} ${selectedContact.lastName}` : 'Select a contact...'}
                </Text>
                {contactId && (
                  <TouchableOpacity onPress={() => setContactId(null)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                )}
                <Ionicons name={contactPickerOpen ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
              </TouchableOpacity>
              {contactPickerOpen && (
                <View style={styles.pickerDropdown}>
                  <TextInput
                    style={styles.pickerSearch}
                    placeholder="Search contacts..."
                    placeholderTextColor={colors.textTertiary}
                    value={contactSearch}
                    onChangeText={setContactSearch}
                  />
                  <ScrollView style={styles.pickerList} nestedScrollEnabled>
                    {filteredContacts.length === 0 ? (
                      <Text style={styles.pickerEmpty}>No contacts found</Text>
                    ) : (
                      filteredContacts.map((c: any) => (
                        <TouchableOpacity
                          key={c._id}
                          style={[styles.pickerItem, contactId === c._id && styles.pickerItemSelected]}
                          onPress={() => { setContactId(c._id); setContactPickerOpen(false); setContactSearch(''); }}
                        >
                          <Text style={styles.pickerItemName}>{c.firstName} {c.lastName}</Text>
                          {c.companyName && <Text style={styles.pickerItemSub}>{c.companyName}</Text>}
                        </TouchableOpacity>
                      ))
                    )}
                  </ScrollView>
                </View>
              )}

              {/* Opportunity Picker */}
              <Text style={styles.formLabel}>Opportunity</Text>
              <TouchableOpacity
                style={[styles.formInput, styles.pickerTouchable]}
                onPress={() => { setOppPickerOpen(!oppPickerOpen); setContactPickerOpen(false); }}
              >
                <Ionicons name="git-branch-outline" size={16} color={selectedOpp ? colors.primary : colors.textTertiary} />
                <Text style={selectedOpp ? styles.pickerValueText : styles.pickerPlaceholderText} numberOfLines={1}>
                  {selectedOpp ? selectedOpp.title : 'Select an opportunity...'}
                </Text>
                {opportunityId && (
                  <TouchableOpacity onPress={() => setOpportunityId(null)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                )}
                <Ionicons name={oppPickerOpen ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
              </TouchableOpacity>
              {oppPickerOpen && (
                <View style={styles.pickerDropdown}>
                  <TextInput
                    style={styles.pickerSearch}
                    placeholder="Search opportunities..."
                    placeholderTextColor={colors.textTertiary}
                    value={oppSearch}
                    onChangeText={setOppSearch}
                  />
                  <ScrollView style={styles.pickerList} nestedScrollEnabled>
                    {filteredOpps.length === 0 ? (
                      <Text style={styles.pickerEmpty}>No opportunities found</Text>
                    ) : (
                      filteredOpps.map((o: any) => (
                        <TouchableOpacity
                          key={o._id}
                          style={[styles.pickerItem, opportunityId === o._id && styles.pickerItemSelected]}
                          onPress={() => { setOpportunityId(o._id); setOppPickerOpen(false); setOppSearch(''); }}
                        >
                          <Text style={styles.pickerItemName}>{o.title}</Text>
                          {o.companyName && <Text style={styles.pickerItemSub}>{o.companyName}</Text>}
                        </TouchableOpacity>
                      ))
                    )}
                  </ScrollView>
                </View>
              )}

              {/* Validation hint */}
              {!hasEntitySelected && (
                <View style={styles.validationHint}>
                  <Ionicons name="information-circle" size={16} color={colors.warning} />
                  <Text style={styles.validationHintText}>
                    Select at least a contact or an opportunity to log this interaction.
                  </Text>
                </View>
              )}

              {/* Details */}
              <Text style={styles.formLabel}>Details</Text>
              <TextInput
                style={[styles.formInput, { height: 100, textAlignVertical: 'top' }]}
                placeholder="Details..."
                placeholderTextColor={colors.textTertiary}
                value={body}
                onChangeText={setBody}
                multiline
              />
            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  filterRow: {
    flexDirection: 'row', paddingHorizontal: spacing.lg, gap: spacing.sm, marginBottom: spacing.md,
  },
  filterChip: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: radius.full,
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
  },
  filterChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { fontSize: fontSize.sm, color: colors.textSecondary },
  filterTextActive: { color: colors.white, fontWeight: '600' },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'flex-start', backgroundColor: colors.white,
    padding: spacing.lg, borderRadius: radius.lg, marginBottom: spacing.sm, ...shadow.sm,
  },
  typeIcon: {
    width: 36, height: 36, borderRadius: radius.md,
    justifyContent: 'center', alignItems: 'center', marginRight: spacing.md,
  },
  cardBody: { flex: 1 },
  cardSubject: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  cardBodyText: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  cardMeta: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: spacing.xs, flexWrap: 'wrap' },
  metaChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: colors.bg, paddingHorizontal: 6, paddingVertical: 2, borderRadius: radius.sm,
  },
  metaChipText: { fontSize: fontSize.xs, color: colors.textSecondary },
  dateText: { fontSize: fontSize.xs, color: colors.textTertiary },

  // Modal styles
  modalContainer: { flex: 1, backgroundColor: colors.bg },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  modalCancel: { fontSize: fontSize.md, color: colors.textSecondary },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  modalSave: { fontSize: fontSize.md, fontWeight: '600', color: colors.primary },
  formScroll: { padding: spacing.lg, paddingBottom: 40 },
  formLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginTop: spacing.md, marginBottom: 4 },
  formInput: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  pickerTouchable: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
  },
  pickerValueText: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary },
  pickerPlaceholderText: { flex: 1, fontSize: fontSize.md, color: colors.textTertiary },
  pickerDropdown: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.primary,
    borderRadius: radius.md, marginTop: 4, overflow: 'hidden',
  },
  pickerSearch: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  pickerList: { maxHeight: 180 },
  pickerEmpty: { padding: spacing.md, color: colors.textTertiary, fontSize: fontSize.sm, textAlign: 'center' },
  pickerItem: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    borderBottomWidth: 1, borderBottomColor: colors.bg,
  },
  pickerItemSelected: { backgroundColor: colors.primaryLight },
  pickerItemName: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  pickerItemSub: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 1 },
  validationHint: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.warningLight, padding: spacing.sm,
    borderRadius: radius.md, marginTop: spacing.md,
  },
  validationHintText: { flex: 1, fontSize: fontSize.xs, color: colors.warning, fontWeight: '500' },

  // Type selector
  typeSelector: { marginBottom: spacing.sm },
  typeSelectorRow: { flexDirection: 'row', gap: spacing.sm },
  typeOption: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.md,
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
  },
  typeOptionActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  typeOptionText: { fontSize: fontSize.sm, color: colors.textSecondary },
  typeOptionTextActive: { color: colors.white, fontWeight: '600' },
});