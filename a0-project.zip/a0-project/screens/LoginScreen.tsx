import React, { useState } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, TextInput,
  ActivityIndicator, ScrollView, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useAuthActions } from '@convex-dev/auth/react';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

export default function LoginScreen() {
  const { signIn } = useAuthActions();
  const [isSignUp, setIsSignUp] = useState(false);
  const [version, setVersion] = useState<'solo' | 'team'>('solo');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDemoSignIn = async () => {
    setLoading(true);
    setError('');
    try {
      await signIn('anonymous');
    } catch (err: any) {
      setError(err.message || 'Demo sign-in failed');
    }
    setLoading(false);
  };

  const handleEmailAuth = async () => {
    if (!email || !password) {
      setError('Email and password required');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await signIn('password', {
        email,
        password,
        flow: isSignUp ? 'signUp' : 'signIn',
      });
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    }
    setLoading(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={styles.scrollContent} bounces={false}>
          <View style={styles.header}>
            <Ionicons name="rocket" size={48} color={colors.primary} />
            <Text style={styles.title}>BDBuddy</Text>
            <Text style={styles.tagline}>Your AI-Powered CRM Copilot</Text>
          </View>

          <View style={styles.versionCard}>
            <Text style={styles.versionLabel}>Choose your version</Text>
            <View style={styles.versionRow}>
              <TouchableOpacity
                style={[styles.versionBtn, version === 'solo' && styles.versionBtnActive]}
                onPress={() => setVersion('solo')}
              >
                <Text style={[styles.versionBtnText, version === 'solo' && styles.versionBtnTextActive]}>Solo</Text>
                <Text style={styles.versionBtnSub}>Existing version</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.versionBtn, version === 'team' && styles.versionBtnActive]}
                onPress={() => setVersion('team')}
              >
                <Text style={[styles.versionBtnText, version === 'team' && styles.versionBtnTextActive]}>Team</Text>
                <Text style={styles.versionBtnSub}>Shared workspace</Text>
              </TouchableOpacity>
            </View>
          </View>

          {version === 'solo' ? (
            <TouchableOpacity
              style={[styles.demoBtn, loading && styles.disabled]}
              onPress={handleDemoSignIn}
              disabled={loading}
            >
              <Ionicons name="flash" size={20} color={colors.white} />
              <Text style={styles.demoBtnText}>Continue Solo — No Account Needed</Text>
            </TouchableOpacity>
          ) : (
            <View style={styles.teamPrompt}>
              <Ionicons name="people" size={18} color={colors.primary} />
              <Text style={styles.teamPromptText}>Create or join a team after signing in below.</Text>
            </View>
          )}

          <View style={styles.divider}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>Or sign in</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.form}>
            <Text style={styles.formTitle}>{isSignUp ? 'Create Account' : 'Sign In'}</Text>

            <TextInput
              style={styles.input}
              placeholder="Email"
              placeholderTextColor={colors.textTertiary}
              value={email}
              onChangeText={setEmail}
              editable={!loading}
              keyboardType="email-address"
              autoCapitalize="none"
            />
            <TextInput
              style={styles.input}
              placeholder="Password"
              placeholderTextColor={colors.textTertiary}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
              editable={!loading}
            />

            {error && <Text style={styles.error}>{error}</Text>}

            <TouchableOpacity
              style={[styles.submitBtn, loading && styles.disabled]}
              onPress={handleEmailAuth}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <Text style={styles.submitBtnText}>
                  {version === 'team'
                    ? (isSignUp ? 'Create Team Account' : 'Sign In to Team')
                    : (isSignUp ? 'Sign Up' : 'Sign In')}
                </Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity onPress={() => setIsSignUp(!isSignUp)}>
              <Text style={styles.toggleText}>
                {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  scrollContent: { flexGrow: 1, padding: spacing.lg },
  header: { alignItems: 'center', marginBottom: spacing.xxl, marginTop: spacing.xl },
  title: { fontSize: 36, fontWeight: '800', color: colors.textPrimary, marginTop: spacing.md },
  tagline: { fontSize: 14, color: colors.textSecondary, marginTop: spacing.xs },
  versionCard: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
    ...shadow.sm,
  },
  versionLabel: { fontSize: 14, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  versionRow: { flexDirection: 'row', gap: spacing.sm },
  versionBtn: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    padding: spacing.md,
    backgroundColor: colors.bg,
  },
  versionBtnActive: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight,
  },
  versionBtnText: { fontSize: 16, fontWeight: '700', color: colors.textPrimary },
  versionBtnTextActive: { color: colors.primary },
  versionBtnSub: { fontSize: 12, color: colors.textTertiary, marginTop: 2 },
  teamPrompt: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primaryLight,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  teamPromptText: { flex: 1, color: colors.textPrimary, fontSize: 13, fontWeight: '500' },
  demoBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.lg,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    ...shadow.md,
  },
  demoBtnText: { color: colors.white, fontSize: 16, fontWeight: '600', marginLeft: spacing.sm },
  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: spacing.lg },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerText: { marginHorizontal: spacing.md, color: colors.textTertiary, fontSize: 12 },
  form: { marginTop: spacing.lg },
  formTitle: { fontSize: 18, fontWeight: '600', color: colors.textPrimary, marginBottom: spacing.md },
  input: {
    backgroundColor: colors.white,
    borderRadius: radius.md,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.md,
    marginBottom: spacing.md,
    color: colors.textPrimary,
    borderWidth: 1,
    borderColor: colors.border,
    fontSize: 16,
  },
  submitBtn: {
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    alignItems: 'center',
    marginTop: spacing.md,
    ...shadow.md,
  },
  submitBtnText: { color: colors.white, fontSize: 16, fontWeight: '600' },
  toggleText: { textAlign: 'center', color: colors.primary, marginTop: spacing.md, fontSize: 14 },
  error: { color: colors.danger, fontSize: 14, marginBottom: spacing.md },
  disabled: { opacity: 0.6 },
});