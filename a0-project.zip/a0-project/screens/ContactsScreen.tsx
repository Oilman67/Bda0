import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import {
  View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput,
  Modal, ScrollView, KeyboardAvoidingView, Platform, Alert, ActivityIndicator,
  Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';
import ContactSeekerAI from '../components/ContactSeekerAI';
import * as Contacts from 'expo-contacts';

const MAX_IMPORT = 5;

function kpiStanceColor(stance: string): string {
  switch (stance) {
    case 'Champion': return '#16a34a';
    case 'Supportive': return '#65a30d';
    case 'Neutral': return '#9ca3af';
    case 'Skeptical': return '#ea580c';
    case 'Opposed': return '#dc2626';
    default: return '#9ca3af';
  }
}

function kpiInfluenceColor(inf: string): string {
  switch (inf) {
    case 'High': return '#2563EB';
    case 'Medium': return '#475569';
    case 'Low': return '#94A3B8';
    default: return '#475569';
  }
}

function kpiStrengthColor(s: string): string {
  switch (s) {
    case 'Strong': return '#16a34a';
    case 'Medium': return '#d97706';
    case 'Weak': return '#dc2626';
    default: return '#9ca3af';
  }
}

function getFreshness(lastInteractionDate?: number): { label: string; color: string } {
  if (!lastInteractionDate) return { label: 'Stale', color: '#dc2626' };
  const days = Math.floor((Date.now() - lastInteractionDate) / (1000 * 60 * 60 * 24));
  if (days <= 14) return { label: 'Fresh', color: '#16a34a' };
  if (days <= 30) return { label: 'Aging', color: '#d97706' };
  return { label: 'Stale', color: '#dc2626' };
}

function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

type DeviceContact = {
  id: string;
  firstName: string;
  lastName: string;
  email?: string;
  phone?: string;
  title?: string;
  company?: string;
  notes?: string;
};

export default function ContactsScreen({ navigation, route }: any) {
  const contacts = useQuery(api.contacts.list, {});
  const companies = useQuery(api.companies.list, {});
  const createContact = useMutation(api.contacts.create);
  const batchCreateContacts = useMutation(api.contacts.batchCreate);
  const scanAndMatch = useMutation(api.contacts.scanAndMatch);
  const createAction = useMutation(api.actions.create);
  const [search, setSearch] = useState('');

  // Form state
  const [showForm, setShowForm] = useState(false);
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [title, setTitle] = useState('');
  const [notes, setNotes] = useState('');
  const [companyId, setCompanyId] = useState<any>(null);
  const [companyPickerOpen, setCompanyPickerOpen] = useState(false);
  const [companySearch, setCompanySearch] = useState('');

  // Ref to preserve form state across navigation (for cascading company creation)
  const formStateRef = useRef<{
    firstName: string; lastName: string; email: string; phone: string;
    linkedin: string; title: string; notes: string;
  } | null>(null);

  // Import state
  const [showAddChoice, setShowAddChoice] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [deviceContacts, setDeviceContacts] = useState<DeviceContact[]>([]);
  const [loadingContacts, setLoadingContacts] = useState(false);
  const [importSearch, setImportSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [importing, setImporting] = useState(false);
  const [limitedAccess, setLimitedAccess] = useState(false);

  const pendingCompaniesRef = useRef<string[]>([]);

  // Pending company match filter
  const [pendingFilter, setPendingFilter] = useState(false);
  const hasScanRun = useRef(false);

  // Handle return from AddCompany (cascading creation)
  useEffect(() => {
    if (route?.params?.returnToContactForm) {
      // Clear the param so it doesn't re-trigger
      navigation.setParams({ returnToContactForm: undefined });
      // Restore form state and reopen modal
      if (formStateRef.current) {
        setFirstName(formStateRef.current.firstName);
        setLastName(formStateRef.current.lastName);
        setEmail(formStateRef.current.email);
        setPhone(formStateRef.current.phone);
        setLinkedin(formStateRef.current.linkedin);
        setTitle(formStateRef.current.title);
        setNotes(formStateRef.current.notes);
        formStateRef.current = null;
      }
      // Auto-select the most recently created company
      setTimeout(() => {
        if (companies && companies.length > 0) {
          setCompanyId(companies[0]._id);
        }
        setShowForm(true);
      }, 300);
    }
  }, [route?.params?.returnToContactForm, companies]);

  // Run company scan on startup
  useEffect(() => {
    if (hasScanRun.current || !contacts || !companies) return;
    hasScanRun.current = true;

    (async () => {
      try {
        const result = await scanAndMatch({});
        if (result.matched > 0) {
          console.log(`[CompanyScan] Auto-matched ${result.matched} contacts to companies`);
        }
        if (result.pending > 0) {
          // Create an action to update base data (with deepLink for navigation)
          await createAction({
            title: `Match ${result.pending} contact${result.pending > 1 ? 's' : ''} to companies`,
            description: `The following companies need to be created or matched:\n${result.pendingNames.join('\n')}`,
            priority: 'medium',
            deepLink: 'contacts:pending',
          });
        }
      } catch (e) {
        console.error('[CompanyScan] Error:', e);
      }
    })();
  }, [contacts, companies]);

  // When screen regains focus, check for remaining unmatched companies
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      const pending = pendingCompaniesRef.current;
      if (pending.length === 0) return;
      const next = pending[0];
      pendingCompaniesRef.current = pending.slice(1);
      setTimeout(() => {
        Alert.alert(
          'Create Company',
          `"${next}" was not found in your companies. Would you like to create it?`,
          [
            { text: 'Skip', style: 'cancel', onPress: () => { pendingCompaniesRef.current = []; } },
            {
              text: 'Create',
              onPress: () => navigation.navigate('AddCompany', { initialName: next }),
            },
          ],
        );
      }, 500);
    });
    return unsubscribe;
  }, [navigation]);

  // Match a company name against existing companies (case-insensitive)
  const matchCompany = useCallback((companyName: string | undefined) => {
    if (!companyName || !companies) return null;
    const name = companyName.toLowerCase().trim();
    return companies.find((c: any) => c.name.toLowerCase().trim() === name) || null;
  }, [companies]);

  // Load device contacts — always fetch fresh from device
  const handleOpenImport = useCallback(async () => {
    setShowAddChoice(false);

    // Request permissions first (before opening any modal)
    try {
      const { status } = await Contacts.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Please enable contacts access in your device settings.');
        return;
      }
    } catch (permErr) {
      console.error('Permission error:', permErr);
      Alert.alert('Error', 'Could not request contacts permission.');
      return;
    }

    // Delay to let the add choice sheet finish closing before opening import modal
    await new Promise(resolve => setTimeout(resolve, 400));

    // Reset all import state and fetch fresh
    setDeviceContacts([]);
    setSelectedIds(new Set());
    setImportSearch('');
    setLoadingContacts(true);
    setLimitedAccess(false);
    setShowImport(true);

    try {
      // Try with specific fields first
      let data: any[] | null = null;

      try {
        const result = await Contacts.getContactsAsync({
          fields: [
            Contacts.Fields.FirstName,
            Contacts.Fields.LastName,
            Contacts.Fields.Emails,
            Contacts.Fields.PhoneNumbers,
            Contacts.Fields.JobTitle,
            Contacts.Fields.Company,
          ],
          pageSize: 500,
          pageOffset: 0,
        });
        data = result?.data ?? null;
      } catch (e1) {
        console.warn('getContactsAsync with fields failed, retrying without:', e1);
      }

      // Fallback: no fields, no pagination
      if (!data) {
        try {
          const result2 = await Contacts.getContactsAsync({});
          data = result2?.data ?? null;
        } catch (e2) {
          console.warn('getContactsAsync fallback also failed:', e2);
        }
      }

      // Last resort: try with just name fields
      if (!data) {
        try {
          const result3 = await Contacts.getContactsAsync({
            fields: [Contacts.Fields.FirstName, Contacts.Fields.LastName],
          });
          data = result3?.data ?? null;
        } catch (e3) {
          console.warn('getContactsAsync minimal also failed:', e3);
        }
      }

      if (!data || !Array.isArray(data) || data.length === 0) {
        setDeviceContacts([]);
        setLoadingContacts(false);
        return;
      }

      const mapped: DeviceContact[] = data
        .filter((c: any) => c.firstName || c.lastName || c.name)
        .map((c: any) => {
          // Handle contacts that only have a composite name (no separate first/last)
          let fn = c.firstName || '';
          let ln = c.lastName || '';
          if (!fn && !ln && c.name) {
            const parts = c.name.trim().split(/\s+/);
            fn = parts[0] || '';
            ln = parts.slice(1).join(' ') || '';
          }
          return {
            id: c.id ?? `${fn}-${ln}-${Math.random()}`,
            firstName: fn,
            lastName: ln,
            email: c.emails?.[0]?.email,
            phone: c.phoneNumbers?.[0]?.number,
            title: c.jobTitle || undefined,
            company: c.company || undefined,
            notes: c.note || undefined,
          };
        })
        .filter(c => c.firstName || c.lastName); // Remove any that still have no name

      // Sort by last name, then first name
      mapped.sort((a, b) => {
        const cmp = a.lastName.localeCompare(b.lastName);
        return cmp !== 0 ? cmp : a.firstName.localeCompare(b.firstName);
      });

      setDeviceContacts(mapped);

      // Detect possible iOS limited contact access
      if (mapped.length > 0 && mapped.length <= 10) {
        setLimitedAccess(true);
      }
    } catch (err) {
      console.error('Error loading contacts:', err);
      Alert.alert('Error', 'Unable to load contacts. Please try again.');
    } finally {
      setLoadingContacts(false);
    }
  }, []);

  // Toggle contact selection (max 5)
  const toggleSelect = useCallback((id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        if (next.size >= MAX_IMPORT) {
          Alert.alert('Limit Reached', `You can select up to ${MAX_IMPORT} contacts at a time.`);
          return prev;
        }
        next.add(id);
      }
      return next;
    });
  }, []);

  // Filtered device contacts for search
  const filteredDeviceContacts = useMemo(() => {
    if (!importSearch.trim()) return deviceContacts;
    const q = importSearch.toLowerCase();
    return deviceContacts.filter(c =>
      `${c.firstName} ${c.lastName}`.toLowerCase().includes(q)
      || (c.company || '').toLowerCase().includes(q)
      || (c.email || '').toLowerCase().includes(q)
    );
  }, [deviceContacts, importSearch]);

  // Import selected contacts with company matching
  const handleImport = useCallback(async () => {
    const toImport = deviceContacts.filter(c => selectedIds.has(c.id));
    if (toImport.length === 0) return;

    setImporting(true);
    try {
      const unmatchedCompanies: string[] = [];

      for (const c of toImport) {
        const matchedCompany = matchCompany(c.company);
        if (c.company && !matchedCompany && !unmatchedCompanies.includes(c.company)) {
          unmatchedCompanies.push(c.company);
        }

        await createContact({
          firstName: c.firstName.trim() || 'Unknown',
          lastName: c.lastName.trim() || 'Unknown',
          email: c.email?.trim() || undefined,
          phone: c.phone?.trim() || undefined,
          title: c.title?.trim() || undefined,
          companyId: matchedCompany?._id || undefined,
          pendingCompanyName: c.company && !matchedCompany ? c.company : undefined,
          notes: c.notes || undefined,
        });
      }

      const count = toImport.length;
      setShowImport(false);
      setSelectedIds(new Set());

      if (unmatchedCompanies.length > 0) {
        // Store remaining companies (after the first) for sequential prompting
        pendingCompaniesRef.current = unmatchedCompanies.slice(1);
        Alert.alert(
          'Import Complete',
          `${count} contact${count > 1 ? 's' : ''} imported.\n\n${unmatchedCompanies.length} compan${unmatchedCompanies.length > 1 ? 'ies need' : 'y needs'} to be created:\n${unmatchedCompanies.join(', ')}`,
          [
            { text: 'Later', style: 'cancel', onPress: () => { pendingCompaniesRef.current = []; } },
            {
              text: 'Create Now',
              onPress: () => navigation.navigate('AddCompany', { initialName: unmatchedCompanies[0] }),
            },
          ],
        );
      } else {
        Alert.alert('Import Complete', `${count} contact${count > 1 ? 's' : ''} imported successfully.`);
      }
    } catch (e) {
      console.error(e);
      Alert.alert('Import Failed', 'Something went wrong. Please try again.');
    } finally {
      setImporting(false);
    }
  }, [deviceContacts, selectedIds, matchCompany, createContact, navigation]);

  const filteredCompanies = useMemo(() => {
    if (!companies) return [];
    if (!companySearch.trim()) return companies;
    const q = companySearch.toLowerCase();
    return companies.filter((c: any) => c.name.toLowerCase().includes(q) || (c.domain || '').toLowerCase().includes(q));
  }, [companies, companySearch]);

  const selectedCompany = useMemo(() => {
    if (!companyId || !companies) return null;
    return companies.find((c: any) => c._id === companyId);
  }, [companyId, companies]);

  const resetForm = () => {
    setFirstName(''); setLastName(''); setEmail(''); setPhone('');
    setLinkedin(''); setTitle(''); setNotes(''); setCompanyId(null);
    setCompanyPickerOpen(false); setCompanySearch('');
  };

  const handleCreate = async () => {
    if (!companyId) {
      Alert.alert('Required', 'Please select a company for this contact.');
      return;
    }
    try {
      await createContact({
        firstName: firstName.trim(),
        lastName: lastName.trim(),
        email: email.trim() || undefined,
        phone: phone.trim() || undefined,
        linkedin: linkedin.trim() || undefined,
        title: title.trim() || undefined,
        companyId: companyId || undefined,
        notes: notes.trim() || undefined,
      });
      resetForm();
      setShowForm(false);
    } catch (e) { console.error(e); }
  };

  // Navigate to AddCompany for cascading creation
  const handleCreateCompanyInline = () => {
    // Save current form state
    formStateRef.current = {
      firstName, lastName, email, phone, linkedin, title, notes,
    };
    setShowForm(false);
    setCompanyPickerOpen(false);
    setCompanySearch('');
    navigation.navigate('AddCompany', { returnToContactForm: true });
  };

  const filtered = contacts?.filter(c => {
    // Apply pending filter
    if (pendingFilter && !c.pendingCompanyName) return false;
    const q = search.toLowerCase();
    return `${c.firstName} ${c.lastName}`.toLowerCase().includes(q)
      || (c.companyName || '').toLowerCase().includes(q)
      || (c.pendingCompanyName || '').toLowerCase().includes(q)
      || (c.email || '').toLowerCase().includes(q);
  });

  // Count of contacts with pending company match
  const pendingCount = contacts?.filter(c => c.pendingCompanyName).length ?? 0;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Contacts</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowAddChoice(true)}>
          <Ionicons name="add" size={24} color={colors.white} />
        </TouchableOpacity>
      </View>

      <View style={styles.searchWrap}>
        <Ionicons name="search" size={18} color={colors.textTertiary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search contacts..."
          placeholderTextColor={colors.textTertiary}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Contact Seeker AI */}
      <ContactSeekerAI navigation={navigation} />

      {/* Pending Company Match Banner */}
      {pendingCount > 0 && (
        <TouchableOpacity
          style={[styles.pendingBanner, pendingFilter && styles.pendingBannerActive]}
          onPress={() => setPendingFilter(!pendingFilter)}
        >
          <View style={styles.pendingBannerLeft}>
            <Ionicons name="alert-circle" size={20} color={pendingFilter ? colors.white : colors.warning} />
            <Text style={[styles.pendingBannerText, pendingFilter && { color: colors.white }]}>
              {pendingCount} contact{pendingCount > 1 ? 's' : ''} pending company match
            </Text>
          </View>
          <View style={[styles.pendingBadge, pendingFilter && { backgroundColor: 'rgba(255,255,255,0.3)' }]}>
            <Text style={[styles.pendingBadgeText, pendingFilter && { color: colors.white }]}>
              {pendingFilter ? 'Show All' : 'Filter'}
            </Text>
          </View>
        </TouchableOpacity>
      )}

      {!contacts ? (
        <View style={styles.loading}><Text style={styles.loadingText}>Loading...</Text></View>
      ) : filtered && filtered.length === 0 ? (
        <EmptyState icon="people" title="No contacts yet" subtitle="Contacts will appear here" />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate('ContactDetail', { id: item._id })}
            >
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{item.firstName[0]}{item.lastName[0]}</Text>
              </View>
              <View style={styles.cardBody}>
                <Text style={styles.cardTitle}>{item.firstName} {item.lastName}</Text>
                {item.title && <Text style={styles.cardSub}>{item.title}</Text>}
                <View style={styles.cardMeta}>
                  {item.companyName && (
                    <View style={styles.metaChip}>
                      <Ionicons name="business" size={12} color={colors.primary} />
                      <Text style={styles.metaChipText}>{item.companyName}</Text>
                    </View>
                  )}
                  {!item.companyName && item.pendingCompanyName && (
                    <View style={[styles.metaChip, { backgroundColor: colors.warningLight }]}>
                      <Ionicons name="alert-circle" size={12} color={colors.warning} />
                      <Text style={[styles.metaChipText, { color: colors.warning }]}>{item.pendingCompanyName}</Text>
                    </View>
                  )}
                  {item.lastInteraction && (
                    <View style={styles.metaChip}>
                      <Ionicons name="time" size={12} color={colors.textTertiary} />
                      <Text style={styles.metaChipText}>{timeAgo(item.lastInteraction.date)}</Text>
                    </View>
                  )}
                  {item.linkedin && (
                    <View style={styles.metaChip}>
                      <Ionicons name="logo-linkedin" size={12} color="#0A66C2" />
                    </View>
                  )}
                </View>
                {item.riKPI && (() => {
                  const freshness = getFreshness(item.lastInteraction?.date);
                  return (
                    <View style={styles.kpiWrap}>
                      {/* Badges row: Stance, Influence, Role + source */}
                      <View style={styles.kpiBadgeRow}>
                        <View style={[styles.kpiBadge, { backgroundColor: kpiStanceColor(item.riKPI.stance) }]}>
                          <Text style={styles.kpiBadgeText}>{item.riKPI.stance}</Text>
                        </View>
                        <View style={[styles.kpiBadge, { backgroundColor: kpiInfluenceColor(item.riKPI.influence) }]}>
                          <Text style={styles.kpiBadgeText}>{item.riKPI.influence}</Text>
                        </View>
                        <View style={[styles.kpiOutlineBadge, { borderColor: colors.textTertiary }]}>
                          <Text style={styles.kpiOutlineBadgeText}>{item.riKPI.role}</Text>
                        </View>
                        <View style={[styles.kpiSourceBadge, {
                          backgroundColor: item.riKPI.isUserOverride ? colors.warningLight : colors.primaryLight,
                        }]}>
                          <Text style={[styles.kpiSourceText, {
                            color: item.riKPI.isUserOverride ? colors.warning : colors.primary,
                          }]}>
                            {item.riKPI.isUserOverride ? 'Manual' : 'AI'}
                          </Text>
                        </View>
                      </View>
                      {/* Strength + Freshness */}
                      <View style={styles.kpiMetaRow}>
                        <View style={styles.kpiMetaItem}>
                          <View style={[styles.kpiDot, { backgroundColor: kpiStrengthColor(item.riKPI.relationshipStrength) }]} />
                          <Text style={styles.kpiMetaText}>{item.riKPI.relationshipStrength}</Text>
                        </View>
                        <View style={styles.kpiMetaItem}>
                          <View style={[styles.kpiDot, { backgroundColor: freshness.color }]} />
                          <Text style={styles.kpiMetaText}>{freshness.label}</Text>
                        </View>
                        {item.riKPI.assessmentCount > 1 && (
                          <Text style={styles.kpiCountText}>{item.riKPI.assessmentCount} opps</Text>
                        )}
                      </View>
                      {/* Next Move */}
                      {item.riKPI.nextMove && (
                        <View style={styles.kpiNextMove}>
                          <Ionicons name="arrow-forward-circle" size={12} color={colors.primary} />
                          <Text style={styles.kpiNextMoveText} numberOfLines={1}>{item.riKPI.nextMove}</Text>
                        </View>
                      )}
                    </View>
                  );
                })()}
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </TouchableOpacity>
          )}
        />
      )}

      {/* Add Choice Sheet */}
      <Modal visible={showAddChoice} transparent animationType="fade">
        <TouchableOpacity
          style={styles.sheetOverlay}
          activeOpacity={1}
          onPress={() => setShowAddChoice(false)}
        >
          <View style={styles.sheetContainer}>
            <View style={styles.sheetHandle} />
            <Text style={styles.sheetTitle}>Add Contact</Text>

            <TouchableOpacity
              style={styles.sheetOption}
              onPress={() => { setShowAddChoice(false); setShowForm(true); }}
            >
              <View style={[styles.sheetIconWrap, { backgroundColor: colors.primaryLight }]}>
                <Ionicons name="create-outline" size={22} color={colors.primary} />
              </View>
              <View style={styles.sheetOptionText}>
                <Text style={styles.sheetOptionTitle}>Create Manually</Text>
                <Text style={styles.sheetOptionSub}>Enter contact details by hand</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.sheetOption}
              onPress={handleOpenImport}
            >
              <View style={[styles.sheetIconWrap, { backgroundColor: colors.accentLight }]}>
                <Ionicons name="people-outline" size={22} color={colors.accent} />
              </View>
              <View style={styles.sheetOptionText}>
                <Text style={styles.sheetOptionTitle}>Import from Contacts</Text>
                <Text style={styles.sheetOptionSub}>Select contacts from your device</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textTertiary} />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.sheetCancelBtn}
              onPress={() => setShowAddChoice(false)}
            >
              <Text style={styles.sheetCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </Modal>

      {/* New Contact Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => { resetForm(); setShowForm(false); }}>
              <Text style={styles.modalCancel}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>New Contact</Text>
            <TouchableOpacity
              onPress={handleCreate}
              disabled={!firstName.trim() || !lastName.trim() || !companyId}
            >
              <Text style={[styles.modalSave, (!firstName.trim() || !lastName.trim() || !companyId) && { opacity: 0.4 }]}>Save</Text>
            </TouchableOpacity>
          </View>
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={styles.formScroll}>

              <Text style={styles.formLabel}>First Name *</Text>
              <TextInput style={styles.formInput} value={firstName} onChangeText={setFirstName} placeholder="First Name" placeholderTextColor={colors.textTertiary} />

              <Text style={styles.formLabel}>Last Name *</Text>
              <TextInput style={styles.formInput} value={lastName} onChangeText={setLastName} placeholder="Last Name" placeholderTextColor={colors.textTertiary} />

              <Text style={styles.formLabel}>Company *</Text>
              <TouchableOpacity
                style={[styles.formInput, { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, !companyId && { borderColor: colors.warning }]}
                onPress={() => setCompanyPickerOpen(!companyPickerOpen)}
              >
                <Text style={selectedCompany ? { color: colors.textPrimary, fontSize: fontSize.md } : { color: colors.textTertiary, fontSize: fontSize.md }}>
                  {selectedCompany ? selectedCompany.name : 'Select a company...'}
                </Text>
                <Ionicons name={companyPickerOpen ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
              </TouchableOpacity>
              {companyPickerOpen && (
                <View style={styles.pickerDropdown}>
                  <TextInput
                    style={styles.pickerSearch}
                    placeholder="Search companies..."
                    placeholderTextColor={colors.textTertiary}
                    value={companySearch}
                    onChangeText={setCompanySearch}
                  />
                  <ScrollView style={styles.pickerList} nestedScrollEnabled>
                    {filteredCompanies.length === 0 ? (
                      <Text style={styles.pickerEmpty}>No companies found</Text>
                    ) : (
                      filteredCompanies.map((c: any) => (
                        <TouchableOpacity
                          key={c._id}
                          style={[styles.pickerItem, companyId === c._id && styles.pickerItemSelected]}
                          onPress={() => { setCompanyId(c._id); setCompanyPickerOpen(false); setCompanySearch(''); }}
                        >
                          <Text style={styles.pickerItemName}>{c.name}</Text>
                          {c.domain && <Text style={styles.pickerItemDomain}>{c.domain}</Text>}
                        </TouchableOpacity>
                      ))
                    )}
                  </ScrollView>
                  {/* Create New Company button for cascading creation */}
                  <TouchableOpacity
                    style={{
                      flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
                      gap: spacing.sm, paddingVertical: spacing.md,
                      borderTopWidth: 1, borderTopColor: colors.border,
                      backgroundColor: colors.primaryLight,
                    }}
                    onPress={handleCreateCompanyInline}
                  >
                    <Ionicons name="add-circle-outline" size={18} color={colors.primary} />
                    <Text style={{ fontSize: fontSize.sm, fontWeight: '600', color: colors.primary }}>
                      Create New Company
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              <Text style={styles.formLabel}>Job Title</Text>
              <TextInput style={styles.formInput} value={title} onChangeText={setTitle} placeholder="Job Title" placeholderTextColor={colors.textTertiary} />

              <Text style={styles.formLabel}>Email</Text>
              <TextInput style={styles.formInput} value={email} onChangeText={setEmail} placeholder="Email" placeholderTextColor={colors.textTertiary} keyboardType="email-address" autoCapitalize="none" />

              <Text style={styles.formLabel}>Phone</Text>
              <TextInput style={styles.formInput} value={phone} onChangeText={setPhone} placeholder="Phone" placeholderTextColor={colors.textTertiary} keyboardType="phone-pad" />

              <Text style={styles.formLabel}>LinkedIn Profile</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <TextInput style={[styles.formInput, { flex: 1, marginBottom: 0 }]} value={linkedin} onChangeText={setLinkedin} placeholder="https://linkedin.com/in/..." placeholderTextColor={colors.textTertiary} autoCapitalize="none" />
                <TouchableOpacity
                  style={{
                    flexDirection: 'row', alignItems: 'center', gap: 4,
                    backgroundColor: '#0A66C2', paddingHorizontal: 12, paddingVertical: 10,
                    borderRadius: radius.md,
                    opacity: (firstName.trim() || lastName.trim()) ? 1 : 0.4,
                  }}
                  disabled={!(firstName.trim() || lastName.trim())}
                  onPress={() => {
                    const name = `${firstName.trim()} ${lastName.trim()}`.trim();
                    const searchUrl = `https://www.linkedin.com/search/results/all/?keywords=${encodeURIComponent(name)}&origin=GLOBAL_SEARCH_HEADER`;
                    Linking.openURL(searchUrl);
                  }}
                >
                  <Ionicons name="logo-linkedin" size={16} color="#fff" />
                  <Text style={{ fontSize: fontSize.xs, fontWeight: '600', color: '#fff' }}>Search</Text>
                </TouchableOpacity>
              </View>

              <Text style={styles.formLabel}>Notes</Text>
              <TextInput style={[styles.formInput, { height: 80, textAlignVertical: 'top' }]} value={notes} onChangeText={setNotes} placeholder="Notes" placeholderTextColor={colors.textTertiary} multiline />

            </ScrollView>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>

      {/* Import Contacts Modal */}
      <Modal visible={showImport} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => {
              setShowImport(false);
              setSelectedIds(new Set());
              setImportSearch('');
            }}>
              <Text style={styles.modalCancel}>Cancel</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Import Contacts</Text>
            <TouchableOpacity
              onPress={handleImport}
              disabled={selectedIds.size === 0 || importing}
            >
              <Text style={[styles.modalSave, (selectedIds.size === 0 || importing) && { opacity: 0.4 }]}>
                {importing ? 'Importing...' : `Import (${selectedIds.size})`}
              </Text>
            </TouchableOpacity>
          </View>

          {importing ? (
            <View style={styles.loadingCenter}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={styles.loadingSubText}>Importing contacts...</Text>
            </View>
          ) : loadingContacts ? (
            <View style={styles.loadingCenter}>
              <ActivityIndicator size="large" color={colors.primary} />
              <Text style={styles.loadingSubText}>Loading contacts...</Text>
            </View>
          ) : (
            <>
              <View style={[styles.searchWrap, { marginTop: spacing.md }]}>
                <Ionicons name="search" size={18} color={colors.textTertiary} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search contacts..."
                  placeholderTextColor={colors.textTertiary}
                  value={importSearch}
                  onChangeText={setImportSearch}
                />
                {selectedIds.size > 0 && (
                  <Text style={{ fontSize: fontSize.sm, color: colors.primary, fontWeight: '600' }}>
                    {selectedIds.size}/{MAX_IMPORT}
                  </Text>
                )}
              </View>

              {limitedAccess && (
                <TouchableOpacity
                  style={styles.limitedAccessBanner}
                  onPress={() => Linking.openSettings()}
                >
                  <View style={styles.limitedAccessContent}>
                    <Ionicons name="information-circle" size={20} color={colors.primary} />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.limitedAccessText}>
                        Not seeing all your contacts? You may have granted limited access.
                      </Text>
                      <Text style={styles.limitedAccessLink}>
                        Tap to open Settings and allow full access
                      </Text>
                    </View>
                    <Ionicons name="open-outline" size={16} color={colors.primary} />
                  </View>
                </TouchableOpacity>
              )}

              <FlatList
                data={filteredDeviceContacts}
                keyExtractor={(item) => item.id}
                contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 40 }}
                ListEmptyComponent={
                  <View style={styles.loadingCenter}>
                    <Ionicons name="people-outline" size={48} color={colors.textTertiary} />
                    <Text style={styles.emptyImportTitle}>No contacts found</Text>
                    <Text style={styles.emptyImportSub}>
                      {deviceContacts.length === 0
                        ? 'No contacts available on this device.'
                        : 'Try adjusting your search.'}
                    </Text>
                  </View>
                }
                renderItem={({ item }) => {
                  const isSelected = selectedIds.has(item.id);
                  return (
                    <TouchableOpacity
                      style={[
                        styles.stagingCard,
                        isSelected && styles.stagingCardSelected,
                      ]}
                      onPress={() => toggleSelect(item.id)}
                    >
                      <View style={styles.stagingCardBody}>
                        <View style={styles.stagingCardHeader}>
                          <Text style={styles.stagingCardName}>
                            {item.firstName} {item.lastName}
                          </Text>
                          <Ionicons
                            name={isSelected ? 'checkmark-circle' : 'ellipse-outline'}
                            size={24}
                            color={isSelected ? colors.primary : colors.border}
                          />
                        </View>
                        {item.company && (
                          <View style={styles.stagingDetailRow}>
                            <Ionicons name="business-outline" size={13} color={colors.textTertiary} />
                            <Text style={styles.stagingDetailText}>{item.company}</Text>
                          </View>
                        )}
                        {item.email && (
                          <View style={styles.stagingDetailRow}>
                            <Ionicons name="mail-outline" size={13} color={colors.textTertiary} />
                            <Text style={styles.stagingDetailText}>{item.email}</Text>
                          </View>
                        )}
                        {item.phone && (
                          <View style={styles.stagingDetailRow}>
                            <Ionicons name="call-outline" size={13} color={colors.textTertiary} />
                            <Text style={styles.stagingDetailText}>{item.phone}</Text>
                          </View>
                        )}
                      </View>
                    </TouchableOpacity>
                  );
                }}
              />
            </>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  headerTitle: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    marginHorizontal: spacing.lg, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, marginBottom: spacing.md,
  },
  searchInput: { flex: 1, marginLeft: spacing.sm, fontSize: fontSize.md, color: colors.textPrimary },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    padding: spacing.lg, borderRadius: radius.lg, marginBottom: spacing.sm, ...shadow.sm,
  },
  avatar: {
    width: 44, height: 44, borderRadius: radius.full, backgroundColor: colors.accentLight,
    justifyContent: 'center', alignItems: 'center',
  },
  avatarText: { fontSize: fontSize.md, fontWeight: '700', color: colors.accent },
  cardBody: { flex: 1, marginLeft: spacing.md },
  cardTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  cardSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  cardMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginTop: 4 },
  metaChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: colors.bg, paddingHorizontal: 6, paddingVertical: 2, borderRadius: radius.sm,
  },
  metaChipText: { fontSize: fontSize.xs, color: colors.textTertiary },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: colors.textSecondary },
  // Sheet styles
  sheetOverlay: {
    flex: 1, backgroundColor: colors.overlay, justifyContent: 'flex-end',
  },
  sheetContainer: {
    backgroundColor: colors.white, borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl,
    paddingBottom: 34, paddingHorizontal: spacing.lg,
  },
  sheetHandle: {
    width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border,
    alignSelf: 'center', marginTop: spacing.sm, marginBottom: spacing.md,
  },
  sheetTitle: {
    fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary,
    marginBottom: spacing.lg,
  },
  sheetOption: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  sheetIconWrap: {
    width: 44, height: 44, borderRadius: radius.lg, justifyContent: 'center', alignItems: 'center',
  },
  sheetOptionText: { flex: 1, marginLeft: spacing.md },
  sheetOptionTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  sheetOptionSub: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  sheetCancelBtn: {
    marginTop: spacing.lg, paddingVertical: spacing.md, borderRadius: radius.md,
    backgroundColor: colors.bg, alignItems: 'center',
  },
  sheetCancelText: { fontSize: fontSize.md, fontWeight: '600', color: colors.textSecondary },
  // Modal styles
  modalContainer: { flex: 1, backgroundColor: colors.bg },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  modalCancel: { fontSize: fontSize.md, color: colors.textSecondary },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, flex: 1, textAlign: 'center' },
  modalSave: { fontSize: fontSize.md, fontWeight: '600', color: colors.primary },
  formScroll: { padding: spacing.lg, paddingBottom: 40 },
  formLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginTop: spacing.md, marginBottom: 4 },
  formInput: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  pickerDropdown: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.primary,
    borderRadius: radius.md, marginTop: 4, overflow: 'hidden',
  },
  pickerSearch: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  pickerList: { maxHeight: 180 },
  pickerEmpty: { padding: spacing.md, color: colors.textTertiary, fontSize: fontSize.sm, textAlign: 'center' },
  pickerItem: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    borderBottomWidth: 1, borderBottomColor: colors.bg,
  },
  pickerItemSelected: { backgroundColor: colors.primaryLight },
  pickerItemName: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  pickerItemDomain: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 1 },
  // Staging styles
  loadingCenter: {
    flex: 1, justifyContent: 'center', alignItems: 'center', padding: spacing.xxxl,
  },
  loadingSubText: {
    marginTop: spacing.md, fontSize: fontSize.md, color: colors.textSecondary,
  },
  emptyImportTitle: {
    marginTop: spacing.lg, fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary,
  },
  emptyImportSub: {
    marginTop: spacing.sm, fontSize: fontSize.md, color: colors.textSecondary,
    textAlign: 'center', lineHeight: 22,
  },
  stagingList: { padding: spacing.lg, paddingBottom: 40 },
  stagingHeader: {
    fontSize: fontSize.md, fontWeight: '600', color: colors.textSecondary,
    textAlign: 'center', marginBottom: spacing.lg,
  },
  stagingCard: {
    backgroundColor: colors.white, borderRadius: radius.lg, marginBottom: spacing.sm,
    borderWidth: 1, borderColor: colors.border, ...shadow.sm,
  },
  stagingCardSelected: {
    borderWidth: 2, borderColor: colors.primary,
  },
  stagingCardBody: { padding: spacing.md },
  stagingCardHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: spacing.xs,
  },
  stagingCardName: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary, flex: 1 },
  stagingDetailRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  stagingDetailText: { fontSize: fontSize.sm, color: colors.textSecondary, flex: 1 },
  matchBadge: {
    paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10,
  },
  matchBadgeSuccess: { backgroundColor: colors.successLight },
  matchBadgeWarning: { backgroundColor: colors.warningLight },
  matchBadgeText: { fontSize: fontSize.xs, fontWeight: '600' },
  addMoreBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    paddingVertical: spacing.lg, borderRadius: radius.lg,
    borderWidth: 1.5, borderColor: colors.primary, borderStyle: 'dashed',
    marginTop: spacing.sm,
  },
  addMoreText: { fontSize: fontSize.md, fontWeight: '600', color: colors.primary },
  pickContactBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    backgroundColor: colors.primary, paddingVertical: spacing.md, paddingHorizontal: spacing.xl,
    borderRadius: radius.md, marginTop: spacing.lg,
  },
  pickContactBtnText: { fontSize: fontSize.md, fontWeight: '600', color: colors.white },
  pendingBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: colors.warningLight,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm + 2,
    borderRadius: radius.md, marginHorizontal: spacing.lg, marginBottom: spacing.md,
  },
  pendingBannerActive: {
    backgroundColor: colors.primary,
  },
  pendingBannerLeft: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1,
  },
  pendingBannerText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary },
  pendingBadge: {
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderRadius: radius.lg, backgroundColor: colors.bg,
  },
  pendingBadgeText: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  limitedAccessBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: colors.warningLight,
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderRadius: radius.lg, marginHorizontal: spacing.lg, marginBottom: spacing.md,
  },
  limitedAccessContent: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.lg,
  },
  limitedAccessText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary },
  limitedAccessLink: { fontSize: fontSize.sm, color: colors.primary, textDecorationLine: 'underline' },
  // RI indicators on contact cards
  kpiWrap: {
    marginTop: 8,
  },
  kpiBadgeRow: {
    flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 5, marginBottom: 4,
  },
  kpiBadge: {
    paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4,
  },
  kpiBadgeText: {
    fontSize: 10, fontWeight: '700', color: '#fff',
  },
  kpiOutlineBadge: {
    paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4, borderWidth: 1,
  },
  kpiOutlineBadgeText: {
    fontSize: 10, fontWeight: '600', color: colors.textSecondary,
  },
  kpiSourceBadge: {
    paddingHorizontal: 5, paddingVertical: 1, borderRadius: 3, marginLeft: 'auto',
  },
  kpiSourceText: {
    fontSize: 9, fontWeight: '700',
  },
  kpiMetaRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 4,
  },
  kpiMetaItem: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
  },
  kpiDot: {
    width: 7, height: 7, borderRadius: 4,
  },
  kpiMetaText: {
    fontSize: 10, color: colors.textSecondary, fontWeight: '500',
  },
  kpiCountText: {
    fontSize: 10, color: colors.textTertiary, fontWeight: '500',
  },
  kpiNextMove: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.primaryLight, borderRadius: 4,
    paddingHorizontal: 6, paddingVertical: 3,
  },
  kpiNextMoveText: {
    fontSize: 10, color: colors.primary, fontWeight: '600', flex: 1,
  },
});