import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet,
  ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useAction } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import SegmentPicker from '../components/SegmentPicker';

interface UrlSuggestion {
  url: string;
  description: string;
  verified?: boolean | null;
}

interface PriorityScore {
  likelihood: number;
  speed: number;
  strategic_value: number;
}

interface Opportunity {
  title: string;
  description: string;
  bd_focus_area: string;
  trigger: string;
  stakeholders: string[];
  entry_strategy: string;
  competitive_context: {
    likely_competitors: string[];
    differentiation: string;
  };
  priority_score: PriorityScore;
}

type BdAnalysis = {
  opportunity_summary: Array<{
    title: string;
    description: string;
    bd_focus_area: string;
    trigger: string;
    stakeholders: string[];
    entry_strategy: string;
    competitive_context: {
      likely_competitors: string[];
      differentiation: string;
    };
    priority_score: { likelihood: number; speed: number; strategic_value: number };
  }>;
  segment_insights: string[];
  recommended_next_actions: Array<{ title: string; details: string }>;
};

export default function AddCompanyScreen({ navigation, route }: any) {
  const initialName = route?.params?.initialName || '';
  const returnToContactForm = route?.params?.returnToContactForm || false;
  const orgSettings = useQuery(api.orgSettings.get);
  const allSegments = useQuery(api.segments.list);
  const createCompany = useMutation(api.companies.create);
  const linkPendingContacts = useMutation(api.contacts.linkByPendingCompanyName);
  const saveInsights = useMutation(api.companies.saveInsights);
  const createAction = useMutation(api.actions.create);
  const suggestSegmentAction = useAction(api.ai.suggestSegmentFromUrl);
  const createSegmentChain = useMutation(api.segments.createChain);

  // Form state
  const [name, setName] = useState(initialName);
  const [domain, setDomain] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [segmentId, setSegmentId] = useState<any>(undefined);
  const [segmentPath, setSegmentPath] = useState<string | undefined>(undefined);

  // AI state
  const [urlSuggestions, setUrlSuggestions] = useState<UrlSuggestion[]>([]);
  const [loadingUrls, setLoadingUrls] = useState(false);
  const [selectedUrl, setSelectedUrl] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<BdAnalysis | null>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [suggestingSegment, setSuggestingSegment] = useState(false);
  const [segmentReason, setSegmentReason] = useState('');
  const [segmentKeywords, setSegmentKeywords] = useState<string[]>([]);
  const [suggestedEmails, setSuggestedEmails] = useState<string[]>([]);
  const [suggestedPhones, setSuggestedPhones] = useState<string[]>([]);
  const [selectedActions, setSelectedActions] = useState<Set<number>>(new Set());
  const [pushingActions, setPushingActions] = useState(false);

  // Proposal state
  const [isSegmentProposal, setIsSegmentProposal] = useState(false);
  const [segmentConfidence, setSegmentConfidence] = useState(0);
  const [proposedSector, setProposedSector] = useState('');
  const [proposedSubSector, setProposedSubSector] = useState('');
  const [proposedNiche, setProposedNiche] = useState('');
  const [proposedColor, setProposedColor] = useState<string | undefined>(undefined);
  const [fallbackSegmentId, setFallbackSegmentId] = useState<any>(undefined);
  const [fallbackSegmentPath, setFallbackSegmentPath] = useState<string | undefined>(undefined);
  const [creatingSegment, setCreatingSegment] = useState(false);

  // Company dimensions state
  const [companyDimensions, setCompanyDimensions] = useState<{
    revenue?: string;
    employees?: string;
    sites?: string;
    capitalization?: string;
    headquarters?: string;
    founded?: string;
    description?: string;
  } | null>(null);

  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSearchedName = useRef('');
  const lastSegmentSearch = useRef('');
  const [searchAttempted, setSearchAttempted] = useState(false);
  const [urlFieldFocused, setUrlFieldFocused] = useState(false);

  // Clear proposal state helper
  const clearProposalState = () => {
    setIsSegmentProposal(false);
    setSegmentConfidence(0);
    setProposedSector('');
    setProposedSubSector('');
    setProposedNiche('');
    setProposedColor(undefined);
    setFallbackSegmentId(undefined);
    setFallbackSegmentPath(undefined);
  };

  // Server-side AI segment suggestion
  const suggestSegment = useCallback(async (companyName: string, companyDomain: string) => {
    if (!companyName || !companyDomain) return;
    const searchKey = `${companyName}|${companyDomain}`;
    if (searchKey === lastSegmentSearch.current) return;
    if (segmentId) return;
    lastSegmentSearch.current = searchKey;

    setSuggestingSegment(true);
    setSegmentReason('');
    setSegmentKeywords([]);
    clearProposalState();
    setCompanyDimensions(null);
    try {
      const result = await suggestSegmentAction({ companyName, companyDomain });
      if (result && !segmentId) {
        setSegmentConfidence(result.confidence);
        setSegmentReason(result.reason);
        setSegmentKeywords(result.keywords);

        // Capture company dimensions
        if (result.companyDimensions) {
          setCompanyDimensions(result.companyDimensions);

          // Auto-build notes from dimensions
          const dimLines: string[] = [];
          if (result.companyDimensions.description) dimLines.push(result.companyDimensions.description);
          if (result.companyDimensions.headquarters) dimLines.push(`HQ: ${result.companyDimensions.headquarters}`);
          if (result.companyDimensions.founded) dimLines.push(`Founded: ${result.companyDimensions.founded}`);
          if (result.companyDimensions.revenue) dimLines.push(`Revenue: ${result.companyDimensions.revenue}`);
          if (result.companyDimensions.employees) dimLines.push(`Employees: ${result.companyDimensions.employees}`);
          if (result.companyDimensions.sites) dimLines.push(`Sites/Locations: ${result.companyDimensions.sites}`);
          if (result.companyDimensions.capitalization) dimLines.push(`Market Cap: ${result.companyDimensions.capitalization}`);
          if (dimLines.length > 0 && !notes) {
            setNotes(`--- Company Profile (AI-extracted) ---\n${dimLines.join('\n')}`);
          }
        } else if (result.websiteSnippet && result.websiteSnippet.length > 20 && !notes) {
          // Fallback: use website snippet + classification as notes
          const fallbackLines: string[] = [];
          fallbackLines.push(`--- Company Info (from website) ---`);
          // Clean up the snippet: extract the most useful parts
          const snippetParts = result.websiteSnippet.split('\n').filter((l: string) => l.trim().length > 0);
          for (const part of snippetParts) {
            // Extract value after "Title:", "Description:", etc.
            const colonIdx = part.indexOf(':');
            if (colonIdx > 0 && colonIdx < 15) {
              fallbackLines.push(part.trim());
            } else if (part.length > 10) {
              fallbackLines.push(part.trim());
            }
          }
          if (result.reason) fallbackLines.push(`\nIndustry: ${result.reason}`);
          if (result.keywords && result.keywords.length > 0) {
            fallbackLines.push(`Keywords: ${result.keywords.join(', ')}`);
          }
          setNotes(fallbackLines.join('\n'));
        }

        if (result.isProposal) {
          // AI proposes a new segment
          setIsSegmentProposal(true);
          setSegmentPath(result.segmentPath);
          setProposedSector(result.proposedSector || '');
          setProposedSubSector(result.proposedSubSector || '');
          setProposedNiche(result.proposedNiche || '');
          setProposedColor(result.proposedColor || undefined);
          setFallbackSegmentId(result.fallbackSegmentId || undefined);
          setFallbackSegmentPath(result.fallbackSegmentPath || undefined);
          // Don't set segmentId yet  user must accept
        } else {
          // Existing segment matched with good confidence
          setIsSegmentProposal(false);
          setSegmentId(result.segmentId);
          setSegmentPath(result.segmentPath);
        }

        // Auto-fill email/phone if scraped from website
        if (result.emails && result.emails.length > 0) {
          setSuggestedEmails(result.emails);
          if (!email) setEmail(result.emails[0]);
        }
        if (result.phones && result.phones.length > 0) {
          setSuggestedPhones(result.phones);
          if (!phone) setPhone(result.phones[0]);
        }
      }
    } catch (err: any) {
      console.log('[AI Segment] Error:', err?.message || String(err));
    } finally {
      setSuggestingSegment(false);
    }
  }, [suggestSegmentAction, segmentId, email, phone, notes]);

  // Accept proposed segment  create it in DB
  const handleAcceptProposal = async () => {
    if (!proposedSector || !proposedSubSector || !proposedNiche) return;
    setCreatingSegment(true);
    try {
      const result = await createSegmentChain({
        sectorName: proposedSector,
        subSectorName: proposedSubSector,
        nicheName: proposedNiche,
        sectorColor: proposedColor,
      });
      setSegmentId(result.segmentId);
      setSegmentPath(result.segmentPath);
      setIsSegmentProposal(false);
      clearProposalState();
    } catch (err: any) {
      Alert.alert('Error', 'Failed to create segment: ' + (err?.message || String(err)));
    } finally {
      setCreatingSegment(false);
    }
  };

  // Use fallback existing segment instead of proposal
  const handleUseFallback = () => {
    if (fallbackSegmentId) {
      setSegmentId(fallbackSegmentId);
      setSegmentPath(fallbackSegmentPath);
      setIsSegmentProposal(false);
      setSegmentReason(`Used closest existing match (confidence: ${segmentConfidence}/10)`);
      clearProposalState();
    }
  };

  const verifyUrls = useCallback((suggestions: UrlSuggestion[]) => {
    suggestions.forEach((s, i) => {
      const d = s.url.replace(/^(https?:\/\/)?(www\.)?/, '');
      const urlToCheck = `https://${d}`;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6000);
      fetch(urlToCheck, { method: 'HEAD', signal: controller.signal, redirect: 'follow' })
        .then(() => {
          clearTimeout(timeout);
          setUrlSuggestions(prev => {
            const u = [...prev]; if (u[i]) u[i] = { ...u[i], verified: true }; return u;
          });
        })
        .catch(() => {
          clearTimeout(timeout);
          const c2 = new AbortController();
          const t2 = setTimeout(() => c2.abort(), 6000);
          fetch(urlToCheck, { method: 'GET', signal: c2.signal, redirect: 'follow' })
            .then(() => { clearTimeout(t2); setUrlSuggestions(prev => { const u = [...prev]; if (u[i]) u[i] = { ...u[i], verified: true }; return u; }); })
            .catch(() => { clearTimeout(t2); setUrlSuggestions(prev => { const u = [...prev]; if (u[i]) u[i] = { ...u[i], verified: false }; return u; }); });
        });
    });
  }, []);

  const suggestWebsites = useCallback(async (companyName: string) => {
    if (companyName.length < 2) { setUrlSuggestions([]); setSearchAttempted(false); return; }
    if (companyName === lastSearchedName.current) return;
    lastSearchedName.current = companyName;
    setLoadingUrls(true);
    try {
      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: 'You are a business research assistant. Given a company name, suggest 3-5 likely website domains. Return valid JSON with a "suggestions" array. Each item must have "url" (just the domain) and "description" (one sentence).' },
            { role: 'user', content: `What are the most likely website domains for "${companyName}"? Give me 3-5 suggestions.` },
          ],
          schema: {
            type: 'object',
            properties: { suggestions: { type: 'array', items: { type: 'object', properties: { url: { type: 'string' }, description: { type: 'string' } }, required: ['url', 'description'] } } },
            required: ['suggestions'],
          },
        }),
      });
      const data = await res.json();
      let suggestions: UrlSuggestion[] = [];
      if (data.schema_data?.suggestions && Array.isArray(data.schema_data.suggestions)) {
        suggestions = data.schema_data.suggestions;
      }
      if (suggestions.length === 0 && data.completion) {
        try {
          const cleaned = data.completion.replace(/```json?\n?/g, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(cleaned);
          if (Array.isArray(parsed.suggestions)) suggestions = parsed.suggestions;
          else if (Array.isArray(parsed)) suggestions = parsed;
        } catch {
          const domainRegex = /\b([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.(?:com|org|net|io|co|biz))\b/gi;
          const matches = data.completion.match(domainRegex);
          if (matches) suggestions = ([...new Set(matches)] as string[]).slice(0, 5).map((url: string) => ({ url: url.toLowerCase(), description: 'Possible company website' }));
        }
      }
      if (suggestions.length === 0) {
        const slug = companyName.toLowerCase().replace(/[^a-z0-9]/g, '');
        suggestions = [
          { url: `${slug}.com`, description: `Most likely domain for ${companyName}` },
          { url: `${slug}.net`, description: 'Alternative domain' },
        ];
      }
      const withStatus = suggestions.map(s => ({ ...s, verified: null as boolean | null }));
      setUrlSuggestions(withStatus);
      verifyUrls(withStatus);
    } catch {
      const slug = companyName.toLowerCase().replace(/[^a-z0-9]/g, '');
      const fallbacks: UrlSuggestion[] = [
        { url: `${slug}.com`, description: `Most likely domain for ${companyName}`, verified: null },
      ];
      setUrlSuggestions(fallbacks);
      verifyUrls(fallbacks);
    } finally {
      setLoadingUrls(false);
      setSearchAttempted(true);
    }
  }, [verifyUrls]);

  // Trigger website suggestions on mount if initial name was provided
  useEffect(() => {
    if (initialName) {
      suggestWebsites(initialName);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps


  // Filtered suggestions for URL autocomplete
  const filteredSuggestions = urlSuggestions.filter((s: UrlSuggestion) => {
    if (!domain.trim()) return true;
    const q = domain.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '');
    return s.url.toLowerCase().includes(q) || s.description.toLowerCase().includes(q);
  });
  const showUrlDropdown = !selectedUrl && (loadingUrls || filteredSuggestions.length > 0);

  const handleNameChange = (text: string) => {
    setName(text);
    setAnalysis(null);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => suggestWebsites(text.trim()), 800);
  };

  const handleSelectUrl = (url: string) => {
    setSelectedUrl(url);
    setDomain(url);
    setAnalysis(null);
    setUrlFieldFocused(false);
    suggestSegment(name.trim(), url);
  };
  const handleAnalyze = async () => {
    if (!orgSettings) {
      Alert.alert('Profile Required', 'Set up your company profile in Settings first to enable AI opportunity analysis.');
      return;
    }
    if (!name.trim()) { Alert.alert('Required', 'Please enter a company name.'); return; }
    setAnalyzing(true);
    try {
      const companyMetadata = [
        domain && `Website: ${domain}`,
        segmentPath && `Segment: ${segmentPath}`,
        email && `Contact email: ${email}`,
        phone && `Contact phone: ${phone}`,
        notes && `Notes: ${notes}`,
      ].filter(Boolean).join('\n');

      const requestBody = JSON.stringify({
        messages: [
          {
            role: 'system',
            content: `You are a Business Development Intelligence Officer specialized in identifying high-probability commercial opportunities in industrial and B2B environments.

OBJECTIVE:
Identify and prioritize concrete business development opportunities for the following context.

TASK:
1. CONTEXT ANALYSIS - Analyze the target company's strategic priorities, operational pressures, and likely initiatives.
2. OPPORTUNITY MAPPING - Identify specific BD entry points, relevant opportunity situations, and timing triggers.
3. ENTRY STRATEGY - For each opportunity: focus area, likely stakeholders (roles not names), best entry angle.
4. COMPETITIVE CONTEXT - Likely competitors, their strengths, and differentiation strategy.
5. PRIORITIZATION - Score each opportunity: likelihood (1-5), speed (1-5), strategic_value (1-5).

CONSTRAINTS:
- Be concrete and actionable (no generic consulting language)
- Prefer operational and project-level opportunities over vague strategy
- If data is incomplete, infer based on industry norms
- Think like a senior BD executive under pressure to generate pipeline in 30 days

You MUST respond with ONLY valid JSON (no markdown, no explanation) in this exact format:
{
  "opportunity_summary": [
    {
      "title": "Short opportunity name",
      "description": "Clear description",
      "bd_focus_area": "Where to focus",
      "trigger": "Why now",
      "stakeholders": ["Role 1", "Role 2"],
      "entry_strategy": "Recommended approach",
      "competitive_context": {
        "likely_competitors": ["Competitor A"],
        "differentiation": "How to win"
      },
      "priority_score": { "likelihood": 4, "speed": 3, "strategic_value": 5 }
    }
  ],
  "segment_insights": ["Key insight 1", "Key insight 2"],
  "recommended_next_actions": ["Action 1", "Action 2"]
}`,
          },
          {
            role: 'user',
            content: `INPUT:
- Company Seeking Opportunities: ${orgSettings.companyName}${orgSettings.companyUrl ? ` (${orgSettings.companyUrl})` : ''}
- Offer / Opportunity Types Sought: ${orgSettings.interests}
- Target Company: ${name.trim()}
- Industrial Segment: ${segmentPath || 'Not classified'}
- Target Company Metadata:
${companyMetadata || 'No additional metadata available'}

Analyze and return the JSON response.`,
          },
        ],
      });

      // Helper: single LLM fetch attempt
      const attemptFetch = async (): Promise<any> => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 60000);
        try {
          const res = await fetch('https://api.a0.dev/ai/llm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: controller.signal,
            body: requestBody,
          });
          clearTimeout(timeout);
          if (!res.ok) {
            console.log('[BD Analysis] API error:', res.status);
            return null;
          }
          const data = await res.json();
          // Treat empty responses as failures to trigger retry
          if (!data.schema_data && !data.completion) {
            console.log('[BD Analysis] Empty response from LLM');
            return null;
          }
          return data;
        } catch (e: any) {
          clearTimeout(timeout);
          console.log('[BD Analysis] Fetch failed:', e.message);
          return null;
        }
      };

      // Attempt with one automatic retry on empty/failed response
      let data = await attemptFetch();
      if (!data) {
        console.log('[BD Analysis] First attempt failed, retrying...');
        data = await attemptFetch();
      }

      if (!data) {
        Alert.alert('Analysis Failed', 'No response received from AI after retry. Please try again.');
        return;
      }

      console.log('[BD Analysis] Response keys:', Object.keys(data));
      console.log('[BD Analysis] has schema_data:', !!data.schema_data);
      console.log('[BD Analysis] has completion:', !!data.completion);
      console.log('[BD Analysis] completion length:', data.completion?.length || 0);

      let result: BdAnalysis | null = null;

      // Strategy 1: Use schema_data if available
      if (data.schema_data && typeof data.schema_data === 'object') {
        result = data.schema_data as BdAnalysis;
      }

      // Strategy 2: Parse completion text as JSON
      if (!result && data.completion) {
        const completion = data.completion;

        const extractionAttempts = [
          // Method 1: Direct parse (response should be pure JSON)
          () => JSON.parse(completion.trim()),
          // Method 2: Strip markdown code fences
          () => {
            const cleaned = completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
            return JSON.parse(cleaned);
          },
          // Method 3: Extract JSON between first { and last }
          () => {
            const firstBrace = completion.indexOf('{');
            const lastBrace = completion.lastIndexOf('}');
            if (firstBrace !== -1 && lastBrace > firstBrace) {
              return JSON.parse(completion.substring(firstBrace, lastBrace + 1));
            }
            throw new Error('No braces found');
          },
        ];

        for (const attempt of extractionAttempts) {
          try {
            const parsed = attempt();
            if (parsed && typeof parsed === 'object') {
              result = parsed as BdAnalysis;
              console.log('[BD Analysis] Parsed successfully');
              break;
            }
          } catch (e: any) {
            console.log('[BD Analysis] Parse attempt failed:', e.message?.substring(0, 80));
          }
        }
      }

      // Validate and fill defaults for any missing fields
      if (result) {
        if (!Array.isArray(result.opportunity_summary)) {
          result.opportunity_summary = [];
        }
        if (!Array.isArray(result.segment_insights)) {
          result.segment_insights = [];
        }
        if (!Array.isArray(result.recommended_next_actions)) {
          result.recommended_next_actions = [];
        }
        result.recommended_next_actions = result.recommended_next_actions.map((a: any) => {
          if (typeof a === 'string') {
            const short = a.length > 60 ? a.substring(0, 57) + '...' : a;
            return { title: short, details: a };
          }
          return { title: a.title || 'Untitled Action', details: a.details || a.description || '' };
        });
        // Ensure each opportunity has valid structure
        result.opportunity_summary = result.opportunity_summary.map((opp: any) => ({
          title: opp.title || 'Untitled Opportunity',
          description: opp.description || '',
          bd_focus_area: opp.bd_focus_area || opp.focus_area || opp.focus || 'General',
          trigger: opp.trigger || 'Market opportunity',
          stakeholders: Array.isArray(opp.stakeholders) ? opp.stakeholders : [],
          entry_strategy: opp.entry_strategy || opp.strategy || '',
          competitive_context: {
            likely_competitors: Array.isArray(opp.competitive_context?.likely_competitors) ? opp.competitive_context.likely_competitors : [],
            differentiation: opp.competitive_context?.differentiation || '',
          },
          priority_score: {
            likelihood: Number(opp.priority_score?.likelihood) || 3,
            speed: Number(opp.priority_score?.speed) || 3,
            strategic_value: Number(opp.priority_score?.strategic_value) || 3,
          },
        }));
        setAnalysis(result);
      } else {
        // Last resort: create a minimal result from the completion text
        if (data.completion) {
          console.log('[BD Analysis] Using completion as plain text fallback');
          setAnalysis({
            opportunity_summary: [{
              title: 'General Opportunity Analysis',
              description: data.completion.substring(0, 500),
              bd_focus_area: 'See description',
              trigger: 'Market analysis',
              stakeholders: [],
              entry_strategy: 'Review the analysis above and identify key contacts.',
              competitive_context: { likely_competitors: [], differentiation: '' },
              priority_score: { likelihood: 3, speed: 3, strategic_value: 3 },
            }],
            segment_insights: ['AI returned unstructured analysis  see opportunity description for details.'],
            recommended_next_actions: [{ title: 'Review analysis', details: 'Review the analysis and extract actionable items.' }],
          });
        } else {
          Alert.alert('Analysis Failed', 'No response received from AI. Please try again.');
        }
      }
    } catch {
      Alert.alert('Error', 'Failed to analyze. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleSave = async () => {
    if (!name.trim()) { Alert.alert('Required', 'Please enter a company name.'); return; }
    if (!segmentId) { Alert.alert('Required', 'Please select a market segment.'); return; }
    setSaving(true);
    try {
      let fullNotes = notes;
      if (analysis) {
        const aiNotes = [
          '--- AI BD Analysis ---',
          '',
          'SEGMENT INSIGHTS:',
          ...analysis.segment_insights.map((s, i) => `${i + 1}. ${s}`),
          '',
          'OPPORTUNITIES:',
          ...analysis.opportunity_summary.map((opp, i) =>
            `${i + 1}. ${opp.title}\n   ${opp.description}\n   Focus: ${opp.bd_focus_area}\n   Trigger: ${opp.trigger}\n   Entry: ${opp.entry_strategy}\n   Priority: L${opp.priority_score.likelihood}/S${opp.priority_score.speed}/V${opp.priority_score.strategic_value}`
          ),
          '',
          'NEXT ACTIONS:',
          ...analysis.recommended_next_actions.map((a, i) => `${i + 1}. ${a.title || a.details}`),
        ].join('\n');
        fullNotes = fullNotes ? `${fullNotes}\n\n${aiNotes}` : aiNotes;
      }

      const companyId = await createCompany({
        name: name.trim(),
        domain: domain.trim() || undefined,
        industry: segmentPath || undefined,
        email: email.trim() || undefined,
        phone: phone.trim() || undefined,
        notes: fullNotes.trim() || undefined,
        segmentId: segmentId || undefined,
      });

      // Save insights report to the company record
      if (analysis) {
        try {
          await saveInsights({ id: companyId, insightsReport: JSON.stringify(analysis) });
        } catch (e) {
          console.error('[SaveInsights] Error:', e);
        }

        // Push selected recommended actions to the Actions list
        if (selectedActions.size > 0 && analysis.recommended_next_actions) {
          try {
            const actions = analysis.recommended_next_actions;
            let pushed = 0;
            for (const idx of Array.from(selectedActions) as number[]) {
              const action = actions[idx];
              if (action) {
                await createAction({
                  title: action.title || 'BD Action',
                  description: action.details || '',
                  companyId,
                  priority: 'medium',
                });
                pushed++;
              }
            }
            if (pushed > 0) {
              console.log(`[BD Actions] Pushed ${pushed} actions for ${name.trim()}`);
            }
          } catch (e) {
            console.error('[BD Actions] Error pushing actions:', e);
          }
        }
      }

      // If this company was created from the contact import flow,
      // auto-link all contacts with the matching pendingCompanyName
      if (initialName) {
        try {
          const linked = await linkPendingContacts({
            companyId,
            companyName: initialName,
          });
          if (linked > 0) {
            Alert.alert(
              'Company Created',
              `${name.trim()} created and ${linked} contact${linked > 1 ? 's' : ''} automatically linked.`,
            );
          }
        } catch (e) {
          console.error('[LinkPending] Error:', e);
        }
        // Navigate back to the contacts list instead of showing CompanyDetail in the wrong tab
        navigation.goBack();
      } else if (returnToContactForm) {
        // Return to contact creation flow with the new company
        navigation.navigate('ContactsList', { returnToContactForm: true });
      } else {
        navigation.replace('CompanyDetail', { id: companyId });
      }
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setSaving(false);
    }
  };

  const hasProfile = !!orgSettings?.companyName;

  const renderPriorityDots = (score: number) => {
    return (
      <View style={styles.priorityDots}>
        {[1, 2, 3, 4, 5].map(n => (
          <View key={n} style={[styles.priorityDot, n <= score ? styles.priorityDotActive : styles.priorityDotInactive]} />
        ))}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="close" size={24} color={colors.textSecondary} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>New Company</Text>
          <TouchableOpacity
            style={[styles.saveBtn, (!name.trim() || !segmentId || saving) && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={!name.trim() || !segmentId || saving}
          >
            {saving ? <ActivityIndicator size="small" color={colors.white} /> : <Text style={styles.saveBtnText}>Save</Text>}
          </TouchableOpacity>
        </View>

        {/* Pinned: Company Name */}
        <View style={styles.pinnedSection}>
          <View style={styles.field}>
            <Text style={styles.label}>Company Name *</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter company name..."
              placeholderTextColor={colors.textTertiary}
              value={name}
              onChangeText={handleNameChange}
              autoFocus
            />
          </View>
        </View>

        <ScrollView style={styles.body} keyboardShouldPersistTaps="handled">
          {/* Website URL with autocomplete */}
          <View style={[styles.field, { zIndex: 10 }]}>
            <Text style={styles.label}>Website URL</Text>
            <View style={[styles.urlInputRow, showUrlDropdown && styles.urlInputRowFocused]}>
              <Ionicons name="globe-outline" size={16} color={urlFieldFocused ? colors.primary : colors.textTertiary} style={{ marginLeft: spacing.md }} />
              <TextInput
                style={styles.urlInputField}
                placeholder="Search or enter URL..."
                placeholderTextColor={colors.textTertiary}
                value={domain}
                onChangeText={(t: string) => { setDomain(t); setSelectedUrl(null); }}
                onFocus={() => setUrlFieldFocused(true)}
                onBlur={() => {
                  setTimeout(() => setUrlFieldFocused(false), 200);
                  if (domain.trim() && name.trim()) suggestSegment(name.trim(), domain.trim());
                }}
                autoCapitalize="none"
                keyboardType="url"
              />
              {domain.trim() ? (
                <TouchableOpacity
                  onPress={() => { setDomain(''); setSelectedUrl(null); setUrlFieldFocused(true); }}
                  style={{ padding: spacing.sm }}
                >
                  <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                </TouchableOpacity>
              ) : loadingUrls ? (
                <ActivityIndicator size="small" color={colors.primary} style={{ marginRight: spacing.md }} />
              ) : null}
            </View>

            {/* Autocomplete dropdown */}
            {showUrlDropdown && (
              <View style={styles.urlDropdown}>
                <ScrollView nestedScrollEnabled keyboardShouldPersistTaps="handled" style={{ maxHeight: 220 }}>
                {loadingUrls && filteredSuggestions.length === 0 && (
                  <View style={styles.urlDropdownLoading}>
                    <ActivityIndicator size="small" color={colors.primary} />
                    <Text style={styles.urlDropdownLoadingText}>Finding websites for "{name.trim()}"...</Text>
                  </View>
                )}
                {filteredSuggestions.map((s: UrlSuggestion, i: number) => (
                  <TouchableOpacity
                    key={i}
                    style={[
                      styles.urlDropdownItem,
                      i < filteredSuggestions.length - 1 && styles.urlDropdownItemBorder,
                    ]}
                    onPress={() => handleSelectUrl(s.url)}
                  >
                    <Ionicons
                      name={s.verified === true ? 'checkmark-circle' : s.verified === false ? 'close-circle' : 'globe-outline'}
                      size={16}
                      color={s.verified === true ? colors.success : s.verified === false ? colors.danger : colors.textTertiary}
                    />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.urlDropdownUrl} numberOfLines={1}>{s.url}</Text>
                      <Text style={styles.urlDropdownDesc} numberOfLines={1}>{s.description}</Text>
                    </View>
                    <View style={styles.urlDropdownRight}>
                      {s.verified === null && <ActivityIndicator size="small" color={colors.textTertiary} />}
                      {s.verified === true && (
                        <View style={styles.urlBadge}>
                          <Text style={[styles.urlBadgeText, { color: colors.success }]}>Live</Text>
                        </View>
                      )}
                      {s.verified === false && (
                        <View style={styles.urlBadge}>
                          <Text style={[styles.urlBadgeText, { color: colors.danger }]}>N/A</Text>
                        </View>
                      )}
                      <Ionicons name="arrow-forward" size={14} color={colors.textTertiary} />
                    </View>
                  </TouchableOpacity>
                ))}
                </ScrollView>
              </View>
            )}

            {/* Selected URL chip */}
            {selectedUrl && (
              <View style={styles.selectedUrlChip}>
                <Ionicons name="checkmark-circle" size={14} color={colors.success} />
                <Text style={styles.selectedUrlText} numberOfLines={1}>{selectedUrl}</Text>
                <TouchableOpacity onPress={() => { setSelectedUrl(null); setDomain(''); }}>
                  <Ionicons name="close" size={14} color={colors.textTertiary} />
                </TouchableOpacity>
              </View>
            )}
          </View>
          {/* Market Segment */}
          <View style={styles.field}>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: spacing.xs }}>
              <Text style={[styles.label, { marginBottom: 0 }]}>Market Segment *</Text>
              {suggestingSegment && (
                <View style={{ flexDirection: 'row', alignItems: 'center', marginLeft: spacing.sm }}>
                  <ActivityIndicator size="small" color={colors.primary} />
                  <Text style={{ fontSize: fontSize.xs, color: colors.primary, marginLeft: 4 }}>AI classifying...</Text>
                </View>
              )}
            </View>
            <SegmentPicker
              value={segmentId}
              valuePath={segmentPath}
              onChange={(segId: any) => {
                setSegmentId(segId);
                if (segId && allSegments) {
                  const path: string[] = [];
                  let cur = allSegments.find((s: any) => s._id === segId);
                  while (cur) { path.unshift(cur.name); cur = cur.parentId ? allSegments.find((s: any) => s._id === cur!.parentId) : undefined; }
                  setSegmentPath(path.join(' > '));
                } else { setSegmentPath(undefined); }
                setSegmentReason('');
                setSegmentKeywords([]);
                clearProposalState();
              }}
            />

            {/* AI Proposal Card  new segment suggested */}
            {isSegmentProposal && !segmentId && (
              <View style={styles.proposalCard}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 8 }}>
                  <Ionicons name="bulb" size={14} color={colors.accent} />
                  <Text style={{ fontSize: fontSize.xs, fontWeight: '700', color: colors.accent }}>
                    New Segment Suggested
                  </Text>
                  <View style={styles.confidenceBadge}>
                    <Text style={styles.confidenceText}>Fit: {segmentConfidence}/10</Text>
                  </View>
                </View>

                <Text style={{ fontSize: fontSize.xs, color: colors.textSecondary, marginBottom: 6, lineHeight: 16 }}>
                  No existing segment is a strong match. AI proposes:
                </Text>

                <View style={styles.proposedPathContainer}>
                  <View style={styles.proposedPathLevel}>
                    <Text style={styles.proposedPathLevelLabel}>Sector</Text>
                    <Text style={styles.proposedPathLevelValue}>{proposedSector}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={12} color={colors.textTertiary} />
                  <View style={styles.proposedPathLevel}>
                    <Text style={styles.proposedPathLevelLabel}>Sub-sector</Text>
                    <Text style={styles.proposedPathLevelValue}>{proposedSubSector}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={12} color={colors.textTertiary} />
                  <View style={styles.proposedPathLevel}>
                    <Text style={styles.proposedPathLevelLabel}>Niche</Text>
                    <Text style={styles.proposedPathLevelValue}>{proposedNiche}</Text>
                  </View>
                </View>

                {segmentReason ? (
                  <Text style={{ fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 16, marginBottom: 8 }}>
                    {segmentReason}
                  </Text>
                ) : null}

                {segmentKeywords.length > 0 && (
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 10 }}>
                    {segmentKeywords.map((kw, idx) => (
                      <View key={idx} style={styles.keywordChip}><Text style={styles.keywordText}>{kw}</Text></View>
                    ))}
                  </View>
                )}

                <View style={styles.proposalActions}>
                  <TouchableOpacity
                    style={styles.acceptProposalBtn}
                    onPress={handleAcceptProposal}
                    disabled={creatingSegment}
                  >
                    {creatingSegment ? (
                      <ActivityIndicator size="small" color={colors.white} />
                    ) : (
                      <>
                        <Ionicons name="checkmark-circle" size={16} color={colors.white} />
                        <Text style={styles.acceptProposalBtnText}>Create Segment</Text>
                      </>
                    )}
                  </TouchableOpacity>

                  {fallbackSegmentPath && (
                    <TouchableOpacity style={styles.useFallbackBtn} onPress={handleUseFallback}>
                      <Ionicons name="arrow-undo" size={14} color={colors.primary} />
                      <Text style={styles.useFallbackBtnText} numberOfLines={1}>
                        Use: {fallbackSegmentPath}
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}

            {/* AI Classification reason  existing match */}
            {segmentReason && !isSegmentProposal ? (
              <View style={styles.segmentAiCard}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                  <Ionicons name="sparkles" size={12} color={colors.primary} />
                  <Text style={{ fontSize: fontSize.xs, fontWeight: '600', color: colors.primary }}>AI Classification</Text>
                  {segmentConfidence > 0 && (
                    <View style={[styles.confidenceBadge, segmentConfidence >= 8 ? styles.confidenceHigh : segmentConfidence >= 6 ? styles.confidenceMed : styles.confidenceLow]}>
                      <Text style={styles.confidenceText}>Fit: {segmentConfidence}/10</Text>
                    </View>
                  )}
                </View>
                <Text style={{ fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 16 }}>{segmentReason}</Text>
                {segmentKeywords.length > 0 && (
                  <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginTop: 6 }}>
                    {segmentKeywords.map((kw, idx) => (
                      <View key={idx} style={styles.keywordChip}><Text style={styles.keywordText}>{kw}</Text></View>
                    ))}
                  </View>
                )}

                {/* Low confidence  offer to create a new segment */}
                {segmentConfidence > 0 && segmentConfidence < 7 && (
                  <View style={{ marginTop: spacing.sm, paddingTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 6 }}>
                      <Ionicons name="warning" size={13} color={colors.warning} />
                      <Text style={{ fontSize: fontSize.xs, fontWeight: '600', color: colors.warning }}>
                        Poor fit  this segment doesn't match the company's industry
                      </Text>
                    </View>
                    <TouchableOpacity
                      style={{
                        flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xs,
                        backgroundColor: colors.accent, paddingVertical: spacing.sm, paddingHorizontal: spacing.md,
                        borderRadius: radius.md,
                      }}
                      onPress={() => {
                        // Force re-run: clear the segment and re-trigger with proposal forced
                        setSegmentId(undefined);
                        setSegmentPath(undefined);
                        lastSegmentSearch.current = '';
                        clearProposalState();
                        setSegmentReason('');
                        setSegmentKeywords([]);
                        setSuggestingSegment(true);
                        (async () => {
                          try {
                            const result = await suggestSegmentAction({ companyName: name.trim(), companyDomain: domain.trim() });
                            if (result) {
                              setSegmentConfidence(result.confidence);
                              setSegmentReason(result.reason);
                              setSegmentKeywords(result.keywords);
                              if (result.companyDimensions) setCompanyDimensions(result.companyDimensions);
                              // Force as proposal regardless  user explicitly asked for new segment
                              if (result.proposedSector && result.proposedSubSector && result.proposedNiche) {
                                setIsSegmentProposal(true);
                                setSegmentPath(result.isProposal ? result.segmentPath : `${result.proposedSector} > ${result.proposedSubSector} > ${result.proposedNiche}`);
                                setProposedSector(result.proposedSector);
                                setProposedSubSector(result.proposedSubSector);
                                setProposedNiche(result.proposedNiche);
                                setProposedColor(result.proposedColor || undefined);
                                setFallbackSegmentId(result.segmentId || result.fallbackSegmentId || undefined);
                                setFallbackSegmentPath(result.segmentPath || result.fallbackSegmentPath || undefined);
                              } else if (result.isProposal) {
                                setIsSegmentProposal(true);
                                setSegmentPath(result.segmentPath);
                                setProposedSector(result.proposedSector || '');
                                setProposedSubSector(result.proposedSubSector || '');
                                setProposedNiche(result.proposedNiche || '');
                                setProposedColor(result.proposedColor || undefined);
                                setFallbackSegmentId(result.fallbackSegmentId || undefined);
                                setFallbackSegmentPath(result.fallbackSegmentPath || undefined);
                              } else {
                                // AI still didn't propose  use existing result but keep showing it
                                setSegmentId(result.segmentId);
                                setSegmentPath(result.segmentPath);
                              }
                            }
                          } catch (err: any) {
                            console.log('[AI Reclassify] Error:', err?.message);
                          } finally {
                            setSuggestingSegment(false);
                          }
                        })();
                      }}
                    >
                      <Ionicons name="bulb" size={16} color={colors.white} />
                      <Text style={{ color: colors.white, fontWeight: '600', fontSize: fontSize.sm }}>
                        Create New Segment from Keywords
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            ) : null}
          </View>

          {/* Company Intel Card  extracted dimensions */}
          {companyDimensions && (
            <View style={styles.intelCard}>
              <View style={styles.intelHeader}>
                <Ionicons name="business" size={16} color={colors.info} />
                <Text style={styles.intelTitle}>Company Intel</Text>
                <Text style={styles.intelSubtitle}>(AI-extracted from website)</Text>
              </View>

              {companyDimensions.description && (
                <Text style={styles.intelDescription}>{companyDimensions.description}</Text>
              )}

              <View style={styles.intelGrid}>
                {companyDimensions.revenue && (
                  <View style={styles.intelItem}>
                    <Ionicons name="cash-outline" size={14} color={colors.success} />
                    <View>
                      <Text style={styles.intelItemLabel}>Revenue</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.revenue}</Text>
                    </View>
                  </View>
                )}
                {companyDimensions.employees && (
                  <View style={styles.intelItem}>
                    <Ionicons name="people-outline" size={14} color={colors.primary} />
                    <View>
                      <Text style={styles.intelItemLabel}>Employees</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.employees}</Text>
                    </View>
                  </View>
                )}
                {companyDimensions.sites && (
                  <View style={styles.intelItem}>
                    <Ionicons name="location-outline" size={14} color={colors.accent} />
                    <View>
                      <Text style={styles.intelItemLabel}>Sites / Locations</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.sites}</Text>
                    </View>
                  </View>
                )}
                {companyDimensions.capitalization && (
                  <View style={styles.intelItem}>
                    <Ionicons name="trending-up-outline" size={14} color={colors.warning} />
                    <View>
                      <Text style={styles.intelItemLabel}>Market Cap</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.capitalization}</Text>
                    </View>
                  </View>
                )}
                {companyDimensions.headquarters && (
                  <View style={styles.intelItem}>
                    <Ionicons name="flag-outline" size={14} color={colors.textSecondary} />
                    <View>
                      <Text style={styles.intelItemLabel}>Headquarters</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.headquarters}</Text>
                    </View>
                  </View>
                )}
                {companyDimensions.founded && (
                  <View style={styles.intelItem}>
                    <Ionicons name="calendar-outline" size={14} color={colors.textSecondary} />
                    <View>
                      <Text style={styles.intelItemLabel}>Founded</Text>
                      <Text style={styles.intelItemValue}>{companyDimensions.founded}</Text>
                    </View>
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Email + Phone (with AI suggestions) */}
          <View style={styles.row}>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor={colors.textTertiary}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
              />
              {suggestedEmails.length > 1 && (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 4 }}>
                  {suggestedEmails.map((e, i) => (
                    <TouchableOpacity key={i} onPress={() => setEmail(e)} style={styles.contactChip}>
                      <Text style={[styles.contactChipText, email === e && { color: colors.primary, fontWeight: '700' }]} numberOfLines={1}>{e}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}
            </View>
            <View style={{ width: spacing.md }} />
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={styles.label}>Phone</Text>
              <TextInput
                style={styles.input}
                placeholder="Phone"
                placeholderTextColor={colors.textTertiary}
                value={phone}
                onChangeText={setPhone}
                keyboardType="phone-pad"
              />
              {suggestedPhones.length > 1 && (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 4 }}>
                  {suggestedPhones.map((p, i) => (
                    <TouchableOpacity key={i} onPress={() => setPhone(p)} style={styles.contactChip}>
                      <Text style={[styles.contactChipText, phone === p && { color: colors.primary, fontWeight: '700' }]} numberOfLines={1}>{p}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Notes</Text>
            <TextInput
              style={[styles.input, styles.multiline]}
              placeholder="Notes..."
              placeholderTextColor={colors.textTertiary}
              value={notes}
              onChangeText={setNotes}
              multiline
              numberOfLines={3}
            />
          </View>

          {/* AI BD Analysis Section */}
          {hasProfile && (
            <View style={styles.aiSection}>
              <View style={styles.aiHeader}>
                <Ionicons name="bulb" size={18} color={colors.accent} />
                <Text style={styles.aiTitle}>BD Intelligence</Text>
              </View>

              {!analysis && !analyzing && (
                <TouchableOpacity style={styles.analyzeBtn} onPress={handleAnalyze} disabled={!name.trim()}>
                  <Ionicons name="sparkles" size={16} color={colors.white} />
                  <Text style={styles.analyzeBtnText}>Analyze Opportunities</Text>
                </TouchableOpacity>
              )}

              {analyzing && (
                <View style={styles.analyzingContainer}>
                  <ActivityIndicator size="small" color={colors.accent} />
                  <Text style={styles.analyzingText}>
                    BD Intelligence Officer analyzing {name.trim()}...
                  </Text>
                </View>
              )}

              {analysis && (
                <View style={styles.analysisResults}>
                  {/* Segment Insights */}
                  {analysis.segment_insights.length > 0 && (
                    <View style={styles.insightsCard}>
                      <Text style={styles.sectionLabel}>SEGMENT INSIGHTS</Text>
                      {analysis.segment_insights.map((insight, i) => (
                        <View key={i} style={styles.insightRow}>
                          <Ionicons name="analytics" size={12} color={colors.primary} />
                          <Text style={styles.insightText}>{insight}</Text>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Opportunities */}
                  <Text style={styles.sectionLabel}>
                    OPPORTUNITIES ({analysis.opportunity_summary.length})
                  </Text>
                  {analysis.opportunity_summary
                    .sort((a, b) => {
                      const scoreA = a.priority_score.likelihood + a.priority_score.speed + a.priority_score.strategic_value;
                      const scoreB = b.priority_score.likelihood + b.priority_score.speed + b.priority_score.strategic_value;
                      return scoreB - scoreA;
                    })
                    .map((opp, i) => (
                    <View key={i} style={styles.oppCard}>
                      <View style={styles.oppHeader}>
                        <View style={styles.oppRank}>
                          <Text style={styles.oppRankText}>{i + 1}</Text>
                        </View>
                        <Text style={styles.oppTitle}>{opp.title}</Text>
                      </View>

                      <Text style={styles.oppDescription}>{opp.description}</Text>

                      <View style={styles.oppMeta}>
                        <View style={styles.oppMetaItem}>
                          <Ionicons name="locate" size={11} color={colors.primary} />
                          <Text style={styles.oppMetaLabel}>Focus:</Text>
                          <Text style={styles.oppMetaValue}>{opp.bd_focus_area}</Text>
                        </View>
                        <View style={styles.oppMetaItem}>
                          <Ionicons name="flash" size={11} color={colors.warning} />
                          <Text style={styles.oppMetaLabel}>Trigger:</Text>
                          <Text style={styles.oppMetaValue}>{opp.trigger}</Text>
                        </View>
                      </View>

                      {/* Stakeholders */}
                      <View style={styles.stakeholders}>
                        <Ionicons name="people" size={11} color={colors.textTertiary} />
                        {opp.stakeholders.map((s, j) => (
                          <View key={j} style={styles.stakeholderChip}>
                            <Text style={styles.stakeholderText}>{s}</Text>
                          </View>
                        ))}
                      </View>

                      {/* Entry Strategy */}
                      <View style={styles.entryStrategy}>
                        <Ionicons name="arrow-forward-circle" size={13} color={colors.success} />
                        <Text style={styles.entryText}>{opp.entry_strategy}</Text>
                      </View>

                      {/* Competitive Context */}
                      {opp.competitive_context && (
                        <View style={styles.competitiveCtx}>
                          <Text style={styles.competitiveTitle}>Competitive Context</Text>
                          {opp.competitive_context.likely_competitors.length > 0 && (
                            <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 4, marginBottom: 4 }}>
                              {opp.competitive_context.likely_competitors.map((c, j) => (
                                <View key={j} style={styles.competitorChip}>
                                  <Text style={styles.competitorText}>{c}</Text>
                                </View>
                              ))}
                            </View>
                          )}
                          <Text style={styles.differentiationText}>
                            <Text style={{ fontWeight: '600' }}>Differentiate: </Text>
                            {opp.competitive_context.differentiation}
                          </Text>
                        </View>
                      )}

                      {/* Priority Scores */}
                      <View style={styles.priorityRow}>
                        <View style={styles.priorityItem}>
                          <Text style={styles.priorityLabel}>Likelihood</Text>
                          {renderPriorityDots(opp.priority_score.likelihood)}
                        </View>
                        <View style={styles.priorityItem}>
                          <Text style={styles.priorityLabel}>Speed</Text>
                          {renderPriorityDots(opp.priority_score.speed)}
                        </View>
                        <View style={styles.priorityItem}>
                          <Text style={styles.priorityLabel}>Value</Text>
                          {renderPriorityDots(opp.priority_score.strategic_value)}
                        </View>
                      </View>
                    </View>
                  ))}

                  {/* Next Actions */}
                  {analysis.recommended_next_actions.length > 0 && (
                    <View style={styles.nextActionsCard}>
                      <Text style={styles.sectionLabel}>RECOMMENDED NEXT ACTIONS</Text>
                      <Text style={styles.selectHint}>Select actions to push to your Actions list when saving</Text>
                      {analysis.recommended_next_actions.map((action: any, i: number) => (
                        <TouchableOpacity
                          key={i}
                          style={styles.actionRow}
                          onPress={() => setSelectedActions(prev => {
                            const next = new Set(prev);
                            next.has(i) ? next.delete(i) : next.add(i);
                            return next;
                          })}
                        >
                          <Ionicons
                            name={selectedActions.has(i) ? 'checkbox' : 'square-outline'}
                            size={20}
                            color={selectedActions.has(i) ? colors.primary : colors.textTertiary}
                          />
                          <View style={{ flex: 1 }}>
                            <Text style={[styles.bulletText, { fontWeight: '600' }]}>{action.title}</Text>
                            {action.details ? <Text style={[styles.bulletText, { color: colors.textSecondary, marginTop: 2 }]}>{action.details}</Text> : null}
                          </View>
                        </TouchableOpacity>
                      ))}
                      {selectedActions.size > 0 && (
                        <View style={styles.pushInfo}>
                          <Ionicons name="information-circle-outline" size={14} color={colors.primary} />
                          <Text style={styles.pushInfoText}>
                            {selectedActions.size} action{selectedActions.size > 1 ? 's' : ''} will be pushed to your Actions list when you save
                          </Text>
                        </View>
                      )}
                    </View>
                  )}

                  <TouchableOpacity style={styles.reanalyzeBtn} onPress={handleAnalyze}>
                    <Ionicons name="refresh" size={14} color={colors.primary} />
                    <Text style={styles.reanalyzeBtnText}>Re-analyze</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}

          {!hasProfile && name.trim().length > 0 && (
            <View style={styles.profilePrompt}>
              <Ionicons name="information-circle" size={18} color={colors.info} />
              <Text style={styles.profilePromptText}>
                Set up your company profile in Settings to unlock AI-powered BD intelligence.
              </Text>
            </View>
          )}

          <View style={{ height: 60 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.white,
  },
  headerTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  saveBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: radius.md },
  saveBtnDisabled: { opacity: 0.5 },
  saveBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.md },
  body: { flex: 1, padding: spacing.lg },
  field: { marginBottom: spacing.lg },
  label: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md,
    color: colors.textPrimary, ...shadow.sm,
  },
  multiline: { height: 80, textAlignVertical: 'top' },
  row: { flexDirection: 'row' },

  pinnedSection: {
    flexDirection: 'column', gap: spacing.sm, paddingHorizontal: spacing.lg,
    paddingTop: spacing.md, paddingBottom: spacing.sm,
    backgroundColor: colors.bg, borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  suggestionsSection: {
    backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.md, ...shadow.sm,
  },
  suggestionsHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginBottom: spacing.sm },
  suggestionsLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.primary, flex: 1 },
  suggestionsScroll: { maxHeight: 180 },
  suggestionChip: {
    flexDirection: 'row', alignItems: 'center', padding: spacing.sm,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.primaryLight,
    backgroundColor: colors.primaryLight + '40', marginBottom: spacing.xs,
    justifyContent: 'space-between',
  },
  suggestionChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  suggestionChipVerified: { borderColor: colors.success + '60', backgroundColor: colors.successLight + '40' },
  suggestionChipFailed: { borderColor: colors.border, backgroundColor: colors.bg, opacity: 0.6 },
  suggestionContent: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1, minWidth: 0 },
  suggestionTextContainer: { flex: 1, minWidth: 0 },
  suggestionUrl: { fontSize: 12, fontWeight: '600', color: colors.primary },
  suggestionDesc: { fontSize: 11, color: colors.textSecondary, marginTop: 2 },
  noSuggestionsText: { fontSize: fontSize.sm, color: colors.textTertiary, fontStyle: 'italic', paddingVertical: spacing.sm },
  verifiedBadge: { flexDirection: 'row', alignItems: 'center', gap: 2 },
  verifiedText: { fontSize: fontSize.xs, color: colors.success, fontWeight: '600' },
  unverifiedText: { fontSize: fontSize.xs, color: colors.danger, fontWeight: '600' },
  suggestionStatus: { flexDirection: 'row', alignItems: 'center', marginLeft: spacing.sm },

  // Contact chips (email/phone suggestions)
  contactChip: {
    backgroundColor: colors.primaryLight + '50', paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 12, marginRight: 4,
  },
  contactChipText: { fontSize: 10, color: colors.textSecondary },

  // AI Section
  aiSection: {
    marginBottom: spacing.lg, backgroundColor: colors.accentLight,
    borderRadius: radius.lg, padding: spacing.lg, borderWidth: 1, borderColor: colors.accent + '30',
  },
  aiHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  aiTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.accent },
  analyzeBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    backgroundColor: colors.accent, padding: spacing.md, borderRadius: radius.md,
  },
  analyzeBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.md },
  analyzingContainer: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md },
  analyzingText: { flex: 1, fontSize: fontSize.sm, color: colors.accent, fontStyle: 'italic' },
  analysisResults: { marginTop: spacing.sm },

  // Insights
  insightsCard: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md, marginBottom: spacing.md,
  },
  insightRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs, marginTop: spacing.xs },
  insightText: { flex: 1, fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 16 },

  sectionLabel: {
    fontSize: 11, fontWeight: '700', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.sm,
  },

  // Opportunity cards
  oppCard: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md,
    marginBottom: spacing.sm, borderLeftWidth: 3, borderLeftColor: colors.accent,
  },
  oppHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.xs },
  oppRank: {
    width: 22, height: 22, borderRadius: 11, backgroundColor: colors.accent,
    justifyContent: 'center', alignItems: 'center',
  },
  oppRankText: { fontSize: 11, fontWeight: '700', color: colors.white },
  oppTitle: { flex: 1, fontSize: fontSize.sm, fontWeight: '700', color: colors.textPrimary },
  oppDescription: { fontSize: fontSize.xs, color: colors.textSecondary, lineHeight: 17, marginBottom: spacing.sm },

  oppMeta: { marginBottom: spacing.sm },
  oppMetaItem: { flexDirection: 'row', alignItems: 'flex-start', gap: 4, marginBottom: 3 },
  oppMetaLabel: { fontSize: 11, fontWeight: '600', color: colors.textTertiary },
  oppMetaValue: { flex: 1, fontSize: 11, color: colors.textSecondary },

  stakeholders: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 4, marginBottom: spacing.sm },
  stakeholderChip: { backgroundColor: colors.primaryLight + '50', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 },
  stakeholderText: { fontSize: 10, color: colors.primary, fontWeight: '500' },

  entryStrategy: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.xs,
    backgroundColor: colors.successLight, padding: spacing.sm, borderRadius: radius.sm, marginBottom: spacing.sm,
  },
  entryText: { flex: 1, fontSize: fontSize.xs, color: colors.success, fontWeight: '500', lineHeight: 16 },

  competitiveCtx: {
    backgroundColor: colors.bg, padding: spacing.sm, borderRadius: radius.sm, marginBottom: spacing.sm,
  },
  competitiveTitle: { fontSize: 10, fontWeight: '700', color: colors.textTertiary, textTransform: 'uppercase', marginBottom: 4 },
  competitorChip: { backgroundColor: colors.warningLight + '60', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 8 },
  competitorText: { fontSize: 10, color: colors.warning, fontWeight: '500' },
  differentiationText: { fontSize: 11, color: colors.textSecondary, lineHeight: 15 },

  // Priority scores
  priorityRow: { flexDirection: 'row', justifyContent: 'space-between', paddingTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border },
  priorityItem: { alignItems: 'center', flex: 1 },
  priorityLabel: { fontSize: 9, fontWeight: '600', color: colors.textTertiary, textTransform: 'uppercase', marginBottom: 3 },
  priorityDots: { flexDirection: 'row', gap: 3 },
  priorityDot: { width: 8, height: 8, borderRadius: 4 },
  priorityDotActive: { backgroundColor: colors.accent },
  priorityDotInactive: { backgroundColor: colors.border },

  // Next actions
  nextActionsCard: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md, marginTop: spacing.sm,
  },
  selectHint: {
    fontSize: fontSize.xs, color: colors.textTertiary, fontStyle: 'italic', marginBottom: spacing.sm,
  },
  actionRow: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm,
    marginBottom: spacing.sm, paddingVertical: spacing.xs,
  },
  pushInfo: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.xs,
    backgroundColor: colors.primaryLight + '40', padding: spacing.sm,
    borderRadius: radius.sm, marginTop: spacing.xs,
  },
  pushInfoText: {
    fontSize: fontSize.xs, color: colors.primary, fontWeight: '500', flex: 1,
  },
  bulletDot: { fontSize: 10, color: colors.textSecondary, fontWeight: '700' },
  bulletText: { flex: 1, fontSize: fontSize.xs, color: colors.textPrimary, lineHeight: 16 },

  reanalyzeBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.xs, paddingVertical: spacing.sm, marginTop: spacing.sm,
  },
  reanalyzeBtnText: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '600' },

  profilePrompt: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.sm,
    backgroundColor: colors.infoLight, padding: spacing.md, borderRadius: radius.md, marginBottom: spacing.lg,
  },
  profilePromptText: { flex: 1, fontSize: fontSize.sm, color: colors.info },

  segmentAiCard: {
    marginTop: spacing.sm, backgroundColor: colors.primaryLight + '30', borderRadius: radius.md,
    padding: spacing.sm, borderLeftWidth: 3, borderLeftColor: colors.primary,
  },
  keywordChip: { backgroundColor: colors.primaryLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 10 },
  keywordText: { fontSize: 10, color: colors.primary, fontWeight: '500' },

  // Proposal card styles
  proposalCard: {
    marginTop: spacing.sm,
    backgroundColor: colors.accentLight,
    borderRadius: radius.md,
    padding: spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: colors.accent,
  },
  confidenceBadge: {
    backgroundColor: colors.warningLight,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
    marginLeft: 'auto',
  },
  confidenceHigh: { backgroundColor: colors.successLight },
  confidenceMed: { backgroundColor: colors.warningLight },
  confidenceLow: { backgroundColor: colors.dangerLight || '#FEE2E2' },
  confidenceText: { fontSize: 9, fontWeight: '700', color: colors.textSecondary },
  proposedPathContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginBottom: 8,
    gap: 4,
  },
  proposedPathLevel: {
    flex: 1,
    alignItems: 'center',
  },
  proposedPathLevelLabel: {
    fontSize: 8,
    fontWeight: '700',
    color: colors.textTertiary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  proposedPathLevelValue: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.textPrimary,
    textAlign: 'center',
  },
  proposalActions: {
    gap: spacing.sm,
  },
  acceptProposalBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    backgroundColor: colors.accent,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
  },
  acceptProposalBtnText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: fontSize.sm,
  },
  useFallbackBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.primary + '40',
    backgroundColor: colors.white,
  },
  useFallbackBtnText: {
    color: colors.primary,
    fontWeight: '500',
    fontSize: fontSize.xs,
    flex: 1,
  },

  // Company Intel card styles
  intelCard: {
    marginBottom: spacing.lg,
    backgroundColor: colors.infoLight,
    borderRadius: radius.lg,
    padding: spacing.md,
    borderWidth: 1,
    borderColor: colors.info + '30',
  },
  intelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginBottom: spacing.sm,
  },
  intelTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.info,
  },
  intelSubtitle: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
    fontStyle: 'italic',
  },
  intelDescription: {
    fontSize: fontSize.sm,
    color: colors.textPrimary,
    lineHeight: 20,
    marginBottom: spacing.md,
  },
  intelGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  intelItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.xs,
    backgroundColor: colors.white,
    borderRadius: radius.md,
    padding: spacing.sm,
    minWidth: '45%' as any,
    flex: 1,
  },
  intelItemLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: colors.textTertiary,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  intelItemValue: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textPrimary,
    marginTop: 1,
  urlInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    ...shadow.sm,
  },
  urlInputRowFocused: {
    borderColor: colors.primary,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
  },
  urlInputField: {
    flex: 1,
    padding: spacing.md,
    fontSize: fontSize.md,
    color: colors.textPrimary,
  },
  urlDropdown: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderTopWidth: 0,
    borderColor: colors.primary,
    borderBottomLeftRadius: radius.md,
    borderBottomRightRadius: radius.md,
    ...shadow.md,
  },
  // ... existing code ...

  urlDropdownLoading: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    padding: spacing.md,
  },
  urlDropdownLoadingText: {
    fontSize: fontSize.sm,
    color: colors.textTertiary,
    fontStyle: 'italic',
  },
  urlDropdownItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
  },
  urlDropdownItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
  },
  urlDropdownUrl: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  urlDropdownDesc: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
    marginTop: 1,
  },
  urlDropdownRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  urlBadge: {
    backgroundColor: colors.bg,
    paddingHorizontal: 6,
    paddingVertical: 1,
    borderRadius: 8,
  },
  urlBadgeText: {
    fontSize: 10,
    fontWeight: '600',
  },
  selectedUrlChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    marginTop: spacing.sm,
    backgroundColor: colors.successLight,
    paddingHorizontal: spacing.sm,
    paddingVertical: spacing.xs,
    borderRadius: radius.sm,
  },
  selectedUrlText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.success,
    fontWeight: '500',
  },
  },
});