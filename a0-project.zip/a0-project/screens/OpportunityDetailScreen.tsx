import React, { useState, useEffect, useMemo } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, ActivityIndicator,
  FlatList, TextInput, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import FormModal from '../components/FormModal';
import ActionFormModal from '../components/ActionFormModal';
import NbaCard from '../components/NbaCard';
import ContextualEntry from '../components/ContextualEntry';
import RelationshipIntelligence from '../components/RelationshipIntelligence';
import { COMPANY_ROLES } from '../lib/taxonomyData';

const STATUS_CONFIG = [
  { key: 'early_planning', label: 'Early Planning', color: '#8B5CF6', icon: 'bulb' },
  { key: 'pushed_assessment', label: 'Pushed — Assessment', color: '#0D9488', icon: 'arrow-up-circle' },
  { key: 'pushed_scoping', label: 'Pushed — Scoping', color: '#0F766E', icon: 'resize' },
  { key: 'pushed_proposal', label: 'Pushed — Proposal', color: '#115E59', icon: 'document-attach' },
  { key: 'pushed_negotiation', label: 'Pushed — Negotiation', color: '#134E4A', icon: 'swap-horizontal' },
  { key: 'rfi', label: 'RFI', color: '#3B82F6', icon: 'information-circle' },
  { key: 'rfp', label: 'RFP', color: '#F59E0B', icon: 'document-text' },
  { key: 'rfq', label: 'RFQ', color: '#F97316', icon: 'calculator' },
  { key: 'won', label: 'Won', color: '#10B981', icon: 'trophy' },
  { key: 'abandoned', label: 'Abandoned', color: '#F59E0B', icon: 'warning' },
  { key: 'lost', label: 'Lost', color: '#EF4444', icon: 'close-circle' },
];

type StrategistReport = {
  opportunityHealthScore: { score: number; reasoning: string };
  stageReadiness: { ready: boolean; missingElements: string[]; recommendation: string };
  riskAnalysis: { risk: string; severity: string; mitigation: string }[];
  stakeholderGaps: { role: string; whyNeeded: string; accessStrategy: string }[];
  winStrategy: { positioning: string; differentiation: string; keyMessages: string[] };
  interactionAnalysis: { lastInteractionDate: string; engagementLevel: string; recommendedCadence: string };
  closePlan: { step: string; description: string; timeline: string }[];
  probabilityAdjustment: { current: number; aiSuggested: number; justification: string };
  recommendedActions: { title: string; details: string; priority: string; suggestedOwner: string; suggestedDeadline: string }[];
};

const safeStr = (v: any, fallback = ''): string => {
  if (typeof v === 'string') return v;
  if (v == null) return fallback;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  // Flatten objects to readable text — use '. ' not '\n' to avoid RN layout issues
  if (typeof v === 'object') {
    if (Array.isArray(v)) return v.map(item => safeStr(item)).join('; ');
    const entries = Object.values(v).filter(Boolean);
    if (entries.length > 0) return entries.map(e => safeStr(e)).join('. ');
    return fallback;
  }
  return fallback;
};

// Safely extract an array, handling both array and object-with-array cases
const safeArray = (v: any, arrayKey?: string): any[] => {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object' && arrayKey && Array.isArray(v[arrayKey])) return v[arrayKey];
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    // Try to find the first array property
    for (const val of Object.values(v)) {
      if (Array.isArray(val)) return val as any[];
    }
  }
  return [];
};

// Normalize report to ensure all fields have safe defaults
// Handles BOTH the expected schema AND alternate LLM field names
function normalizeReport(r: any, fallbackProb = 0): StrategistReport | null {
  if (!r || typeof r !== 'object') return null;

  // Map alternate field names to expected ones
  const ohs = r.opportunityHealthScore || r.opportunityHealth || {};
  const sr = r.stageReadiness || {};
  const ws = r.winStrategy || {};
  const ia = r.interactionAnalysis || {};
  const pa = r.probabilityAdjustment || {};

  // Risk analysis: could be r.riskAnalysis or r.risks
  const rawRisks = r.riskAnalysis || r.risks || [];
  const riskArray = safeArray(rawRisks);

  // Stakeholder gaps: could be r.stakeholderGaps or r.stakeholderMap
  const rawStakeholders = r.stakeholderGaps || r.stakeholderMap || [];
  let stakeholderArray: any[] = [];
  if (Array.isArray(rawStakeholders)) {
    stakeholderArray = rawStakeholders;
  } else if (rawStakeholders && typeof rawStakeholders === 'object') {
    // stakeholderMap format: { missingRoles: [...], accessPlan: ... }
    const missing = rawStakeholders.missingRoles || rawStakeholders.gaps || [];
    if (Array.isArray(missing)) {
      stakeholderArray = missing.map((m: any) => {
        if (typeof m === 'string') return { role: m, whyNeeded: '', accessStrategy: safeStr(rawStakeholders.accessPlan) };
        return m;
      });
    }
  }

  // Close plan: could be array or object with steps
  const rawClose = r.closePlan || [];
  let closeArray: any[] = [];
  if (Array.isArray(rawClose)) {
    closeArray = rawClose;
  } else if (rawClose && typeof rawClose === 'object') {
    closeArray = safeArray(rawClose, 'steps');
  }

  // Stage readiness: handle alternate field names
  const stageReady = sr.ready ?? sr.readyToAdvance ?? false;
  const missingElements = sr.missingElements || sr.missingForNextStage || [];

  // Health score: could be { score, reasoning } or { summary, strengths, weaknesses }
  let healthScore = ohs.score ?? 5;
  let healthReasoning = '';
  if (ohs.reasoning) {
    healthReasoning = safeStr(ohs.reasoning, 'No data');
  } else if (ohs.summary) {
    // Build reasoning from summary + strengths/weaknesses
    const parts = [ohs.summary];
    if (Array.isArray(ohs.strengths) && ohs.strengths.length > 0) {
      parts.push('Strengths: ' + ohs.strengths.map((s: any) => safeStr(s)).join('; '));
    }
    if (Array.isArray(ohs.weaknesses) && ohs.weaknesses.length > 0) {
      parts.push('Weaknesses: ' + ohs.weaknesses.map((w: any) => safeStr(w)).join('; '));
    }
    healthReasoning = parts.join('\n\n');
  } else {
    healthReasoning = 'No data';
  }

  return {
    opportunityHealthScore: { score: healthScore, reasoning: healthReasoning.slice(0, 300) },
    stageReadiness: {
      ready: !!stageReady,
      missingElements: Array.isArray(missingElements) ? missingElements.map((e: any) => safeStr(e)).slice(0, 5) : [],
      recommendation: safeStr(sr.recommendation || sr.currentStage || ''),
    },
    riskAnalysis: riskArray.slice(0, 5).map((x: any) => ({
      risk: safeStr(x.risk || x.name || x.title, 'Risk').slice(0, 100),
      severity: safeStr(x.severity || x.level, 'Medium'),
      mitigation: safeStr(x.mitigation || x.action, '').slice(0, 150),
    })),
    stakeholderGaps: stakeholderArray.slice(0, 4).map((x: any) => ({
      role: safeStr(x.role || x.title, 'Role').slice(0, 60),
      whyNeeded: safeStr(x.whyNeeded || x.why || x.reason, '').slice(0, 150),
      accessStrategy: safeStr(x.accessStrategy || x.access || x.strategy, '').slice(0, 150),
    })),
    winStrategy: {
      positioning: safeStr(ws.positioning).slice(0, 200),
      differentiation: safeStr(ws.differentiation).slice(0, 200),
      keyMessages: Array.isArray(ws.keyMessages) ? ws.keyMessages.map((m: any) => safeStr(m)).slice(0, 4) : [],
    },
    interactionAnalysis: {
      lastInteractionDate: safeStr(ia.lastInteractionDate, 'Unknown'),
      engagementLevel: safeStr(ia.engagementLevel, 'Unknown'),
      recommendedCadence: safeStr(ia.recommendedCadence).slice(0, 150),
    },
    closePlan: closeArray.slice(0, 6).map((x: any) => ({
      step: safeStr(x.step || x.name || x.title || `Step`).slice(0, 60),
      description: safeStr(x.description || x.details || x.deliverable, '').slice(0, 150),
      timeline: safeStr(x.timeline || x.timeframe || x.when || (x.deadlineDays ? `Day ${x.deadlineDays}` : ''), ''),
    })),
    probabilityAdjustment: {
      current: pa.current ?? pa.currentProbability ?? fallbackProb,
      aiSuggested: pa.aiSuggested ?? pa.suggested ?? pa.adjustedProbability ?? fallbackProb,
      justification: safeStr(pa.justification || pa.reasoning).slice(0, 250),
    },
    recommendedActions: (Array.isArray(r.recommendedActions) ? r.recommendedActions : []).slice(0, 6).map((a: any) => ({
      title: (typeof a === 'string' ? a : safeStr(a.title, 'Action')).slice(0, 50),
      details: (typeof a === 'string' ? a : safeStr(a.details)).slice(0, 150),
      priority: safeStr(a.priority, 'Medium'),
      suggestedOwner: safeStr(a.suggestedOwner || a.owner) || '',
      suggestedDeadline: safeStr(a.suggestedDeadline || a.deadline) || '',
    })),
  };
}

export default function OpportunityDetailScreen({ route, navigation }: any) {
  const { id } = route.params;
  const opp = useQuery(api.opportunities.get, { id });
  const interactions = useQuery(api.interactions.listByEntity, { entityType: 'opportunity', entityId: id });
  const tasks = useQuery(api.actions.listByEntity, { entityType: 'opportunity', entityId: id });
  const nbas = useQuery(api.nba.getNextActions, { entryType: 'opportunity', entryId: id });
  const stageHistory = useQuery(api.opportunities.getStageHistory, { opportunityId: id });
  const company = useQuery(api.companies.get, opp?.companyId ? { id: opp.companyId } : "skip");
  const contact = useQuery(api.contacts.get, opp?.contactId ? { id: opp.contactId } : "skip");
  const relatedOpps = useQuery(api.opportunities.list, opp?.companyId ? { companyId: opp.companyId } : "skip");
  const orgSettings = useQuery(api.orgSettings.get);
  const stakeholders = useQuery(api.opportunityStakeholders.listByOpportunity, { opportunityId: id });
  const allCompanies = useQuery(api.companies.list);
  const addStakeholder = useMutation(api.opportunityStakeholders.add);
  const removeStakeholder = useMutation(api.opportunityStakeholders.remove);
  const updateStakeholder = useMutation(api.opportunityStakeholders.update);
  const updateOpp = useMutation(api.opportunities.update);
  const removeOpp = useMutation(api.opportunities.remove);
  const createInteraction = useMutation(api.interactions.create);
  const createTask = useMutation(api.actions.create);
  const dismissNba = useMutation(api.nba.dismiss);
  const executeNba = useMutation(api.nba.execute);
  const requestRefresh = useMutation(api.nbaActions.requestRefresh);
  const saveReport = useMutation(api.opportunities.saveStrategistReport);
  const saveCompanyInsights = useMutation(api.companies.saveInsights);
  const [showEdit, setShowEdit] = useState(false);
  const [showAddNote, setShowAddNote] = useState(false);
  const [showAddAction, setShowAddAction] = useState(false);
  const [showContext, setShowContext] = useState(false);
  const [showStatusPicker, setShowStatusPicker] = useState(false);
  const [lostCompetitor, setLostCompetitor] = useState('');
  const [showLostPrompt, setShowLostPrompt] = useState(false);

  // Stakeholder state
  const [showAddStakeholder, setShowAddStakeholder] = useState(false);
  const [stakeholderSearch, setStakeholderSearch] = useState('');
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState('primary_target');
  const [stakeholderNotes, setStakeholderNotes] = useState('');
  const [stakeholdersExpanded, setStakeholdersExpanded] = useState(true);

  // Strategist state
  const [strategistExpanded, setStrategistExpanded] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [selectedActions, setSelectedActions] = useState<Set<number>>(new Set());
  const [pushingActions, setPushingActions] = useState(false);
  const [localReport, setLocalReport] = useState<StrategistReport | null>(null);

  // Filtered companies for stakeholder picker (exclude already-added ones)
  const filteredCompanies = useMemo(() => {
    if (!allCompanies) return [];
    const existingIds = new Set((stakeholders || []).map(s => s.companyId));
    return allCompanies
      .filter(c => !existingIds.has(c._id))
      .filter(c => !stakeholderSearch || c.name.toLowerCase().includes(stakeholderSearch.toLowerCase()));
  }, [allCompanies, stakeholders, stakeholderSearch]);

  // Parse stored report
  const storedReport = useMemo<StrategistReport | null>(() => {
    if (localReport) return localReport;
    if (!opp?.strategistReport) return null;
    try { return normalizeReport(JSON.parse(opp.strategistReport), opp.probability || 0); } catch { return null; }
  }, [opp?.strategistReport, localReport]);

  // Auto-populate actions when opportunity loads or status changes
  useEffect(() => {
    if (opp?.status) {
    }
  }, [opp?.status]);

  const formatValue = (val?: number) => {
    if (!val) return '-';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(val);
  };

  if (!opp) return (
    <SafeAreaView style={styles.container}>
      <View style={styles.loading}><Text>Loading...</Text></View>
    </SafeAreaView>
  );

  const currentStatus = STATUS_CONFIG.find(s => s.key === opp.status) || STATUS_CONFIG[0];
  const createdDate = new Date(opp._creationTime).toLocaleDateString('en-US', {
    day: 'numeric', month: 'short', year: 'numeric',
  });

  const handleStatusChange = async (newStatus: string) => {
    if (newStatus === 'lost') {
      setShowLostPrompt(true);
      setShowStatusPicker(false);
      return;
    }
    await updateOpp({ id, status: newStatus });
    setShowStatusPicker(false);
  };

  const handleLostConfirm = async () => {
    await updateOpp({ id, status: 'lost', lostCompetitor: lostCompetitor.trim() || undefined });
    setShowLostPrompt(false);
    setLostCompetitor('');
  };

  const handleAddStakeholder = async () => {
    if (!selectedCompanyId) return;
    try {
      await addStakeholder({
        opportunityId: id,
        companyId: selectedCompanyId as any,
        role: selectedRole,
        notes: stakeholderNotes.trim() || undefined,
        isPrimary: selectedRole === 'primary_target',
      });
      setShowAddStakeholder(false);
      setSelectedCompanyId(null);
      setSelectedRole('primary_target');
      setStakeholderNotes('');
      setStakeholderSearch('');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to add stakeholder');
    }
  };

  const handleRemoveStakeholder = (stakeId: any, companyName: string) => {
    Alert.alert('Remove Stakeholder', `Remove ${companyName} from this deal?`, [
      { text: 'Cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => removeStakeholder({ id: stakeId }) },
    ]);
  };

  const getRoleLabel = (value: string) => {
    return COMPANY_ROLES.find(r => r.value === value)?.label || value;
  };

  const getRoleColor = (value: string) => {
    const roleColors: Record<string, string> = {
      primary_target: '#10B981',
      technical_influencer: '#6366F1',
      financial_gatekeeper: '#F59E0B',
      infrastructure_partner: '#3B82F6',
      regulatory: '#475569',
      vendor: '#F97316',
      consortium_member: '#8B5CF6',
      end_user: '#0891B2',
      other: colors.textTertiary,
    };
    return roleColors[value] || colors.textTertiary;
  };

  const handleAnalyze = async (mode: 'generate' | 'regenerate' | 'build') => {
    // --- BD Intelligence: generate if missing ---
    if (company && !(company as any).insightsReport) {
      const userChoice = await new Promise<string>((resolve) => {
        Alert.alert(
          'BD Intelligence Required',
          `No BD Intelligence report found for ${company.name}. Generate one first?`,
          [
            { text: 'Skip', style: 'cancel', onPress: () => resolve('skip') },
            { text: 'Generate BD Intel', onPress: () => resolve('generate') },
          ]
        );
      });

      if (userChoice === 'generate') {
        if (!orgSettings) {
          Alert.alert('Profile Required', 'Set up your company profile in Settings first.');
          return;
        }
        setAnalyzing(true);
        setStrategistExpanded(true);
        try {
          const companyMeta = [
            (company as any).domain && `Website: ${(company as any).domain}`,
            (company as any).industry && `Industry: ${(company as any).industry}`,
            (company as any).size && `Size: ${(company as any).size}`,
            (company as any).notes && `Notes: ${(company as any).notes?.slice(0, 200)}`,
            (company as any).companyRoleNotes && `Role context: ${(company as any).companyRoleNotes?.slice(0, 150)}`,
          ].filter(Boolean).join(', ');

          const ctrl = new AbortController();
          const t = setTimeout(() => ctrl.abort(), 30000);
          const bdRes = await fetch('https://api.a0.dev/ai/llm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              messages: [
                { role: 'system', content: `You are a BD Intelligence Officer. Identify concrete, actionable business development opportunities. Be specific — no generic consulting language. Think like a senior BD exec under pressure to generate pipeline in 30 days. Keep descriptions under 2 sentences each.` },
                { role: 'user', content: `Our company: ${orgSettings.companyName}. We offer: ${orgSettings.interests}.\nTarget: ${company.name}. ${companyMeta || ''}\nIdentify top BD opportunities.` },
              ],
              schema: {
                type: 'object',
                properties: {
                  opportunity_summary: {
                    type: 'array', description: 'Max 3 opportunities',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string', description: 'Short name, max 8 words' },
                        description: { type: 'string', description: 'Max 2 sentences' },
                        bd_focus_area: { type: 'string', description: 'Max 6 words' },
                        trigger: { type: 'string', description: 'Why now, max 1 sentence' },
                        stakeholders: { type: 'array', items: { type: 'string' }, description: 'Max 3 role titles' },
                        entry_strategy: { type: 'string', description: 'Max 1 sentence' },
                        competitive_context: {
                          type: 'object',
                          properties: {
                            likely_competitors: { type: 'array', items: { type: 'string' }, description: 'Max 2' },
                            differentiation: { type: 'string', description: 'Max 1 sentence' },
                          },
                          required: ['likely_competitors', 'differentiation'],
                        },
                        priority_score: {
                          type: 'object',
                          properties: {
                            likelihood: { type: 'number' }, speed: { type: 'number' }, strategic_value: { type: 'number' },
                          },
                          required: ['likelihood', 'speed', 'strategic_value'],
                        },
                      },
                      required: ['title', 'description', 'bd_focus_area', 'trigger', 'stakeholders', 'entry_strategy', 'priority_score'],
                    },
                  },
                  segment_insights: { type: 'array', items: { type: 'string' }, description: 'Max 3 key insights, each max 1 sentence' },
                  recommended_next_actions: {
                    type: 'array', description: 'Max 4 actions',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string', description: 'Max 8 words' },
                        details: { type: 'string', description: 'Max 1 sentence' },
                      },
                      required: ['title', 'details'],
                    },
                  },
                },
                required: ['opportunity_summary', 'segment_insights', 'recommended_next_actions'],
              },
            }),
            signal: ctrl.signal,
          });
          clearTimeout(t);

          if (bdRes.ok) {
            const bdData = await bdRes.json();
            let bdReport = bdData.schema_data || null;
            if (!bdReport && bdData.completion) {
              try {
                const cleaned = bdData.completion.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
                bdReport = JSON.parse(cleaned);
              } catch { /* ignore */ }
            }
            if (bdReport) {
              const reportStr = JSON.stringify(bdReport);
              await saveCompanyInsights({ id: (company as any)._id, insightsReport: reportStr });
              (company as any).insightsReport = reportStr;
            }
          }
        } catch (e: any) {
          console.log('[BD Intel] generation failed:', e?.message);
        }
      }
    }

    // --- BD Intelligence: check staleness (> 12 months) ---
    if (company && (company as any).insightsReport && (company as any).insightsGeneratedAt) {
      const ageMonths = Math.floor((Date.now() - (company as any).insightsGeneratedAt) / (1000 * 60 * 60 * 24 * 30));
      if (ageMonths >= 12) {
        const userChoice = await new Promise<string>((resolve) => {
          Alert.alert(
            'BD Intelligence Outdated',
            `Report is ${ageMonths} months old. Regenerate?`,
            [
              { text: 'Use Existing', style: 'cancel', onPress: () => resolve('skip') },
              { text: 'Regenerate', onPress: () => resolve('generate') },
            ]
          );
        });

        if (userChoice === 'generate') {
          if (!orgSettings) { Alert.alert('Profile Required', 'Set up your company profile in Settings first.'); return; }
          setAnalyzing(true);
          setStrategistExpanded(true);
          try {
            const companyMeta = [
              company.domain && `Website: ${company.domain}`,
              company.industry && `Industry: ${company.industry}`,
              (company as any).size && `Size: ${(company as any).size}`,
            ].filter(Boolean).join(', ');

            const ctrl = new AbortController();
            const t = setTimeout(() => ctrl.abort(), 30000);
            const res = await fetch('https://api.a0.dev/ai/llm', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                messages: [
                  { role: 'system', content: `You are a BD Intelligence Officer. Identify concrete, actionable BD opportunities. Be specific — no generic language. Keep descriptions under 2 sentences.` },
                  { role: 'user', content: `Our company: ${orgSettings.companyName}. We offer: ${orgSettings.interests}.\nTarget: ${company.name}. ${companyMeta || ''}\nIdentify top BD opportunities.` },
                ],
                schema: {
                  type: 'object',
                  properties: {
                    opportunity_summary: {
                      type: 'array', description: 'Max 3 opportunities',
                      items: {
                        type: 'object',
                        properties: {
                          title: { type: 'string' }, description: { type: 'string' },
                          bd_focus_area: { type: 'string' }, trigger: { type: 'string' },
                          stakeholders: { type: 'array', items: { type: 'string' } },
                          entry_strategy: { type: 'string' },
                          competitive_context: {
                            type: 'object',
                            properties: { likely_competitors: { type: 'array', items: { type: 'string' } }, differentiation: { type: 'string' } },
                            required: ['likely_competitors', 'differentiation'],
                          },
                          priority_score: {
                            type: 'object',
                            properties: { likelihood: { type: 'number' }, speed: { type: 'number' }, strategic_value: { type: 'number' } },
                            required: ['likelihood', 'speed', 'strategic_value'],
                          },
                        },
                        required: ['title', 'description', 'bd_focus_area', 'trigger', 'priority_score'],
                      },
                    },
                    segment_insights: { type: 'array', items: { type: 'string' }, description: 'Max 3' },
                    recommended_next_actions: {
                      type: 'array', description: 'Max 4',
                      items: { type: 'object', properties: { title: { type: 'string' }, details: { type: 'string' } }, required: ['title', 'details'] },
                    },
                  },
                  required: ['opportunity_summary', 'segment_insights', 'recommended_next_actions'],
                },
              }),
              signal: ctrl.signal,
            });
            clearTimeout(t);
            if (res.ok) {
              const data = await res.json();
              let result = data.schema_data || null;
              if (!result && data.completion) {
                try { result = JSON.parse(data.completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim()); } catch {}
              }
              if (result) {
                const reportStr = JSON.stringify(result);
                await saveCompanyInsights({ id: (company as any)._id, insightsReport: reportStr });
                (company as any).insightsReport = reportStr;
                (company as any).insightsGeneratedAt = Date.now();
              }
            }
          } catch { /* continue */ }
        }
      }
    }

    // --- Strategist call ---
    setAnalyzing(true);
    setSelectedActions(new Set());
    try {
      // Build lean context — strip bodies/descriptions to minimize tokens
      const leanInteractions = (interactions || []).slice(-10).map((i: any) => ({
        subject: i.subject, type: i.type, date: new Date(i.date).toLocaleDateString(),
      }));
      const leanActions = (tasks || []).slice(0, 10).map((t: any) => ({
        title: t.title, status: t.status, priority: t.priority,
      }));
      const leanHistory = (stageHistory || []).slice(-5).map((s: any) => ({
        from: s.fromStage, to: s.toStage, date: new Date(s.changedAt).toLocaleDateString(),
      }));
      let companyInsights = (company as any)?.insightsReport || '';
      if (companyInsights.length > 1000) companyInsights = companyInsights.slice(0, 1000) + '...';

      const ctx = {
        opp: { title: opp.title, ref: opp.reference, status: opp.status, value: opp.value, probability: opp.probability, closeDate: opp.closeDate, location: opp.location, notes: opp.notes?.slice(0, 300), lostCompetitor: opp.lostCompetitor },
        company: company ? { name: company.name, industry: (company as any).industry, insights: companyInsights || undefined, notes: (company as any).notes?.slice(0, 200), companyRoleNotes: (company as any).companyRoleNotes?.slice(0, 150) } : { name: opp.companyName || 'Unknown' },
        contact: contact ? { name: `${contact.firstName} ${contact.lastName}`, title: contact.title, notes: contact.notes?.slice(0, 200) } : { name: opp.contactName || 'Unknown' },
        interactions: leanInteractions,
        actions: leanActions,
        stageHistory: leanHistory,
        org: orgSettings ? { name: orgSettings.companyName, interests: orgSettings.interests } : null,
        relatedOpps: (relatedOpps || []).filter((r: any) => r._id !== id).slice(0, 5).map((r: any) => ({ status: r.status, value: r.value, lostTo: r.lostCompetitor })),
        nbas: (nbas || []).slice(0, 5).map((n: any) => ({ title: n.title, score: n.score })),
        stakeholderNotes: (stakeholders || []).filter((s: any) => s.notes).slice(0, 5).map((s: any) => ({ company: s.companyName, role: s.role, notes: s.notes?.slice(0, 100) })),
      };

      const systemPrompt = `You are an Opportunity Strategist for complex B2B industrial deals. Analyze this opportunity and produce a concrete win strategy.

Adapt to status: early_planning→shape/position; pushed_assessment→validate fit/qualify; pushed_scoping→define scope/value prop; pushed_proposal→differentiate/articulate ROI; pushed_negotiation→close terms/align; rfi/rfp/rfq→differentiate/comply; late-stage→close/align; lost→lessons.

Assess: health (1-10), stage readiness, risks, stakeholder gaps, win positioning, interaction cadence, close plan, probability adjustment, and recommended actions.

Detect contradictions (high prob + low activity, imminent close + early stage). Be specific and execution-oriented — no generic advice. All text fields: max 2 sentences. Action titles: max 8 words.${mode === 'build' && storedReport ? `\n\nPREVIOUS REPORT (enhance, don't repeat):\n${JSON.stringify(storedReport)}` : ''}`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 45000);
      try {
        const res = await fetch('https://api.a0.dev/ai/llm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: [
              { role: 'system', content: systemPrompt },
              { role: 'user', content: `Analyze:\n${JSON.stringify(ctx)}` },
            ],
            schema: {
              type: 'object',
              properties: {
                opportunityHealthScore: {
                  type: 'object',
                  properties: { score: { type: 'number', description: '1-10' }, reasoning: { type: 'string', description: 'Max 2 sentences' } },
                  required: ['score', 'reasoning'],
                },
                stageReadiness: {
                  type: 'object',
                  properties: {
                    ready: { type: 'boolean' },
                    missingElements: { type: 'array', items: { type: 'string' }, description: 'Max 4 items, each under 60 chars' },
                    recommendation: { type: 'string', description: 'Max 2 sentences' },
                  },
                  required: ['ready', 'missingElements', 'recommendation'],
                },
                riskAnalysis: {
                  type: 'array', description: 'Max 4 risks',
                  items: {
                    type: 'object',
                    properties: { risk: { type: 'string' }, severity: { type: 'string', enum: ['Low', 'Medium', 'High'] }, mitigation: { type: 'string', description: 'Max 1 sentence' } },
                    required: ['risk', 'severity', 'mitigation'],
                  },
                },
                stakeholderGaps: {
                  type: 'array', description: 'Max 3 gaps',
                  items: {
                    type: 'object',
                    properties: { role: { type: 'string' }, whyNeeded: { type: 'string', description: 'Max 1 sentence' }, accessStrategy: { type: 'string', description: 'Max 1 sentence' } },
                    required: ['role', 'whyNeeded', 'accessStrategy'],
                  },
                },
                winStrategy: {
                  type: 'object',
                  properties: {
                    positioning: { type: 'string', description: 'Max 2 sentences' },
                    differentiation: { type: 'string', description: 'Max 2 sentences' },
                    keyMessages: { type: 'array', items: { type: 'string' }, description: 'Max 3, each under 50 chars' },
                  },
                  required: ['positioning', 'differentiation', 'keyMessages'],
                },
                interactionAnalysis: {
                  type: 'object',
                  properties: {
                    lastInteractionDate: { type: 'string' },
                    engagementLevel: { type: 'string', enum: ['High', 'Medium', 'Low', 'Unknown'] },
                    recommendedCadence: { type: 'string', description: 'Max 1 sentence' },
                  },
                  required: ['lastInteractionDate', 'engagementLevel', 'recommendedCadence'],
                },
                closePlan: {
                  type: 'array', description: 'Max 5 steps',
                  items: {
                    type: 'object',
                    properties: { step: { type: 'string' }, description: { type: 'string', description: 'Max 1 sentence' }, timeline: { type: 'string' } },
                    required: ['step', 'description', 'timeline'],
                  },
                },
                probabilityAdjustment: {
                  type: 'object',
                  properties: { current: { type: 'number' }, aiSuggested: { type: 'number' }, justification: { type: 'string', description: 'Max 2 sentences' } },
                  required: ['current', 'aiSuggested', 'justification'],
                },
                recommendedActions: {
                  type: 'array', description: 'Max 5 actions',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string', description: 'Max 8 words' },
                      details: { type: 'string', description: 'Max 1 sentence' },
                      priority: { type: 'string', enum: ['High', 'Medium', 'Low'] },
                      suggestedOwner: { type: 'string' },
                      suggestedDeadline: { type: 'string' },
                    },
                    required: ['title', 'details', 'priority'],
                  },
                },
              },
              required: ['opportunityHealthScore', 'stageReadiness', 'riskAnalysis', 'stakeholderGaps', 'winStrategy', 'interactionAnalysis', 'closePlan', 'probabilityAdjustment', 'recommendedActions'],
            },
          }),
          signal: controller.signal,
        });
        clearTimeout(timeout);

        if (!res.ok) {
          Alert.alert('Analysis Failed', `API error ${res.status}. Try again.`);
          return;
        }
        const data = await res.json();
        let result = data.schema_data || null;
        if (!result && data.completion) {
          try { result = JSON.parse(data.completion.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim()); } catch {}
        }
        // Retry without schema if structured output failed
        if (!result) {
          try {
            const ctrl2 = new AbortController();
            const t2 = setTimeout(() => ctrl2.abort(), 45000);
            const r2 = await fetch('https://api.a0.dev/ai/llm', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              signal: ctrl2.signal,
              body: JSON.stringify({
                messages: [
                  { role: 'system', content: systemPrompt + '\n\nReturn ONLY valid JSON matching the StrategistReport schema with keys: opportunityHealthScore, stageReadiness, riskAnalysis, stakeholderGaps, winStrategy, interactionAnalysis, closePlan, probabilityAdjustment, recommendedActions.' },
                  { role: 'user', content: JSON.stringify(ctx) },
                ],
              }),
            });
            clearTimeout(t2);
            if (r2.ok) {
              const d2 = await r2.json();
              const raw = (d2.completion || '').replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
              try { result = JSON.parse(raw); } catch {}
            }
          } catch { /* retry failed */ }
        }
        if (!result) {
          Alert.alert('Analysis Failed', 'No response from AI. Try again.');
          return;
        }

        const normalized = normalizeReport(result, opp?.probability || 0);
        if (!normalized) {
          Alert.alert('Analysis Failed', 'Could not parse response.');
          return;
        }

        setLocalReport(normalized);
        setStrategistExpanded(true);
        try { await saveReport({ id, report: JSON.stringify(result) }); } catch {}
      } catch (e: any) {
        clearTimeout(timeout);
        if (e?.name === 'AbortError') {
          Alert.alert('Timeout', 'Analysis took too long. Try again.');
        } else {
          Alert.alert('Error', 'Failed to analyze. Try again.');
        }
      }
    } catch (err) {
      console.error('[Strategist] Error:', err);
      Alert.alert('Error', 'Failed to analyze opportunity.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handlePushActions = async () => {
    if (!storedReport || selectedActions.size === 0) return;
    setPushingActions(true);
    try {
      const actions = storedReport.recommendedActions;
      for (const idx of selectedActions) {
        const action = actions[idx];
        if (!action) continue;
        await createTask({
          title: action.title,
          description: `${action.details}${action.suggestedOwner ? `\nSuggested owner: ${action.suggestedOwner}` : ''}${action.suggestedDeadline ? `\nSuggested deadline: ${action.suggestedDeadline}` : ''}`,
          priority: (action.priority || 'medium').toLowerCase() as any,
          opportunityId: id,
          companyId: opp.companyId || undefined,
        });
      }
      Alert.alert('Done', `${selectedActions.size} action(s) added to your Actions list.`);
      setSelectedActions(new Set());
    } catch {
      Alert.alert('Error', 'Failed to push actions.');
    } finally {
      setPushingActions(false);
    }
  };

  const toggleAction = (idx: number) => {
    setSelectedActions(prev => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const severityColor = (s: string) => {
    if (s === 'High') return colors.danger;
    if (s === 'Medium') return '#F59E0B';
    return colors.success;
  };

  const healthColor = (score: number) => {
    if (score >= 7) return colors.success;
    if (score >= 4) return '#F59E0B';
    return colors.danger;
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.navBar}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.navActions}>
          <TouchableOpacity onPress={() => setShowEdit(true)} style={styles.navBtn}>
            <Ionicons name="pencil" size={18} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => Alert.alert('Delete?', '', [
            { text: 'Cancel' },
            { text: 'Delete', style: 'destructive', onPress: () => { removeOpp({ id }); navigation.goBack(); } },
          ])} style={styles.navBtn}>
            <Ionicons name="trash" size={18} color={colors.danger} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.heroCard}>
          {/* Reference & Date */}
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginBottom: spacing.sm }}>
            <Text style={{ fontSize: fontSize.sm, fontWeight: '700', color: colors.primary, fontFamily: 'monospace' }}>
              {opp.reference || '—'}
            </Text>
            <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary }}>
              Created {createdDate}
            </Text>
          </View>

          {/* Status badge */}
          <TouchableOpacity
            style={[styles.stageBadge, { backgroundColor: currentStatus.color + '20' }]}
            onPress={() => setShowStatusPicker(true)}
          >
            <Ionicons name={currentStatus.icon as any} size={14} color={currentStatus.color} />
            <Text style={[styles.stageBadgeText, { color: currentStatus.color }]}>
              {currentStatus.label}
            </Text>
            <Ionicons name="chevron-down" size={12} color={currentStatus.color} />
          </TouchableOpacity>

          <Text style={styles.heroName}>{opp.title}</Text>
          <Text style={styles.heroValue}>{formatValue(opp.value)}</Text>

          <View style={styles.metaGrid}>
            <MetaItem label="Probability" value={opp.probability ? `${opp.probability}%` : '-'} />
            <MetaItem
              label="Company"
              value={opp.companyName || '-'}
              onPress={opp.companyId ? () => navigation.navigate('CompanyDetail', { id: opp.companyId }) : undefined}
            />
            <MetaItem
              label="Contact"
              value={opp.contactName || '-'}
              onPress={opp.contactId ? () => navigation.navigate('ContactDetail', { id: opp.contactId }) : undefined}
            />
            {opp.closeDate && <MetaItem label="Close Date" value={new Date(opp.closeDate).toLocaleDateString()} />}
            {opp.location && <MetaItem label="Location" value={(() => {
              try { return JSON.parse(opp.location).address || opp.location; } catch { return opp.location; }
            })()} />}
            {opp.lostCompetitor && opp.status === 'lost' && (
              <MetaItem label="Lost To" value={opp.lostCompetitor} />
            )}
          </View>

          {/* Notes */}
          {opp.notes && (
            <View style={{ width: '100%', marginTop: spacing.lg, paddingTop: spacing.md, borderTopWidth: 1, borderTopColor: colors.borderLight }}>
              <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: 4 }}>NOTES</Text>
              <Text style={{ fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 20 }}>{opp.notes}</Text>
            </View>
          )}
        </View>

        {/* Quick actions */}
        <View style={styles.quickActions}>
          <QuickBtn icon="chatbubble" label="Note" onPress={() => setShowAddNote(true)} />
          <QuickBtn icon="checkmark-circle" label="Action" onPress={() => setShowAddAction(true)} />
          <QuickBtn icon="sparkles" label="Context" onPress={() => setShowContext(true)} />
          <QuickBtn icon="swap-horizontal" label="Status" onPress={() => setShowStatusPicker(true)} />
        </View>

        {/* === Deal Stakeholders === */}
        <View style={styles.section}>
          <TouchableOpacity
            style={shStyles.header}
            onPress={() => setStakeholdersExpanded(!stakeholdersExpanded)}
          >
            <View style={shStyles.headerLeft}>
              <Ionicons name="business" size={20} color="#3B82F6" />
              <Text style={shStyles.headerTitle}>Deal Stakeholders</Text>
              {stakeholders && stakeholders.length > 0 && (
                <View style={shStyles.countBadge}>
                  <Text style={shStyles.countText}>{stakeholders.length}</Text>
                </View>
              )}
            </View>
            <Ionicons name={stakeholdersExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
          </TouchableOpacity>

          {stakeholdersExpanded && (
            <View style={shStyles.body}>
              {(!stakeholders || stakeholders.length === 0) && (
                <View style={shStyles.emptyState}>
                  <Ionicons name="people-outline" size={32} color={colors.textTertiary} />
                  <Text style={shStyles.emptyText}>No stakeholder companies added yet</Text>
                  <Text style={shStyles.emptySubtext}>Add companies involved in this deal and their roles</Text>
                </View>
              )}

              {stakeholders?.map((s) => (
                <View key={s._id} style={shStyles.stakeCard}>
                  <TouchableOpacity
                    style={shStyles.stakeMain}
                    onPress={() => navigation.navigate('CompanyDetail', { id: s.companyId })}
                  >
                    <View style={[shStyles.roleIndicator, { backgroundColor: getRoleColor(s.role) }]} />
                    <View style={shStyles.stakeInfo}>
                      <Text style={shStyles.stakeName}>{s.companyName}</Text>
                      <View style={[shStyles.roleBadge, { backgroundColor: getRoleColor(s.role) + '15' }]}>
                        <Text style={[shStyles.roleText, { color: getRoleColor(s.role) }]}>
                          {getRoleLabel(s.role)}
                        </Text>
                        {s.isPrimary && (
                          <View style={shStyles.primaryBadge}>
                            <Text style={shStyles.primaryText}>PRIMARY</Text>
                          </View>
                        )}
                      </View>
                      {s.notes && <Text style={shStyles.stakeNotes} numberOfLines={2}>{s.notes}</Text>}
                    </View>
                    <TouchableOpacity
                      style={shStyles.removeBtn}
                      onPress={() => handleRemoveStakeholder(s._id, s.companyName)}
                      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                    >
                      <Ionicons name="close-circle" size={20} color={colors.textTertiary} />
                    </TouchableOpacity>
                  </TouchableOpacity>
                </View>
              ))}

              <TouchableOpacity
                style={shStyles.addBtn}
                onPress={() => setShowAddStakeholder(true)}
              >
                <Ionicons name="add-circle" size={20} color="#3B82F6" />
                <Text style={shStyles.addBtnText}>Add Company</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* === Opportunity Development Strategist === */}
        <View style={styles.section}>
          <TouchableOpacity
            style={stStyles.header}
            onPress={() => setStrategistExpanded(!strategistExpanded)}
          >
            <View style={stStyles.headerLeft}>
              <Ionicons name="analytics" size={22} color="#7C3AED" />
              <Text style={stStyles.headerTitle}>Opportunity Strategist</Text>
            </View>
            <View style={stStyles.headerRight}>
              {storedReport && (
                <View style={[stStyles.healthBadge, { backgroundColor: healthColor(storedReport.opportunityHealthScore.score) + '20' }]}>
                  <Text style={[stStyles.healthScore, { color: healthColor(storedReport.opportunityHealthScore.score) }]}>
                    {storedReport.opportunityHealthScore.score}/10
                  </Text>
                </View>
              )}
              <Ionicons name={strategistExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
            </View>
          </TouchableOpacity>

          {strategistExpanded && (
            <View style={stStyles.body}>
              {/* Action buttons */}
              <View style={stStyles.buttonRow}>
                {!storedReport ? (
                  <TouchableOpacity
                    style={[stStyles.actionBtn, { backgroundColor: '#7C3AED' }]}
                    onPress={() => handleAnalyze('generate')}
                    disabled={analyzing}
                  >
                    {analyzing ? <ActivityIndicator color="#fff" size="small" /> : (
                      <>
                        <Ionicons name="flash" size={16} color="#fff" />
                        <Text style={stStyles.actionBtnText}>Generate Strategy</Text>
                      </>
                    )}
                  </TouchableOpacity>
                ) : (
                  <>
                    <TouchableOpacity
                      style={[stStyles.actionBtn, { backgroundColor: '#7C3AED' }]}
                      onPress={() => handleAnalyze('build')}
                      disabled={analyzing}
                    >
                      {analyzing ? <ActivityIndicator color="#fff" size="small" /> : (
                        <>
                          <Ionicons name="layers" size={16} color="#fff" />
                          <Text style={stStyles.actionBtnText}>Build Upon</Text>
                        </>
                      )}
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[stStyles.actionBtn, { backgroundColor: colors.textSecondary }]}
                      onPress={() => handleAnalyze('regenerate')}
                      disabled={analyzing}
                    >
                      <Ionicons name="refresh" size={16} color="#fff" />
                      <Text style={stStyles.actionBtnText}>Regenerate</Text>
                    </TouchableOpacity>
                  </>
                )}
              </View>

              {analyzing && (
                <View style={stStyles.loadingBox}>
                  <ActivityIndicator color="#7C3AED" />
                  <Text style={stStyles.loadingText}>Analyzing opportunity...</Text>
                </View>
              )}

              {opp.strategistGeneratedAt && storedReport && !analyzing && (
                <Text style={stStyles.timestamp}>
                  Last analyzed {new Date(opp.strategistGeneratedAt).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                </Text>
              )}

              {storedReport && !analyzing && (
                <>
                  {/* Health Score */}
                  <View style={stStyles.card}>
                    <View style={stStyles.cardHeader}>
                      <Ionicons name="pulse" size={18} color={healthColor(storedReport.opportunityHealthScore.score)} />
                      <Text style={stStyles.cardTitle}>Opportunity Health</Text>
                      <View style={[stStyles.scorePill, { backgroundColor: healthColor(storedReport.opportunityHealthScore.score) + '20' }]}>
                        <Text style={[stStyles.scorePillText, { color: healthColor(storedReport.opportunityHealthScore.score) }]}>
                          {storedReport.opportunityHealthScore.score}/10
                        </Text>
                      </View>
                    </View>
                    <Text style={stStyles.cardBody} numberOfLines={8}>{storedReport.opportunityHealthScore.reasoning}</Text>
                  </View>

                  {/* Probability Adjustment */}
                  {storedReport.probabilityAdjustment && (
                    <View style={stStyles.card}>
                      <View style={stStyles.cardHeader}>
                        <Ionicons name="trending-up" size={18} color="#7C3AED" />
                        <Text style={stStyles.cardTitle}>Probability Assessment</Text>
                      </View>
                      <View style={stStyles.probRow}>
                        <View style={stStyles.probItem}>
                          <Text style={stStyles.probLabel}>Current</Text>
                          <Text style={stStyles.probValue}>{storedReport.probabilityAdjustment.current}%</Text>
                        </View>
                        <Ionicons name="arrow-forward" size={18} color={colors.textTertiary} />
                        <View style={stStyles.probItem}>
                          <Text style={stStyles.probLabel}>AI Suggested</Text>
                          <Text style={[stStyles.probValue, {
                            color: storedReport.probabilityAdjustment.aiSuggested > storedReport.probabilityAdjustment.current
                              ? colors.success : storedReport.probabilityAdjustment.aiSuggested < storedReport.probabilityAdjustment.current
                              ? colors.danger : colors.textPrimary,
                          }]}>{storedReport.probabilityAdjustment.aiSuggested}%</Text>
                        </View>
                      </View>
                      <Text style={stStyles.cardBody} numberOfLines={6}>{storedReport.probabilityAdjustment.justification}</Text>
                    </View>
                  )}

                  {/* Stage Readiness */}
                  <View style={stStyles.card}>
                    <View style={stStyles.cardHeader}>
                      <Ionicons name="flag" size={18} color={storedReport.stageReadiness.ready ? colors.success : '#F59E0B'} />
                      <Text style={stStyles.cardTitle}>Stage Readiness</Text>
                      <View style={[stStyles.scorePill, { backgroundColor: (storedReport.stageReadiness.ready ? colors.success : '#F59E0B') + '20' }]}>
                        <Text style={[stStyles.scorePillText, { color: storedReport.stageReadiness.ready ? colors.success : '#F59E0B' }]}>
                          {storedReport.stageReadiness.ready ? 'Ready' : 'Not Ready'}
                        </Text>
                      </View>
                    </View>
                    <Text style={stStyles.cardBody} numberOfLines={4}>{storedReport.stageReadiness.recommendation}</Text>
                    {storedReport.stageReadiness.missingElements.length > 0 && (
                      <View style={{ marginTop: spacing.sm }}>
                        <Text style={stStyles.subLabel}>Missing Elements:</Text>
                        {storedReport.stageReadiness.missingElements.map((m, i) => (
                          <View key={i} style={stStyles.bulletRow}>
                            <Text style={stStyles.bullet}>•</Text>
                            <Text style={stStyles.bulletText}>{m}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>

                  {/* Risk Analysis */}
                  {storedReport.riskAnalysis.length > 0 && (
                    <View style={stStyles.card}>
                      <View style={stStyles.cardHeader}>
                        <Ionicons name="warning" size={18} color={colors.danger} />
                        <Text style={stStyles.cardTitle}>Risk Analysis</Text>
                      </View>
                      {storedReport.riskAnalysis.map((r, i) => (
                        <View key={i} style={stStyles.riskItem}>
                          <View style={stStyles.riskHeader}>
                            <View style={[stStyles.severityBadge, { backgroundColor: severityColor(r.severity) + '20' }]}>
                              <Text style={[stStyles.severityText, { color: severityColor(r.severity) }]}>{r.severity}</Text>
                            </View>
                            <Text style={stStyles.riskTitle}>{r.risk}</Text>
                          </View>
                          <Text style={stStyles.riskMitigation} numberOfLines={3}>{r.mitigation}</Text>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Stakeholder Gaps */}
                  {storedReport.stakeholderGaps.length > 0 && (
                    <View style={stStyles.card}>
                      <View style={stStyles.cardHeader}>
                        <Ionicons name="people" size={18} color="#3B82F6" />
                        <Text style={stStyles.cardTitle}>Stakeholder Gaps</Text>
                      </View>
                      {storedReport.stakeholderGaps.map((s, i) => (
                        <View key={i} style={stStyles.stakeholderItem}>
                          <Text style={stStyles.stakeholderRole}>{s.role}</Text>
                          <Text style={stStyles.stakeholderWhy}>{s.whyNeeded}</Text>
                          <Text style={stStyles.stakeholderAccess}>→ {s.accessStrategy}</Text>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Win Strategy */}
                  <View style={stStyles.card}>
                    <View style={stStyles.cardHeader}>
                      <Ionicons name="trophy" size={18} color="#10B981" />
                      <Text style={stStyles.cardTitle}>Win Strategy</Text>
                    </View>
                    {storedReport.winStrategy.positioning && (
                      <View style={{ marginBottom: spacing.sm }}>
                        <Text style={stStyles.subLabel}>Positioning</Text>
                        <Text style={stStyles.cardBody}>{storedReport.winStrategy.positioning}</Text>
                      </View>
                    )}
                    {storedReport.winStrategy.differentiation && (
                      <View style={{ marginBottom: spacing.sm }}>
                        <Text style={stStyles.subLabel}>Differentiation</Text>
                        <Text style={stStyles.cardBody}>{storedReport.winStrategy.differentiation}</Text>
                      </View>
                    )}
                    {storedReport.winStrategy.keyMessages?.length > 0 && (
                      <View>
                        <Text style={stStyles.subLabel}>Key Messages</Text>
                        {storedReport.winStrategy.keyMessages.map((m, i) => (
                          <View key={i} style={stStyles.bulletRow}>
                            <Text style={stStyles.bullet}>•</Text>
                            <Text style={stStyles.bulletText}>{m}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                  </View>

                  {/* Interaction Analysis */}
                  <View style={stStyles.card}>
                    <View style={stStyles.cardHeader}>
                      <Ionicons name="chatbubbles" size={18} color="#F59E0B" />
                      <Text style={stStyles.cardTitle}>Interaction Analysis</Text>
                    </View>
                    <View style={stStyles.interactionGrid}>
                      <View style={stStyles.interactionItem}>
                        <Text style={stStyles.interactionLabel}>Last Contact</Text>
                        <Text style={stStyles.interactionValue}>{storedReport.interactionAnalysis.lastInteractionDate}</Text>
                      </View>
                      <View style={stStyles.interactionItem}>
                        <Text style={stStyles.interactionLabel}>Engagement</Text>
                        <Text style={[stStyles.interactionValue, {
                          color: storedReport.interactionAnalysis.engagementLevel === 'High' ? colors.success
                            : storedReport.interactionAnalysis.engagementLevel === 'Low' ? colors.danger : '#F59E0B',
                        }]}>{storedReport.interactionAnalysis.engagementLevel}</Text>
                      </View>
                    </View>
                    <Text style={stStyles.cardBody} numberOfLines={4}>{storedReport.interactionAnalysis.recommendedCadence}</Text>
                  </View>

                  {/* Close Plan */}
                  {storedReport.closePlan.length > 0 && (
                    <View style={stStyles.card}>
                      <View style={stStyles.cardHeader}>
                        <Ionicons name="git-branch" size={18} color="#7C3AED" />
                        <Text style={stStyles.cardTitle}>Close Plan</Text>
                      </View>
                      {storedReport.closePlan.map((step, i) => (
                        <View key={i} style={stStyles.closeStep}>
                          <View style={stStyles.stepNumber}>
                            <Text style={stStyles.stepNumberText}>{i + 1}</Text>
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={stStyles.stepTitle}>{step.step}</Text>
                            <Text style={stStyles.stepDesc}>{step.description}</Text>
                            {step.timeline && <Text style={stStyles.stepTimeline}>{step.timeline}</Text>}
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Recommended Actions */}
                  {storedReport.recommendedActions.length > 0 && (
                    <View style={stStyles.card}>
                      <View style={stStyles.cardHeader}>
                        <Ionicons name="rocket" size={18} color="#7C3AED" />
                        <Text style={stStyles.cardTitle}>Recommended Actions</Text>
                      </View>
                      <Text style={stStyles.selectHint}>Select actions to push to your Actions list</Text>
                      {storedReport.recommendedActions.map((action, i) => (
                        <TouchableOpacity key={i} style={stStyles.actionItem} onPress={() => toggleAction(i)}>
                          <Ionicons
                            name={selectedActions.has(i) ? 'checkbox' : 'square-outline'}
                            size={22}
                            color={selectedActions.has(i) ? '#7C3AED' : colors.textTertiary}
                          />
                          <View style={{ flex: 1 }}>
                            <View style={stStyles.actionTitleRow}>
                              <Text style={stStyles.actionTitle}>{action.title}</Text>
                              <View style={[stStyles.severityBadge, { backgroundColor: severityColor(action.priority === 'High' ? 'High' : action.priority === 'Low' ? 'Low' : 'Medium') + '20' }]}>
                                <Text style={[stStyles.severityText, { color: severityColor(action.priority === 'High' ? 'High' : action.priority === 'Low' ? 'Low' : 'Medium'), fontSize: 10 }]}>{action.priority}</Text>
                              </View>
                            </View>
                            <Text style={stStyles.actionDetails} numberOfLines={3}>{action.details}</Text>
                            {(action.suggestedOwner || action.suggestedDeadline) && (
                              <Text style={stStyles.actionMeta}>
                                {action.suggestedOwner ? `Owner: ${action.suggestedOwner}` : ''}
                                {action.suggestedOwner && action.suggestedDeadline ? ' · ' : ''}
                                {action.suggestedDeadline ? `By: ${action.suggestedDeadline}` : ''}
                              </Text>
                            )}
                          </View>
                        </TouchableOpacity>
                      ))}
                      {selectedActions.size > 0 && (
                        <TouchableOpacity
                          style={stStyles.pushBtn}
                          onPress={handlePushActions}
                          disabled={pushingActions}
                        >
                          {pushingActions ? <ActivityIndicator color="#fff" size="small" /> : (
                            <>
                              <Ionicons name="arrow-forward-circle" size={18} color="#fff" />
                              <Text style={stStyles.pushBtnText}>Push {selectedActions.size} Action{selectedActions.size > 1 ? 's' : ''} to List</Text>
                            </>
                          )}
                        </TouchableOpacity>
                      )}
                    </View>
                  )}
                </>
              )}
            </View>
          )}
        </View>

        {/* NBAs */}
        {/* Relationship Intelligence */}
        {opp && (
          <RelationshipIntelligence
            opportunityId={id}
            opportunity={{
              title: opp.title,
              status: opp.status,
              value: opp.value,
              probability: opp.probability,
              closeDate: opp.closeDate,
              notes: opp.notes,
              companyId: opp.companyId,
              contactId: opp.contactId,
            }}
            company={company ? {
              name: company.name,
              domain: (company as any).domain,
              industry: (company as any).industry,
              size: (company as any).size,
              insightsReport: (company as any).insightsReport,
            } : null}
            orgSettings={orgSettings ? {
              companyName: orgSettings.companyName,
              interests: orgSettings.interests,
              taxonomyProfile: orgSettings.taxonomyProfile,
            } : null}
          />
        )}

        {/* NBAs */}
        {nbas && nbas.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Next Best Actions</Text>
            {nbas.map((n) => (
              <NbaCard
                key={n._id}
                actionType={n.actionType}
                title={n.title}
                description={n.description}
                score={n.score}
                engine={n.engine}
                reasoning={n.reasoning}
                onExecute={() => executeNba({ id: n._id })}
                onDismiss={() => dismissNba({ id: n._id })}
              />
            ))}
          </View>
        )}

        {/* Timeline */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Timeline ({interactions?.length || 0})</Text>
          {interactions?.map((i) => (
            <View key={i._id} style={styles.timelineItem}>
              <View style={[styles.dot, { backgroundColor: colors.primary }]} />
              <View style={{ flex: 1 }}>
                <Text style={styles.tlType}>{i.type.toUpperCase()}</Text>
                {i.subject && <Text style={styles.tlSubject}>{i.subject}</Text>}
                {i.body && <Text style={styles.tlBody} numberOfLines={2}>{i.body}</Text>}
                <Text style={styles.tlDate}>{new Date(i.date).toLocaleDateString()}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Actions ({tasks?.length || 0})</Text>
          {tasks?.map((t) => (
            <View key={t._id} style={styles.taskRow}>
              <View style={[styles.statusDot, { backgroundColor: t.status === 'done' ? colors.success : colors.warning }]} />
              <Text style={styles.taskText}>{t.title}</Text>
            </View>
          ))}
        </View>
        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Status Picker Modal */}
      <Modal visible={showStatusPicker} animationType="fade" transparent>
        <TouchableOpacity
          style={{ flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.3)' }}
          onPress={() => setShowStatusPicker(false)}
        >
          <View style={{ backgroundColor: colors.white, borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: spacing.lg }}>
            <Text style={{ fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md }}>
              Change Status
            </Text>
            {STATUS_CONFIG.map(s => (
              <TouchableOpacity
                key={s.key}
                style={{
                  flexDirection: 'row', alignItems: 'center', gap: spacing.md,
                  paddingVertical: spacing.md, paddingHorizontal: spacing.md,
                  borderRadius: radius.md, marginBottom: 4,
                  backgroundColor: opp.status === s.key ? s.color + '15' : 'transparent',
                }}
                onPress={() => handleStatusChange(s.key)}
              >
                <Ionicons name={s.icon as any} size={20} color={s.color} />
                <Text style={{ fontSize: fontSize.md, fontWeight: opp.status === s.key ? '700' : '500', color: s.color, flex: 1 }}>
                  {s.label}
                </Text>
                {opp.status === s.key && <Ionicons name="checkmark-circle" size={20} color={s.color} />}
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>

      {/* Lost Competitor Prompt */}
      <Modal visible={showLostPrompt} animationType="fade" transparent>
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.4)', padding: spacing.xl }}>
          <View style={{ backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.xl, width: '100%' }}>
            <Text style={{ fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.sm }}>
              Mark as Lost
            </Text>
            <Text style={{ fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: spacing.lg }}>
              Optionally record the competitor who won this opportunity.
            </Text>
            <TextInput
              style={{ backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md, marginBottom: spacing.lg }}
              placeholder="Competitor name (optional)"
              placeholderTextColor={colors.textTertiary}
              value={lostCompetitor}
              onChangeText={setLostCompetitor}
            />
            <View style={{ flexDirection: 'row', gap: spacing.md }}>
              <TouchableOpacity
                style={{ flex: 1, paddingVertical: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, alignItems: 'center' }}
                onPress={() => { setShowLostPrompt(false); setLostCompetitor(''); }}
              >
                <Text style={{ color: colors.textSecondary, fontWeight: '600' }}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{ flex: 1, paddingVertical: spacing.md, borderRadius: radius.md, backgroundColor: colors.danger, alignItems: 'center' }}
                onPress={handleLostConfirm}
              >
                <Text style={{ color: colors.white, fontWeight: '700' }}>Mark Lost</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Add Stakeholder Modal */}
      <Modal visible={showAddStakeholder} animationType="slide" transparent>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          keyboardVerticalOffset={10}
        >
          <View style={shStyles.modalOverlay}>
            <View style={shStyles.modalContent}>
              <View style={shStyles.modalHeader}>
                <Text style={shStyles.modalTitle}>Add Stakeholder Company</Text>
                <TouchableOpacity onPress={() => { setShowAddStakeholder(false); setSelectedCompanyId(null); setStakeholderSearch(''); }}>
                  <Ionicons name="close" size={24} color={colors.textPrimary} />
                </TouchableOpacity>
              </View>

              <ScrollView style={{ flex: 1 }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ paddingBottom: 40 }}>
                {/* Company Search */}
                <Text style={shStyles.fieldLabel}>Company</Text>
                {selectedCompanyId ? (
                  <View style={shStyles.selectedCompany}>
                    <Text style={shStyles.selectedCompanyName}>
                      {allCompanies?.find(c => c._id === selectedCompanyId)?.name || 'Selected'}
                    </Text>
                    <TouchableOpacity onPress={() => { setSelectedCompanyId(null); setStakeholderSearch(''); }}>
                      <Ionicons name="close-circle" size={20} color={colors.textTertiary} />
                    </TouchableOpacity>
                  </View>
                ) : (
                  <>
                    <TextInput
                      style={shStyles.searchInput}
                      placeholder="Search companies..."
                      placeholderTextColor={colors.textTertiary}
                      value={stakeholderSearch}
                      onChangeText={setStakeholderSearch}
                      autoFocus
                    />
                    <FlatList
                      data={filteredCompanies}
                      keyExtractor={(item) => item._id}
                      style={shStyles.companyList}
                      showsVerticalScrollIndicator
                      keyboardShouldPersistTaps="handled"
                      renderItem={({ item }) => (
                        <TouchableOpacity
                          style={shStyles.companyItem}
                          onPress={() => { setSelectedCompanyId(item._id); setStakeholderSearch(''); }}
                        >
                          <Ionicons name="business-outline" size={16} color={colors.textSecondary} />
                          <Text style={shStyles.companyItemName} numberOfLines={1}>{item.name}</Text>
                        </TouchableOpacity>
                      )}
                      ListEmptyComponent={
                        <Text style={shStyles.noResults}>No matching companies</Text>
                      }
                    />
                  </>
                )}

                {/* Role Picker */}
                <Text style={[shStyles.fieldLabel, { marginTop: spacing.md }]}>Role in this Deal</Text>
                <View style={shStyles.roleGrid}>
                  {COMPANY_ROLES.map(r => (
                    <TouchableOpacity
                      key={r.value}
                      style={[
                        shStyles.roleChip,
                        selectedRole === r.value && { backgroundColor: getRoleColor(r.value) + '20', borderColor: getRoleColor(r.value) },
                      ]}
                      onPress={() => setSelectedRole(r.value)}
                    >
                      <Text style={[
                        shStyles.roleChipText,
                        selectedRole === r.value && { color: getRoleColor(r.value), fontWeight: '700' },
                      ]}>
                        {r.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Notes */}
                <Text style={[shStyles.fieldLabel, { marginTop: spacing.md }]}>Notes (optional)</Text>
                <TextInput
                  style={[shStyles.searchInput, { height: 60, textAlignVertical: 'top' }]}
                  placeholder="e.g., Key decision maker for pipeline access..."
                  placeholderTextColor={colors.textTertiary}
                  value={stakeholderNotes}
                  onChangeText={setStakeholderNotes}
                  multiline
                />

                {/* Submit */}
                <TouchableOpacity
                  style={[shStyles.submitBtn, !selectedCompanyId && { opacity: 0.5 }]}
                  onPress={handleAddStakeholder}
                  disabled={!selectedCompanyId}
                >
                  <Ionicons name="add-circle" size={18} color="#fff" />
                  <Text style={shStyles.submitBtnText}>Add to Deal</Text>
                </TouchableOpacity>
              </ScrollView>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      <ActionFormModal
        visible={showAddAction}
        onClose={() => setShowAddAction(false)}
        preLinkedType="opportunity"
        preLinkedId={id}
        preLinkedLabel={`Opportunity: ${opp.title}`}
      />

      <FormModal
        visible={showEdit}
        title="Edit Opportunity"
        fields={[
          { key: 'title', label: 'Title', required: true },
          { key: 'value', label: 'Value ($)', type: 'number' },
          { key: 'probability', label: 'Probability (%)', type: 'number' },
          { key: 'location', label: 'Location' },
          { key: 'notes', label: 'Notes', type: 'multiline' },
        ]}
        initialValues={{
          title: opp.title,
          value: opp.value?.toString() || '',
          probability: opp.probability?.toString() || '',
          location: opp.location || '',
          notes: opp.notes || '',
        }}
        onClose={() => setShowEdit(false)}
        onSubmit={async (vals) => {
          await updateOpp({
            id,
            title: vals.title || undefined,
            value: vals.value ? parseFloat(vals.value) : undefined,
            probability: vals.probability ? parseInt(vals.probability) : undefined,
            location: vals.location || undefined,
            notes: vals.notes || undefined,
          });
          setShowEdit(false);
        }}
      />

      <FormModal
        visible={showAddNote}
        title="Add Note"
        fields={[
          { key: 'subject', label: 'Subject' },
          { key: 'body', label: 'Note', type: 'multiline', required: true },
        ]}
        onClose={() => setShowAddNote(false)}
        onSubmit={async (vals) => {
          await createInteraction({ type: 'note', subject: vals.subject || undefined, body: vals.body, opportunityId: id });
          setShowAddNote(false);
        }}
      />

      <ContextualEntry
        visible={showContext}
        onClose={() => setShowContext(false)}
        entryType="opportunity"
        entryId={id}
        entityContext={JSON.stringify({
          title: opp.title, value: opp.value, stage: opp.stageName,
          company: opp.companyName, contact: opp.contactName, status: opp.status,
        })}
      />
    </SafeAreaView>
  );
}

function MetaItem({ label, value, onPress }: { label: string; value: string; onPress?: () => void }) {
  const content = (
    <View style={styles.metaItem}>
      <Text style={styles.metaLabel}>{label}</Text>
      <Text style={[styles.metaValue, onPress && { color: colors.primary }]}>{value}</Text>
    </View>
  );
  if (onPress) {
    return <TouchableOpacity onPress={onPress}>{content}</TouchableOpacity>;
  }
  return content;
}

function QuickBtn({ icon, label, color, onPress }: { icon: string; label: string; color?: string; onPress: () => void }) {
  const c = color || colors.primary;
  return (
    <TouchableOpacity style={styles.quickBtn} onPress={onPress}>
      <View style={[styles.quickBtnIcon, { backgroundColor: c + '15' }]}>
        <Ionicons name={icon as any} size={20} color={c} />
      </View>
      <Text style={[styles.quickBtnLabel, { color: c }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  navBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: spacing.sm },
  navActions: { flexDirection: 'row', gap: spacing.md },
  navBtn: { width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.white, justifyContent: 'center', alignItems: 'center', ...shadow.sm },
  scroll: { paddingHorizontal: spacing.lg },
  heroCard: { backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.xl, alignItems: 'center', ...shadow.md },
  stageBadge: { paddingHorizontal: spacing.md, paddingVertical: 4, borderRadius: radius.sm },
  stageBadgeText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.primary },
  heroName: { fontSize: fontSize.xl, fontWeight: '700', color: colors.textPrimary, marginTop: spacing.sm, textAlign: 'center' },
  heroValue: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.success, marginTop: spacing.xs },
  metaGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.lg, marginTop: spacing.lg, justifyContent: 'center' },
  metaItem: { alignItems: 'center', minWidth: 80 },
  metaLabel: { fontSize: fontSize.xs, color: colors.textTertiary },
  metaValue: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, marginTop: 2 },
  quickActions: { flexDirection: 'row', justifyContent: 'center', gap: spacing.lg, marginVertical: spacing.lg, flexWrap: 'wrap' },
  quickBtn: { alignItems: 'center', gap: spacing.xs },
  quickBtnIcon: { width: 44, height: 44, borderRadius: radius.lg, justifyContent: 'center', alignItems: 'center' },
  quickBtnLabel: { fontSize: fontSize.xs, fontWeight: '500' },
  section: { marginTop: spacing.lg },
  sectionTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  timelineItem: { flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  dot: { width: 10, height: 10, borderRadius: 5, marginTop: 4 },
  tlType: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary, letterSpacing: 0.5 },
  tlSubject: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  tlBody: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  tlDate: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  taskRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.sm },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  taskText: { fontSize: fontSize.md, color: colors.textPrimary },
});

const stStyles = StyleSheet.create({
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.lg, ...shadow.sm,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  headerTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  healthBadge: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  healthScore: { fontSize: fontSize.sm, fontWeight: '700' },
  body: { marginTop: spacing.md },
  buttonRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md },
  actionBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.xs, paddingVertical: spacing.md, borderRadius: radius.lg,
  },
  actionBtnText: { color: '#fff', fontWeight: '700', fontSize: fontSize.sm },
  loadingBox: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.sm, padding: spacing.lg, backgroundColor: '#7C3AED10', borderRadius: radius.lg,
  },
  loadingText: { color: '#7C3AED', fontWeight: '600', fontSize: fontSize.sm },
  timestamp: { fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: spacing.md, textAlign: 'center' },
  card: {
    backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg,
    marginBottom: spacing.lg, ...shadow.sm,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.md },
  cardTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.textPrimary, flex: 1 },
  cardBody: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 22 },
  subLabel: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 },
  bulletRow: { flexDirection: 'row', gap: spacing.sm, marginTop: 6 },
  bullet: { fontSize: fontSize.sm, color: colors.textTertiary, lineHeight: 22 },
  bulletText: { fontSize: fontSize.sm, color: colors.textSecondary, flex: 1, lineHeight: 22 },
  probRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.lg, marginBottom: spacing.sm, paddingVertical: spacing.sm },
  probItem: { alignItems: 'center' },
  probLabel: { fontSize: fontSize.xs, color: colors.textTertiary },
  probValue: { fontSize: fontSize.xl, fontWeight: '800', color: colors.textPrimary },
  scorePill: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  scorePillText: { fontSize: fontSize.xs, fontWeight: '700' },
  riskItem: { paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  riskHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 4 },
  riskTitle: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, flex: 1 },
  riskMitigation: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 22, marginLeft: spacing.xl },
  severityBadge: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  severityText: { fontSize: fontSize.xs, fontWeight: '700' },
  stakeholderItem: { paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  stakeholderRole: { fontSize: fontSize.sm, fontWeight: '700', color: '#3B82F6' },
  stakeholderWhy: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2, lineHeight: 22 },
  stakeholderAccess: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500', marginTop: 4, lineHeight: 22 },
  interactionGrid: { flexDirection: 'row', gap: spacing.lg, marginBottom: spacing.sm },
  interactionItem: { flex: 1 },
  interactionLabel: { fontSize: fontSize.xs, color: colors.textTertiary },
  interactionValue: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textPrimary, marginTop: 2 },
  closeStep: { flexDirection: 'row', gap: spacing.md, paddingVertical: spacing.sm },
  stepNumber: {
    width: 24, height: 24, borderRadius: 12, backgroundColor: '#7C3AED20',
    justifyContent: 'center', alignItems: 'center', marginTop: 2,
  },
  stepNumberText: { fontSize: fontSize.xs, fontWeight: '700', color: '#7C3AED' },
  stepTitle: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textPrimary },
  stepDesc: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 22, marginTop: 2 },
  stepTimeline: { fontSize: fontSize.xs, color: '#7C3AED', fontWeight: '600', marginTop: 4 },
  selectHint: { fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: spacing.sm },
  actionItem: { flexDirection: 'row', gap: spacing.sm, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight, alignItems: 'flex-start' },
  actionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  actionTitle: { fontSize: fontSize.sm, fontWeight: '700', color: colors.textPrimary, flex: 1 },
  actionDetails: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 22, marginTop: 4 },
  actionMeta: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  pushBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    backgroundColor: '#7C3AED', paddingVertical: spacing.md, borderRadius: radius.lg, marginTop: spacing.md,
  },
  pushBtnText: { color: '#fff', fontWeight: '700', fontSize: fontSize.sm },
});

const shStyles = StyleSheet.create({
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: colors.white, borderRadius: radius.xl, padding: spacing.lg, ...shadow.sm,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  headerTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  countBadge: {
    backgroundColor: '#3B82F620', paddingHorizontal: spacing.sm, paddingVertical: 2,
    borderRadius: radius.full, minWidth: 24, alignItems: 'center',
  },
  countText: { fontSize: fontSize.xs, fontWeight: '700', color: '#3B82F6' },
  body: { marginTop: spacing.sm },
  emptyState: { alignItems: 'center', paddingVertical: spacing.xl },
  emptyText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginTop: spacing.sm },
  emptySubtext: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  stakeCard: {
    backgroundColor: colors.white, borderRadius: radius.lg, marginBottom: spacing.sm,
    ...shadow.sm, overflow: 'hidden',
  },
  stakeMain: { flexDirection: 'row', alignItems: 'center', padding: spacing.md },
  roleIndicator: { width: 4, height: 40, borderRadius: 2, marginRight: spacing.md },
  stakeInfo: { flex: 1 },
  stakeName: { fontSize: fontSize.md, fontWeight: '700', color: colors.textPrimary },
  roleBadge: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.xs,
    paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm,
    alignSelf: 'flex-start', marginTop: 4,
  },
  roleText: { fontSize: fontSize.xs, fontWeight: '600' },
  primaryBadge: {
    backgroundColor: '#10B981', paddingHorizontal: 6, paddingVertical: 1, borderRadius: 4,
  },
  primaryText: { fontSize: 9, fontWeight: '800', color: '#fff', letterSpacing: 0.5 },
  stakeNotes: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },
  removeBtn: { padding: spacing.xs },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xs,
    paddingVertical: spacing.md, backgroundColor: '#3B82F610', borderRadius: radius.lg,
    borderWidth: 1, borderColor: '#3B82F630', borderStyle: 'dashed',
  },
  addBtnText: { fontSize: fontSize.sm, fontWeight: '600', color: '#3B82F6' },
  modalOverlay: {
    flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.4)',
  },
  modalContent: {
    backgroundColor: colors.white, borderTopLeftRadius: radius.xl, borderTopRightRadius: radius.xl,
    padding: spacing.xl, maxHeight: '85%',
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    marginBottom: spacing.lg,
  },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  fieldLabel: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: spacing.xs,
  },
  searchInput: {
    backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md,
    color: colors.textPrimary,
  },
  selectedCompany: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#3B82F610', borderWidth: 1, borderColor: '#3B82F640',
    borderRadius: radius.md, padding: spacing.md,
  },
  selectedCompanyName: { fontSize: fontSize.md, fontWeight: '600', color: '#3B82F6' },
  companyList: { maxHeight: 132, marginTop: spacing.xs, borderWidth: 1, borderColor: colors.borderLight, borderRadius: 8 },
  companyItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingVertical: spacing.sm, paddingHorizontal: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  companyItemName: { fontSize: fontSize.md, color: colors.textPrimary },
  noResults: { fontSize: fontSize.sm, color: colors.textTertiary, textAlign: 'center', padding: spacing.lg },
  roleGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  roleChip: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
    backgroundColor: colors.bg,
  },
  roleChipText: { fontSize: fontSize.xs, color: colors.textSecondary },
  submitBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    backgroundColor: '#3B82F6', paddingVertical: spacing.md, borderRadius: radius.lg,
    marginTop: spacing.lg,
  },
  submitBtnText: { color: '#fff', fontWeight: '700', fontSize: fontSize.sm },
});
