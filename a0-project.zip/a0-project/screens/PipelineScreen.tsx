import React, { useState, useMemo } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput,
  Modal, FlatList, Alert, Dimensions, ActivityIndicator, Platform,
  KeyboardAvoidingView, TouchableWithoutFeedback,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import * as Location from 'expo-location';
import OpportunityScoutAI from '../components/OpportunityScoutAI';

let MapView: any = View;
let Marker: any = View;
if (Platform.OS !== 'web') {
  try {
    const maps = require('react-native-maps');
    MapView = maps.default || maps.MapView;
    Marker = maps.Marker;
  } catch {}
}

// Strategist report type
type StrategistReport = {
  opportunityHealthScore: { score: number; reasoning: string };
  stageReadiness: { ready: boolean; missingElements: string[]; recommendation: string };
  riskAnalysis: { risk: string; severity: string; mitigation: string }[];
  stakeholderGaps: { role: string; whyNeeded: string; accessStrategy: string }[];
  winStrategy: { positioning: string; differentiation: string; keyMessages: string[] };
  interactionAnalysis: { lastInteractionDate: string; engagementLevel: string; recommendedCadence: string };
  closePlan: { step: string; description: string; timeline: string }[];
  probabilityAdjustment: { current: number; aiSuggested: number; justification: string };
  recommendedActions: { title: string; details: string; priority: string; suggestedOwner: string; suggestedDeadline: string }[];
};

const safeStr = (v: any, fallback = ''): string => {
  if (typeof v === 'string') return v;
  if (v == null) return fallback;
  if (typeof v === 'number' || typeof v === 'boolean') return String(v);
  if (typeof v === 'object') {
    if (Array.isArray(v)) return v.map(item => safeStr(item)).join('; ');
    const entries = Object.values(v).filter(Boolean);
    if (entries.length > 0) return entries.map(e => safeStr(e)).join('. ');
    return fallback;
  }
  return fallback;
};

const safeArray = (v: any, arrayKey?: string): any[] => {
  if (Array.isArray(v)) return v;
  if (v && typeof v === 'object' && arrayKey && Array.isArray(v[arrayKey])) return v[arrayKey];
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    for (const val of Object.values(v)) {
      if (Array.isArray(val)) return val as any[];
    }
  }
  return [];
};

const normalizeReport = (r: any, fallbackProb = 0): StrategistReport | null => {
  if (!r || typeof r !== 'object') return null;
  const ohs = r.opportunityHealthScore || r.opportunityHealth || {};
  const sr = r.stageReadiness || {};
  const ws = r.winStrategy || {};
  const ia = r.interactionAnalysis || {};
  const pa = r.probabilityAdjustment || {};
  const rawRisks = r.riskAnalysis || r.risks || [];
  const riskArray = safeArray(rawRisks);
  const rawStakeholders = r.stakeholderGaps || r.stakeholderMap || [];
  let stakeholderArray: any[] = [];
  if (Array.isArray(rawStakeholders)) {
    stakeholderArray = rawStakeholders;
  } else if (rawStakeholders && typeof rawStakeholders === 'object') {
    const missing = rawStakeholders.missingRoles || rawStakeholders.gaps || [];
    if (Array.isArray(missing)) {
      stakeholderArray = missing.map((m: any) =>
        typeof m === 'string' ? { role: m, whyNeeded: '', accessStrategy: safeStr(rawStakeholders.accessPlan) } : m
      );
    }
  }
  const rawClose = r.closePlan || [];
  const closeArray = Array.isArray(rawClose) ? rawClose : safeArray(rawClose, 'steps');
  const missingElements = sr.missingElements || sr.missingForNextStage || [];

  let healthReasoning = '';
  if (ohs.reasoning) {
    healthReasoning = safeStr(ohs.reasoning, 'No data');
  } else if (ohs.summary) {
    const parts = [ohs.summary];
    if (Array.isArray(ohs.strengths)) parts.push('Strengths: ' + ohs.strengths.map((s: any) => safeStr(s)).join('; '));
    if (Array.isArray(ohs.weaknesses)) parts.push('Weaknesses: ' + ohs.weaknesses.map((w: any) => safeStr(w)).join('; '));
    healthReasoning = parts.join('\n\n');
  } else {
    healthReasoning = 'No data';
  }

  return {
    opportunityHealthScore: { score: Number(ohs.score) || 5, reasoning: healthReasoning.slice(0, 500) },
    stageReadiness: {
      ready: !!(sr.ready ?? sr.readyToAdvance),
      missingElements: Array.isArray(missingElements) ? missingElements.map((e: any) => safeStr(e)).slice(0, 8) : [],
      recommendation: safeStr(sr.recommendation || sr.currentStage || ''),
    },
    riskAnalysis: riskArray.slice(0, 6).map((x: any) => ({
      risk: safeStr(x.risk || x.name || x.title, 'Risk').slice(0, 120),
      severity: safeStr(x.severity || x.level, 'Medium'),
      mitigation: safeStr(x.mitigation || x.action, '').slice(0, 200),
    })),
    stakeholderGaps: stakeholderArray.slice(0, 6).map((x: any) => ({
      role: safeStr(x.role || x.title, 'Role').slice(0, 60),
      whyNeeded: safeStr(x.whyNeeded || x.why, '').slice(0, 200),
      accessStrategy: safeStr(x.accessStrategy || x.access, '').slice(0, 200),
    })),
    winStrategy: {
      positioning: safeStr(ws.positioning).slice(0, 300),
      differentiation: safeStr(ws.differentiation).slice(0, 300),
      keyMessages: Array.isArray(ws.keyMessages) ? ws.keyMessages.map((m: any) => safeStr(m)).slice(0, 5) : [],
    },
    interactionAnalysis: {
      lastInteractionDate: safeStr(ia.lastInteractionDate, 'Unknown'),
      engagementLevel: safeStr(ia.engagementLevel, 'Unknown'),
      recommendedCadence: safeStr(ia.recommendedCadence).slice(0, 200),
    },
    closePlan: closeArray.slice(0, 8).map((x: any) => ({
      step: safeStr(x.step || x.name || x.title || 'Step').slice(0, 80),
      description: safeStr(x.description || x.details, '').slice(0, 200),
      timeline: safeStr(x.timeline || x.timeframe || x.when, ''),
    })),
    probabilityAdjustment: {
      current: pa.current ?? pa.currentProbability ?? fallbackProb,
      aiSuggested: pa.aiSuggested ?? pa.suggested ?? pa.adjustedProbability ?? fallbackProb,
      justification: safeStr(pa.justification || pa.reasoning).slice(0, 250),
    },
    recommendedActions: (Array.isArray(r.recommendedActions) ? r.recommendedActions : []).slice(0, 6).map((a: any) => {
      if (typeof a === 'string') return { title: a.slice(0, 60), details: a, priority: 'Medium', suggestedOwner: '', suggestedDeadline: '' };
      return {
        title: safeStr(a.title, 'Action').slice(0, 60),
        details: safeStr(a.details).slice(0, 200),
        priority: safeStr(a.priority, 'Medium'),
        suggestedOwner: safeStr(a.suggestedOwner),
        suggestedDeadline: safeStr(a.suggestedDeadline),
      };
    }),
  };
};

const STRATEGIST_PROMPT = `You are an Opportunity Strategist for complex B2B industrial deals. Analyze this opportunity and produce a concrete win strategy.

Adapt to status: early_planning→shape/position; pushed_assessment→validate fit/qualify; pushed_scoping→define scope/value prop; pushed_proposal→differentiate/articulate ROI; pushed_negotiation→close terms/align; rfi/rfp/rfq→differentiate/comply; late-stage→close/align; lost→lessons.

Assess: health (1-10), stage readiness, risks, stakeholder gaps, win positioning, interaction cadence, close plan, probability adjustment, and recommended actions.

Detect contradictions (high prob + low activity, imminent close + early stage). Be specific and execution-oriented — no generic advice. All text fields: max 2 sentences. Action titles: max 8 words.`;

const STATUS_CONFIG = [
  { key: 'early_planning', label: 'Early Planning', color: '#8B5CF6', icon: 'bulb' },
  { key: 'pushed_assessment', label: 'Pushed — Assessment', color: '#0D9488', icon: 'arrow-up-circle' },
  { key: 'pushed_scoping', label: 'Pushed — Scoping', color: '#0F766E', icon: 'resize' },
  { key: 'pushed_proposal', label: 'Pushed — Proposal', color: '#115E59', icon: 'document-attach' },
  { key: 'pushed_negotiation', label: 'Pushed — Negotiation', color: '#134E4A', icon: 'swap-horizontal' },
  { key: 'rfi', label: 'RFI', color: '#3B82F6', icon: 'information-circle' },
  { key: 'rfp', label: 'RFP', color: '#F59E0B', icon: 'document-text' },
  { key: 'rfq', label: 'RFQ', color: '#F97316', icon: 'calculator' },
  { key: 'won', label: 'Won', color: '#10B981', icon: 'trophy' },
  { key: 'lost', label: 'Lost', color: '#EF4444', icon: 'close-circle' },
];

const SORT_OPTIONS = [
  { key: 'date_desc', label: 'Newest First' },
  { key: 'date_asc', label: 'Oldest First' },
  { key: 'value_desc', label: 'Highest Value' },
  { key: 'value_asc', label: 'Lowest Value' },
];

const DATE_FILTERS = [
  { key: 'all', label: 'All Time' },
  { key: 'month', label: 'This Month' },
  { key: 'quarter', label: 'This Quarter' },
  { key: 'year', label: 'This Year' },
  { key: '6months', label: 'Last 6 Mo' },
];

const getDateFilterStart = (key: string): number | null => {
  if (key === 'all') return null;
  const now = new Date();
  switch (key) {
    case 'month':
      return new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    case 'quarter': {
      const q = Math.floor(now.getMonth() / 3) * 3;
      return new Date(now.getFullYear(), q, 1).getTime();
    }
    case 'year':
      return new Date(now.getFullYear(), 0, 1).getTime();
    case '6months':
      return new Date(now.getFullYear(), now.getMonth() - 6, now.getDate()).getTime();
    default: return null;
  }
};

const formatValue = (val?: number) => {
  if (!val) return '';
  if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
  if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
  return `$${val}`;
};

const formatDate = (ts: number) => {
  const d = new Date(ts);
  return `${d.getDate()} ${d.toLocaleString('default', { month: 'short' })} ${d.getFullYear().toString().slice(-2)}`;
};

export default function PipelineScreen({ navigation }: any) {
  const opportunities = useQuery(api.opportunities.list, {});
  const companies = useQuery(api.companies.list);
  const createOpp = useMutation(api.opportunities.create);
  const orgSettings = useQuery(api.orgSettings.get);
  const saveStrategistReport = useMutation(api.opportunities.saveStrategistReport);
  const saveCompanyInsights = useMutation(api.companies.saveInsights);

  // Filters
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [companyFilter, setCompanyFilter] = useState<string | null>(null);
  const [dateFilter, setDateFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date_desc');
  const [showCompanyFilter, setShowCompanyFilter] = useState(false);
  const [showSortPicker, setShowSortPicker] = useState(false);
  const [showDateFilter, setShowDateFilter] = useState(false);
  const [scoutExpanded, setScoutExpanded] = useState(false);

  // Collapse state
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  // Create form
  const [showCreate, setShowCreate] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formCompanyId, setFormCompanyId] = useState<string | null>(null);
  const [formStatus, setFormStatus] = useState('early_planning');
  const [formValue, setFormValue] = useState('');
  const [formProbability, setFormProbability] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formLostCompetitor, setFormLostCompetitor] = useState('');
  const [companyPickerOpen, setCompanyPickerOpen] = useState(false);
  const [companySearch, setCompanySearch] = useState('');
  const [creating, setCreating] = useState(false);

  // Map location picker
  const [showMap, setShowMap] = useState(false);
  const [mapCoords, setMapCoords] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapAddress, setMapAddress] = useState('');
  const [locationSearch, setLocationSearch] = useState('');
  const [searchingLocation, setSearchingLocation] = useState(false);
  const [mapRegion, setMapRegion] = useState({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 40,
    longitudeDelta: 40,
  });

  // AI Strategist
  const [aiAnalyzing, setAiAnalyzing] = useState(false);
  const [aiReport, setAiReport] = useState<StrategistReport | null>(null);
  const [aiExpanded, setAiExpanded] = useState(false);

  // Get full company details when selected (for insightsReport)
  const companyDetail = useQuery(
    api.companies.get,
    formCompanyId ? { id: formCompanyId as any } : "skip"
  );

  // Filter & sort
  const filtered = useMemo(() => {
    if (!opportunities) return [];
    let list = [...opportunities];
    if (statusFilter) list = list.filter(o => o.status === statusFilter);
    if (companyFilter) list = list.filter(o => o.companyId === companyFilter);

    // Date filter
    const dateStart = getDateFilterStart(dateFilter);
    if (dateStart) list = list.filter(o => o._creationTime >= dateStart);

    list.sort((a, b) => {
      switch (sortBy) {
        case 'date_asc': return a._creationTime - b._creationTime;
        case 'value_desc': return (b.value || 0) - (a.value || 0);
        case 'value_asc': return (a.value || 0) - (b.value || 0);
        default: return b._creationTime - a._creationTime;
      }
    });
    return list;
  }, [opportunities, statusFilter, companyFilter, dateFilter, sortBy]);

  // Group by status
  const grouped = useMemo(() => {
    const groups: Record<string, typeof filtered> = {};
    for (const s of STATUS_CONFIG) groups[s.key] = [];
    for (const o of filtered) {
      const status = o.status || 'early_planning';
      if (!groups[status]) groups[status] = [];
      groups[status].push(o);
    }
    return groups;
  }, [filtered]);

  const totalValue = filtered.reduce((s, o) => s + (o.value || 0), 0);
  const wonCount = filtered.filter(o => o.status === 'won').length;
  const closedCount = filtered.filter(o => o.status === 'won' || o.status === 'lost').length;
  const winRate = closedCount > 0 ? Math.round((wonCount / closedCount) * 100) : 0;

  const toggleCollapse = (key: string) => {
    setCollapsed(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const selectedCompanyName = companyFilter
    ? companies?.find((c: any) => c._id === companyFilter)?.name || 'Company'
    : 'All Companies';

  const filteredCompanies = useMemo(() => {
    if (!companies) return [];
    if (!companySearch.trim()) return companies;
    const q = companySearch.toLowerCase();
    return companies.filter((c: any) => c.name.toLowerCase().includes(q) || (c.domain || '').toLowerCase().includes(q));
  }, [companies, companySearch]);

  const selectedCompanyObj = formCompanyId ? companies?.find((c: any) => c._id === formCompanyId) : null;

  const handleCreate = async () => {
    if (!formTitle.trim()) { Alert.alert('Required', 'Enter an opportunity title.'); return; }
    if (!formCompanyId) { Alert.alert('Required', 'Select a company.'); return; }
    setCreating(true);
    try {
      // Build location JSON if we have coords or address
      let locationData: string | undefined;
      if (mapCoords) {
        locationData = JSON.stringify({
          lat: mapCoords.latitude,
          lng: mapCoords.longitude,
          address: mapAddress || formLocation.trim() || '',
        });
      } else if (formLocation.trim()) {
        locationData = JSON.stringify({ address: formLocation.trim() });
      }

      const oppId = await createOpp({
        title: formTitle.trim(),
        companyId: formCompanyId as any,
        status: formStatus,
        value: formValue ? parseFloat(formValue) : undefined,
        probability: formProbability ? parseInt(formProbability) : undefined,
        location: locationData,
        notes: formNotes.trim() || undefined,
        ...(formStatus === 'lost' && formLostCompetitor.trim()
          ? { lostCompetitor: formLostCompetitor.trim() } : {}),
      });

      // Save strategist report if generated
      if (aiReport && oppId) {
        try {
          await saveStrategistReport({
            id: oppId as any,
            report: JSON.stringify(aiReport),
          });
        } catch {
          // Non-critical — report can be regenerated from detail screen
        }
      }

      setShowCreate(false);
      resetForm();
    } catch (e: any) {
      Alert.alert('Error', e.message);
    } finally {
      setCreating(false);
    }
  };

  const resetForm = () => {
    setFormTitle(''); setFormCompanyId(null); setFormStatus('early_planning');
    setFormValue(''); setFormProbability(''); setFormLocation('');
    setFormNotes(''); setFormLostCompetitor('');
    setCompanyPickerOpen(false); setCompanySearch('');
    setShowMap(false); setMapCoords(null); setMapAddress('');
    setLocationSearch(''); setSearchingLocation(false);
    setAiReport(null); setAiExpanded(false); setAiAnalyzing(false);
  };

  const handleMapPress = async (e: any) => {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setMapCoords({ latitude, longitude });
    // Reverse geocode
    try {
      const results = await Location.reverseGeocodeAsync({ latitude, longitude });
      if (results.length > 0) {
        const r = results[0];
        const parts = [r.name, r.street, r.city, r.region, r.country].filter(Boolean);
        const addr = parts.join(', ');
        setMapAddress(addr);
        setFormLocation(addr);
      }
    } catch {
      // Reverse geocode failed, keep coords without address
    }
  };

  const handleLocationSearch = async () => {
    if (!locationSearch.trim()) return;
    setSearchingLocation(true);
    try {
      const results = await Location.geocodeAsync(locationSearch.trim());
      if (results.length > 0) {
        const { latitude, longitude } = results[0];
        setMapCoords({ latitude, longitude });
        setMapRegion({
          latitude,
          longitude,
          latitudeDelta: 0.5,
          longitudeDelta: 0.5,
        });
        // Reverse geocode for formatted address
        try {
          const rev = await Location.reverseGeocodeAsync({ latitude, longitude });
          if (rev.length > 0) {
            const r = rev[0];
            const parts = [r.name, r.street, r.city, r.region, r.country].filter(Boolean);
            const addr = parts.join(', ');
            setMapAddress(addr);
            setFormLocation(addr);
          } else {
            setMapAddress(locationSearch.trim());
            setFormLocation(locationSearch.trim());
          }
        } catch {
          setMapAddress(locationSearch.trim());
          setFormLocation(locationSearch.trim());
        }
      } else {
        Alert.alert('Not Found', 'Could not find that location. Try a different search.');
      }
    } catch {
      Alert.alert('Error', 'Location search failed. Try again.');
    } finally {
      setSearchingLocation(false);
    }
  };

  const handleStrategyAnalysis = async () => {
    if (!formTitle.trim()) { Alert.alert('Required', 'Enter an opportunity title first.'); return; }
    if (!formCompanyId) { Alert.alert('Required', 'Select a company first.'); return; }

    const company = companyDetail || companies?.find((c: any) => c._id === formCompanyId);

    // Check if company has BD Intelligence report
    if (!companyDetail?.insightsReport) {
      const userChoice = await new Promise<string>((resolve) => {
        Alert.alert(
          'BD Intelligence Required',
          `No BD Intelligence report found for ${(company as any)?.name || 'this company'}. The Strategist works best with a company intelligence report. Generate one first?`,
          [
            { text: 'Skip', style: 'cancel', onPress: () => resolve('skip') },
            { text: 'Generate BD Intel', onPress: () => resolve('generate') },
          ]
        );
      });

      if (userChoice === 'generate') {
        if (!orgSettings) {
          Alert.alert('Profile Required', 'Set up your company profile in Settings first.');
          return;
        }
        setAiAnalyzing(true);
        setAiExpanded(true);
        try {
          const companyMeta = [
            (company as any)?.domain && `Website: ${(company as any).domain}`,
            (company as any)?.industry && `Industry: ${(company as any).industry}`,
            (company as any)?.size && `Size: ${(company as any).size}`,
          ].filter(Boolean).join(', ');

          const bdController = new AbortController();
          const bdTimeout = setTimeout(() => bdController.abort(), 30000);
          const bdRes = await fetch('https://api.a0.dev/ai/llm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              messages: [
                { role: 'system', content: `You are a BD Intelligence Officer. Identify concrete, actionable BD opportunities. Be specific — no generic language. Keep descriptions under 2 sentences.` },
                { role: 'user', content: `Our company: ${orgSettings.companyName}. We offer: ${orgSettings.interests}.\nTarget: ${(company as any)?.name || 'Unknown'}. ${companyMeta || ''}\nIdentify top BD opportunities.` },
              ],
              schema: {
                type: 'object',
                properties: {
                  opportunity_summary: {
                    type: 'array', description: 'Max 3 opportunities',
                    items: {
                      type: 'object',
                      properties: {
                        title: { type: 'string' }, description: { type: 'string' },
                        bd_focus_area: { type: 'string' }, trigger: { type: 'string' },
                        stakeholders: { type: 'array', items: { type: 'string' } },
                        entry_strategy: { type: 'string' },
                        competitive_context: {
                          type: 'object',
                          properties: { likely_competitors: { type: 'array', items: { type: 'string' } }, differentiation: { type: 'string' } },
                          required: ['likely_competitors', 'differentiation'],
                        },
                        priority_score: {
                          type: 'object',
                          properties: { likelihood: { type: 'number' }, speed: { type: 'number' }, strategic_value: { type: 'number' } },
                          required: ['likelihood', 'speed', 'strategic_value'],
                        },
                      },
                      required: ['title', 'description', 'bd_focus_area', 'trigger', 'priority_score'],
                    },
                  },
                  segment_insights: { type: 'array', items: { type: 'string' }, description: 'Max 3' },
                  recommended_next_actions: {
                    type: 'array', description: 'Max 4',
                    items: { type: 'object', properties: { title: { type: 'string' }, details: { type: 'string' } }, required: ['title', 'details'] },
                  },
                },
                required: ['opportunity_summary', 'segment_insights', 'recommended_next_actions'],
              },
            }),
            signal: bdController.signal,
          });
          clearTimeout(bdTimeout);

          if (bdRes.ok) {
            const bdData = await bdRes.json();
            let bdReport = bdData.schema_data || null;
            if (!bdReport && bdData.completion) {
              try {
                const cleaned = bdData.completion.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
                bdReport = JSON.parse(cleaned);
              } catch { /* ignore parse error */ }
            }
            // Retry without schema if structured output failed
            if (!bdReport) {
              try {
                const c2 = new AbortController();
                const t2 = setTimeout(() => c2.abort(), 30000);
                const r2 = await fetch('https://api.a0.dev/ai/llm', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  signal: c2.signal,
                  body: JSON.stringify({
                    messages: [
                      { role: 'system', content: `You are a BD Intelligence Officer. Identify concrete, actionable BD opportunities. Return ONLY valid JSON with keys: opportunity_summary (array), segment_insights (array of strings), recommended_next_actions (array of {title, details}).` },
                      { role: 'user', content: `Our company: ${orgSettings.companyName}. We offer: ${orgSettings.interests}.\nTarget: ${(company as any)?.name || 'Unknown'}. ${companyMeta || ''}\nIdentify top BD opportunities.` },
                    ],
                  }),
                });
                clearTimeout(t2);
                if (r2.ok) {
                  const d2 = await r2.json();
                  try { bdReport = JSON.parse((d2.completion || '').replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim()); } catch {}
                }
              } catch { /* retry failed */ }
            }
            if (bdReport) {
              const reportStr = JSON.stringify(bdReport);
              await saveCompanyInsights({ id: formCompanyId as any, insightsReport: reportStr });
              console.log('[Strategist] BD Intelligence generated and saved');
            }
          }
        } catch (e: any) {
          console.log('[Strategist] BD Intelligence generation failed:', e?.message);
        }
        // Continue to strategy generation below
      }
    }

    // Check if BD Intelligence report is stale (> 12 months old)
    if (companyDetail?.insightsReport && (companyDetail as any).insightsGeneratedAt) {
      const ageMs = Date.now() - (companyDetail as any).insightsGeneratedAt;
      const ageMonths = Math.floor(ageMs / (1000 * 60 * 60 * 24 * 30));
      if (ageMonths >= 12) {
        const userChoice = await new Promise<string>((resolve) => {
          Alert.alert(
            'BD Intelligence Report Outdated',
            `The BD Intelligence report for ${(company as any)?.name || 'this company'} is ${ageMonths} months old. A fresh report will improve strategy quality. Regenerate it first?`,
            [
              { text: 'Use Existing', style: 'cancel', onPress: () => resolve('skip') },
              { text: 'Regenerate BD Intel', onPress: () => resolve('generate') },
            ]
          );
        });

        if (userChoice === 'generate') {
          if (!orgSettings) {
            Alert.alert('Profile Required', 'Set up your company profile in Settings first.');
            return;
          }
          setAiAnalyzing(true);
          setAiExpanded(true);
          try {
            const companyMeta = [
              (company as any)?.domain && `Website: ${(company as any).domain}`,
              (company as any)?.industry && `Industry: ${(company as any).industry}`,
              (company as any)?.size && `Size: ${(company as any).size}`,
              (company as any)?.segment?.sector && `Sector: ${(company as any).segment.sector}`,
              (company as any)?.segment?.subSector && `Sub-sector: ${(company as any).segment.subSector}`,
              (company as any)?.segment?.niche && `Niche: ${(company as any).segment.niche}`,
              (company as any)?.notes && `Notes: ${(company as any).notes?.slice(0, 200)}`,
              (company as any)?.companyRoleNotes && `Role context: ${(company as any).companyRoleNotes?.slice(0, 150)}`,
            ].filter(Boolean).join('\n');

            const userProfile = [
              orgSettings.companyName && `Company: ${orgSettings.companyName}`,
              orgSettings.url && `Website: ${orgSettings.url}`,
              orgSettings.interests && `Interests: ${orgSettings.interests}`,
            ].filter(Boolean).join('\n');

            const res = await fetch('https://api.a0.dev/ai/llm', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                messages: [
                  { role: 'system', content: `You are a BD Intelligence Officer. Analyze this company for business development opportunities. Return JSON with: segment_insights (array of {insight, relevance}), opportunity_summary (array of {title, focus_area, trigger, stakeholders, entry_strategy, competitive_context, priority_score: {impact:1-5, likelihood:1-5, timeframe:1-5}}), recommended_next_actions (array of {title (max 8 words), details}).` },
                  { role: 'user', content: `Analyze "${(company as any)?.name || 'this company'}" for BD opportunities.\n\nCompany info:\n${companyMeta}\n\nOur profile:\n${userProfile}\n\nReturn ONLY valid JSON.` },
                ],
              }),
            });

            if (res.ok) {
              const data = await res.json();
              const completion = data.completion || '';
              const cleaned = completion.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
              try {
                const parsed = JSON.parse(cleaned);
                const reportStr = JSON.stringify(parsed);
                await saveCompanyInsights({ id: formCompanyId as any, insightsReport: reportStr });
                // Update local reference
                (companyDetail as any).insightsReport = reportStr;
                (companyDetail as any).insightsGeneratedAt = Date.now();
              } catch { /* parsing failed, continue */ }
            }
          } catch { /* fetch failed, continue */ }
        }
      }
    }

    setAiAnalyzing(true);
    setAiExpanded(true);

    const companyInsights = companyDetail?.insightsReport
      ? (() => { try { return companyDetail.insightsReport.substring(0, 2000); } catch { return ''; } })()
      : '';

    const context = {
      opportunity: {
        title: formTitle.trim(),
        status: formStatus,
        value: formValue ? parseFloat(formValue) : null,
        probability: formProbability ? parseInt(formProbability) : null,
        location: formLocation.trim() || null,
        notes: formNotes.trim() || null,
      },
      company: {
        name: (company as any)?.name || '',
        domain: (company as any)?.domain || '',
        industry: (company as any)?.industry || '',
        size: (company as any)?.size || '',
        segment: (company as any)?.segmentPath || (company as any)?.segmentName || '',
        notes: (company as any)?.notes?.slice(0, 200) || '',
        companyRoleNotes: (company as any)?.companyRoleNotes?.slice(0, 150) || '',
        insightsReport: companyInsights,
      },
      contact: null,
      interactions: [],
      actions: [],
      stageHistory: [],
      pipeline: { stageName: formStatus, stagePosition: 0, pipelineName: 'Default' },
      orgContext: {
        companyName: orgSettings?.companyName || '',
        url: orgSettings?.companyUrl || '',
        interests: orgSettings?.interests || '',
        taxonomyProfile: orgSettings?.taxonomyProfile || null,
      },
      relatedOpportunities: [],
      nextBestActions: [],
    };

    const callLLM = async (): Promise<StrategistReport | null> => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 45000);
        const res = await fetch('https://api.a0.dev/ai/llm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: [
              { role: 'system', content: STRATEGIST_PROMPT },
              { role: 'user', content: `Analyze this NEW opportunity (no interactions/history yet). Focus on initial positioning and first actions.\n${JSON.stringify(context)}` },
            ],
            schema: {
              type: 'object',
              properties: {
                opportunityHealthScore: {
                  type: 'object',
                  properties: { score: { type: 'number', description: '1-10' }, reasoning: { type: 'string', description: 'Max 2 sentences' } },
                  required: ['score', 'reasoning'],
                },
                stageReadiness: {
                  type: 'object',
                  properties: {
                    ready: { type: 'boolean' },
                    missingElements: { type: 'array', items: { type: 'string' }, description: 'Max 4 items' },
                    recommendation: { type: 'string', description: 'Max 2 sentences' },
                  },
                  required: ['ready', 'missingElements', 'recommendation'],
                },
                riskAnalysis: {
                  type: 'array', description: 'Max 4',
                  items: {
                    type: 'object',
                    properties: { risk: { type: 'string' }, severity: { type: 'string', enum: ['Low', 'Medium', 'High'] }, mitigation: { type: 'string' } },
                    required: ['risk', 'severity', 'mitigation'],
                  },
                },
                stakeholderGaps: {
                  type: 'array', description: 'Max 3',
                  items: {
                    type: 'object',
                    properties: { role: { type: 'string' }, whyNeeded: { type: 'string' }, accessStrategy: { type: 'string' } },
                    required: ['role', 'whyNeeded', 'accessStrategy'],
                  },
                },
                winStrategy: {
                  type: 'object',
                  properties: {
                    positioning: { type: 'string', description: 'Max 2 sentences' },
                    differentiation: { type: 'string', description: 'Max 2 sentences' },
                    keyMessages: { type: 'array', items: { type: 'string' }, description: 'Max 3' },
                  },
                  required: ['positioning', 'differentiation', 'keyMessages'],
                },
                interactionAnalysis: {
                  type: 'object',
                  properties: {
                    lastInteractionDate: { type: 'string' },
                    engagementLevel: { type: 'string', enum: ['High', 'Medium', 'Low', 'Unknown'] },
                    recommendedCadence: { type: 'string' },
                  },
                  required: ['lastInteractionDate', 'engagementLevel', 'recommendedCadence'],
                },
                closePlan: {
                  type: 'array', description: 'Max 5',
                  items: {
                    type: 'object',
                    properties: { step: { type: 'string' }, description: { type: 'string' }, timeline: { type: 'string' } },
                    required: ['step', 'description', 'timeline'],
                  },
                },
                probabilityAdjustment: {
                  type: 'object',
                  properties: { current: { type: 'number' }, aiSuggested: { type: 'number' }, justification: { type: 'string' } },
                  required: ['current', 'aiSuggested', 'justification'],
                },
                recommendedActions: {
                  type: 'array', description: 'Max 5',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string', description: 'Max 8 words' },
                      details: { type: 'string', description: 'Max 1 sentence' },
                      priority: { type: 'string', enum: ['High', 'Medium', 'Low'] },
                      suggestedOwner: { type: 'string' },
                      suggestedDeadline: { type: 'string' },
                    },
                    required: ['title', 'details', 'priority'],
                  },
                },
              },
              required: ['opportunityHealthScore', 'stageReadiness', 'riskAnalysis', 'stakeholderGaps', 'winStrategy', 'interactionAnalysis', 'closePlan', 'probabilityAdjustment', 'recommendedActions'],
            },
          }),
          signal: controller.signal,
        });
        clearTimeout(timeout);
        if (!res.ok) return null;
        const data = await res.json();
        if (data.schema_data) return normalizeReport(data.schema_data, formProbability ? parseInt(formProbability) : 0);
        if (data.completion) {
          try {
            const cleaned = data.completion.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
            return normalizeReport(JSON.parse(cleaned), formProbability ? parseInt(formProbability) : 0);
          } catch { return null; }
        }
        return null;
      } catch {
        return null;
      }
    };

    try {
      const result = await callLLM();
      if (result) {
        setAiReport(result);
      } else {
        Alert.alert('Analysis Failed', 'Could not generate strategy. Try again.');
      }
    } finally {
      setAiAnalyzing(false);
    }
  };

  const dateFilterLabel = DATE_FILTERS.find(d => d.key === dateFilter)?.label || 'All Time';

  if (!opportunities) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.header}>
          <Text style={styles.title}>Opportunities</Text>
        </View>
        <View style={styles.loading}><Text style={styles.loadingText}>Loading...</Text></View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Opportunities</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowCreate(true)}>
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      {/* Opportunity Scout AI — collapsible */}
      <TouchableOpacity
        style={styles.scoutHeader}
        onPress={() => setScoutExpanded(!scoutExpanded)}
        activeOpacity={0.7}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
          <Ionicons name="search" size={18} color={colors.primary} />
          <Text style={styles.scoutHeaderText}>Opportunity Scout AI</Text>
        </View>
        <Ionicons name={scoutExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
      </TouchableOpacity>
      {scoutExpanded && (
        <View style={{ paddingHorizontal: spacing.lg }}>
          <OpportunityScoutAI navigation={navigation} />
        </View>
      )}

      {/* Summary */}
      <View style={styles.summaryBar}>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryValue}>{filtered.length}</Text>
          <Text style={styles.summaryLabel}>Opportunities</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryValue}>{formatValue(totalValue) || '$0'}</Text>
          <Text style={styles.summaryLabel}>Total Value</Text>
        </View>
        <View style={styles.summaryItem}>
          <Text style={styles.summaryValue}>{winRate}%</Text>
          <Text style={styles.summaryLabel}>Win Rate</Text>
        </View>
      </View>

      {/* Status filter chips */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterRow} contentContainerStyle={styles.filterRowContent}>
        <TouchableOpacity
          style={[styles.filterChip, !statusFilter && styles.filterChipActive]}
          onPress={() => setStatusFilter(null)}
        >
          <Text style={[styles.filterChipText, !statusFilter && styles.filterChipTextActive]}>All</Text>
        </TouchableOpacity>
        {STATUS_CONFIG.map(s => {
          const count = grouped[s.key]?.length || 0;
          const isActive = statusFilter === s.key;
          return (
            <TouchableOpacity
              key={s.key}
              style={[styles.filterChip, isActive && { backgroundColor: s.color }]}
              onPress={() => setStatusFilter(isActive ? null : s.key)}
            >
              <Text style={[styles.filterChipText, isActive && { color: colors.white }]}>
                {s.label} ({count})
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Secondary filters */}
      <View style={styles.secondaryFilters}>
        <TouchableOpacity style={styles.dropdownBtn} onPress={() => setShowDateFilter(true)}>
          <Ionicons name="calendar-outline" size={14} color={dateFilter !== 'all' ? colors.primary : colors.textSecondary} />
          <Text style={[styles.dropdownText, dateFilter !== 'all' && { color: colors.primary, fontWeight: '600' }]} numberOfLines={1}>
            {dateFilterLabel}
          </Text>
          <Ionicons name="chevron-down" size={12} color={colors.textTertiary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.dropdownBtn} onPress={() => setShowCompanyFilter(true)}>
          <Ionicons name="business-outline" size={14} color={companyFilter ? colors.primary : colors.textSecondary} />
          <Text style={[styles.dropdownText, companyFilter && { color: colors.primary, fontWeight: '600' }]} numberOfLines={1}>
            {selectedCompanyName}
          </Text>
          <Ionicons name="chevron-down" size={12} color={colors.textTertiary} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.dropdownBtn} onPress={() => setShowSortPicker(true)}>
          <Ionicons name="swap-vertical" size={14} color={colors.textSecondary} />
          <Text style={styles.dropdownText} numberOfLines={1}>
            {SORT_OPTIONS.find(s => s.key === sortBy)?.label || 'Sort'}
          </Text>
          <Ionicons name="chevron-down" size={12} color={colors.textTertiary} />
        </TouchableOpacity>
      </View>

      {/* Opportunity list grouped by status */}
      <ScrollView style={styles.listContainer} contentContainerStyle={styles.listContent}>
        {STATUS_CONFIG.map(statusDef => {
          const items = grouped[statusDef.key] || [];
          if (statusFilter && statusFilter !== statusDef.key) return null;
          if (items.length === 0 && statusFilter !== statusDef.key) return null;
          const isCollapsed = collapsed[statusDef.key];
          const groupValue = items.reduce((s, o) => s + (o.value || 0), 0);

          return (
            <View key={statusDef.key} style={styles.statusGroup}>
              <TouchableOpacity
                style={styles.groupHeader}
                onPress={() => toggleCollapse(statusDef.key)}
              >
                <View style={styles.groupHeaderLeft}>
                  <Ionicons
                    name={isCollapsed ? 'add-circle' : 'remove-circle'}
                    size={22}
                    color={statusDef.color}
                  />
                  <View style={[styles.groupDot, { backgroundColor: statusDef.color }]} />
                  <Text style={styles.groupTitle}>{statusDef.label}</Text>
                  <View style={styles.groupBadge}>
                    <Text style={styles.groupBadgeText}>{items.length}</Text>
                  </View>
                </View>
                {groupValue > 0 && (
                  <Text style={[styles.groupValue, { color: statusDef.color }]}>
                    {formatValue(groupValue)}
                  </Text>
                )}
              </TouchableOpacity>

              {!isCollapsed && items.map(opp => (
                <TouchableOpacity
                  key={opp._id}
                  style={styles.oppCard}
                  onPress={() => navigation.navigate('OpportunityDetail', { id: opp._id })}
                >
                  <View style={styles.oppTop}>
                    <Text style={styles.oppRef}>{opp.reference || '—'}</Text>
                    <Text style={styles.oppDate}>{formatDate(opp._creationTime)}</Text>
                  </View>
                  <Text style={styles.oppTitle} numberOfLines={1}>{opp.title}</Text>
                  {opp.companyName && (
                    <View style={styles.oppCompanyRow}>
                      <Ionicons name="business-outline" size={12} color={colors.textTertiary} />
                      <Text style={styles.oppCompany} numberOfLines={1}>{opp.companyName}</Text>
                    </View>
                  )}
                  <View style={styles.oppBottom}>
                    {opp.value ? (
                      <Text style={styles.oppValue}>{formatValue(opp.value)}</Text>
                    ) : <View />}
                    <View style={styles.oppMeta}>
                      {opp.probability ? (
                        <View style={styles.oppProbBadge}>
                          <Text style={styles.oppProbText}>{opp.probability}%</Text>
                        </View>
                      ) : null}
                      {opp.location && (
                        <Ionicons name="location" size={14} color={colors.textTertiary} />
                      )}
                      {opp.lostCompetitor && opp.status === 'lost' && (
                        <Text style={styles.oppLost}>Lost to: {opp.lostCompetitor}</Text>
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
              ))}

              {!isCollapsed && items.length === 0 && (
                <Text style={styles.emptyGroup}>No opportunities</Text>
              )}
            </View>
          );
        })}
        <View style={{ height: 80 }} />
      </ScrollView>

      {/* Create Opportunity Modal */}
      <Modal visible={showCreate} animationType="slide" presentationStyle="pageSheet">
        <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
          <SafeAreaView style={styles.modalContainer} edges={['top']}>
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={() => { setShowCreate(false); resetForm(); }}>
                <Text style={styles.modalCancel}>Cancel</Text>
              </TouchableOpacity>
              <Text style={styles.modalTitle}>New Opportunity</Text>
              <TouchableOpacity onPress={handleCreate} disabled={creating}>
                <Text style={[styles.modalSave, creating && { opacity: 0.5 }]}>
                  {creating ? 'Saving...' : 'Save'}
                </Text>
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={styles.formScroll} keyboardShouldPersistTaps="handled">
              {/* Title */}
              <Text style={styles.formLabel}>Opportunity Title *</Text>
              <TextInput
                style={styles.formInput}
                placeholder="e.g. Shell CCUS Phase 2"
                placeholderTextColor={colors.textTertiary}
                value={formTitle}
                onChangeText={setFormTitle}
              />

              {/* Company picker */}
              <Text style={styles.formLabel}>Company *</Text>
              <TouchableOpacity
                style={[styles.pickerBtn, companyPickerOpen && { borderColor: colors.primary, borderWidth: 2 }]}
                onPress={() => setCompanyPickerOpen(!companyPickerOpen)}
              >
                <Ionicons name="business-outline" size={16} color={formCompanyId ? colors.primary : colors.textSecondary} />
                <Text style={[styles.pickerBtnText, !formCompanyId && { color: colors.textTertiary }]}>
                  {selectedCompanyObj
                    ? (selectedCompanyObj as any).name
                    : 'Select a company...'}
                </Text>
                <Ionicons name={companyPickerOpen ? 'chevron-up' : 'chevron-down'} size={16} color={colors.textTertiary} />
              </TouchableOpacity>

              {companyPickerOpen && (
                <View style={styles.inlinePickerContainer}>
                  <View style={styles.inlineSearchRow}>
                    <Ionicons name="search" size={16} color={colors.textTertiary} />
                    <TextInput
                      style={styles.inlineSearchInput}
                      placeholder="Search companies..."
                      placeholderTextColor={colors.textTertiary}
                      value={companySearch}
                      onChangeText={setCompanySearch}
                      autoFocus
                    />
                    {companySearch.length > 0 && (
                      <TouchableOpacity onPress={() => setCompanySearch('')}>
                        <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                      </TouchableOpacity>
                    )}
                  </View>
                  <ScrollView style={styles.inlinePickerList} nestedScrollEnabled keyboardShouldPersistTaps="handled">
                    {filteredCompanies.map((c: any) => (
                      <TouchableOpacity
                        key={c._id}
                        style={[styles.inlinePickerItem, formCompanyId === c._id && styles.inlinePickerItemActive]}
                        onPress={() => {
                          setFormCompanyId(c._id);
                          setCompanyPickerOpen(false);
                          setCompanySearch('');
                        }}
                      >
                        <View style={styles.companyPickerDot}>
                          <Text style={styles.companyPickerInitial}>{c.name[0]}</Text>
                        </View>
                        <View style={{ flex: 1 }}>
                          <Text style={styles.companyPickerName}>{c.name}</Text>
                          {c.domain && <Text style={styles.companyPickerDomain}>{c.domain}</Text>}
                        </View>
                        {formCompanyId === c._id && (
                          <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
                        )}
                      </TouchableOpacity>
                    ))}
                    {filteredCompanies.length === 0 && (
                      <View style={styles.emptyCompanies}>
                        <Text style={styles.emptyCompaniesText}>
                          {companies?.length === 0 ? 'No companies yet. Add a company first.' : 'No matches found.'}
                        </Text>
                      </View>
                    )}
                  </ScrollView>
                </View>
              )}

              {/* Status */}
              <Text style={styles.formLabel}>Status</Text>
              <View style={styles.statusChips}>
                {STATUS_CONFIG.map(s => (
                  <TouchableOpacity
                    key={s.key}
                    style={[styles.statusChip, formStatus === s.key && { backgroundColor: s.color, borderColor: s.color }]}
                    onPress={() => setFormStatus(s.key)}
                  >
                    <Ionicons name={s.icon as any} size={14} color={formStatus === s.key ? colors.white : s.color} />
                    <Text style={[styles.statusChipText, formStatus === s.key && { color: colors.white }]}>
                      {s.label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Value & Probability */}
              <View style={styles.formRow}>
                <View style={styles.formHalf}>
                  <Text style={styles.formLabel}>Value ($)</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="0"
                    placeholderTextColor={colors.textTertiary}
                    value={formValue}
                    onChangeText={setFormValue}
                    keyboardType="numeric"
                  />
                </View>
                <View style={styles.formHalf}>
                  <Text style={styles.formLabel}>Probability (%)</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="0"
                    placeholderTextColor={colors.textTertiary}
                    value={formProbability}
                    onChangeText={setFormProbability}
                    keyboardType="numeric"
                  />
                </View>
              </View>

              {/* Location */}
              <Text style={styles.formLabel}>Location</Text>
              <TouchableOpacity
                style={[styles.pickerBtn, showMap && { borderColor: colors.primary, borderWidth: 2 }]}
                onPress={() => setShowMap(!showMap)}
              >
                <Ionicons
                  name={mapCoords ? 'location' : 'location-outline'}
                  size={16}
                  color={mapCoords ? colors.primary : colors.textSecondary}
                />
                <Text
                  style={[styles.pickerBtnText, !formLocation && { color: colors.textTertiary }]}
                  numberOfLines={1}
                >
                  {formLocation || 'Tap to set location on map...'}
                </Text>
                {mapCoords ? (
                  <TouchableOpacity
                    onPress={(e) => {
                      e.stopPropagation();
                      setMapCoords(null);
                      setMapAddress('');
                      setFormLocation('');
                      setLocationSearch('');
                    }}
                    hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                  >
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                ) : (
                  <Ionicons name={showMap ? 'chevron-up' : 'chevron-down'} size={16} color={colors.textTertiary} />
                )}
              </TouchableOpacity>

              {showMap && (
                <View style={styles.mapContainer}>
                  {/* Search bar */}
                  <View style={styles.mapSearchRow}>
                    <Ionicons name="search" size={16} color={colors.textTertiary} />
                    <TextInput
                      style={styles.mapSearchInput}
                      placeholder="Search city, address, or place..."
                      placeholderTextColor={colors.textTertiary}
                      value={locationSearch}
                      onChangeText={setLocationSearch}
                      onSubmitEditing={handleLocationSearch}
                      returnKeyType="search"
                    />
                    {searchingLocation ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : locationSearch.length > 0 ? (
                      <TouchableOpacity onPress={handleLocationSearch}>
                        <Ionicons name="arrow-forward-circle" size={22} color={colors.primary} />
                      </TouchableOpacity>
                    ) : null}
                  </View>

                  {/* Map */}
                  <MapView
                    style={styles.mapView}
                    region={mapRegion}
                    onRegionChangeComplete={setMapRegion}
                    onPress={handleMapPress}
                    mapType="standard"
                  >
                    {mapCoords && (
                      <Marker
                        coordinate={mapCoords}
                        draggable
                        onDragEnd={(e) => handleMapPress(e as any)}
                      />
                    )}
                  </MapView>

                  {/* Selected location info */}
                  {mapCoords && (
                    <View style={styles.mapInfoRow}>
                      <Ionicons name="pin" size={14} color={colors.primary} />
                      <Text style={styles.mapInfoText} numberOfLines={2}>
                        {mapAddress || `${mapCoords.latitude.toFixed(4)}, ${mapCoords.longitude.toFixed(4)}`}
                      </Text>
                    </View>
                  )}

                  {!mapCoords && (
                    <Text style={styles.mapHint}>Tap the map to drop a pin, or search above</Text>
                  )}
                </View>
              )}

              {/* Lost Competitor (only if status is lost) */}
              {formStatus === 'lost' && (
                <>
                  <Text style={styles.formLabel}>Competitor Who Won</Text>
                  <TextInput
                    style={styles.formInput}
                    placeholder="e.g. Schlumberger"
                    placeholderTextColor={colors.textTertiary}
                    value={formLostCompetitor}
                    onChangeText={setFormLostCompetitor}
                  />
                </>
              )}

              {/* Notes */}
              <Text style={styles.formLabel}>Notes</Text>
              <TextInput
                style={[styles.formInput, styles.formMultiline]}
                placeholder="Additional details..."
                placeholderTextColor={colors.textTertiary}
                value={formNotes}
                onChangeText={setFormNotes}
                multiline
                numberOfLines={4}
              />

              {/* AI Opportunity Strategist */}
              <View style={styles.aiSection}>
                <TouchableOpacity
                  style={styles.aiHeader}
                  onPress={() => aiReport ? setAiExpanded(!aiExpanded) : handleStrategyAnalysis()}
                >
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flex: 1 }}>
                    <Ionicons name="flash" size={20} color={colors.primary} />
                    <Text style={styles.aiSectionTitle}>Opportunity Strategist</Text>
                    {aiReport && (
                      <View style={[styles.aiScoreBadge, {
                        backgroundColor: aiReport.opportunityHealthScore.score >= 7 ? '#10B981' :
                          aiReport.opportunityHealthScore.score >= 4 ? '#F59E0B' : '#EF4444'
                      }]}>
                        <Text style={styles.aiScoreText}>{aiReport.opportunityHealthScore.score}/10</Text>
                      </View>
                    )}
                  </View>
                  {aiAnalyzing ? (
                    <ActivityIndicator size="small" color={colors.primary} />
                  ) : aiReport ? (
                    <Ionicons name={aiExpanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
                  ) : null}
                </TouchableOpacity>

                {!aiReport && !aiAnalyzing && (
                  <TouchableOpacity style={styles.aiGenerateBtn} onPress={handleStrategyAnalysis}>
                    <Ionicons name="flash-outline" size={16} color={colors.white} />
                    <Text style={styles.aiGenerateBtnText}>Generate Initial Strategy</Text>
                  </TouchableOpacity>
                )}

                {aiAnalyzing && (
                  <View style={styles.aiLoadingContainer}>
                    <ActivityIndicator size="large" color={colors.primary} />
                    <Text style={styles.aiLoadingText}>Analyzing opportunity...</Text>
                    <Text style={styles.aiLoadingSubtext}>Building strategy based on company profile and market context</Text>
                  </View>
                )}

                {aiReport && aiExpanded && (
                  <View style={styles.aiContent}>
                    {/* Health Score */}
                    <View style={styles.aiCard}>
                      <Text style={styles.aiCardTitle}>Opportunity Health</Text>
                      <Text style={styles.aiCardBody}>{aiReport.opportunityHealthScore.reasoning}</Text>
                    </View>

                    {/* Probability */}
                    <View style={styles.aiCard}>
                      <Text style={styles.aiCardTitle}>Probability Assessment</Text>
                      <View style={{ flexDirection: 'row', gap: spacing.lg, marginBottom: spacing.sm }}>
                        <View style={{ alignItems: 'center' }}>
                          <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary }}>Current</Text>
                          <Text style={{ fontSize: fontSize.xl, fontWeight: '800', color: colors.textSecondary }}>
                            {aiReport.probabilityAdjustment.current}%
                          </Text>
                        </View>
                        <Ionicons name="arrow-forward" size={20} color={colors.textTertiary} style={{ marginTop: 14 }} />
                        <View style={{ alignItems: 'center' }}>
                          <Text style={{ fontSize: fontSize.xs, color: colors.textTertiary }}>AI Suggested</Text>
                          <Text style={{ fontSize: fontSize.xl, fontWeight: '800', color: colors.primary }}>
                            {aiReport.probabilityAdjustment.aiSuggested}%
                          </Text>
                        </View>
                      </View>
                      <Text style={styles.aiCardBody}>{aiReport.probabilityAdjustment.justification}</Text>
                    </View>

                    {/* Stage Readiness */}
                    <View style={styles.aiCard}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                        <Text style={styles.aiCardTitle}>Stage Readiness</Text>
                        <View style={[styles.aiBadge, { backgroundColor: aiReport.stageReadiness.ready ? '#10B981' : '#F59E0B' }]}>
                          <Text style={styles.aiBadgeText}>{aiReport.stageReadiness.ready ? 'Ready' : 'Not Ready'}</Text>
                        </View>
                      </View>
                      {aiReport.stageReadiness.missingElements.length > 0 && (
                        <View style={{ marginTop: spacing.sm }}>
                          {aiReport.stageReadiness.missingElements.map((el, i) => (
                            <View key={i} style={{ flexDirection: 'row', gap: spacing.sm, marginBottom: 4 }}>
                              <Text style={{ color: '#F59E0B' }}>•</Text>
                              <Text style={styles.aiCardBody}>{el}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {aiReport.stageReadiness.recommendation ? (
                        <Text style={[styles.aiCardBody, { marginTop: spacing.sm, fontStyle: 'italic' }]}>
                          {aiReport.stageReadiness.recommendation}
                        </Text>
                      ) : null}
                    </View>

                    {/* Risk Analysis */}
                    {aiReport.riskAnalysis.length > 0 && (
                      <View style={styles.aiCard}>
                        <Text style={styles.aiCardTitle}>Risk Analysis</Text>
                        {aiReport.riskAnalysis.map((r, i) => (
                          <View key={i} style={styles.aiRiskItem}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                              <View style={[styles.aiBadge, {
                                backgroundColor: r.severity === 'High' ? '#EF4444' : r.severity === 'Medium' ? '#F59E0B' : '#10B981'
                              }]}>
                                <Text style={styles.aiBadgeText}>{r.severity}</Text>
                              </View>
                              <Text style={styles.aiRiskTitle}>{r.risk}</Text>
                            </View>
                            <Text style={styles.aiCardBody}>Mitigation: {r.mitigation}</Text>
                          </View>
                        ))}
                      </View>
                    )}

                    {/* Win Strategy */}
                    <View style={styles.aiCard}>
                      <Text style={styles.aiCardTitle}>Win Strategy</Text>
                      {aiReport.winStrategy.positioning ? (
                        <View style={{ marginBottom: spacing.sm }}>
                          <Text style={styles.aiSubLabel}>Positioning</Text>
                          <Text style={styles.aiCardBody}>{aiReport.winStrategy.positioning}</Text>
                        </View>
                      ) : null}
                      {aiReport.winStrategy.differentiation ? (
                        <View style={{ marginBottom: spacing.sm }}>
                          <Text style={styles.aiSubLabel}>Differentiation</Text>
                          <Text style={styles.aiCardBody}>{aiReport.winStrategy.differentiation}</Text>
                        </View>
                      ) : null}
                      {aiReport.winStrategy.keyMessages.length > 0 && (
                        <View>
                          <Text style={styles.aiSubLabel}>Key Messages</Text>
                          {aiReport.winStrategy.keyMessages.map((m, i) => (
                            <View key={i} style={{ flexDirection: 'row', gap: spacing.sm, marginBottom: 4 }}>
                              <Text style={{ color: colors.primary }}>•</Text>
                              <Text style={styles.aiCardBody}>{m}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                    </View>

                    {/* Close Plan */}
                    {aiReport.closePlan.length > 0 && (
                      <View style={styles.aiCard}>
                        <Text style={styles.aiCardTitle}>Close Plan</Text>
                        {aiReport.closePlan.map((step, i) => (
                          <View key={i} style={styles.aiStepItem}>
                            <View style={styles.aiStepNumber}>
                              <Text style={styles.aiStepNumberText}>{i + 1}</Text>
                            </View>
                            <View style={{ flex: 1 }}>
                              <Text style={styles.aiRiskTitle}>{step.step}</Text>
                              <Text style={styles.aiCardBody}>{step.description}</Text>
                              {step.timeline ? <Text style={styles.aiTimeline}>{step.timeline}</Text> : null}
                            </View>
                          </View>
                        ))}
                      </View>
                    )}

                    {/* Recommended Actions */}
                    {aiReport.recommendedActions.length > 0 && (
                      <View style={styles.aiCard}>
                        <Text style={styles.aiCardTitle}>Recommended First Actions</Text>
                        {aiReport.recommendedActions.map((a, i) => (
                          <View key={i} style={styles.aiActionItem}>
                            <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: 4 }}>
                              <View style={[styles.aiBadge, {
                                backgroundColor: a.priority === 'High' ? '#EF4444' : a.priority === 'Medium' ? '#F59E0B' : '#10B981'
                              }]}>
                                <Text style={styles.aiBadgeText}>{a.priority}</Text>
                              </View>
                              <Text style={styles.aiRiskTitle}>{a.title}</Text>
                            </View>
                            <Text style={styles.aiCardBody}>{a.details}</Text>
                          </View>
                        ))}
                      </View>
                    )}

                    {/* Regenerate button */}
                    <TouchableOpacity style={styles.aiRegenerateBtn} onPress={handleStrategyAnalysis}>
                      <Ionicons name="refresh" size={16} color={colors.primary} />
                      <Text style={styles.aiRegenerateBtnText}>Regenerate Strategy</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </ScrollView>
          </SafeAreaView>
        </KeyboardAvoidingView>
      </Modal>

      {/* Company Filter Modal */}
      <Modal visible={showCompanyFilter} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.modalContainer} edges={['top']}>
          <View style={styles.modalHeader}>
            <TouchableOpacity onPress={() => setShowCompanyFilter(false)}>
              <Text style={styles.modalCancel}>Close</Text>
            </TouchableOpacity>
            <Text style={styles.modalTitle}>Filter by Company</Text>
            <View style={{ width: 60 }} />
          </View>
          <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
            <TouchableOpacity
              style={[styles.companyPickerItem, !companyFilter && styles.companyPickerItemActive]}
              onPress={() => { setCompanyFilter(null); setShowCompanyFilter(false); }}
            >
              <Ionicons name="globe-outline" size={20} color={colors.textSecondary} />
              <Text style={[styles.companyPickerName, { marginLeft: spacing.md }]}>All Companies</Text>
              {!companyFilter && <Ionicons name="checkmark-circle" size={22} color={colors.primary} />}
            </TouchableOpacity>
            {(companies || []).map((c: any) => (
              <TouchableOpacity
                key={c._id}
                style={[styles.companyPickerItem, companyFilter === c._id && styles.companyPickerItemActive]}
                onPress={() => { setCompanyFilter(c._id); setShowCompanyFilter(false); }}
              >
                <View style={styles.companyPickerDot}>
                  <Text style={styles.companyPickerInitial}>{c.name[0]}</Text>
                </View>
                <Text style={[styles.companyPickerName, { flex: 1 }]}>{c.name}</Text>
                {companyFilter === c._id && <Ionicons name="checkmark-circle" size={22} color={colors.primary} />}
              </TouchableOpacity>
            ))}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* Date Filter Modal */}
      <Modal visible={showDateFilter} animationType="fade" transparent>
        <TouchableWithoutFeedback onPress={() => setShowDateFilter(false)}>
          <View style={styles.sortOverlay}>
            <View style={styles.sortSheet}>
              <Text style={styles.sortSheetTitle}>Filter by Date</Text>
              {DATE_FILTERS.map(d => (
                <TouchableOpacity
                  key={d.key}
                  style={[styles.sortOption, dateFilter === d.key && styles.sortOptionActive]}
                  onPress={() => { setDateFilter(d.key); setShowDateFilter(false); }}
                >
                  <Text style={[styles.sortOptionText, dateFilter === d.key && styles.sortOptionTextActive]}>
                    {d.label}
                  </Text>
                  {dateFilter === d.key && <Ionicons name="checkmark" size={18} color={colors.primary} />}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>

      {/* Sort Picker Modal */}
      <Modal visible={showSortPicker} animationType="fade" transparent>
        <TouchableWithoutFeedback onPress={() => setShowSortPicker(false)}>
          <View style={styles.sortOverlay}>
            <View style={styles.sortSheet}>
              <Text style={styles.sortSheetTitle}>Sort By</Text>
              {SORT_OPTIONS.map(s => (
                <TouchableOpacity
                  key={s.key}
                  style={[styles.sortOption, sortBy === s.key && styles.sortOptionActive]}
                  onPress={() => { setSortBy(s.key); setShowSortPicker(false); }}
                >
                  <Text style={[styles.sortOptionText, sortBy === s.key && styles.sortOptionTextActive]}>
                    {s.label}
                  </Text>
                  {sortBy === s.key && <Ionicons name="checkmark" size={18} color={colors.primary} />}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: colors.textSecondary },

  // Summary
  summaryBar: {
    flexDirection: 'row', justifyContent: 'space-around', paddingVertical: spacing.md,
    marginHorizontal: spacing.lg, backgroundColor: colors.white, borderRadius: radius.lg,
    marginBottom: spacing.sm, ...shadow.sm,
  },
  summaryItem: { alignItems: 'center' },
  summaryValue: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  summaryLabel: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 2 },

  // Filters
  filterRow: { maxHeight: 44, marginBottom: spacing.xs },
  filterRowContent: { paddingHorizontal: spacing.lg, gap: spacing.xs },
  filterChip: {
    paddingHorizontal: spacing.md, paddingVertical: 6, borderRadius: radius.full,
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
  },
  filterChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterChipText: { fontSize: fontSize.sm, fontWeight: '500', color: colors.textSecondary },
  filterChipTextActive: { color: colors.white },

  secondaryFilters: {
    flexDirection: 'row', paddingHorizontal: spacing.lg, gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  dropdownBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.white, paddingHorizontal: spacing.md, paddingVertical: 8,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
  },
  dropdownText: { flex: 1, fontSize: fontSize.sm, color: colors.textPrimary },

  // List
  listContainer: { flex: 1 },
  listContent: { paddingHorizontal: spacing.lg },

  // Status group
  statusGroup: { marginBottom: spacing.md },
  groupHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  groupHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  groupDot: { width: 10, height: 10, borderRadius: 5 },
  groupTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.textPrimary },
  groupBadge: {
    backgroundColor: colors.borderLight, borderRadius: radius.full,
    paddingHorizontal: 8, paddingVertical: 1,
  },
  groupBadgeText: { fontSize: fontSize.xs, fontWeight: '700', color: colors.textSecondary },
  groupValue: { fontSize: fontSize.md, fontWeight: '700' },

  // Opportunity card
  oppCard: {
    backgroundColor: colors.white, borderRadius: radius.md, padding: spacing.md,
    marginBottom: spacing.sm, marginLeft: spacing.xl, ...shadow.sm,
  },
  oppTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  oppRef: { fontSize: fontSize.xs, fontWeight: '700', color: colors.primary, fontFamily: 'monospace' },
  oppDate: { fontSize: fontSize.xs, color: colors.textTertiary },
  oppTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  oppCompanyRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  oppCompany: { fontSize: fontSize.sm, color: colors.textSecondary },
  oppBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.sm },
  oppValue: { fontSize: fontSize.md, fontWeight: '700', color: colors.success },
  oppMeta: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  oppProbBadge: { backgroundColor: colors.primaryLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.sm },
  oppProbText: { fontSize: fontSize.xs, fontWeight: '600', color: colors.primary },
  oppLost: { fontSize: fontSize.xs, color: colors.danger, fontStyle: 'italic' },
  emptyGroup: { fontSize: fontSize.sm, color: colors.textTertiary, marginLeft: spacing.xl, paddingVertical: spacing.sm },

  // Modals
  modalContainer: { flex: 1, backgroundColor: colors.bg },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  modalCancel: { fontSize: fontSize.md, color: colors.textSecondary },
  modalSave: { fontSize: fontSize.md, fontWeight: '700', color: colors.primary },

  // Form
  formScroll: { padding: spacing.lg, paddingBottom: 100 },
  formLabel: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, marginBottom: spacing.xs, marginTop: spacing.md },
  formInput: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md, color: colors.textPrimary,
  },
  formMultiline: { height: 100, textAlignVertical: 'top' },
  formRow: { flexDirection: 'row', gap: spacing.md },
  formHalf: { flex: 1 },

  pickerBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, padding: spacing.md,
  },
  pickerBtnText: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary },

  statusChips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  statusChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: spacing.md, paddingVertical: 8, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white,
  },
  statusChipText: { fontSize: fontSize.sm, fontWeight: '500', color: colors.textSecondary },

  // Company picker
  companyPickerItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingVertical: spacing.md, paddingHorizontal: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight, borderRadius: radius.md,
  },
  companyPickerItemActive: { backgroundColor: colors.primaryLight },
  companyPickerDot: {
    width: 36, height: 36, borderRadius: 18, backgroundColor: colors.primary + '20',
    justifyContent: 'center', alignItems: 'center',
  },
  companyPickerInitial: { fontSize: fontSize.md, fontWeight: '700', color: colors.primary },
  companyPickerName: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  companyPickerDomain: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 2 },
  emptyCompanies: { alignItems: 'center', paddingVertical: spacing.xxxl },
  emptyCompaniesText: { fontSize: fontSize.md, color: colors.textTertiary, marginTop: spacing.md },

  // Inline company picker
  inlinePickerContainer: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.primary,
    borderRadius: radius.md, marginTop: spacing.xs, overflow: 'hidden',
  },
  inlineSearchRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
    backgroundColor: colors.bg,
  },
  inlineSearchInput: {
    flex: 1, fontSize: fontSize.md, color: colors.textPrimary, paddingVertical: 4,
  },
  inlinePickerList: {
    maxHeight: 200,
  },
  inlinePickerItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingVertical: spacing.sm, paddingHorizontal: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  inlinePickerItemActive: {
    backgroundColor: colors.primaryLight,
  },

  // Sort picker
  sortOverlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.3)' },
  sortSheet: { backgroundColor: colors.white, borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: spacing.lg },
  sortSheetTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  sortOption: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  sortOptionActive: { backgroundColor: colors.primaryLight, marginHorizontal: -spacing.md, paddingHorizontal: spacing.md, borderRadius: radius.md },
  sortOptionText: { fontSize: fontSize.md, color: colors.textPrimary },
  sortOptionTextActive: { color: colors.primary, fontWeight: '600' },

  // Map picker
  mapContainer: {
    marginTop: spacing.xs,
    borderRadius: radius.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
  },
  mapSearchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    backgroundColor: colors.bg,
  },
  mapSearchInput: {
    flex: 1,
    fontSize: fontSize.md,
    color: colors.textPrimary,
    paddingVertical: 4,
  },
  mapView: {
    width: '100%',
    height: Dimensions.get('window').width * 0.6,
  },
  mapInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    backgroundColor: colors.primaryLight,
  },
  mapInfoText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.textPrimary,
  },
  mapHint: {
    fontSize: fontSize.sm,
    color: colors.textTertiary,
    textAlign: 'center',
    paddingVertical: spacing.sm,
  },

  // AI Strategist
  aiSection: {
    marginTop: spacing.lg,
    backgroundColor: colors.white,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  aiHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    backgroundColor: colors.primaryLight,
  },
  aiSectionTitle: { fontSize: fontSize.md, fontWeight: '700', color: colors.textPrimary },
  aiScoreBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: radius.sm },
  aiScoreText: { fontSize: fontSize.sm, fontWeight: '600' },
  aiGenerateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md,
  },
  aiGenerateBtnText: { fontSize: fontSize.md, fontWeight: '600', color: colors.white },
  aiLoadingContainer: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    paddingVertical: spacing.md, paddingHorizontal: spacing.md,
    backgroundColor: colors.primaryLight,
  },
  aiLoadingText: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  aiLoadingSubtext: { fontSize: fontSize.sm, color: colors.textTertiary },
  aiContent: {
    padding: spacing.lg,
  },
  aiCard: {
    marginBottom: spacing.lg,
  },
  aiCardTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.sm },
  aiCardBody: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 1.5 },
  aiSubLabel: { fontSize: fontSize.xs, color: colors.textTertiary, marginBottom: 4 },
  aiRiskItem: { marginBottom: spacing.sm },
  aiRiskTitle: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  aiStepItem: { marginBottom: spacing.sm },
  aiStepNumber: { backgroundColor: colors.primary, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginRight: spacing.sm },
  aiStepNumberText: { fontSize: fontSize.md, fontWeight: '700', color: colors.white },
  aiActionItem: { marginBottom: spacing.sm },
  aiRegenerateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    borderRadius: radius.md,
  },
  aiRegenerateBtnText: { fontSize: fontSize.md, fontWeight: '600', color: colors.white },
  aiBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginRight: spacing.sm },
  aiBadgeText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.white },
  aiTimeline: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 4 },

  // Scout AI header
  scoutHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: spacing.lg,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    backgroundColor: colors.white,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  scoutHeaderText: {
    fontSize: fontSize.md,
    fontWeight: '600',
    color: colors.textPrimary,
  },
});