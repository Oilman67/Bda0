import React, { useState, useMemo } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, TextInput, Modal, ScrollView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';
import { useNavigation, CommonActions } from '@react-navigation/native';
import DateTimePicker from '@react-native-community/datetimepicker';

const statusFilters = ['all', 'todo', 'in_progress', 'done'] as const;
const priorityColors: Record<string, string> = {
  high: colors.danger,
  medium: colors.warning,
  low: colors.textTertiary,
};
const priorityOptions = ['low', 'medium', 'high'];
const entityTypeLabels: Record<string, string> = {
  contact: 'Contact',
  company: 'Company',
  opportunity: 'Opportunity',
  segment: 'Segment',
  interaction: 'Interaction',
};

function formatDate(ts?: number): string {
  if (!ts) return '';
  return new Date(ts).toLocaleDateString();
}

function formatDateTime(ts?: number): string {
  if (!ts) return '';
  const d = new Date(ts);
  return `${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
}

export default function TasksScreen() {
  const navigation = useNavigation<any>();
  const [filter, setFilter] = useState<string>('all');
  const tasks = useQuery(api.actions.list, filter === 'all' ? {} : { status: filter });
  const createTask = useMutation(api.actions.create);
  const updateStatus = useMutation(api.actions.updateStatus);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // New Action form state
  const [showForm, setShowForm] = useState(false);
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formPriority, setFormPriority] = useState('medium');
  const [formStartDate, setFormStartDate] = useState<Date | null>(null);
  const [formTargetDate, setFormTargetDate] = useState<Date | null>(null);
  const [formLinkedType, setFormLinkedType] = useState<string | null>(null);
  const [formLinkedId, setFormLinkedId] = useState<string | null>(null);
  const [formLinkedLabel, setFormLinkedLabel] = useState('');
  const [showEntityPicker, setShowEntityPicker] = useState(false);
  const [entitySearch, setEntitySearch] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Owner picker state
  const [formOwnerType, setFormOwnerType] = useState<'user' | 'contact' | 'custom'>('user');
  const [formOwnerLabel, setFormOwnerLabel] = useState('You');
  const [formOwnerId, setFormOwnerId] = useState<string | null>(null); // userId or contactId
  const [formOwnerCustomName, setFormOwnerCustomName] = useState('');
  const [showOwnerPicker, setShowOwnerPicker] = useState(false);
  const [ownerSearch, setOwnerSearch] = useState('');
  const [ownerCustomInput, setOwnerCustomInput] = useState('');

  // Date picker visibility
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showTargetPicker, setShowTargetPicker] = useState(false);

  // Queries for entity picker
  const contacts = useQuery(api.contacts.list, {});
  const companies = useQuery(api.companies.list, {});
  const opportunities = useQuery(api.opportunities.list, {});
  const orgMembers = useQuery(api.actions.listOrgMembers, {});

  // Build entity list for picker
  const entityOptions = useMemo(() => {
    const items: { type: string; id: string; label: string; icon: string }[] = [];
    if (contacts) {
      for (const c of contacts) {
        items.push({ type: 'contact', id: c._id, label: `${c.firstName} ${c.lastName}`.trim(), icon: 'person' });
      }
    }
    if (companies) {
      for (const c of companies) {
        items.push({ type: 'company', id: c._id, label: c.name, icon: 'business' });
      }
    }
    if (opportunities) {
      for (const o of opportunities) {
        items.push({ type: 'opportunity', id: o._id, label: o.title, icon: 'trending-up' });
      }
    }
    return items;
  }, [contacts, companies, opportunities]);

  const filteredEntities = useMemo(() => {
    if (!entitySearch.trim()) return entityOptions;
    const q = entitySearch.toLowerCase();
    return entityOptions.filter(e => e.label.toLowerCase().includes(q));
  }, [entityOptions, entitySearch]);

  // Owner picker options
  const ownerOptions = useMemo(() => {
    const items: { section: string; type: 'user' | 'contact' | 'custom'; id: string | null; label: string; sub: string; icon: string; isCurrent?: boolean }[] = [];
    // Team members
    if (orgMembers) {
      for (const m of orgMembers) {
        items.push({
          section: 'Team',
          type: 'user',
          id: m.userId,
          label: m.isCurrentUser ? `${m.name} (You)` : m.name,
          sub: m.role.charAt(0).toUpperCase() + m.role.slice(1),
          icon: 'people',
          isCurrent: m.isCurrentUser,
        });
      }
    }
    // Clients (contacts)
    if (contacts) {
      for (const c of contacts) {
        const name = `${c.firstName} ${c.lastName}`.trim();
        if (name) {
          items.push({
            section: 'Client',
            type: 'contact',
            id: c._id,
            label: name,
            sub: c.companyName || 'Contact',
            icon: 'person',
          });
        }
      }
    }
    return items;
  }, [orgMembers, contacts]);

  const filteredOwnerOptions = useMemo(() => {
    if (!ownerSearch.trim()) return ownerOptions;
    const q = ownerSearch.toLowerCase();
    return ownerOptions.filter(o => o.label.toLowerCase().includes(q) || o.sub.toLowerCase().includes(q));
  }, [ownerOptions, ownerSearch]);

  const resetForm = () => {
    setFormTitle(''); setFormDesc(''); setFormNotes(''); setFormPriority('medium');
    setFormStartDate(null); setFormTargetDate(null);
    setFormLinkedType(null); setFormLinkedId(null); setFormLinkedLabel('');
    setFormOwnerType('user'); setFormOwnerLabel('You'); setFormOwnerId(null);
    setFormOwnerCustomName('');
    setShowStartPicker(false); setShowTargetPicker(false);
    setShowForm(false);
  };

  const handleSubmit = async () => {
    if (!formTitle.trim()) return;
    setSubmitting(true);
    try {
      const linkArgs: any = {};
      if (formLinkedType === 'contact' && formLinkedId) linkArgs.contactId = formLinkedId;
      else if (formLinkedType === 'company' && formLinkedId) linkArgs.companyId = formLinkedId;
      else if (formLinkedType === 'opportunity' && formLinkedId) linkArgs.opportunityId = formLinkedId;

      const ownerArgs: any = { ownerType: formOwnerType };
      if (formOwnerType === 'user' && formOwnerId) {
        ownerArgs.assigneeId = formOwnerId;
      } else if (formOwnerType === 'contact' && formOwnerId) {
        ownerArgs.ownerContactId = formOwnerId;
      } else if (formOwnerType === 'custom' && formOwnerCustomName.trim()) {
        ownerArgs.ownerCustomName = formOwnerCustomName.trim();
      }

      await createTask({
        title: formTitle.trim(),
        description: formDesc.trim() || undefined,
        notes: formNotes.trim() || undefined,
        priority: formPriority,
        startDate: formStartDate ? formStartDate.getTime() : undefined,
        targetDate: formTargetDate ? formTargetDate.getTime() : undefined,
        ...linkArgs,
        ...ownerArgs,
      });
      resetForm();
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeepLink = (deepLink: string) => {
    if (deepLink === 'contacts:pending') {
      navigation.dispatch(CommonActions.navigate({ name: 'Contacts' }));
    }
  };

  const entityIconForType = (type?: string) => {
    if (type === 'contact') return 'person';
    if (type === 'company') return 'business';
    if (type === 'opportunity') return 'trending-up';
    if (type === 'segment') return 'layers';
    if (type === 'interaction') return 'chatbubbles';
    return 'link';
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Actions</Text>
        <TouchableOpacity style={styles.addBtn} onPress={() => setShowForm(true)}>
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      <View style={styles.filterRow}>
        {statusFilters.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.filterChip, filter === f && styles.filterChipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'all' ? 'All' : f === 'in_progress' ? 'In Progress' : f.charAt(0).toUpperCase() + f.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {!tasks ? (
        <View style={styles.loading}><Text>Loading...</Text></View>
      ) : tasks.length === 0 ? (
        <EmptyState icon="checkmark-circle" title="No actions" subtitle="Create an action to stay organized" actionLabel="Add Action" onAction={() => setShowForm(true)} />
      ) : (
        <FlatList
          data={tasks}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => {
            const isExpanded = expandedId === item._id;
            const dueTs = item.targetDate || item.dueDate;
            const isOverdue = dueTs && dueTs < Date.now() && item.status !== 'done';
            return (
              <TouchableOpacity
                style={styles.card}
                onPress={() => setExpandedId(isExpanded ? null : item._id)}
                activeOpacity={0.7}
              >
                <View style={styles.cardTop}>
                  <TouchableOpacity
                    style={[styles.checkbox, item.status === 'done' && styles.checkboxDone]}
                    onPress={() => updateStatus({ id: item._id, status: item.status === 'done' ? 'todo' : 'done' })}
                  >
                    {item.status === 'done' && <Ionicons name="checkmark" size={14} color={colors.white} />}
                  </TouchableOpacity>
                  <View style={styles.cardBody}>
                    <View style={styles.cardTitleRow}>
                      {item.actionNumber && (
                        <Text style={styles.actionNumber}>{item.actionNumber}</Text>
                      )}
                      <Text style={[styles.cardTitle, item.status === 'done' && styles.cardTitleDone]} numberOfLines={isExpanded ? undefined : 2}>
                        {item.title}
                      </Text>
                    </View>
                    <View style={styles.cardMeta}>
                      <View style={[styles.priorityDot, { backgroundColor: priorityColors[item.priority] || colors.textTertiary }]} />
                      <Text style={styles.cardMetaText}>{item.priority}</Text>
                      {item.entityLabel && (
                        <>
                          <Text style={styles.cardMetaSep}>·</Text>
                          <Ionicons name={entityIconForType(item.entityType) as any} size={11} color={colors.textTertiary} />
                          <Text style={styles.cardMetaText} numberOfLines={1}>{item.entityLabel}</Text>
                        </>
                      )}
                    </View>
                    <View style={styles.infoRow}>
                      <View style={styles.infoChip}>
                        <Ionicons name="calendar-outline" size={11} color={colors.textTertiary} />
                        <Text style={styles.infoChipText}>Added {formatDate(item._creationTime)}</Text>
                      </View>
                      {item.ownerName && (
                        <View style={styles.fieldBlock}>
                          <Text style={styles.fieldLabel}>Owner</Text>
                          <View style={styles.ownerRow}>
                            <View style={[styles.ownerAvatar,
                              item.ownerType === 'contact' && { backgroundColor: colors.success },
                              item.ownerType === 'custom' && { backgroundColor: colors.warning },
                            ]}>
                              <Ionicons
                                name={item.ownerType === 'contact' ? 'person' : item.ownerType === 'custom' ? 'create' : 'people'}
                                size={14}
                                color={colors.white}
                              />
                            </View>
                            <Text style={styles.ownerName}>{item.ownerName}</Text>
                            {item.ownerType && item.ownerType !== 'user' && (
                              <View style={[styles.ownerTypeBadge,
                                item.ownerType === 'contact' && { backgroundColor: '#E8F5E9' },
                                item.ownerType === 'custom' && { backgroundColor: colors.warningLight },
                              ]}>
                                <Text style={[styles.ownerTypeBadgeText,
                                  item.ownerType === 'contact' && { color: colors.success },
                                  item.ownerType === 'custom' && { color: colors.warning },
                                ]}>
                                  {item.ownerType === 'contact' ? 'Client' : 'Third Party'}
                                </Text>
                              </View>
                            )}
                          </View>
                        </View>
                      )}
                      {dueTs && (
                        <View style={[styles.infoChip, isOverdue && styles.infoChipOverdue]}>
                          <Ionicons name="flag-outline" size={11} color={isOverdue ? colors.danger : colors.textTertiary} />
                          <Text style={[styles.infoChipText, isOverdue && styles.infoChipTextOverdue]}>
                            Due {formatDate(dueTs)}
                          </Text>
                        </View>
                      )}
                      {item.status === 'done' && item.completedDate && (
                        <View style={[styles.infoChip, { backgroundColor: '#E8F5E9' }]}>
                          <Ionicons name="checkmark-circle" size={11} color={colors.success} />
                          <Text style={[styles.infoChipText, { color: colors.success, fontWeight: '600' }]}>
                            Done {formatDate(item.completedDate)}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={16} color={colors.textTertiary} />
                </View>

                {isExpanded && (
                  <View style={styles.expandedSection}>
                    {item.description && (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>Description</Text>
                        <Text style={styles.fieldText}>{item.description}</Text>
                      </View>
                    )}
                    {item.notes && (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>Notes</Text>
                        <Text style={styles.fieldText}>{item.notes}</Text>
                      </View>
                    )}
                    {item.entityLabel && (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>Linked With</Text>
                        <View style={styles.linkedRow}>
                          <Ionicons name={entityIconForType(item.entityType) as any} size={16} color={colors.primary} />
                          <Text style={styles.linkedLabel}>
                            {entityTypeLabels[item.entityType || ''] || 'Entity'}: {item.entityLabel}
                          </Text>
                        </View>
                      </View>
                    )}
                    <View style={styles.dateRow}>
                      <View style={styles.dateBlock}>
                        <Text style={styles.dateLabel}>Created</Text>
                        <Text style={styles.dateValue}>{formatDateTime(item._creationTime)}</Text>
                      </View>
                      {item.startDate && (
                        <View style={styles.dateBlock}>
                          <Text style={styles.dateLabel}>Start By</Text>
                          <Text style={styles.dateValue}>{formatDate(item.startDate)}</Text>
                        </View>
                      )}
                      {dueTs && (
                        <View style={styles.dateBlock}>
                          <Text style={styles.dateLabel}>Target Date</Text>
                          <Text style={[styles.dateValue, isOverdue && { color: colors.danger }]}>{formatDate(dueTs)}</Text>
                        </View>
                      )}
                      {item.status === 'done' && item.completedDate && (
                        <View style={styles.dateBlock}>
                          <Text style={[styles.dateLabel, { color: colors.success }]}>Completed</Text>
                          <Text style={[styles.dateValue, { color: colors.success, fontWeight: '700' }]}>{formatDate(item.completedDate)}</Text>
                        </View>
                      )}
                    </View>
                    {item.precursors && item.precursors.length > 0 && (
                      <View style={styles.fieldBlock}>
                        <Text style={styles.fieldLabel}>Depends on</Text>
                        <View style={styles.precursorsRow}>
                          {item.precursors.map((p: string) => (
                            <View key={p} style={styles.precursorChip}>
                              <Text style={styles.precursorText}>{p}</Text>
                            </View>
                          ))}
                        </View>
                      </View>
                    )}
                    {item.deepLink && (
                      <TouchableOpacity style={styles.deepLinkBtn} onPress={() => handleDeepLink(item.deepLink!)}>
                        <Ionicons name="open-outline" size={16} color={colors.primary} />
                        <Text style={styles.deepLinkText}>
                          {item.deepLink === 'contacts:pending' ? 'Go to Contacts (Pending Match)' : 'Open'}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                )}
              </TouchableOpacity>
            );
          }}
        />
      )}

      {/* New Action Modal */}
      <Modal visible={showForm} animationType="slide" presentationStyle="pageSheet">
        <SafeAreaView style={styles.formContainer} edges={['top']}>
          {showEntityPicker ? (
            /* ── Entity Picker View ── */
            <>
              <View style={styles.formHeader}>
                <TouchableOpacity onPress={() => setShowEntityPicker(false)}>
                  <Text style={styles.formCancel}>Back</Text>
                </TouchableOpacity>
                <Text style={styles.formTitle}>Link With</Text>
                <View style={{ width: 50 }} />
              </View>
              <TextInput
                style={styles.entitySearchInput}
                placeholder="Search contacts, companies, opportunities..."
                placeholderTextColor={colors.textTertiary}
                value={entitySearch}
                onChangeText={setEntitySearch}
                autoFocus
              />
              <FlatList
                data={filteredEntities}
                keyExtractor={(item) => `${item.type}-${item.id}`}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 40 }}
                renderItem={({ item: e }) => (
                  <TouchableOpacity
                    style={styles.entityRow}
                    onPress={() => {
                      setFormLinkedType(e.type);
                      setFormLinkedId(e.id);
                      setFormLinkedLabel(`${entityTypeLabels[e.type]}: ${e.label}`);
                      setShowEntityPicker(false);
                    }}
                  >
                    <View style={[styles.entityIcon, {
                      backgroundColor: e.type === 'contact' ? colors.primaryLight
                        : e.type === 'company' ? '#E8F5E9'
                        : colors.warningLight
                    }]}>
                      <Ionicons name={e.icon as any} size={16} color={
                        e.type === 'contact' ? colors.primary
                          : e.type === 'company' ? colors.success
                          : colors.warning
                      } />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.entityName}>{e.label}</Text>
                      <Text style={styles.entityType}>{entityTypeLabels[e.type]}</Text>
                    </View>
                  </TouchableOpacity>
                )}
                ListEmptyComponent={
                  <Text style={styles.entityEmpty}>No matches found</Text>
                }
              />
            </>
          ) : showOwnerPicker ? (
            /* ── Owner Picker View ── */
            <>
              <View style={styles.formHeader}>
                <TouchableOpacity onPress={() => setShowOwnerPicker(false)}>
                  <Text style={styles.formCancel}>Back</Text>
                </TouchableOpacity>
                <Text style={styles.formTitle}>Action Owner</Text>
                <View style={{ width: 50 }} />
              </View>
              <TextInput
                style={styles.entitySearchInput}
                placeholder="Search team members, clients..."
                placeholderTextColor={colors.textTertiary}
                value={ownerSearch}
                onChangeText={setOwnerSearch}
              />

              {/* Custom / Third Party entry */}
              <View style={styles.ownerCustomSection}>
                <Text style={styles.ownerSectionTitle}>Third Party / Other</Text>
                <View style={styles.ownerCustomRow}>
                  <TextInput
                    style={styles.ownerCustomInput}
                    placeholder="Enter name (e.g. external partner)..."
                    placeholderTextColor={colors.textTertiary}
                    value={ownerCustomInput}
                    onChangeText={setOwnerCustomInput}
                  />
                  <TouchableOpacity
                    style={[styles.ownerCustomBtn, !ownerCustomInput.trim() && { opacity: 0.4 }]}
                    disabled={!ownerCustomInput.trim()}
                    onPress={() => {
                      setFormOwnerType('custom');
                      setFormOwnerLabel(ownerCustomInput.trim());
                      setFormOwnerCustomName(ownerCustomInput.trim());
                      setFormOwnerId(null);
                      setShowOwnerPicker(false);
                    }}
                  >
                    <Ionicons name="checkmark" size={18} color={colors.white} />
                  </TouchableOpacity>
                </View>
              </View>

              <FlatList
                data={filteredOwnerOptions}
                keyExtractor={(item) => `${item.type}-${item.id || 'current'}`}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 40 }}
                renderItem={({ item: o }) => {
                  const isSelected = (formOwnerType === o.type && formOwnerId === o.id) ||
                    (o.isCurrent && formOwnerType === 'user' && !formOwnerId);
                  return (
                    <TouchableOpacity
                      style={[styles.entityRow, isSelected && { backgroundColor: colors.primaryLight }]}
                      onPress={() => {
                        setFormOwnerType(o.type);
                        setFormOwnerId(o.id);
                        setFormOwnerLabel(o.label);
                        setFormOwnerCustomName('');
                        setShowOwnerPicker(false);
                      }}
                    >
                      <View style={[styles.entityIcon, {
                        backgroundColor: o.type === 'user' ? colors.primaryLight : '#E8F5E9'
                      }]}>
                        <Ionicons
                          name={o.icon as any}
                          size={16}
                          color={o.type === 'user' ? colors.primary : colors.success}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.entityName}>{o.label}</Text>
                        <Text style={styles.entityType}>
                          {o.section} · {o.sub}
                        </Text>
                      </View>
                      {isSelected && (
                        <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
                      )}
                    </TouchableOpacity>
                  );
                }}
                ListHeaderComponent={
                  filteredOwnerOptions.length > 0 ? (
                    <Text style={styles.ownerSectionTitle}>Team & Clients</Text>
                  ) : null
                }
                ListEmptyComponent={
                  <Text style={styles.entityEmpty}>No matches found</Text>
                }
              />
            </>
          ) : (
            /* ── Normal Form View ── */
            <>
              <View style={styles.formHeader}>
                <TouchableOpacity onPress={resetForm}>
                  <Text style={styles.formCancel}>Cancel</Text>
                </TouchableOpacity>
                <Text style={styles.formTitle}>New Action</Text>
                <TouchableOpacity onPress={handleSubmit} disabled={!formTitle.trim() || submitting}>
                  <Text style={[styles.formSave, (!formTitle.trim() || submitting) && { opacity: 0.4 }]}>
                    {submitting ? 'Saving...' : 'Save'}
                  </Text>
                </TouchableOpacity>
              </View>
              <ScrollView style={styles.formScroll} contentContainerStyle={styles.formContent} keyboardShouldPersistTaps="handled">
                {/* Title */}
                <Text style={styles.inputLabel}>Action Title *</Text>
                <TextInput
                  style={styles.input}
                  placeholder="What needs to be done?"
                  placeholderTextColor={colors.textTertiary}
                  value={formTitle}
                  onChangeText={setFormTitle}
                />

                {/* Description */}
                <Text style={styles.inputLabel}>Description</Text>
                <TextInput
                  style={[styles.input, styles.inputMultiline]}
                  placeholder="Add description..."
                  placeholderTextColor={colors.textTertiary}
                  value={formDesc}
                  onChangeText={setFormDesc}
                  multiline
                />

                {/* Notes */}
                <Text style={styles.inputLabel}>Notes</Text>
                <TextInput
                  style={[styles.input, styles.inputMultiline]}
                  placeholder="Free-form notes..."
                  placeholderTextColor={colors.textTertiary}
                  value={formNotes}
                  onChangeText={setFormNotes}
                  multiline
                />

                {/* Priority */}
                <Text style={styles.inputLabel}>Priority</Text>
                <View style={styles.priorityRow}>
                  {priorityOptions.map(p => (
                    <TouchableOpacity
                      key={p}
                      style={[styles.priorityBtn, formPriority === p && styles.priorityBtnActive,
                        formPriority === p && { borderColor: priorityColors[p] }]}
                      onPress={() => setFormPriority(p)}
                    >
                      <View style={[styles.priorityDotForm, { backgroundColor: priorityColors[p] }]} />
                      <Text style={[styles.priorityBtnText, formPriority === p && styles.priorityBtnTextActive]}>
                        {p.charAt(0).toUpperCase() + p.slice(1)}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Linked With */}
                <Text style={styles.inputLabel}>Linked With</Text>
                <TouchableOpacity
                  style={styles.linkedPicker}
                  onPress={() => { setEntitySearch(''); setShowEntityPicker(true); }}
                >
                  {formLinkedId ? (
                    <View style={styles.linkedSelected}>
                      <Ionicons name={entityIconForType(formLinkedType || undefined) as any} size={16} color={colors.primary} />
                      <Text style={styles.linkedSelectedText}>{formLinkedLabel}</Text>
                      <TouchableOpacity onPress={() => { setFormLinkedType(null); setFormLinkedId(null); setFormLinkedLabel(''); }}>
                        <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                      </TouchableOpacity>
                    </View>
                  ) : (
                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                      <Text style={[styles.linkedPlaceholder, { flex: 1 }]}>Select a contact, company, or opportunity...</Text>
                      <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
                    </View>
                  )}
                </TouchableOpacity>

                {/* Owner */}
                <Text style={styles.inputLabel}>Action Owner</Text>
                <TouchableOpacity
                  style={styles.ownerDisplay}
                  onPress={() => { setOwnerSearch(''); setOwnerCustomInput(''); setShowOwnerPicker(true); }}
                >
                  <View style={[styles.ownerAvatarSmall, formOwnerType === 'contact' && { backgroundColor: colors.success }, formOwnerType === 'custom' && { backgroundColor: colors.warning }]}>
                    <Ionicons name={formOwnerType === 'contact' ? 'person' : formOwnerType === 'custom' ? 'create' : 'people'} size={12} color={colors.white} />
                  </View>
                  <Text style={[styles.ownerDisplayText, formOwnerLabel !== 'You' && { color: colors.textPrimary, fontWeight: '500' }]}>
                    {formOwnerLabel}
                  </Text>
                  {formOwnerLabel !== 'You' && (
                    <TouchableOpacity onPress={() => { setFormOwnerType('user'); setFormOwnerLabel('You'); setFormOwnerId(null); setFormOwnerCustomName(''); }}>
                      <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                    </TouchableOpacity>
                  )}
                  <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} style={{ marginLeft: 'auto' }} />
                </TouchableOpacity>

                {/* Start By date */}
                <Text style={styles.inputLabel}>Start By</Text>
                <TouchableOpacity
                  style={styles.dateFieldRow}
                  onPress={() => {
                    if (!formStartDate) setFormStartDate(new Date());
                    setShowStartPicker(!showStartPicker);
                  }}
                  activeOpacity={0.7}
                >
                  <Ionicons name="calendar-outline" size={18} color={formStartDate ? colors.primary : colors.textTertiary} />
                  <Text style={[styles.datePlaceholder, formStartDate && styles.dateValueText]}>
                    {formStartDate ? formStartDate.toLocaleDateString() : 'Select start date...'}
                  </Text>
                  {formStartDate && (
                    <TouchableOpacity onPress={() => { setFormStartDate(null); setShowStartPicker(false); }}>
                      <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                    </TouchableOpacity>
                  )}
                </TouchableOpacity>
                {showStartPicker && (
                  <DateTimePicker
                    value={formStartDate || new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={(event: any, date?: Date) => {
                      if (Platform.OS === 'android') setShowStartPicker(false);
                      if (date) setFormStartDate(date);
                    }}
                    style={{ alignSelf: 'center' }}
                  />
                )}

                {/* Target Date */}
                <Text style={styles.inputLabel}>Target Date</Text>
                <TouchableOpacity
                  style={styles.dateFieldRow}
                  onPress={() => {
                    if (!formTargetDate) setFormTargetDate(new Date());
                    setShowTargetPicker(!showTargetPicker);
                  }}
                  activeOpacity={0.7}
                >
                  <Ionicons name="flag-outline" size={18} color={formTargetDate ? colors.primary : colors.textTertiary} />
                  <Text style={[styles.datePlaceholder, formTargetDate && styles.dateValueText]}>
                    {formTargetDate ? formTargetDate.toLocaleDateString() : 'Select target date...'}
                  </Text>
                  {formTargetDate && (
                    <TouchableOpacity onPress={() => { setFormTargetDate(null); setShowTargetPicker(false); }}>
                      <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                    </TouchableOpacity>
                  )}
                </TouchableOpacity>
                {showTargetPicker && (
                  <DateTimePicker
                    value={formTargetDate || new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={(event: any, date?: Date) => {
                      if (Platform.OS === 'android') setShowTargetPicker(false);
                      if (date) setFormTargetDate(date);
                    }}
                    style={{ alignSelf: 'center' }}
                  />
                )}
              </ScrollView>
            </>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: '800', color: colors.textPrimary },
  addBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  filterRow: {
    flexDirection: 'row', paddingHorizontal: spacing.lg, gap: spacing.sm, marginBottom: spacing.md,
  },
  filterChip: {
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: radius.full,
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
  },
  filterChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { fontSize: fontSize.sm, color: colors.textSecondary },
  filterTextActive: { color: colors.white, fontWeight: '600' },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  list: { paddingHorizontal: spacing.lg, paddingBottom: 100 },
  card: {
    backgroundColor: colors.white, borderRadius: radius.lg, marginBottom: spacing.sm,
    ...shadow.sm, overflow: 'hidden',
  },
  cardTop: {
    flexDirection: 'row', alignItems: 'flex-start', padding: spacing.lg,
  },
  checkbox: {
    width: 24, height: 24, borderRadius: radius.full, borderWidth: 2, borderColor: colors.border,
    justifyContent: 'center', alignItems: 'center', marginRight: spacing.md, marginTop: 2,
  },
  checkboxDone: { backgroundColor: colors.success, borderColor: colors.success },
  cardBody: { flex: 1 },
  cardTitleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, flexWrap: 'wrap' },
  actionNumber: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.primary,
    backgroundColor: colors.primaryLight, paddingHorizontal: 6, paddingVertical: 1,
    borderRadius: radius.sm, overflow: 'hidden',
  },
  cardTitle: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary, flex: 1 },
  cardTitleDone: { textDecorationLine: 'line-through', color: colors.textTertiary },
  cardMeta: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginTop: spacing.xs, flexWrap: 'wrap' },
  priorityDot: { width: 6, height: 6, borderRadius: 3 },
  cardMetaText: { fontSize: fontSize.xs, color: colors.textTertiary },
  cardMetaSep: { fontSize: fontSize.xs, color: colors.textTertiary },
  infoRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: spacing.sm },
  infoChip: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    backgroundColor: colors.bg, paddingHorizontal: 6, paddingVertical: 2, borderRadius: radius.sm,
  },
  infoChipOverdue: { backgroundColor: '#FEE2E2' },
  infoChipText: { fontSize: 10, color: colors.textTertiary },
  infoChipTextOverdue: { color: colors.danger, fontWeight: '600' },
  expandedSection: {
    paddingHorizontal: spacing.lg, paddingBottom: spacing.lg,
    borderTopWidth: 1, borderTopColor: colors.borderLight,
  },
  fieldBlock: { marginTop: spacing.md },
  fieldLabel: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4,
  },
  fieldText: { fontSize: fontSize.sm, color: colors.textSecondary, lineHeight: 20 },
  linkedRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  linkedLabel: { fontSize: fontSize.sm, color: colors.primary, fontWeight: '500' },
  dateRow: { flexDirection: 'row', gap: spacing.lg, marginTop: spacing.md, flexWrap: 'wrap' },
  dateBlock: {},
  dateLabel: {
    fontSize: 10, fontWeight: '600', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.3,
  },
  dateValue: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500', marginTop: 2 },
  ownerRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: 2 },
  ownerAvatar: {
    width: 24, height: 24, borderRadius: 12, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  ownerName: { fontSize: fontSize.sm, color: colors.textPrimary, fontWeight: '500' },
  ownerTypeBadge: {
    paddingHorizontal: 6, paddingVertical: 1, borderRadius: radius.sm,
    backgroundColor: colors.primaryLight,
  },
  ownerTypeBadgeText: {
    fontSize: 10, fontWeight: '700', color: colors.primary,
  },
  precursorsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs, marginTop: 4 },
  precursorChip: {
    backgroundColor: colors.warningLight, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.sm,
  },
  precursorText: { fontSize: fontSize.xs, fontWeight: '600', color: colors.warning },
  deepLinkBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    marginTop: spacing.md, paddingVertical: spacing.sm, paddingHorizontal: spacing.md,
    backgroundColor: colors.primaryLight, borderRadius: radius.md, alignSelf: 'flex-start',
  },
  deepLinkText: { fontSize: fontSize.sm, fontWeight: '600', color: colors.primary },
  // Form styles
  formContainer: { flex: 1, backgroundColor: colors.bg },
  formHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  formCancel: { fontSize: fontSize.md, color: colors.textSecondary },
  formTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  formSave: { fontSize: fontSize.md, fontWeight: '600', color: colors.primary },
  formScroll: { flex: 1 },
  formContent: { padding: spacing.lg, paddingBottom: 60 },
  inputLabel: {
    fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary,
    marginBottom: spacing.xs, marginTop: spacing.md,
  },
  input: {
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  inputMultiline: { minHeight: 80, textAlignVertical: 'top' },
  priorityRow: { flexDirection: 'row', gap: spacing.sm },
  priorityBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xs,
    paddingVertical: spacing.sm, borderRadius: radius.md,
    backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border,
  },
  priorityBtnActive: { backgroundColor: colors.white },
  priorityDotForm: { width: 8, height: 8, borderRadius: 4 },
  priorityBtnText: { fontSize: fontSize.sm, color: colors.textTertiary },
  priorityBtnTextActive: { fontWeight: '700', color: colors.textPrimary },
  linkedPicker: {
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  linkedSelected: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  linkedSelectedText: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary, fontWeight: '500' },
  linkedPlaceholder: { fontSize: fontSize.md, color: colors.textTertiary },
  ownerDisplay: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  ownerAvatarSmall: {
    width: 20, height: 20, borderRadius: 10, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  ownerDisplayText: { fontSize: fontSize.md, color: colors.textSecondary },
  // Entity picker
  entitySearchInput: {
    backgroundColor: colors.white, marginHorizontal: spacing.lg, marginVertical: spacing.md,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  entityRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  entityIcon: {
    width: 36, height: 36, borderRadius: radius.md,
    justifyContent: 'center', alignItems: 'center',
  },
  entityName: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  entityType: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 1 },
  entityEmpty: {
    textAlign: 'center', color: colors.textTertiary, fontSize: fontSize.md,
    marginTop: spacing.xl,
  },
  // Date picker styles
  dateFieldRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  datePlaceholder: {
    flex: 1, fontSize: fontSize.md, color: colors.textTertiary,
  },
  dateValueText: {
    color: colors.textPrimary, fontWeight: '500',
  },
  // Owner picker styles
  ownerCustomSection: {
    paddingHorizontal: spacing.lg, paddingBottom: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  ownerSectionTitle: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.5,
    marginTop: spacing.md, marginBottom: spacing.sm,
  },
  ownerCustomRow: {
    flexDirection: 'row', gap: spacing.sm, alignItems: 'center',
  },
  ownerCustomInput: {
    flex: 1, backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  ownerCustomBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
});