import React from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import EmptyState from '../components/EmptyState';

export default function SegmentCompaniesScreen({ route, navigation }: any) {
  const { segmentId, segmentName } = route.params;
  const companies = useQuery(api.segments.getCompanies, {
    segmentId,
    includeDescendants: true,
  });
  const breadcrumb = useQuery(api.segments.getBreadcrumb, { segmentId });

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <View style={styles.headerText}>
          <Text style={styles.title} numberOfLines={1}>{segmentName}</Text>
          {breadcrumb && (
            <Text style={styles.subtitle} numberOfLines={1}>
              {breadcrumb.map((b: any) => b.name).join(' > ')}
            </Text>
          )}
        </View>
      </View>

      <FlatList
        data={companies || []}
        keyExtractor={(item: any) => item._id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }: any) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() => navigation.navigate('CompanyDetail', { id: item._id })}
          >
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>
                {item.name.charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.cardBody}>
              <Text style={styles.cardName}>{item.name}</Text>
              {item.domain && <Text style={styles.cardMeta}>{item.domain}</Text>}
            </View>
            <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          companies !== undefined ? (
            <EmptyState
              icon="business-outline"
              title="No companies"
              subtitle="No companies are assigned to this segment yet"
            />
          ) : null
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, marginBottom: 16, marginTop: 8,
  },
  backBtn: { marginRight: 12, padding: 4 },
  headerText: { flex: 1 },
  title: { fontSize: 22, fontWeight: '800', color: colors.textPrimary },
  subtitle: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },
  listContent: { paddingHorizontal: 16, paddingBottom: 100 },
  card: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderRadius: radius.md, padding: 14, marginBottom: 8, ...shadow.sm,
  },
  avatar: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center', marginRight: 12,
  },
  avatarText: { fontSize: 16, fontWeight: '700', color: colors.primary },
  cardBody: { flex: 1 },
  cardName: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  cardMeta: { fontSize: 12, color: colors.textSecondary, marginTop: 2 },
});
