import React, { useEffect, useState, useRef } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import {
  StyleSheet, ActivityIndicator, View, Text, TouchableOpacity,
  ScrollView, Modal, TextInput, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaProvider, SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Authenticated, Unauthenticated, AuthLoading, useMutation, useQuery, useAction } from 'convex/react';
import { Ionicons } from '@expo/vector-icons';
import { api } from './convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from './lib/theme';
import { SECTOR_NAMES, COMPANY_ROLES } from './lib/taxonomyData';
import LoginScreen from './screens/LoginScreen';
import CompaniesScreen from './screens/CompaniesScreen';
import CompanyDetailScreen from './screens/CompanyDetailScreen';
import ContactsScreen from './screens/ContactsScreen';
import ContactDetailScreen from './screens/ContactDetailScreen';
import PipelineScreen from './screens/PipelineScreen';
import OpportunityDetailScreen from './screens/OpportunityDetailScreen';
import TasksScreen from './screens/TasksScreen';
import ReportsScreen from './screens/ReportsScreen';
import SettingsScreen from './screens/SettingsScreen';
import SegmentsScreen from './screens/SegmentsScreen';
import SegmentCompaniesScreen from './screens/SegmentCompaniesScreen';
import AddCompanyScreen from './screens/AddCompanyScreen';
import InteractionsScreen from './screens/InteractionsScreen';

interface GeoZone {
  region: string;
  country?: string;
  stateProvince?: string;
  city?: string;
}

function formatZone(z: GeoZone): string {
  const parts = [z.region];
  if (z.country) parts.push(z.country);
  if (z.stateProvince) parts.push(z.stateProvince);
  if (z.city) parts.push(z.city);
  return parts.join(' > ');
}

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

// --- Stack navigators for each section ---

function SegmentsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SegmentsList" component={SegmentsScreen} />
      <Stack.Screen name="SegmentCompanies" component={SegmentCompaniesScreen} />
      <Stack.Screen name="AddCompany" component={AddCompanyScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
    </Stack.Navigator>
  );
}

function CompaniesStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="CompaniesList" component={CompaniesScreen} />
      <Stack.Screen name="AddCompany" component={AddCompanyScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
    </Stack.Navigator>
  );
}

function PipelineStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="PipelineBoard" component={PipelineScreen} />
      <Stack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
    </Stack.Navigator>
  );
}

function ContactsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ContactsList" component={ContactsScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="AddCompany" component={AddCompanyScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
      <Stack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
    </Stack.Navigator>
  );
}

function InteractionsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="InteractionsList" component={InteractionsScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="OpportunityDetail" component={OpportunityDetailScreen} />
    </Stack.Navigator>
  );
}

function ActionsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="TasksList" component={TasksScreen} />
      <Stack.Screen name="ContactsList" component={ContactsScreen} />
      <Stack.Screen name="ContactDetail" component={ContactDetailScreen} />
      <Stack.Screen name="AddCompany" component={AddCompanyScreen} />
      <Stack.Screen name="CompanyDetail" component={CompanyDetailScreen} />
    </Stack.Navigator>
  );
}

function ReportsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="ReportsList" component={ReportsScreen} />
    </Stack.Navigator>
  );
}

function SettingsStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SettingsMain" component={SettingsScreen} />
    </Stack.Navigator>
  );
}

// --- Tab configuration ---

const CAROUSEL_TABS = [
  { name: 'Segments', icon: 'layers' },
  { name: 'Companies', icon: 'business' },
  { name: 'Opportunities', icon: 'git-branch' },
  { name: 'Contacts', icon: 'people' },
  { name: 'Interactions', icon: 'chatbubbles' },
];

const UTILITY_TABS = [
  { name: 'Actions', icon: 'checkmark-circle' },
  { name: 'Reports', icon: 'bar-chart' },
  { name: 'Settings', icon: 'settings' },
];

// --- Custom Tab Bar ---

function CustomTabBar({ state, navigation }: any) {
  const insets = useSafeAreaInsets();
  const scrollRef = useRef<any>(null);
  const carouselCount = CAROUSEL_TABS.length;

  return (
    <View style={[tabStyles.container, { paddingBottom: Math.max(insets.bottom, 6) }]}>
      {/* Carousel section */}
      <View style={tabStyles.carouselWrapper}>
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={tabStyles.carousel}
          style={tabStyles.carouselScroll}
        >
          {state.routes.slice(0, carouselCount).map((route: any, index: number) => {
            const isFocused = state.index === index;
            const tab = CAROUSEL_TABS[index];
            return (
              <TouchableOpacity
                key={route.key}
                style={[tabStyles.carouselItem, isFocused && tabStyles.carouselItemActive]}
                onPress={() => {
                  if (!isFocused) {
                    navigation.navigate(route.name);
                  } else {
                    // Pop to root of the stack when re-tapping active tab
                    navigation.navigate(route.name, { screen: route.state?.routes?.[0]?.name });
                  }
                }}
              >
                <View style={[tabStyles.carouselIconWrap, isFocused && tabStyles.carouselIconWrapActive]}>
                  <Ionicons
                    name={tab.icon as any}
                    size={22}
                    color={isFocused ? colors.white : colors.textSecondary}
                  />
                </View>
                <Text
                  style={[tabStyles.carouselLabel, isFocused && tabStyles.carouselLabelActive]}
                  numberOfLines={1}
                >
                  {tab.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {/* Utility buttons */}
      <View style={tabStyles.utilitySection}>
        {state.routes.slice(carouselCount).map((route: any, index: number) => {
          const actualIndex = carouselCount + index;
          const isFocused = state.index === actualIndex;
          const tab = UTILITY_TABS[index];
          return (
            <TouchableOpacity
              key={route.key}
              style={[tabStyles.utilityItem, isFocused && tabStyles.utilityItemActive]}
              onPress={() => {
                if (!isFocused) {
                  navigation.navigate(route.name);
                } else {
                  navigation.navigate(route.name, { screen: route.state?.routes?.[0]?.name });
                }
              }}
            >
              <Ionicons
                name={tab.icon as any}
                size={18}
                color={isFocused ? colors.primary : colors.textTertiary}
              />
              <Text
                style={[tabStyles.utilityLabel, isFocused && tabStyles.utilityLabelActive]}
                numberOfLines={1}
              >
                {tab.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

const tabStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    alignItems: 'flex-end',
  },
  carouselWrapper: {
    flex: 1,
    backgroundColor: colors.bg,
    borderTopRightRadius: 16,
    marginRight: 2,
  },
  carouselScroll: {
    flex: 1,
  },
  carousel: {
    flexDirection: 'row',
    paddingHorizontal: 6,
    paddingTop: 8,
    paddingBottom: 4,
    gap: 4,
  },
  carouselItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    minWidth: 62,
  },
  carouselItemActive: {
    // active state handled by icon wrap and label
  },
  carouselIconWrap: {
    width: 38,
    height: 38,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
  },
  carouselIconWrapActive: {
    backgroundColor: colors.primary,
  },
  carouselLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: colors.textSecondary,
    marginTop: 3,
  },
  carouselLabelActive: {
    color: colors.primary,
    fontWeight: '800',
  },
  divider: {
    width: 1,
    backgroundColor: colors.border,
    marginVertical: 8,
    alignSelf: 'stretch',
  },
  utilitySection: {
    flexDirection: 'column',
    paddingHorizontal: 4,
    paddingTop: 6,
    paddingBottom: 2,
    alignItems: 'center',
    gap: 2,
  },
  utilityItem: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
    minWidth: 44,
  },
  utilityItemActive: {
    backgroundColor: colors.primaryLight,
  },
  utilityLabel: {
    fontSize: 9,
    fontWeight: '500',
    color: colors.textTertiary,
    marginTop: 2,
  },
  utilityLabelActive: {
    color: colors.primary,
    fontWeight: '700',
  },
});

// --- Onboarding Modal ---

const CLIENT_TYPES = [
  'Large Enterprise (1000+)',
  'Mid-market (100-1000)',
  'Small Business (<100)',
  'Government / Public Sector',
  'Non-profit / Institutional',
  'Private Equity / Investment',
];

const REGIONS = [
  'North America',
  'Latin America',
  'Western Europe',
  'Eastern Europe',
  'Middle East',
  'Africa',
  'South Asia',
  'East Asia',
  'Southeast Asia',
  'Oceania',
];

function OnboardingModal({ visible, onComplete }: { visible: boolean; onComplete: () => void }) {
  const ensureOnboarded = useMutation(api.onboarding.ensureOnboarded);
  const upsertSettings = useMutation(api.orgSettings.upsert);
  const saveBusinessContext = useMutation(api.orgSettings.saveBusinessContext);
  const generateTaxonomy = useAction(api.ai.generateTaxonomy);
  const seedFromTaxonomy = useMutation(api.segments.seedFromTaxonomy);
  const seedDefaults = useMutation(api.segments.seedDefaults);

  // Step 1: Company profile
  const [companyName, setCompanyName] = useState('');
  const [companyUrl, setCompanyUrl] = useState('');
  const [interests, setInterests] = useState('');

  // Step 2: Business context
  const [targetIndustries, setTargetIndustries] = useState<string[]>([]);
  const [clientTypes, setClientTypes] = useState<string[]>([]);
  const [geoZones, setGeoZones] = useState<GeoZone[]>([]);
  const [multiPartyDeals, setMultiPartyDeals] = useState(false);
  const [companyRoles, setCompanyRoles] = useState<string[]>([]);

  // Zone builder state
  const [addingZone, setAddingZone] = useState(false);
  const [zoneRegion, setZoneRegion] = useState('');
  const [zoneCountry, setZoneCountry] = useState('');
  const [zoneState, setZoneState] = useState('');
  const [zoneCity, setZoneCity] = useState('');

  const [saving, setSaving] = useState(false);
  const [step, setStep] = useState<'profile' | 'context' | 'generating' | 'seeding'>('profile');
  const [statusMsg, setStatusMsg] = useState('');

  const toggleItem = (list: string[], setList: (v: string[]) => void, item: string) => {
    setList(list.includes(item) ? list.filter(i => i !== item) : [...list, item]);
  };

  const handleNextToContext = () => {
    if (!companyName.trim()) {
      Alert.alert('Required', 'Please enter your company name.');
      return;
    }
    if (!interests.trim()) {
      Alert.alert('Required', 'Please describe the types of opportunities you seek.');
      return;
    }
    setStep('context');
  };

  const handleSubmit = async () => {
    setSaving(true);
    setStep('generating');

    try {
      // Step 0: Ensure org exists
      setStatusMsg('Setting up your workspace...');
      await ensureOnboarded();

      // Step 1: Save basic settings
      setStatusMsg('Saving your company profile...');
      await upsertSettings({
        companyName: companyName.trim(),
        companyUrl: companyUrl.trim() || undefined,
        interests: interests.trim(),
      });

      // Step 1b: Save business context
      setStatusMsg('Saving your business context...');
      const contextData = {
        targetIndustries,
        clientTypes,
        regions: geoZones.map((z: GeoZone) => formatZone(z)),
        multiPartyDeals,
        companyRoles: multiPartyDeals ? companyRoles : [],
      };
      await saveBusinessContext({ businessContext: JSON.stringify(contextData) });

      // Step 2: Generate personalized taxonomy via AI (with timeout)
      setStatusMsg('Analyzing your business and generating personalized segments...');
      let taxonomy: any = null;
      try {
        // Race between taxonomy generation and 25s timeout
        taxonomy = await Promise.race([
          generateTaxonomy({
            companyName: companyName.trim(),
            companyUrl: companyUrl.trim() || undefined,
            interests: interests.trim(),
          }),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 25000)),
        ]);
        console.log('Taxonomy generated:', taxonomy?.segments?.length, 'sectors');
      } catch (e: any) {
        console.log('Taxonomy generation failed or timed out:', e.message);
        taxonomy = null;
      }

      // Step 3: Seed segments — ALWAYS seed something
      setStep('seeding');
      try {
        if (taxonomy && taxonomy.segments && taxonomy.segments.length > 0) {
          setStatusMsg(`Creating ${taxonomy.segments.length} personalized market sectors...`);
          await seedFromTaxonomy({ segments: taxonomy.segments });

          // Save taxonomy profile metadata
          try {
            const taxonomyProfile = JSON.stringify({
              buyerTypes: taxonomy.buyerTypes || [],
              offerTypes: taxonomy.offerTypes || [],
              problemThemes: taxonomy.problemThemes || [],
              keywords: taxonomy.keywords || [],
              confidence: taxonomy.confidence || 'medium',
            });
            await upsertSettings({
              companyName: companyName.trim(),
              companyUrl: companyUrl.trim() || undefined,
              interests: interests.trim(),
              taxonomyProfile,
            });
          } catch {
            console.log('Failed to save taxonomy profile — continuing');
          }
        } else {
          // Fallback: seed ALL default segments via server mutation
          setStatusMsg('Setting up default market segments...');
          await seedDefaults();
        }
      } catch (e: any) {
        console.log('Segment seeding failed:', e.message);
        // Try one more time with defaults
        try {
          await seedDefaults();
        } catch {
          console.log('Even fallback seeding failed — user will need to create manually');
        }
      }

      // Always complete — settings are saved, segments may or may not exist
      onComplete();
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Something went wrong. Please try again.');
      setStep('profile');
    } finally {
      setSaving(false);
    }
  };

  // Generating/seeding screen
  if (step === 'generating' || step === 'seeding') {
    return (
      <Modal visible={visible} animationType="slide" presentationStyle="fullScreen">
        <SafeAreaView style={obStyles.safeArea} edges={['top', 'bottom']}>
          <View style={[obStyles.scroll, { justifyContent: 'center', alignItems: 'center' }]}>
            <View style={obStyles.iconCircle}>
              <Ionicons
                name={step === 'generating' ? 'sparkles' : 'layers'}
                size={40}
                color={colors.primary}
              />
            </View>
            <Text style={obStyles.title}>
              {step === 'generating' ? 'Building Your Taxonomy' : 'Setting Up Segments'}
            </Text>
            <Text style={[obStyles.subtitle, { marginTop: 12, marginBottom: 32 }]}>
              {statusMsg}
            </Text>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[obStyles.subtitle, { marginTop: 24, fontSize: 13 }]}>
              This may take 10-20 seconds...
            </Text>
          </View>
        </SafeAreaView>
      </Modal>
    );
  }

  // Step 2: Business Context
  if (step === 'context') {
    return (
      <Modal visible={visible} animationType="slide" presentationStyle="fullScreen">
        <KeyboardAvoidingView
          style={obStyles.container}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
          <SafeAreaView style={obStyles.safeArea} edges={['top', 'bottom']}>
            <ScrollView
              contentContainerStyle={obStyles.scroll}
              keyboardShouldPersistTaps="handled"
            >
              {/* Back button + step indicator */}
              <View style={obStyles.stepHeader}>
                <TouchableOpacity onPress={() => setStep('profile')} style={obStyles.backBtn}>
                  <Ionicons name="arrow-back" size={22} color={colors.primary} />
                  <Text style={obStyles.backText}>Back</Text>
                </TouchableOpacity>
                <Text style={obStyles.stepIndicator}>Step 2 of 2</Text>
              </View>

              <View style={obStyles.heroSection}>
                <View style={obStyles.iconCircle}>
                  <Ionicons name="analytics" size={40} color={colors.primary} />
                </View>
                <Text style={obStyles.title}>Business Context</Text>
                <Text style={obStyles.subtitle}>
                  Help the AI understand your market so it can build a better taxonomy.
                </Text>
              </View>

              <View style={obStyles.form}>
                {/* Target Industries */}
                <View style={obStyles.field}>
                  <Text style={obStyles.label}>Target Industries</Text>
                  <Text style={obStyles.hint}>Select the industries you primarily sell into.</Text>
                  <View style={obStyles.chipWrap}>
                    {SECTOR_NAMES.map(s => (
                      <TouchableOpacity
                        key={s}
                        style={[obStyles.chip, targetIndustries.includes(s) && obStyles.chipSelected]}
                        onPress={() => toggleItem(targetIndustries, setTargetIndustries, s)}
                      >
                        <Text style={[obStyles.chipText, targetIndustries.includes(s) && obStyles.chipTextSelected]}>{s}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                {/* Client Types */}
                <View style={obStyles.field}>
                  <Text style={obStyles.label}>Client Types</Text>
                  <Text style={obStyles.hint}>What types of organizations do you target?</Text>
                  <View style={obStyles.chipWrap}>
                    {CLIENT_TYPES.map(t => (
                      <TouchableOpacity
                        key={t}
                        style={[obStyles.chip, clientTypes.includes(t) && obStyles.chipSelected]}
                        onPress={() => toggleItem(clientTypes, setClientTypes, t)}
                      >
                        <Text style={[obStyles.chipText, clientTypes.includes(t) && obStyles.chipTextSelected]}>{t}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                {/* Geographic Regions */}
                <View style={obStyles.field}>
                  <Text style={obStyles.label}>Geographic Zones</Text>
                  <Text style={obStyles.hint}>Select broad regions. Use "Add specific zone" below to narrow to a country, province, or city.</Text>
                  <View style={obStyles.chipWrap}>
                    {REGIONS.map(r => {
                      const hasBroad = geoZones.some((z: GeoZone) => z.region === r && !z.country);
                      return (
                        <TouchableOpacity
                          key={r}
                          style={[obStyles.chip, hasBroad && obStyles.chipSelected]}
                          onPress={() => {
                            if (hasBroad) {
                              setGeoZones(geoZones.filter((z: GeoZone) => !(z.region === r && !z.country)));
                            } else {
                              setGeoZones([...geoZones, { region: r }]);
                            }
                          }}
                        >
                          <Text style={[obStyles.chipText, hasBroad && obStyles.chipTextSelected]}>{r}</Text>
                        </TouchableOpacity>
                      );
                    })}
                  </View>

                  {/* Configured zones list */}
                  {geoZones.filter((z: GeoZone) => z.country).length > 0 && (
                    <View style={{ marginTop: 8, gap: 4 }}>
                      {geoZones.filter((z: GeoZone) => z.country).map((z: GeoZone, i: number) => (
                        <View key={i} style={{ flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.primaryLight + '60', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 16, alignSelf: 'flex-start' }}>
                          <Ionicons name="location" size={12} color={colors.primary} />
                          <Text style={{ fontSize: 12, color: colors.primary, fontWeight: '500' }}>{formatZone(z)}</Text>
                          <TouchableOpacity onPress={() => setGeoZones(geoZones.filter((_: GeoZone, idx: number) => idx !== geoZones.indexOf(z)))}>
                            <Ionicons name="close-circle" size={14} color={colors.textTertiary} />
                          </TouchableOpacity>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Add specific zone */}
                  {!addingZone ? (
                    <TouchableOpacity
                      style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 10, paddingVertical: 4 }}
                      onPress={() => setAddingZone(true)}
                    >
                      <Ionicons name="add-circle-outline" size={16} color={colors.primary} />
                      <Text style={{ fontSize: 13, color: colors.primary, fontWeight: '500' }}>Add specific zone (country, province, city)</Text>
                    </TouchableOpacity>
                  ) : (
                    <View style={{ marginTop: 10, padding: 12, backgroundColor: colors.bg, borderRadius: 10, borderWidth: 1, borderColor: colors.border }}>
                      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
                        <View style={{ flexDirection: 'row', gap: 6 }}>
                          {REGIONS.map(r => (
                            <TouchableOpacity
                              key={r}
                              style={[obStyles.chip, zoneRegion === r && obStyles.chipSelected, { paddingVertical: 4, paddingHorizontal: 10 }]}
                              onPress={() => setZoneRegion(r)}
                            >
                              <Text style={[obStyles.chipText, { fontSize: 12 }, zoneRegion === r && obStyles.chipTextSelected]}>{r}</Text>
                            </TouchableOpacity>
                          ))}
                        </View>
                      </ScrollView>
                      <TextInput style={[obStyles.input, { padding: 10, fontSize: 13, marginBottom: 6 }]} placeholder="Country (e.g. Canada)" placeholderTextColor={colors.textTertiary} value={zoneCountry} onChangeText={setZoneCountry} />
                      <TextInput style={[obStyles.input, { padding: 10, fontSize: 13, marginBottom: 6 }]} placeholder="State/Province (optional)" placeholderTextColor={colors.textTertiary} value={zoneState} onChangeText={setZoneState} />
                      <TextInput style={[obStyles.input, { padding: 10, fontSize: 13, marginBottom: 6 }]} placeholder="City/Metro area (optional)" placeholderTextColor={colors.textTertiary} value={zoneCity} onChangeText={setZoneCity} />
                      <View style={{ flexDirection: 'row', gap: 8 }}>
                        <TouchableOpacity
                          style={{ flex: 1, backgroundColor: colors.primary, paddingVertical: 8, borderRadius: 8, alignItems: 'center' }}
                          onPress={() => {
                            if (!zoneRegion) { Alert.alert('Required', 'Select a region.'); return; }
                            const zone: GeoZone = { region: zoneRegion };
                            if (zoneCountry.trim()) zone.country = zoneCountry.trim();
                            if (zoneState.trim()) zone.stateProvince = zoneState.trim();
                            if (zoneCity.trim()) zone.city = zoneCity.trim();
                            setGeoZones([...geoZones, zone]);
                            setZoneRegion(''); setZoneCountry(''); setZoneState(''); setZoneCity(''); setAddingZone(false);
                          }}
                        >
                          <Text style={{ color: colors.white, fontWeight: '600', fontSize: 13 }}>Add Zone</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={{ paddingVertical: 8, paddingHorizontal: 16, borderRadius: 8, alignItems: 'center', backgroundColor: colors.bg }}
                          onPress={() => { setAddingZone(false); setZoneRegion(''); setZoneCountry(''); setZoneState(''); setZoneCity(''); }}
                        >
                          <Text style={{ color: colors.textSecondary, fontSize: 13 }}>Cancel</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}
                </View>

                {/* Multi-party Deals */}
                <View style={obStyles.field}>
                  <Text style={obStyles.label}>Deal Complexity</Text>
                  <TouchableOpacity
                    style={obStyles.toggleRow}
                    onPress={() => setMultiPartyDeals(!multiPartyDeals)}
                  >
                    <Ionicons
                      name={multiPartyDeals ? 'checkbox' : 'square-outline'}
                      size={22}
                      color={multiPartyDeals ? colors.primary : colors.textTertiary}
                    />
                    <Text style={obStyles.toggleText}>My deals involve multiple parties/stakeholders</Text>
                  </TouchableOpacity>
                </View>

                {/* Company Roles (shown when multi-party is on) */}
                {multiPartyDeals && (
                  <View style={obStyles.field}>
                    <Text style={obStyles.label}>Stakeholder Roles</Text>
                    <Text style={obStyles.hint}>What roles do companies play in your deals?</Text>
                    <View style={obStyles.chipWrap}>
                      {COMPANY_ROLES.map(r => (
                        <TouchableOpacity
                          key={r.value}
                          style={[obStyles.chip, companyRoles.includes(r.value) && obStyles.chipSelected]}
                          onPress={() => toggleItem(companyRoles, setCompanyRoles, r.value)}
                        >
                          <Text style={[obStyles.chipText, companyRoles.includes(r.value) && obStyles.chipTextSelected]}>{r.label}</Text>
                        </TouchableOpacity>
                      ))}
                    </View>
                  </View>
                )}
              </View>

              <TouchableOpacity
                style={[obStyles.submitBtn, saving && { opacity: 0.7 }]}
                onPress={handleSubmit}
                disabled={saving}
              >
                {saving ? (
                  <ActivityIndicator size="small" color={colors.white} />
                ) : (
                  <>
                    <Ionicons name="sparkles" size={20} color={colors.white} style={{ marginRight: 8 }} />
                    <Text style={obStyles.submitText}>Generate My Taxonomy</Text>
                  </>
                )}
              </TouchableOpacity>

              <TouchableOpacity
                style={obStyles.skipBtn}
                onPress={handleSubmit}
                disabled={saving}
              >
                <Text style={obStyles.skipText}>Skip & use defaults</Text>
              </TouchableOpacity>

              <Text style={obStyles.footerHint}>
                You can always update this later in Settings.
              </Text>
            </ScrollView>
          </SafeAreaView>
        </KeyboardAvoidingView>
      </Modal>
    );
  }

  // Step 1: Company Profile
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="fullScreen">
      <KeyboardAvoidingView
        style={obStyles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <SafeAreaView style={obStyles.safeArea} edges={['top', 'bottom']}>
          <ScrollView
            contentContainerStyle={obStyles.scroll}
            keyboardShouldPersistTaps="handled"
          >
            {/* Step indicator */}
            <View style={obStyles.stepHeader}>
              <View />
              <Text style={obStyles.stepIndicator}>Step 1 of 2</Text>
            </View>

            <View style={obStyles.heroSection}>
              <View style={obStyles.iconCircle}>
                <Ionicons name="briefcase" size={40} color={colors.primary} />
              </View>
              <Text style={obStyles.title}>Welcome to BDBuddy</Text>
              <Text style={obStyles.subtitle}>
                Tell us about your company so the AI can build a personalized market taxonomy for your business development.
              </Text>
            </View>

            <View style={obStyles.form}>
              <View style={obStyles.field}>
                <Text style={obStyles.label}>Your Company Name *</Text>
                <TextInput
                  style={obStyles.input}
                  placeholder="e.g. ACME Engineering"
                  placeholderTextColor={colors.textTertiary}
                  value={companyName}
                  onChangeText={setCompanyName}
                />
              </View>

              <View style={obStyles.field}>
                <Text style={obStyles.label}>Company Website</Text>
                <Text style={obStyles.hint}>
                  We'll analyze your website to better understand your business.
                </Text>
                <TextInput
                  style={obStyles.input}
                  placeholder="e.g. acme.com"
                  placeholderTextColor={colors.textTertiary}
                  value={companyUrl}
                  onChangeText={setCompanyUrl}
                  autoCapitalize="none"
                  keyboardType="url"
                />
              </View>

              <View style={obStyles.field}>
                <Text style={obStyles.label}>Types of Opportunities & Services *</Text>
                <Text style={obStyles.hint}>
                  Describe what you sell, the services you offer, and the industries you target. The AI will use this to build your segment taxonomy.
                </Text>
                <TextInput
                  style={[obStyles.input, obStyles.multiline]}
                  placeholder="e.g. Industrial decarbonization consulting, CCUS project development, energy efficiency programs for oil & gas and manufacturing clients"
                  placeholderTextColor={colors.textTertiary}
                  value={interests}
                  onChangeText={setInterests}
                  multiline
                  numberOfLines={5}
                />
              </View>
            </View>

            <TouchableOpacity
              style={obStyles.submitBtn}
              onPress={handleNextToContext}
            >
              <Text style={obStyles.submitText}>Next: Business Context</Text>
              <Ionicons name="arrow-forward" size={20} color={colors.white} style={{ marginLeft: 8 }} />
            </TouchableOpacity>

            <Text style={obStyles.footerHint}>
              Step 1 of 2 — Next we'll ask about your target market to fine-tune the AI.
            </Text>
          </ScrollView>
        </SafeAreaView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const obStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  safeArea: { flex: 1 },
  scroll: { padding: 24, flexGrow: 1 },
  stepHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8,
  },
  stepIndicator: {
    fontSize: 13, fontWeight: '600', color: colors.textTertiary,
    backgroundColor: colors.white, paddingHorizontal: 12, paddingVertical: 4,
    borderRadius: 12, overflow: 'hidden',
  },
  backBtn: { flexDirection: 'row', alignItems: 'center' },
  backText: { fontSize: 15, color: colors.primary, fontWeight: '600', marginLeft: 4 },
  heroSection: { alignItems: 'center', marginBottom: 24 },
  iconCircle: {
    width: 80, height: 80, borderRadius: 40, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center', marginBottom: 16,
  },
  title: { fontSize: 26, fontWeight: '800', color: colors.textPrimary, textAlign: 'center' },
  subtitle: {
    fontSize: 15, color: colors.textSecondary, textAlign: 'center', marginTop: 8,
    lineHeight: 22, paddingHorizontal: 16,
  },
  form: { marginBottom: 24 },
  field: { marginBottom: 20 },
  label: { fontSize: 14, fontWeight: '600', color: colors.textPrimary, marginBottom: 6 },
  hint: { fontSize: 12, color: colors.textTertiary, marginBottom: 6, lineHeight: 17 },
  input: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: 10, padding: 14, fontSize: 15, color: colors.textPrimary, ...shadow.sm,
  },
  multiline: { height: 120, textAlignVertical: 'top' },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20,
    borderWidth: 1, borderColor: colors.border, backgroundColor: colors.white,
  },
  chipSelected: {
    backgroundColor: colors.primary, borderColor: colors.primary,
  },
  chipText: { fontSize: 13, color: colors.textPrimary },
  chipTextSelected: { color: colors.white, fontWeight: '600' },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 4 },
  toggleText: { fontSize: 14, color: colors.textPrimary, flex: 1 },
  submitBtn: {
    backgroundColor: colors.primary, paddingVertical: 16, borderRadius: 12,
    alignItems: 'center', flexDirection: 'row', justifyContent: 'center', ...shadow.md,
  },
  submitText: { fontSize: 17, fontWeight: '700', color: colors.white },
  skipBtn: {
    paddingVertical: 12, alignItems: 'center', marginTop: 8,
  },
  skipText: { fontSize: 14, color: colors.textTertiary, fontWeight: '500' },
  footerHint: {
    fontSize: 12, color: colors.textTertiary, textAlign: 'center',
    marginTop: 16, lineHeight: 17, paddingHorizontal: 8,
  },
});

// --- Main Tab Navigator ---

function MainTabs() {
  return (
    <Tab.Navigator
      tabBar={(props: any) => <CustomTabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Segments" component={SegmentsStack} />
      <Tab.Screen name="Companies" component={CompaniesStack} />
      <Tab.Screen name="Opportunities" component={PipelineStack} />
      <Tab.Screen name="Contacts" component={ContactsStack} />
      <Tab.Screen name="Interactions" component={InteractionsStack} />
      <Tab.Screen name="Actions" component={ActionsStack} />
      <Tab.Screen name="Reports" component={ReportsStack} />
      <Tab.Screen name="Settings" component={SettingsStack} />
    </Tab.Navigator>
  );
}

// --- Authenticated App with Onboarding + Safety Net ---

function AuthenticatedApp() {
  const ensureOnboarded = useMutation(api.onboarding.ensureOnboarded);
  const seedDefaults = useMutation(api.segments.seedDefaults);
  const orgSettings = useQuery(api.orgSettings.get);
  const segments = useQuery(api.segments.list);
  const [ready, setReady] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingDismissed, setOnboardingDismissed] = useState(false);
  const [safetySeeded, setSafetySeeded] = useState(false);

  useEffect(() => {
    let mounted = true;
    ensureOnboarded()
      .then(() => { if (mounted) setReady(true); })
      .catch(() => { if (mounted) setReady(true); });
    return () => { mounted = false; };
  }, [ensureOnboarded]);

  // Show onboarding if no orgSettings configured
  useEffect(() => {
    if (ready && orgSettings === null && !onboardingDismissed) {
      setShowOnboarding(true);
    }
  }, [ready, orgSettings, onboardingDismissed]);

  // SAFETY NET: If orgSettings exists but segments are empty, auto-seed defaults
  useEffect(() => {
    if (ready && orgSettings && segments && segments.length === 0 && !safetySeeded && !showOnboarding) {
      console.log('[SafetyNet] orgSettings exists but no segments — auto-seeding defaults');
      setSafetySeeded(true);
      seedDefaults().catch((e: any) => {
        console.log('[SafetyNet] Auto-seed failed:', e.message);
      });
    }
  }, [ready, orgSettings, segments, safetySeeded, showOnboarding, seedDefaults]);

  if (!ready) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
        <Text style={{ marginTop: 12, color: colors.textSecondary }}>Setting up workspace...</Text>
      </View>
    );
  }

  return (
    <>
      {ready ? <MainTabs /> : null}
      <OnboardingModal
        visible={showOnboarding}
        onComplete={() => {
          setShowOnboarding(false);
          setOnboardingDismissed(true);
        }}
      />
    </>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={styles.container}>
      <SafeAreaProvider style={styles.container}>
        <NavigationContainer linking={{ enabled: false }}>
          <AuthLoading>
            <View style={styles.center}>
              <ActivityIndicator size="large" color={colors.primary} />
            </View>
          </AuthLoading>

          <Unauthenticated>
            <LoginScreen />
          </Unauthenticated>

          <Authenticated>
            <AuthenticatedApp />
          </Authenticated>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.bg },
});