import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Modal, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

interface Props {
  value?: any; // segment ID
  valuePath?: string; // display path
  onChange: (segmentId: any) => void;
}

type BreadcrumbItem = { _id: any; name: string; level: number };

export default function SegmentPicker({ value, valuePath, onChange }: Props) {
  const [visible, setVisible] = useState(false);
  const [parentId, setParentId] = useState<any>(undefined);
  const [breadcrumb, setBreadcrumb] = useState<BreadcrumbItem[]>([]);

  const segments = useQuery(api.segments.getChildren, visible ? { parentId } : "skip");

  const navigateDown = (seg: any) => {
    if (seg.level < 3 && seg.childCount > 0) {
      setBreadcrumb([...breadcrumb, { _id: seg._id, name: seg.name, level: seg.level }]);
      setParentId(seg._id);
    } else {
      // Leaf or no children — select it
      onChange(seg._id);
      setVisible(false);
      reset();
    }
  };

  const navigateUp = (index: number) => {
    if (index < 0) {
      setBreadcrumb([]);
      setParentId(undefined);
    } else {
      setBreadcrumb(breadcrumb.slice(0, index + 1));
      setParentId(breadcrumb[index]._id);
    }
  };

  const reset = () => {
    setBreadcrumb([]);
    setParentId(undefined);
  };

  const selectNonLeaf = (seg: any) => {
    // Allow selecting at any level
    onChange(seg._id);
    setVisible(false);
    reset();
  };

  return (
    <>
      <TouchableOpacity style={styles.picker} onPress={() => setVisible(true)}>
        <Ionicons name="layers-outline" size={18} color={value ? colors.primary : colors.textTertiary} />
        <Text style={[styles.pickerText, !valuePath && styles.pickerPlaceholder]} numberOfLines={1}>
          {valuePath || 'Select market segment...'}
        </Text>
        {value && (
          <TouchableOpacity onPress={() => { onChange(undefined); }} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
          </TouchableOpacity>
        )}
        <Ionicons name="chevron-down" size={16} color={colors.textTertiary} style={{ marginLeft: 4 }} />
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="slide">
        <View style={styles.overlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Select Segment</Text>
              <TouchableOpacity onPress={() => { setVisible(false); reset(); }}>
                <Ionicons name="close" size={24} color={colors.textSecondary} />
              </TouchableOpacity>
            </View>

            {/* Breadcrumb */}
            {breadcrumb.length > 0 && (
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.breadcrumbRow}>
                <TouchableOpacity onPress={() => navigateUp(-1)} style={styles.breadcrumbItem}>
                  <Ionicons name="home" size={14} color={colors.primary} />
                </TouchableOpacity>
                {breadcrumb.map((item, idx) => (
                  <TouchableOpacity
                    key={item._id}
                    style={styles.breadcrumbItem}
                    onPress={() => navigateUp(idx)}
                  >
                    <Ionicons name="chevron-forward" size={12} color={colors.textTertiary} />
                    <Text style={[
                      styles.breadcrumbText,
                      idx === breadcrumb.length - 1 && { fontWeight: '700', color: colors.textPrimary },
                    ]}>{item.name}</Text>
                  </TouchableOpacity>
                ))}
                {/* Select current level button */}
                <TouchableOpacity
                  style={styles.selectCurrentBtn}
                  onPress={() => {
                    const current = breadcrumb[breadcrumb.length - 1];
                    selectNonLeaf(current);
                  }}
                >
                  <Text style={styles.selectCurrentText}>Select this level</Text>
                </TouchableOpacity>
              </ScrollView>
            )}

            <FlatList
              data={segments || []}
              keyExtractor={(item: any) => item._id}
              contentContainerStyle={styles.listContent}
              renderItem={({ item }: any) => (
                <TouchableOpacity
                  style={styles.item}
                  onPress={() => navigateDown(item)}
                >
                  {item.color && <View style={[styles.dot, { backgroundColor: item.color }]} />}
                  <Text style={styles.itemName}>{item.name}</Text>
                  {item.childCount > 0 && (
                    <Text style={styles.itemCount}>{item.childCount}</Text>
                  )}
                  <Ionicons
                    name={item.level >= 3 ? 'checkmark-circle-outline' : 'chevron-forward'}
                    size={18}
                    color={item.level >= 3 ? colors.success : colors.textTertiary}
                  />
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                segments !== undefined ? (
                  <Text style={styles.emptyText}>No segments at this level</Text>
                ) : null
              }
            />
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  picker: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.white,
    borderWidth: 1, borderColor: colors.border, borderRadius: radius.md,
    padding: 12, marginBottom: 12,
  },
  pickerText: { flex: 1, marginLeft: 8, fontSize: fontSize.sm, color: colors.textPrimary },
  pickerPlaceholder: { color: colors.textTertiary },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'flex-end' },
  modal: {
    backgroundColor: colors.white, borderTopLeftRadius: 20, borderTopRightRadius: 20,
    maxHeight: '75%', paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    padding: 16, paddingBottom: 8,
  },
  modalTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  breadcrumbRow: { paddingHorizontal: 16, marginBottom: 8, maxHeight: 36 },
  breadcrumbItem: { flexDirection: 'row', alignItems: 'center', marginRight: 4 },
  breadcrumbText: { fontSize: 13, color: colors.primary, marginLeft: 4 },
  selectCurrentBtn: {
    backgroundColor: colors.primaryLight, paddingHorizontal: 10, paddingVertical: 4,
    borderRadius: 12, marginLeft: 12,
  },
  selectCurrentText: { fontSize: 12, fontWeight: '600', color: colors.primary },
  listContent: { paddingHorizontal: 16, paddingBottom: 20 },
  item: {
    flexDirection: 'row', alignItems: 'center', paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 10 },
  itemName: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary },
  itemCount: { fontSize: 12, color: colors.textSecondary, marginRight: 8 },
  emptyText: { textAlign: 'center', color: colors.textTertiary, marginTop: 24 },
});