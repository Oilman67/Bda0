import React, { useState, useCallback, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, TextInput,
  ActivityIndicator, ScrollView, Alert, FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useAction } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

/* globals available in React Native runtime */
declare const fetch: any;
declare const AbortController: any;

// Types
interface ScoutOpportunity {
  title: string;
  type: string;
  geography: string;
  target: string;
  whyExists: string;
  evidence: string;
  fitReason: string;
  relevance: 'High' | 'Medium' | 'Low';
  timing: 'Immediate' | 'Near-term' | 'Monitor';
  confidence: 'High' | 'Medium' | 'Low';
  netNew: 'Net-new' | 'Adjacent' | 'Already covered';
  nextMove: string;
  sources: string[];
}

interface ScoutResult {
  executiveSummary: {
    count: number;
    themes: string[];
    directionComment: string;
  };
  opportunities: ScoutOpportunity[];
  excluded: { title: string; reason: string }[];
  ranking: { title: string; reason: string }[];
}

interface GeoZone {
  region: string;
  country?: string;
  stateProvince?: string;
  city?: string;
}

function formatZone(z: GeoZone): string {
  return [z.region, z.country, z.stateProvince, z.city].filter(Boolean).join(' > ');
}

const RELEVANCE_COLOR: Record<string, string> = {
  High: '#10B981', Medium: '#F59E0B', Low: '#94A3B8',
};
const TIMING_COLOR: Record<string, string> = {
  Immediate: '#EF4444', 'Near-term': '#F59E0B', Monitor: '#3B82F6',
};
const CONFIDENCE_COLOR: Record<string, string> = {
  High: '#10B981', Medium: '#F59E0B', Low: '#EF4444',
};

const CARD_HEIGHT = 62;
const CAROUSEL_HEIGHT = CARD_HEIGHT * 3.5;

const SCOUT_SYSTEM_PROMPT = `You are a Business Development Opportunity Scout specialized in finding net-new commercial opportunities from public information.

OBJECTIVE: Identify credible, actionable business opportunities for a specific target company that are NOT already captured in the user's current opportunity list.

OPERATING STANDARD:
- Be rigorous, structured, and commercially useful
- Do not produce vague "maybe" ideas without evidence
- Ground every opportunity in observable signals from your knowledge
- Prefer fewer high-quality opportunities over many weak ones
- Think like a BD analyst, not a generic researcher

RESEARCH SCOPE — Use your knowledge of:
1. Target company: press releases, investor relations, annual reports, sustainability/ESG, procurement, expansion plans, innovation/partnerships, careers/hiring signals
2. External context: trade press, industry publications, economic development, infrastructure projects, competitor moves
3. Geography-specific: regional expansions, new facilities, retrofits, logistics changes, energy/infrastructure projects, regulatory drivers

LIVE INTELLIGENCE PRIORITY:
When LIVE WEBSITE INTELLIGENCE or RECENT NEWS HEADLINES are provided in the user message, treat these as PRIMARY evidence sources. This is real, current data scraped from the company's own website and recent news coverage. Prioritize opportunities grounded in this live data over general knowledge. Cite specific pages, headlines, or announcements as evidence.

OPPORTUNITY DEFINITION — Any specific, plausible opening such as:
- Expansion into new site/region/facility/market
- Retrofit, modernization, optimization
- Partnership, vendor, technology gap
- Infrastructure, energy, logistics, sustainability need
- Regulatory or incentive-driven project
- Post-acquisition, restructuring, diversification need
- Pilot, demonstration, or proof-of-concept opening

DEDUPLICATION: Compare every candidate against the existing opportunity list. Only return genuinely net-new items.

EVIDENCE STANDARD: Every opportunity must include a concrete trigger/signal, rationale, and enough specificity for a salesperson to act on it.

QUALITY FILTERS — Reject weak ideas relying only on:
- Generic company growth language
- Vague corporate ambition without visible project signal
- Old news with no continuing relevance

Prefer opportunities with: project announcements, regional expansion, new facilities, procurement initiatives, operational pain points, sustainability targets tied to action, leadership statements tied to execution, local permitting/investment/hiring activity.

OUTPUT FORMAT (STRICT JSON, no markdown):
{
  "executiveSummary": {
    "count": <number of net-new opportunities>,
    "themes": ["theme1", "theme2"],
    "directionComment": "Brief on the company's apparent direction in the target geography"
  },
  "opportunities": [
    {
      "title": "Short opportunity name",
      "type": "expansion|retrofit|partnership|infrastructure|procurement|regulatory|pilot|other",
      "geography": "City, Region, Country",
      "target": "Business unit / site / initiative",
      "whyExists": "Why this opportunity appears to exist",
      "evidence": "Concrete trigger or signal from public knowledge",
      "fitReason": "Why it fits our deal criteria",
      "relevance": "High|Medium|Low",
      "timing": "Immediate|Near-term|Monitor",
      "confidence": "High|Medium|Low",
      "netNew": "Net-new|Adjacent",
      "nextMove": "Suggested next action",
      "sources": ["Source reference 1", "Source reference 2"]
    }
  ],
  "excluded": [
    { "title": "Excluded item name", "reason": "Why excluded (already tracked / weak evidence / outside scope)" }
  ],
  "ranking": [
    { "title": "Opportunity name", "reason": "Why it should be pursued in this order" }
  ]
}

TONE: Disciplined, executive-ready BD research. Concise, factual, commercially sharp. No hype, no fluff.`;

interface Props {
  navigation: any;
}

export default function OpportunityScoutAI({ navigation }: Props) {
  const companies = useQuery(api.companies.list);
  const opportunities = useQuery(api.opportunities.list, {});
  const orgSettings = useQuery(api.orgSettings.get);
  const createOpp = useMutation(api.opportunities.create);
  const scoutIntel = useAction(api.ai.scoutCompanyIntel);

  // UI state
  const [expanded, setExpanded] = useState(true);
  const [targetCompanyId, setTargetCompanyId] = useState<string | null>(null);
  const [geoScope, setGeoScope] = useState('');
  const [customGeo, setCustomGeo] = useState('');

  // Results state
  const [scouting, setScouting] = useState(false);
  const [scoutPhase, setScoutPhase] = useState<'idle' | 'scraping' | 'analyzing'>('idle');
  const [result, setResult] = useState<ScoutResult | null>(null);
  const [selectedOpps, setSelectedOpps] = useState<Set<number>>(new Set());
  const [addingOpps, setAddingOpps] = useState(false);
  const [showExcluded, setShowExcluded] = useState(false);

  const hasProfile = !!orgSettings?.companyName;

  // Parse geo zones from business context
  const savedZones = useMemo(() => {
    if (!orgSettings?.businessContext) return [];
    try {
      const ctx = JSON.parse(orgSettings.businessContext);
      if (ctx.geoZones?.length > 0) return ctx.geoZones as GeoZone[];
      if (ctx.regions?.length > 0) return ctx.regions.map((r: string) => ({ region: r })) as GeoZone[];
    } catch {}
    return [];
  }, [orgSettings]);

  const targetCompany = useMemo(() => {
    if (!targetCompanyId || !companies) return null;
    return companies.find((c: any) => c._id === targetCompanyId) || null;
  }, [targetCompanyId, companies]);

  // Get full company detail for insightsReport
  const companyDetail = useQuery(
    api.companies.get,
    targetCompanyId ? { id: targetCompanyId as any } : "skip"
  );

  const handleScout = useCallback(async () => {
    if (!targetCompanyId || !targetCompany) {
      Alert.alert('Select Company', 'Please select a target company to scout opportunities for.');
      return;
    }
    if (!orgSettings) {
      Alert.alert('Profile Required', 'Set up your company profile in Settings first.');
      return;
    }

    setScouting(true);
    setScoutPhase('scraping');
    setResult(null);
    setSelectedOpps(new Set());
    setShowExcluded(false);

    try {
      // ── Phase 1: Scrape live website + news data ──────────────────
      let liveIntel = { siteContent: '', newsContent: '', pagesScraped: 0 };
      const companyDomain = (targetCompany as any).domain || '';
      if (companyDomain) {
        try {
          liveIntel = await scoutIntel({
            companyDomain,
            companyName: (targetCompany as any).name,
          });
        } catch (e: any) {
          console.log('Scout intel scraping failed, continuing with LLM knowledge:', e.message);
        }
      }

      setScoutPhase('analyzing');

      // ── Phase 2: Build context and call LLM ───────────────────────
      // Build business context
      let businessCtx: any = {};
      if (orgSettings.businessContext) {
        try { businessCtx = JSON.parse(orgSettings.businessContext); } catch {}
      }

      // Build geography string
      let geoStr = '';
      if (customGeo.trim()) {
        geoStr = customGeo.trim();
      } else if (geoScope) {
        geoStr = geoScope;
      } else if (savedZones.length > 0) {
        geoStr = savedZones.map(formatZone).join('; ');
      }

      // Build existing opportunities list for deduplication
      const existingOpps = (opportunities || [])
        .filter((o: any) => o.companyId === targetCompanyId)
        .map((o: any) => ({
          title: o.title,
          status: o.status,
          value: o.value,
          location: o.location,
        }));

      const allExistingOpps = (opportunities || [])
        .map((o: any) => o.title)
        .slice(0, 50);

      // Build company insights context
      let insightsContext = '';
      if (companyDetail?.insightsReport) {
        try {
          insightsContext = companyDetail.insightsReport.substring(0, 3000);
        } catch {}
      }

      const userMessage = `INPUTS:

USER COMPANY / OFFER CONTEXT:
- company_name: "${orgSettings.companyName}"
${orgSettings.companyUrl ? `- website: ${orgSettings.companyUrl}` : ''}
- what_we_sell: "${orgSettings.interests}"
${businessCtx.targetIndustries?.length ? `- target_industries: ${businessCtx.targetIndustries.join(', ')}` : ''}
${businessCtx.clientTypes?.length ? `- target_client_types: ${businessCtx.clientTypes.join(', ')}` : ''}
${businessCtx.valueProposition ? `- value_proposition: ${businessCtx.valueProposition}` : ''}
${businessCtx.dealComplexity ? `- deal_complexity: ${businessCtx.dealComplexity}` : ''}

TARGET SEARCH PARAMETERS:
- target_company_name: "${targetCompany.name}"
${(targetCompany as any).domain ? `- company_website: ${(targetCompany as any).domain}` : ''}
${(targetCompany as any).industry ? `- industry: ${(targetCompany as any).industry}` : ''}
${(targetCompany as any).size ? `- size: ${(targetCompany as any).size}` : ''}
${(targetCompany as any).segmentPath ? `- segment: ${(targetCompany as any).segmentPath}` : ''}
${(targetCompany as any).companyRole ? `- company_role: ${(targetCompany as any).companyRole}` : ''}
${(targetCompany as any).notes ? `- user_notes: ${(targetCompany as any).notes.slice(0, 300)}` : ''}
${(targetCompany as any).companyRoleNotes ? `- role_context: ${(targetCompany as any).companyRoleNotes.slice(0, 200)}` : ''}
- geography_scope: "${geoStr || 'Global — prioritize where this company operates'}"

${insightsContext ? `BD INTELLIGENCE REPORT (existing analysis of this company):\n${insightsContext}\n` : ''}

${liveIntel.siteContent ? `LIVE WEBSITE INTELLIGENCE (freshly scraped from company website — /news, /investors, /press pages):\n${liveIntel.siteContent.slice(0, 8000)}\n` : ''}

${liveIntel.newsContent ? `${liveIntel.newsContent}\n` : ''}

EXISTING OPPORTUNITY LIST (for deduplication):
Company-specific opportunities: ${existingOpps.length > 0 ? JSON.stringify(existingOpps) : 'None yet'}
All tracked opportunity titles: ${allExistingOpps.length > 0 ? allExistingOpps.join('; ') : 'None yet'}

IMPORTANT: Use the live website data and recent news headlines above as PRIMARY evidence sources. These are real, current signals from the company's own website and news coverage. Ground your opportunities in this data wherever possible.

Find 3-8 net-new, high-quality BD opportunities. Be rigorous — only include opportunities with clear evidence signals. Return ONLY valid JSON.`;

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 90000);

      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: SCOUT_SYSTEM_PROMPT },
            { role: 'user', content: userMessage },
          ],
        }),
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!res.ok) {
        console.log('Scout LLM API error:', res.status, res.statusText);
        throw new Error(`API request failed: ${res.status}`);
      }
      const data = await res.json();
      console.log('Scout LLM response keys:', Object.keys(data), 'completion length:', data.completion?.length);

      let parsed: ScoutResult | null = null;

      // Try schema_data first if present
      if (data.schema_data && typeof data.schema_data === 'object' && Array.isArray(data.schema_data.opportunities) && data.schema_data.opportunities.length > 0) {
        const raw = data.schema_data;
        parsed = {
          executiveSummary: {
            count: raw.executiveSummary?.count || raw.opportunities?.length || 0,
            themes: Array.isArray(raw.executiveSummary?.themes) ? raw.executiveSummary.themes : [],
            directionComment: raw.executiveSummary?.directionComment || '',
          },
          opportunities: raw.opportunities.map((o: any) => ({
            title: o.title || 'Untitled',
            type: o.type || 'other',
            geography: o.geography || '',
            target: o.target || '',
            whyExists: o.whyExists || o.why_exists || '',
            evidence: o.evidence || '',
            fitReason: o.fitReason || o.fit_reason || '',
            relevance: o.relevance || 'Medium',
            timing: o.timing || 'Near-term',
            confidence: o.confidence || 'Medium',
            netNew: o.netNew || o.net_new || 'Net-new',
            nextMove: o.nextMove || o.next_move || '',
            sources: Array.isArray(o.sources) ? o.sources : [],
          })),
          excluded: Array.isArray(raw.excluded) ? raw.excluded : [],
          ranking: Array.isArray(raw.ranking) ? raw.ranking : [],
        };
      }

      // Parse from completion text
      if (!parsed) {
        const text = data.completion || '';
        if (text) {
          try {
            const cleaned = (typeof text === 'string' ? text : JSON.stringify(text))
              .replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
            const raw = JSON.parse(cleaned);
            parsed = {
              executiveSummary: {
                count: raw.executiveSummary?.count || raw.opportunities?.length || 0,
                themes: Array.isArray(raw.executiveSummary?.themes) ? raw.executiveSummary.themes : [],
                directionComment: raw.executiveSummary?.directionComment || '',
              },
              opportunities: Array.isArray(raw.opportunities) ? raw.opportunities.map((o: any) => ({
                title: o.title || 'Untitled',
                type: o.type || 'other',
                geography: o.geography || '',
                target: o.target || '',
                whyExists: o.whyExists || o.why_exists || '',
                evidence: o.evidence || '',
                fitReason: o.fitReason || o.fit_reason || '',
                relevance: o.relevance || 'Medium',
                timing: o.timing || 'Near-term',
                confidence: o.confidence || 'Medium',
                netNew: o.netNew || o.net_new || 'Net-new',
                nextMove: o.nextMove || o.next_move || '',
                sources: Array.isArray(o.sources) ? o.sources : [],
              })) : [],
              excluded: Array.isArray(raw.excluded) ? raw.excluded : [],
              ranking: Array.isArray(raw.ranking) ? raw.ranking : [],
            };
          } catch {
            console.log('Scout JSON parse failed, trying extraction. Text preview:', text.substring(0, 200));
            // Try extracting JSON from mixed content
            const first = text.indexOf('{');
            const last = text.lastIndexOf('}');
            if (first !== -1 && last > first) {
              try {
                const raw = JSON.parse(text.substring(first, last + 1));
                parsed = {
                  executiveSummary: {
                    count: raw.executiveSummary?.count || raw.opportunities?.length || 0,
                    themes: Array.isArray(raw.executiveSummary?.themes) ? raw.executiveSummary.themes : [],
                    directionComment: raw.executiveSummary?.directionComment || '',
                  },
                  opportunities: Array.isArray(raw.opportunities) ? raw.opportunities.map((o: any) => ({
                    title: o.title || 'Untitled',
                    type: o.type || 'other',
                    geography: o.geography || '',
                    target: o.target || '',
                    whyExists: o.whyExists || o.why_exists || '',
                    evidence: o.evidence || '',
                    fitReason: o.fitReason || o.fit_reason || '',
                    relevance: o.relevance || 'Medium',
                    timing: o.timing || 'Near-term',
                    confidence: o.confidence || 'Medium',
                    netNew: o.netNew || o.net_new || 'Net-new',
                    nextMove: o.nextMove || o.next_move || '',
                    sources: Array.isArray(o.sources) ? o.sources : [],
                  })) : [],
                  excluded: Array.isArray(raw.excluded) ? raw.excluded : [],
                  ranking: Array.isArray(raw.ranking) ? raw.ranking : [],
                };
              } catch {
                console.log('Scout extraction also failed');
              }
            }
          }
        } else {
          console.log('Scout: No completion text in response');
        }
      }

      if (parsed && parsed.opportunities.length > 0) {
        // Filter out "Already covered"
        parsed.opportunities = parsed.opportunities.filter(
          (o) => o.netNew !== 'Already covered'
        );
        setResult(parsed);
      } else {
        Alert.alert('No Opportunities Found', 'The scout could not identify net-new opportunities for this company. Try broadening the geography or adjusting your company profile.');
      }
    } catch (err: any) {
      console.log('Scout error:', err?.message || err);
      if (err.name === 'AbortError') {
        Alert.alert('Timeout', 'The analysis took too long. Please try again.');
      } else {
        Alert.alert('Scout Failed', 'Could not complete the opportunity scan. Please try again.');
      }
    } finally {
      setScouting(false);
      setScoutPhase('idle');
    }
  }, [targetCompanyId, targetCompany, orgSettings, opportunities, companyDetail, customGeo, geoScope, savedZones, scoutIntel]);

  const toggleOpp = (index: number) => {
    setSelectedOpps((prev: Set<number>) => {
      const next = new Set(prev);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  };

  const handleAddSelected = async () => {
    if (!result || selectedOpps.size === 0 || !targetCompanyId) return;
    setAddingOpps(true);
    try {
      const indices = (Array.from(selectedOpps) as number[]).sort((a, b) => a - b);
      let added = 0;
      for (const idx of indices) {
        const opp = result.opportunities[idx as number];
        if (!opp) continue;
        await createOpp({
          title: opp.title,
          companyId: targetCompanyId as any,
          status: 'early_planning',
          notes: [
            `Type: ${opp.type}`,
            opp.geography && `Geography: ${opp.geography}`,
            opp.target && `Target: ${opp.target}`,
            `\nWhy this exists:\n${opp.whyExists}`,
            `\nEvidence:\n${opp.evidence}`,
            `\nFit reason:\n${opp.fitReason}`,
            `\nNext move:\n${opp.nextMove}`,
            opp.sources.length > 0 && `\nSources: ${opp.sources.join('; ')}`,
          ].filter(Boolean).join('\n'),
        });
        added++;
      }
      Alert.alert('Added', `${added} opportunit${added === 1 ? 'y' : 'ies'} added to your tracking list as Early Planning.`);
      // Remove added items from selection
      setSelectedOpps(new Set());
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to add opportunities.');
    } finally {
      setAddingOpps(false);
    }
  };

  const selectAll = () => {
    if (!result) return;
    if (selectedOpps.size === result.opportunities.length) {
      setSelectedOpps(new Set());
    } else {
      setSelectedOpps(new Set(result.opportunities.map((_: ScoutOpportunity, i: number) => i)));
    }
  };

  return (
    <View style={s.panel}>
      <TouchableOpacity
        style={s.panelHeader}
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <View style={s.panelHeaderLeft}>
          <View style={s.scoutIconWrap}>
            <Ionicons name="compass" size={16} color={colors.white} />
          </View>
          <View>
            <Text style={s.panelTitle}>Opportunity Scout AI</Text>
            <Text style={s.panelSubtitle}>Find net-new opportunities by target company</Text>
          </View>
        </View>
        <Ionicons
          name={expanded ? 'chevron-up' : 'chevron-down'}
          size={20}
          color={colors.textTertiary}
        />
      </TouchableOpacity>

      {expanded && (
        <View style={s.panelBody}>
          {!hasProfile ? (
            <View style={s.profilePrompt}>
              <Ionicons name="information-circle" size={16} color={colors.info} />
              <Text style={s.profilePromptText}>
                Set up your company profile in Settings to enable the Opportunity Scout.
              </Text>
            </View>
          ) : (
            <>
              {/* Target Company - Vertical Carousel */}
              <Text style={s.label}>Target Company</Text>
              {targetCompany && (
                <View style={s.selectedBanner}>
                  <Ionicons name="business" size={14} color={colors.primary} />
                  <Text style={s.selectedBannerText} numberOfLines={1}>
                    {(targetCompany as any).name}
                  </Text>
                  <TouchableOpacity onPress={() => { setTargetCompanyId(null); setResult(null); setSelectedOpps(new Set()); }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                </View>
              )}
              <View style={s.carouselContainer}>
                {!companies || companies.length === 0 ? (
                  <Text style={s.emptyText}>No companies found. Add companies first.</Text>
                ) : (
                  <FlatList
                    data={companies}
                    keyExtractor={(item: any) => item._id}
                    renderItem={({ item }: { item: any }) => {
                      const isSelected = targetCompanyId === item._id;
                      return (
                        <TouchableOpacity
                          style={[s.carouselCard, isSelected && s.carouselCardSelected]}
                          onPress={() => {
                            setTargetCompanyId(item._id);
                            setResult(null);
                            setSelectedOpps(new Set());
                          }}
                          activeOpacity={0.7}
                        >
                          <View style={[s.carouselDot, isSelected && s.carouselDotSelected]}>
                            <Text style={[s.carouselInitial, isSelected && s.carouselInitialSelected]}>
                              {item.name[0]}
                            </Text>
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={[s.carouselName, isSelected && s.carouselNameSelected]} numberOfLines={1}>
                              {item.name}
                            </Text>
                            {item.segmentPath && (
                              <Text style={s.carouselMeta} numberOfLines={1}>{item.segmentPath}</Text>
                            )}
                          </View>
                          {isSelected && (
                            <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
                          )}
                        </TouchableOpacity>
                      );
                    }}
                    showsVerticalScrollIndicator
                    nestedScrollEnabled
                    snapToInterval={CARD_HEIGHT}
                    decelerationRate="fast"
                    contentContainerStyle={{ paddingVertical: 2 }}
                  />
                )}
              </View>

              {/* Geography */}
              <Text style={[s.label, { marginTop: spacing.sm }]}>Geography Scope</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 6 }}>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  <TouchableOpacity
                    style={[s.geoChip, !geoScope && !customGeo && s.geoChipActive]}
                    onPress={() => { setGeoScope(''); setCustomGeo(''); }}
                  >
                    <Text style={[s.geoChipText, !geoScope && !customGeo && s.geoChipTextActive]}>
                      {savedZones.length > 0 ? 'All saved zones' : 'Global'}
                    </Text>
                  </TouchableOpacity>
                  {savedZones.map((z: GeoZone, i: number) => {
                    const label = formatZone(z);
                    const isActive = geoScope === label;
                    return (
                      <TouchableOpacity
                        key={i}
                        style={[s.geoChip, isActive && s.geoChipActive]}
                        onPress={() => { setGeoScope(isActive ? '' : label); setCustomGeo(''); }}
                      >
                        <Ionicons name="location" size={10} color={isActive ? colors.white : colors.textTertiary} />
                        <Text style={[s.geoChipText, isActive && s.geoChipTextActive]} numberOfLines={1}>{label}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </ScrollView>
              <TextInput
                style={s.geoInput}
                placeholder="Or type a specific geography (e.g. Texas, USA)"
                placeholderTextColor={colors.textTertiary}
                value={customGeo}
                onChangeText={(t: string) => { setCustomGeo(t); if (t) setGeoScope(''); }}
              />

              {/* Scout Button */}
              <TouchableOpacity
                style={[s.scoutBtn, (!targetCompanyId || scouting) && s.scoutBtnDisabled]}
                onPress={handleScout}
                disabled={!targetCompanyId || scouting}
              >
                {scouting ? (
                  <>
                    <ActivityIndicator size="small" color={colors.white} />
                    <Text style={s.scoutBtnText}>Scouting opportunities...</Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="compass" size={16} color={colors.white} />
                    <Text style={s.scoutBtnText}>Scout Opportunities</Text>
                  </>
                )}
              </TouchableOpacity>

              {scouting && (
                <Text style={s.timeEstimate}>
                  {scoutPhase === 'scraping'
                    ? 'Scraping company website & recent news — typically 10-15 seconds...'
                    : 'Analyzing intelligence and identifying opportunities — typically 20-30 seconds...'}
                </Text>
              )}

              {/* Results */}
              {result && (
                <View style={s.resultsSection}>
                  {/* Executive Summary */}
                  <View style={s.summaryCard}>
                    <View style={s.summaryHeader}>
                      <Ionicons name="analytics" size={16} color={colors.accent} />
                      <Text style={s.summaryTitle}>Executive Summary</Text>
                    </View>
                    <Text style={s.summaryCount}>
                      {result.executiveSummary.count} net-new opportunit{result.executiveSummary.count === 1 ? 'y' : 'ies'} identified
                    </Text>
                    {result.executiveSummary.themes.length > 0 && (
                      <View style={s.themesWrap}>
                        {result.executiveSummary.themes.map((theme: string, i: number) => (
                          <View key={i} style={s.themeChip}>
                            <Text style={s.themeText}>{theme}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                    {result.executiveSummary.directionComment ? (
                      <Text style={s.directionText}>{result.executiveSummary.directionComment}</Text>
                    ) : null}
                  </View>

                  {/* Priority Ranking */}
                  {result.ranking.length > 0 && (
                    <View style={s.rankingCard}>
                      <Text style={s.sectionLabel}>Priority Ranking</Text>
                      {result.ranking.map((r: { title: string; reason: string }, i: number) => (
                        <View key={i} style={s.rankItem}>
                          <View style={s.rankNumber}>
                            <Text style={s.rankNumberText}>{i + 1}</Text>
                          </View>
                          <View style={{ flex: 1 }}>
                            <Text style={s.rankTitle}>{r.title}</Text>
                            <Text style={s.rankReason}>{r.reason}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Opportunity Cards */}
                  <View style={s.oppListHeader}>
                    <Text style={s.sectionLabel}>
                      Opportunities ({result.opportunities.length})
                    </Text>
                    <TouchableOpacity onPress={selectAll} style={s.selectAllBtn}>
                      <Ionicons
                        name={selectedOpps.size === result.opportunities.length ? 'checkbox' : 'square-outline'}
                        size={18}
                        color={colors.primary}
                      />
                      <Text style={s.selectAllText}>
                        {selectedOpps.size === result.opportunities.length ? 'Deselect' : 'Select All'}
                      </Text>
                    </TouchableOpacity>
                  </View>

                  {result.opportunities.map((opp: ScoutOpportunity, idx: number) => {
                    const isSelected = selectedOpps.has(idx);
                    return (
                      <View key={idx} style={[s.oppCard, isSelected && s.oppCardSelected]}>
                        <TouchableOpacity style={s.oppCheckArea} onPress={() => toggleOpp(idx)}>
                          <Ionicons
                            name={isSelected ? 'checkbox' : 'square-outline'}
                            size={22}
                            color={isSelected ? colors.primary : colors.textTertiary}
                          />
                        </TouchableOpacity>
                        <View style={s.oppBody}>
                          <Text style={s.oppTitle}>{opp.title}</Text>

                          {/* Badges row */}
                          <View style={s.badgeRow}>
                            <View style={[s.badge, { backgroundColor: RELEVANCE_COLOR[opp.relevance] || '#94A3B8' }]}>
                              <Text style={s.badgeText}>{opp.relevance}</Text>
                            </View>
                            <View style={[s.badge, { backgroundColor: TIMING_COLOR[opp.timing] || '#94A3B8' }]}>
                              <Text style={s.badgeText}>{opp.timing}</Text>
                            </View>
                            <View style={[s.badge, { backgroundColor: CONFIDENCE_COLOR[opp.confidence] || '#94A3B8' }]}>
                              <Text style={s.badgeText}>{opp.confidence} conf.</Text>
                            </View>
                            {opp.netNew === 'Adjacent' && (
                              <View style={[s.badge, { backgroundColor: '#8B5CF6' }]}>
                                <Text style={s.badgeText}>Adjacent</Text>
                              </View>
                            )}
                          </View>

                          {/* Type & Geography */}
                          <View style={s.metaRow}>
                            <Ionicons name="pricetag-outline" size={11} color={colors.textTertiary} />
                            <Text style={s.metaText}>{opp.type}</Text>
                            {opp.geography ? (
                              <>
                                <Text style={s.metaDot}>·</Text>
                                <Ionicons name="location-outline" size={11} color={colors.textTertiary} />
                                <Text style={s.metaText}>{opp.geography}</Text>
                              </>
                            ) : null}
                          </View>

                          {opp.target ? (
                            <View style={s.metaRow}>
                              <Ionicons name="flag-outline" size={11} color={colors.textTertiary} />
                              <Text style={s.metaText}>{opp.target}</Text>
                            </View>
                          ) : null}

                          {/* Why it exists */}
                          <Text style={s.fieldLabel}>Why this exists</Text>
                          <Text style={s.fieldText}>{opp.whyExists}</Text>

                          {/* Evidence */}
                          <View style={s.evidenceWrap}>
                            <Ionicons name="document-text-outline" size={12} color={colors.accent} />
                            <Text style={s.evidenceText}>{opp.evidence}</Text>
                          </View>

                          {/* Fit reason */}
                          <View style={s.fitWrap}>
                            <Ionicons name="bulb-outline" size={12} color={colors.success} />
                            <Text style={s.fitText}>{opp.fitReason}</Text>
                          </View>

                          {/* Next move */}
                          <View style={s.nextMoveWrap}>
                            <Ionicons name="arrow-forward-circle-outline" size={12} color={colors.primary} />
                            <Text style={s.nextMoveText}>{opp.nextMove}</Text>
                          </View>

                          {/* Sources */}
                          {opp.sources.length > 0 && (
                            <Text style={s.sourcesText}>
                              Sources: {opp.sources.join('; ')}
                            </Text>
                          )}
                        </View>
                      </View>
                    );
                  })}

                  {/* Add Selected Button */}
                  {selectedOpps.size > 0 && (
                    <TouchableOpacity
                      style={[s.addSelectedBtn, addingOpps && { opacity: 0.6 }]}
                      onPress={handleAddSelected}
                      disabled={addingOpps}
                    >
                      {addingOpps ? (
                        <ActivityIndicator size="small" color={colors.white} />
                      ) : (
                        <Ionicons name="add-circle" size={18} color={colors.white} />
                      )}
                      <Text style={s.addSelectedText}>
                        {addingOpps
                          ? 'Adding...'
                          : `Add ${selectedOpps.size} to Tracking List`}
                      </Text>
                    </TouchableOpacity>
                  )}

                  {/* Excluded items */}
                  {result.excluded.length > 0 && (
                    <View style={{ marginTop: spacing.md }}>
                      <TouchableOpacity
                        style={s.excludedToggle}
                        onPress={() => setShowExcluded(!showExcluded)}
                      >
                        <Ionicons name={showExcluded ? 'chevron-down' : 'chevron-forward'} size={14} color={colors.textTertiary} />
                        <Text style={s.excludedToggleText}>
                          {result.excluded.length} opportunit{result.excluded.length === 1 ? 'y' : 'ies'} excluded
                        </Text>
                      </TouchableOpacity>
                      {showExcluded && result.excluded.map((ex: { title: string; reason: string }, i: number) => (
                        <View key={i} style={s.excludedItem}>
                          <Text style={s.excludedTitle}>{ex.title}</Text>
                          <Text style={s.excludedReason}>{ex.reason}</Text>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* Action prompt */}
                  <View style={s.actionPrompt}>
                    <Text style={s.actionPromptText}>
                      Which of these net-new opportunities should be added to the tracking list?
                    </Text>
                    <Text style={s.actionPromptHint}>
                      Select opportunities above and tap "Add to Tracking List" to create them as Early Planning entries.
                    </Text>
                  </View>
                </View>
              )}
            </>
          )}
        </View>
      )}
    </View>
  );
}

const s = StyleSheet.create({
  panel: {
    backgroundColor: colors.white,
    borderRadius: radius.lg,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.primary + '30',
    ...shadow.sm,
    overflow: 'hidden',
  },
  panelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: spacing.md,
  },
  panelHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flex: 1,
  },
  scoutIconWrap: {
    width: 32,
    height: 32,
    borderRadius: radius.md,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  panelTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  panelSubtitle: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
    marginTop: 1,
  },
  panelBody: {
    paddingHorizontal: spacing.md,
    paddingBottom: spacing.md,
    borderTopWidth: 1,
    borderTopColor: colors.border,
    paddingTop: spacing.md,
  },
  profilePrompt: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: colors.infoLight,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  profilePromptText: {
    flex: 1,
    fontSize: fontSize.sm,
    color: colors.info,
  },
  label: {
    fontSize: fontSize.xs,
    fontWeight: '600',
    color: colors.textSecondary,
    marginBottom: spacing.xs,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  // Company carousel styles
  selectedBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primaryLight,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    marginBottom: spacing.sm,
  },
  selectedBannerText: {
    flex: 1,
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.primary,
  },
  carouselContainer: {
    height: CAROUSEL_HEIGHT,
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  carouselCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    height: CARD_HEIGHT,
    paddingHorizontal: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.borderLight,
    backgroundColor: colors.white,
  },
  carouselCardSelected: {
    backgroundColor: colors.primaryLight,
  },
  carouselDot: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: colors.primary + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carouselDotSelected: {
    backgroundColor: colors.primary,
  },
  carouselInitial: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.primary,
  },
  carouselInitialSelected: {
    color: colors.white,
  },
  carouselName: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  carouselNameSelected: {
    color: colors.primary,
    fontWeight: '700',
  },
  carouselMeta: {
    fontSize: 10,
    color: colors.textTertiary,
    marginTop: 1,
  },
  emptyText: {
    fontSize: fontSize.sm,
    color: colors.textTertiary,
    textAlign: 'center',
    paddingVertical: spacing.lg,
  },
  geoChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.white,
  },
  geoChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  geoChipText: { fontSize: 11, color: colors.textSecondary },
  geoChipTextActive: { color: colors.white, fontWeight: '600' },
  geoInput: {
    backgroundColor: colors.white,
    borderWidth: 1,
    borderColor: colors.borderLight,
    borderRadius: radius.sm,
    paddingHorizontal: 10,
    paddingVertical: 7,
    fontSize: 12,
    color: colors.textPrimary,
    marginBottom: spacing.xs,
  },
  scoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.primary,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    marginTop: spacing.xs,
  },
  scoutBtnDisabled: { opacity: 0.5 },
  scoutBtnText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: fontSize.md,
  },
  timeEstimate: {
    fontSize: fontSize.xs,
    color: colors.primary,
    textAlign: 'center',
    marginTop: spacing.sm,
    fontStyle: 'italic',
  },

  // Results
  resultsSection: {
    marginTop: spacing.lg,
  },
  summaryCard: {
    backgroundColor: colors.bg,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  summaryTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
  },
  summaryCount: {
    fontSize: fontSize.md,
    fontWeight: '700',
    color: colors.accent,
    marginBottom: spacing.sm,
  },
  themesWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: spacing.sm,
  },
  themeChip: {
    backgroundColor: colors.accentLight,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  themeText: {
    fontSize: 10,
    fontWeight: '600',
    color: colors.accent,
  },
  directionText: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    lineHeight: 16,
    fontStyle: 'italic',
  },
  rankingCard: {
    marginBottom: spacing.md,
  },
  sectionLabel: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: spacing.sm,
  },
  rankItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    marginBottom: spacing.sm,
  },
  rankNumber: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rankNumberText: {
    fontSize: 11,
    fontWeight: '700',
    color: colors.white,
  },
  rankTitle: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  rankReason: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    marginTop: 2,
    lineHeight: 16,
  },
  oppListHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  selectAllBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  selectAllText: {
    fontSize: fontSize.xs,
    color: colors.primary,
    fontWeight: '600',
  },
  oppCard: {
    flexDirection: 'row',
    backgroundColor: colors.bg,
    borderRadius: radius.md,
    padding: spacing.sm,
    marginBottom: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  oppCardSelected: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight + '30',
  },
  oppCheckArea: {
    paddingRight: spacing.sm,
    paddingTop: 2,
    justifyContent: 'flex-start',
  },
  oppBody: {
    flex: 1,
  },
  oppTitle: {
    fontSize: fontSize.sm,
    fontWeight: '700',
    color: colors.textPrimary,
    marginBottom: 4,
  },
  badgeRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 4,
    marginBottom: 6,
  },
  badge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '600',
    color: colors.white,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    marginBottom: 3,
  },
  metaText: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  metaDot: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  fieldLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: colors.textSecondary,
    marginTop: spacing.xs,
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.3,
  },
  fieldText: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    lineHeight: 16,
  },
  evidenceWrap: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 4,
    backgroundColor: colors.accentLight,
    padding: spacing.xs,
    borderRadius: radius.sm,
    marginTop: spacing.xs,
  },
  evidenceText: {
    flex: 1,
    fontSize: 10,
    color: colors.accent,
    fontWeight: '500',
    lineHeight: 14,
  },
  fitWrap: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 4,
    backgroundColor: colors.successLight,
    padding: spacing.xs,
    borderRadius: radius.sm,
    marginTop: spacing.xs,
  },
  fitText: {
    flex: 1,
    fontSize: 10,
    color: colors.success,
    fontWeight: '500',
    lineHeight: 14,
  },
  nextMoveWrap: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 4,
    backgroundColor: colors.primaryLight,
    padding: spacing.xs,
    borderRadius: radius.sm,
    marginTop: spacing.xs,
  },
  nextMoveText: {
    flex: 1,
    fontSize: 10,
    color: colors.primary,
    fontWeight: '500',
    lineHeight: 14,
  },
  sourcesText: {
    fontSize: 9,
    color: colors.textTertiary,
    marginTop: spacing.xs,
    fontStyle: 'italic',
  },
  addSelectedBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    backgroundColor: colors.success,
    paddingVertical: spacing.md,
    borderRadius: radius.md,
    marginTop: spacing.sm,
  },
  addSelectedText: {
    color: colors.white,
    fontWeight: '700',
    fontSize: fontSize.md,
  },
  excludedToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: spacing.xs,
  },
  excludedToggleText: {
    fontSize: fontSize.xs,
    color: colors.textTertiary,
    fontWeight: '500',
  },
  excludedItem: {
    paddingLeft: spacing.lg,
    paddingVertical: spacing.xs,
    borderLeftWidth: 2,
    borderLeftColor: colors.borderLight,
    marginBottom: spacing.xs,
  },
  excludedTitle: {
    fontSize: fontSize.xs,
    fontWeight: '600',
    color: colors.textSecondary,
  },
  excludedReason: {
    fontSize: 10,
    color: colors.textTertiary,
  },
  actionPrompt: {
    marginTop: spacing.md,
    backgroundColor: colors.primaryLight,
    padding: spacing.md,
    borderRadius: radius.md,
  },
  actionPromptText: {
    fontSize: fontSize.sm,
    fontWeight: '600',
    color: colors.textPrimary,
  },
  actionPromptHint: {
    fontSize: fontSize.xs,
    color: colors.textSecondary,
    marginTop: spacing.xs,
  },
});