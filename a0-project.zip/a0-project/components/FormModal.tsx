import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView,
  KeyboardAvoidingView, Platform, Modal,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

export interface FormField {
  key: string;
  label: string;
  placeholder?: string;
  type?: 'text' | 'number' | 'multiline';
  required?: boolean;
  action?: {
    icon: string;
    label: string;
    onPress: (values: Record<string, string>) => void;
  };
}

interface Props {
  visible: boolean;
  title: string;
  fields: FormField[];
  initialValues?: Record<string, string>;
  onSubmit: (values: Record<string, string>) => void;
  onClose: () => void;
  submitLabel?: string;
  renderExtra?: () => React.ReactNode;
}

export default function FormModal({ visible, title, fields, initialValues, onSubmit, onClose, submitLabel, renderExtra }: Props) {
  const [values, setValues] = useState<Record<string, string>>(initialValues || {});

  useEffect(() => {
    if (visible) {
      setValues(initialValues || {});
    }
  }, [visible]);

  const handleSubmit = () => {
    for (const f of fields) {
      if (f.required && !values[f.key]?.trim()) return;
    }
    onSubmit(values);
    setValues({});
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={24} color={colors.textSecondary} />
          </TouchableOpacity>
          <Text style={styles.title}>{title}</Text>
          <TouchableOpacity onPress={handleSubmit} style={styles.submitBtn}>
            <Text style={styles.submitText}>{submitLabel || 'Save'}</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={styles.body} keyboardShouldPersistTaps="handled">
          {fields.map((f) => (
            <View key={f.key} style={styles.field}>
              <Text style={styles.label}>
                {f.label}{f.required ? ' *' : ''}
              </Text>
              <View style={f.action ? styles.inputRow : undefined}>
                <TextInput
                  style={[
                    styles.input,
                    f.type === 'multiline' && styles.multiline,
                    f.action && { flex: 1 },
                  ]}
                  placeholder={f.placeholder || f.label}
                  placeholderTextColor={colors.textTertiary}
                  value={values[f.key] || ''}
                  onChangeText={(text) => setValues({ ...values, [f.key]: text })}
                  keyboardType={f.type === 'number' ? 'numeric' : 'default'}
                  multiline={f.type === 'multiline'}
                  numberOfLines={f.type === 'multiline' ? 4 : 1}
                  autoCapitalize="none"
                />
                {f.action && (
                  <TouchableOpacity
                    style={styles.fieldAction}
                    onPress={() => f.action!.onPress(values)}
                  >
                    <Ionicons name={f.action.icon as any} size={16} color={colors.white} />
                    <Text style={styles.fieldActionText}>{f.action.label}</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          ))}
          {renderExtra && renderExtra()}
          <View style={{ height: 40 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  title: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  submitBtn: { backgroundColor: colors.primary, paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, borderRadius: radius.md },
  submitText: { color: colors.white, fontWeight: '600', fontSize: fontSize.md },
  body: { flex: 1, padding: spacing.lg },
  field: { marginBottom: spacing.lg },
  label: { fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary, marginBottom: spacing.xs },
  input: {
    backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border,
    borderRadius: radius.md, padding: spacing.md, fontSize: fontSize.md, color: colors.textPrimary,
    ...shadow.sm,
  },
  multiline: { height: 100, textAlignVertical: 'top' },
  inputRow: {
    flexDirection: 'row' as const,
    alignItems: 'flex-start' as const,
    gap: 8,
  },
  fieldAction: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 4,
    backgroundColor: '#0A66C2',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: radius.md,
    marginTop: 0,
  },
  fieldActionText: {
    fontSize: fontSize.xs,
    fontWeight: '600' as const,
    color: '#fff',
  },
});