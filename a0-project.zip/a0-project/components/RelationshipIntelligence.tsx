import React, { useState, useMemo, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, ScrollView, StyleSheet, Alert,
  ActivityIndicator, Modal, Dimensions,
} from 'react-native';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { Ionicons } from '@expo/vector-icons';
import Svg, { Circle, Line, Rect } from 'react-native-svg';
// @ts-ignore - Text is available at runtime
const SvgText = require('react-native-svg').Text;
import { colors, spacing, radius, fontSize as fs } from '../lib/theme';
import type { Id } from '../convex/_generated/dataModel';

// ── Types ────────────────────────────────────────────────────────
interface Assessment {
  _id: Id<"relationshipIntelligence">;
  contactId: Id<"contacts">;
  contactName: string;
  contactTitle?: string;
  contactCompany?: string;
  stance: number;
  role: string;
  roleConfidence?: string;
  influence: number;
  confidence: string;
  relationshipStrength: string;
  aiReasoning?: string;
  signals?: string;
  risks?: string;
  opportunities?: string;
  nextMoveTitle?: string;
  nextMoveDetails?: string;
  nextMovePriority?: string;
  nextMoveDeadline?: string;
  isUserOverride?: boolean;
  lastAnalyzedAt?: number;
}

interface Props {
  opportunityId: Id<"opportunities">;
  opportunity: {
    title: string;
    status: string;
    value?: number;
    probability?: number;
    closeDate?: number;
    notes?: string;
    companyId?: Id<"companies">;
    contactId?: Id<"contacts">;
  };
  company?: { name: string; domain?: string; industry?: string; size?: string; insightsReport?: string } | null;
  orgSettings?: { companyName: string; interests: string; taxonomyProfile?: string } | null;
}

// ── Helpers ──────────────────────────────────────────────────────
const STANCE_LABELS: Record<number, string> = { [-2]: 'Opposed', [-1]: 'Skeptical', 0: 'Neutral', 1: 'Supportive', 2: 'Champion' };
const INFLUENCE_LABELS: Record<number, string> = { 1: 'Low', 2: 'Medium', 3: 'High' };

function impactColor(score: number): string {
  if (score >= 4) return '#16a34a';
  if (score >= 1) return '#65a30d';
  if (score === 0) return '#9ca3af';
  if (score >= -3) return '#f59e0b';
  return '#ef4444';
}

function stanceColor(stance: number): string {
  if (stance === 2) return '#16a34a';
  if (stance === 1) return '#65a30d';
  if (stance === 0) return '#9ca3af';
  if (stance === -1) return '#f59e0b';
  return '#ef4444';
}

function strengthColor(s: string): string {
  if (s === 'Strong') return '#16a34a';
  if (s === 'Medium') return '#f59e0b';
  return '#ef4444';
}

function safeStr(v: any): string {
  if (typeof v === 'string') return v;
  if (v == null) return '';
  return JSON.stringify(v);
}

// ── AI Prompt ────────────────────────────────────────────────────
const SYSTEM_PROMPT = `You are a Relationship Intelligence Analyst for B2B business development.

Your task is to assess one contact involved in one opportunity.

Using the provided CRM context, interaction history, company context, and deal stage, classify this person across these dimensions:
- stance: Opposed(-2) / Skeptical(-1) / Neutral(0) / Supportive(+1) / Champion(+2)
- role: Decision Maker / Economic Buyer / Technical Evaluator / Operational Owner / Influencer / Gatekeeper / Blocker
- influence: Low(1) / Medium(2) / High(3)
- relationshipStrength: Weak / Medium / Strong
- confidence: Low / Medium / High

Rules:
- Base conclusions on behavior and evidence, not title alone
- Use interaction history as primary evidence
- Infer role from both job title and behavior
- Keep reasoning brief and concrete
- Recommend one next relationship move
- Flag risks if this person could materially harm the deal
- Flag opportunities if this person could become a stronger ally

Return ONLY valid JSON matching this exact structure:
{
  "stance": { "value": 0, "label": "Neutral" },
  "role": { "value": "Influencer", "confidence": "Medium" },
  "influence": { "value": 2, "label": "Medium" },
  "confidence": "Medium",
  "relationshipStrength": "Weak",
  "aiReasoning": "...",
  "signals": ["signal 1", "signal 2"],
  "risks": [{ "type": "...", "severity": "High", "details": "..." }],
  "opportunities": [{ "type": "...", "details": "..." }],
  "nextRelationshipMove": { "title": "Max 8 words", "details": "...", "priority": "High", "suggestedDeadline": "YYYY-MM-DD" }
}`;

// ── Component ────────────────────────────────────────────────────
export default function RelationshipIntelligence({ opportunityId, opportunity, company, orgSettings }: Props) {
  const assessments = useQuery(api.relationshipIntelligence.listByOpportunity, { opportunityId }) ?? [];
  const availableContacts = useQuery(api.relationshipIntelligence.getAvailableContacts, { opportunityId }) ?? [];
  const saveAssessment = useMutation(api.relationshipIntelligence.save);
  const removeAssessment = useMutation(api.relationshipIntelligence.remove);

  const [expanded, setExpanded] = useState(false);
  const [analyzingId, setAnalyzingId] = useState<string | null>(null); // contactId being analyzed
  const [analyzingAll, setAnalyzingAll] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [showAddContact, setShowAddContact] = useState(false);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [showOverride, setShowOverride] = useState<string | null>(null);
  const [overrideValues, setOverrideValues] = useState({ stance: 0, influence: 2, role: 'Influencer', relationshipStrength: 'Medium' });

  // ── Deal-level summary ──
  const dealSummary = useMemo(() => {
    if (assessments.length === 0) return null;
    const allies = assessments.filter(a => a.stance >= 1 && a.influence >= 2);
    const risks = assessments.filter(a => a.stance <= -1 && a.influence >= 2);
    const hasChampion = assessments.some(a => a.influence >= 2 && a.stance >= 1);
    const activeCount = assessments.filter(a => a.lastAnalyzedAt && Date.now() - a.lastAnalyzedAt < 30 * 24 * 60 * 60 * 1000).length;
    const staleHigh = assessments.filter(a => a.influence >= 2 && (!a.lastAnalyzedAt || Date.now() - a.lastAnalyzedAt > 30 * 24 * 60 * 60 * 1000));
    const avgImpact = assessments.reduce((sum, a) => sum + a.stance * a.influence, 0) / assessments.length;
    const warnings: string[] = [];
    if (!hasChampion) warnings.push('No strong champion identified');
    if (assessments.length === 1) warnings.push('Single-threaded opportunity');
    if (staleHigh.length > 0) warnings.push(`${staleHigh.length} high-influence stakeholder(s) stale >30 days`);
    risks.forEach(r => warnings.push(`High-risk: ${r.contactName} (${STANCE_LABELS[r.stance]}, influence ${INFLUENCE_LABELS[r.influence]})`));
    const score = Math.max(1, Math.min(10, Math.round(5 + avgImpact * 1.5 + (hasChampion ? 1 : -1) + (risks.length > 0 ? -1 : 0))));
    return { score, allies: allies.length, risks: risks.length, active: activeCount, warnings, total: assessments.length };
  }, [assessments]);

  // ── Analyze single contact ──
  const analyzeContact = useCallback(async (contactId: Id<"contacts">, contactName: string, contactTitle?: string) => {
    setAnalyzingId(contactId);
    try {
      // Build context for this contact
      const context = {
        opportunity: { title: opportunity.title, status: opportunity.status, value: opportunity.value, probability: opportunity.probability, closeDate: opportunity.closeDate ? new Date(opportunity.closeDate).toISOString() : undefined, notes: opportunity.notes?.substring(0, 500) },
        company: company ? { name: company.name, industry: company.industry, size: company.size, notes: (company as any).notes?.slice(0, 200), insightsReport: company.insightsReport?.substring(0, 1500) } : undefined,
        contact: { name: contactName, title: contactTitle },
        orgContext: orgSettings ? { companyName: orgSettings.companyName, interests: orgSettings.interests } : undefined,
      };

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 90000);
      const res = await fetch('https://api.a0.dev/ai/llm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: SYSTEM_PROMPT },
            { role: 'user', content: `Analyze this contact for this opportunity. Return ONLY valid JSON.\n\n${JSON.stringify(context, null, 2)}` },
          ],
        }),
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (!res.ok) throw new Error(`API error: ${res.status}`);
      const data = await res.json();
      const raw = data.schema_data || data.completion;
      if (!raw) throw new Error('Empty response');

      let parsed: any;
      if (typeof raw === 'object') {
        parsed = raw;
      } else {
        const cleaned = raw.replace(/```json?\s*\n?/gi, '').replace(/```\s*$/gm, '').trim();
        parsed = JSON.parse(cleaned);
      }

      // Normalize and save
      await saveAssessment({
        opportunityId,
        contactId,
        stance: Number(parsed.stance?.value ?? 0),
        role: safeStr(parsed.role?.value || 'Influencer'),
        roleConfidence: safeStr(parsed.role?.confidence || parsed.confidence || 'Medium'),
        influence: Number(parsed.influence?.value ?? 2),
        confidence: safeStr(parsed.confidence || 'Medium'),
        relationshipStrength: safeStr(parsed.relationshipStrength || 'Medium'),
        aiReasoning: safeStr(parsed.aiReasoning),
        signals: JSON.stringify(Array.isArray(parsed.signals) ? parsed.signals.map(safeStr) : []),
        risks: JSON.stringify(Array.isArray(parsed.risks) ? parsed.risks : []),
        opportunities: JSON.stringify(Array.isArray(parsed.opportunities) ? parsed.opportunities : []),
        nextMoveTitle: safeStr(parsed.nextRelationshipMove?.title),
        nextMoveDetails: safeStr(parsed.nextRelationshipMove?.details),
        nextMovePriority: safeStr(parsed.nextRelationshipMove?.priority || 'Medium'),
        nextMoveDeadline: safeStr(parsed.nextRelationshipMove?.suggestedDeadline),
        isUserOverride: false,
      });
    } catch (err: any) {
      console.warn('Relationship analysis failed:', err?.message);
      Alert.alert('Analysis Failed', 'Could not analyze this contact. Please try again.');
    } finally {
      setAnalyzingId(null);
    }
  }, [opportunityId, opportunity, company, orgSettings, saveAssessment]);

  // ── Analyze all contacts ──
  const analyzeAll = useCallback(async () => {
    setAnalyzingAll(true);
    for (const a of assessments) {
      await analyzeContact(a.contactId, a.contactName, a.contactTitle);
    }
    setAnalyzingAll(false);
  }, [assessments, analyzeContact]);

  // ── Add contact ──
  const handleAddContact = useCallback(async (contactId: Id<"contacts">, name: string, title?: string) => {
    setShowAddContact(false);
    // Create a placeholder assessment then analyze
    await saveAssessment({
      opportunityId,
      contactId,
      stance: 0,
      role: 'Influencer',
      influence: 2,
      confidence: 'Low',
      relationshipStrength: 'Weak',
    });
    // Auto-analyze immediately
    await analyzeContact(contactId, name, title);
  }, [opportunityId, saveAssessment, analyzeContact]);

  // ── Manual override save ──
  const handleSaveOverride = useCallback(async (assessment: Assessment) => {
    await saveAssessment({
      opportunityId,
      contactId: assessment.contactId,
      stance: overrideValues.stance,
      role: overrideValues.role,
      influence: overrideValues.influence,
      confidence: 'High',
      relationshipStrength: overrideValues.relationshipStrength,
      aiReasoning: assessment.aiReasoning,
      signals: assessment.signals,
      risks: assessment.risks,
      opportunities: assessment.opportunities,
      nextMoveTitle: assessment.nextMoveTitle,
      nextMoveDetails: assessment.nextMoveDetails,
      nextMovePriority: assessment.nextMovePriority,
      nextMoveDeadline: assessment.nextMoveDeadline,
      isUserOverride: true,
    });
    setShowOverride(null);
  }, [opportunityId, overrideValues, saveAssessment]);

  // ── Render ─────────────────────────────────────────────────────
  const screenW = Dimensions.get('window').width;
  const mapW = screenW - spacing.lg * 4;
  const mapH = 220;

  return (
    <View style={s.section}>
      {/* Header */}
      <TouchableOpacity style={s.header} onPress={() => setExpanded(!expanded)}>
        <View style={s.headerLeft}>
          <Ionicons name="people" size={20} color={colors.primary} />
          <Text style={s.headerTitle}>Relationship Intelligence</Text>
          {assessments.length > 0 && (
            <View style={[s.badge, { backgroundColor: dealSummary && dealSummary.score >= 6 ? '#16a34a' : dealSummary && dealSummary.score >= 4 ? '#f59e0b' : '#ef4444' }]}>
              <Text style={s.badgeText}>{dealSummary?.score ?? '—'}/10</Text>
            </View>
          )}
        </View>
        <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textSecondary} />
      </TouchableOpacity>

      {expanded && (
        <View style={s.content}>
          {/* Deal Summary */}
          {dealSummary && (
            <View style={s.summaryCard}>
              <View style={s.summaryRow}>
                <View style={s.summaryItem}>
                  <Text style={s.summaryLabel}>Health</Text>
                  <Text style={[s.summaryValue, { color: dealSummary.score >= 6 ? '#16a34a' : dealSummary.score >= 4 ? '#f59e0b' : '#ef4444' }]}>{dealSummary.score}/10</Text>
                </View>
                <View style={s.summaryItem}>
                  <Text style={s.summaryLabel}>Stakeholders</Text>
                  <Text style={s.summaryValue}>{dealSummary.total}</Text>
                </View>
                <View style={s.summaryItem}>
                  <Text style={s.summaryLabel}>Allies</Text>
                  <Text style={[s.summaryValue, { color: '#16a34a' }]}>{dealSummary.allies}</Text>
                </View>
                <View style={s.summaryItem}>
                  <Text style={s.summaryLabel}>At Risk</Text>
                  <Text style={[s.summaryValue, { color: '#ef4444' }]}>{dealSummary.risks}</Text>
                </View>
              </View>
              {dealSummary.warnings.length > 0 && (
                <View style={s.warningsBox}>
                  {dealSummary.warnings.map((w, i) => (
                    <View key={i} style={s.warningRow}>
                      <Ionicons name="warning" size={14} color="#f59e0b" />
                      <Text style={s.warningText}>{w}</Text>
                    </View>
                  ))}
                </View>
              )}
            </View>
          )}

          {/* Action Bar */}
          <View style={s.actionBar}>
            {availableContacts.length > 0 && (
              <TouchableOpacity style={s.actionBtn} onPress={() => setShowAddContact(true)}>
                <Ionicons name="person-add" size={16} color="#fff" />
                <Text style={s.actionBtnText}>Add Contact</Text>
              </TouchableOpacity>
            )}
            {assessments.length > 0 && (
              <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#7c3aed' }]} onPress={analyzeAll} disabled={analyzingAll}>
                {analyzingAll ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name="sparkles" size={16} color="#fff" />}
                <Text style={s.actionBtnText}>{analyzingAll ? 'Analyzing...' : 'Analyze All'}</Text>
              </TouchableOpacity>
            )}
            {assessments.length > 0 && (
              <TouchableOpacity style={[s.actionBtn, { backgroundColor: '#6366f1' }]} onPress={() => setShowMap(!showMap)}>
                <Ionicons name="grid" size={16} color="#fff" />
                <Text style={s.actionBtnText}>Map</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Stakeholder Map */}
          {showMap && assessments.length > 0 && (
            <View style={s.mapContainer}>
              <Text style={s.mapTitle}>Stakeholder Map</Text>
              <Svg width={mapW} height={mapH} viewBox={`0 0 ${mapW} ${mapH}`}>
                {/* Grid */}
                <Rect x={0} y={0} width={mapW} height={mapH} rx={8} fill={colors.card} />
                {/* Grid lines */}
                {[1, 2, 3].map(inf => {
                  const y = mapH - ((inf - 0.5) / 3) * mapH;
                  return <Line key={`h${inf}`} x1={40} y1={y} x2={mapW - 10} y2={y} stroke={colors.border} strokeWidth={0.5} strokeDasharray="4,4" />;
                })}
                {[-2, -1, 0, 1, 2].map(st => {
                  const x = 40 + ((st + 2) / 4) * (mapW - 50);
                  return <Line key={`v${st}`} x1={x} y1={10} x2={x} y2={mapH - 25} stroke={colors.border} strokeWidth={0.5} strokeDasharray="4,4" />;
                })}
                {/* Axis labels */}
                <SvgText x={5} y={mapH - ((3 - 0.5) / 3) * mapH + 4} fontSize={9} fill={colors.textSecondary}>High</SvgText>
                <SvgText x={5} y={mapH - ((2 - 0.5) / 3) * mapH + 4} fontSize={9} fill={colors.textSecondary}>Med</SvgText>
                <SvgText x={5} y={mapH - ((1 - 0.5) / 3) * mapH + 4} fontSize={9} fill={colors.textSecondary}>Low</SvgText>
                {[-2, -1, 0, 1, 2].map(st => (
                  <SvgText key={`xl${st}`} x={40 + ((st + 2) / 4) * (mapW - 50)} y={mapH - 5} fontSize={8} fill={colors.textSecondary} textAnchor="middle">
                    {STANCE_LABELS[st]?.substring(0, 4)}
                  </SvgText>
                ))}
                {/* Contact dots */}
                {assessments.map((a, i) => {
                  const x = 40 + ((a.stance + 2) / 4) * (mapW - 50);
                  const y = mapH - 25 - ((a.influence - 0.5) / 3) * (mapH - 35);
                  const impact = a.stance * a.influence;
                  return (
                    <React.Fragment key={i}>
                      <Circle cx={x} cy={y} r={14} fill={impactColor(impact)} opacity={0.85} onPress={() => setSelectedCard(a.contactId)} />
                      <SvgText x={x} y={y + 3.5} fontSize={8} fill="#fff" textAnchor="middle" fontWeight="bold">
                        {a.contactName.split(' ').map(n => n[0]).join('').substring(0, 2)}
                      </SvgText>
                    </React.Fragment>
                  );
                })}
              </Svg>
            </View>
          )}

          {/* Stakeholder Cards */}
          {assessments.length === 0 ? (
            <View style={s.emptyState}>
              <Ionicons name="people-outline" size={36} color={colors.textSecondary} />
              <Text style={s.emptyText}>No stakeholders assessed yet</Text>
              {availableContacts.length > 0 && (
                <TouchableOpacity style={[s.actionBtn, { marginTop: spacing.sm }]} onPress={() => setShowAddContact(true)}>
                  <Ionicons name="person-add" size={16} color="#fff" />
                  <Text style={s.actionBtnText}>Add First Contact</Text>
                </TouchableOpacity>
              )}
            </View>
          ) : (
            assessments.map(a => {
              const impact = a.stance * a.influence;
              const isSelected = selectedCard === a.contactId;
              const signals = a.signals ? JSON.parse(a.signals) : [];
              const risks = a.risks ? JSON.parse(a.risks) : [];
              const opps = a.opportunities ? JSON.parse(a.opportunities) : [];
              const isAnalyzing = analyzingId === a.contactId;

              return (
                <TouchableOpacity key={a._id} style={[s.card, isSelected && s.cardSelected]} onPress={() => setSelectedCard(isSelected ? null : a.contactId)} activeOpacity={0.8}>
                  {/* Card Header */}
                  <View style={s.cardHeader}>
                    <View style={s.cardHeaderLeft}>
                      <View style={[s.impactBadge, { backgroundColor: impactColor(impact) }]}>
                        <Text style={s.impactText}>{impact > 0 ? '+' : ''}{impact}</Text>
                      </View>
                      <View>
                        <Text style={s.cardName}>{a.contactName}</Text>
                        {a.contactTitle && <Text style={s.cardTitle}>{a.contactTitle}</Text>}
                      </View>
                    </View>
                    <View style={s.cardBadges}>
                      <View style={[s.miniTag, { backgroundColor: stanceColor(a.stance) + '20', borderColor: stanceColor(a.stance) }]}>
                        <Text style={[s.miniTagText, { color: stanceColor(a.stance) }]}>{STANCE_LABELS[a.stance] ?? 'Neutral'}</Text>
                      </View>
                    </View>
                  </View>

                  {/* Compact metrics row */}
                  <View style={s.metricsRow}>
                    <View style={s.metric}><Text style={s.metricLabel}>Role</Text><Text style={s.metricValue}>{a.role}</Text></View>
                    <View style={s.metric}><Text style={s.metricLabel}>Influence</Text><Text style={s.metricValue}>{INFLUENCE_LABELS[a.influence] ?? 'Medium'}</Text></View>
                    <View style={s.metric}><Text style={s.metricLabel}>Relationship</Text><Text style={[s.metricValue, { color: strengthColor(a.relationshipStrength) }]}>{a.relationshipStrength}</Text></View>
                    <View style={s.metric}><Text style={s.metricLabel}>Confidence</Text><Text style={s.metricValue}>{a.confidence}</Text></View>
                  </View>

                  {/* Expanded Detail */}
                  {isSelected && (
                    <View style={s.cardDetail}>
                      {a.aiReasoning && (
                        <View style={s.detailSection}>
                          <Text style={s.detailLabel}>AI Reasoning</Text>
                          <Text style={s.detailText}>{a.aiReasoning}</Text>
                        </View>
                      )}
                      {signals.length > 0 && (
                        <View style={s.detailSection}>
                          <Text style={s.detailLabel}>Signals</Text>
                          {signals.map((sig: any, i: number) => (
                            <View key={i} style={s.signalRow}>
                              <Text style={s.signalDot}>•</Text>
                              <Text style={s.signalText}>{safeStr(sig)}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {risks.length > 0 && (
                        <View style={s.detailSection}>
                          <Text style={s.detailLabel}>Risks</Text>
                          {risks.map((r: any, i: number) => (
                            <View key={i} style={[s.alertRow, { backgroundColor: '#fef2f2' }]}>
                              <Ionicons name="warning" size={14} color="#ef4444" />
                              <View style={{ flex: 1 }}>
                                <Text style={[s.alertType, { color: '#ef4444' }]}>{safeStr(r.type)} — {safeStr(r.severity)}</Text>
                                <Text style={s.alertDetail}>{safeStr(r.details)}</Text>
                              </View>
                            </View>
                          ))}
                        </View>
                      )}
                      {opps.length > 0 && (
                        <View style={s.detailSection}>
                          <Text style={s.detailLabel}>Opportunities</Text>
                          {opps.map((o: any, i: number) => (
                            <View key={i} style={[s.alertRow, { backgroundColor: '#f0fdf4' }]}>
                              <Ionicons name="bulb" size={14} color="#16a34a" />
                              <View style={{ flex: 1 }}>
                                <Text style={[s.alertType, { color: '#16a34a' }]}>{safeStr(o.type)}</Text>
                                <Text style={s.alertDetail}>{safeStr(o.details)}</Text>
                              </View>
                            </View>
                          ))}
                        </View>
                      )}
                      {a.nextMoveTitle && (
                        <View style={s.nextMove}>
                          <Ionicons name="arrow-forward-circle" size={16} color={colors.primary} />
                          <View style={{ flex: 1 }}>
                            <Text style={s.nextMoveTitle}>{a.nextMoveTitle}</Text>
                            {a.nextMoveDetails && <Text style={s.nextMoveDetail}>{a.nextMoveDetails}</Text>}
                            {a.nextMovePriority && <Text style={s.nextMoveMeta}>Priority: {a.nextMovePriority}{a.nextMoveDeadline ? ` · By ${a.nextMoveDeadline}` : ''}</Text>}
                          </View>
                        </View>
                      )}

                      {/* Card actions */}
                      <View style={s.cardActions}>
                        <TouchableOpacity
                          style={[s.cardActionBtn, { backgroundColor: '#7c3aed' }]}
                          onPress={() => analyzeContact(a.contactId, a.contactName, a.contactTitle)}
                          disabled={isAnalyzing}
                        >
                          {isAnalyzing ? <ActivityIndicator size="small" color="#fff" /> : <Ionicons name="sparkles" size={14} color="#fff" />}
                          <Text style={s.cardActionText}>{isAnalyzing ? 'Analyzing...' : 'Re-analyze'}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[s.cardActionBtn, { backgroundColor: colors.textSecondary }]}
                          onPress={() => {
                            setOverrideValues({ stance: a.stance, influence: a.influence, role: a.role, relationshipStrength: a.relationshipStrength });
                            setShowOverride(a._id);
                          }}
                        >
                          <Ionicons name="create" size={14} color="#fff" />
                          <Text style={s.cardActionText}>Override</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[s.cardActionBtn, { backgroundColor: '#ef4444' }]}
                          onPress={() => Alert.alert('Remove', `Remove ${a.contactName} from stakeholder map?`, [
                            { text: 'Cancel', style: 'cancel' },
                            { text: 'Remove', style: 'destructive', onPress: () => removeAssessment({ id: a._id }) },
                          ])}
                        >
                          <Ionicons name="trash" size={14} color="#fff" />
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}
                  {a.isUserOverride && (
                    <View style={s.overrideBadge}><Text style={s.overrideBadgeText}>Manual Override</Text></View>
                  )}
                </TouchableOpacity>
              );
            })
          )}

          {/* Add Contact Modal */}
          <Modal visible={showAddContact} transparent animationType="fade">
            <View style={s.modalOverlay}>
              <View style={s.modalContent}>
                <Text style={s.modalTitle}>Add Stakeholder</Text>
                <ScrollView style={{ maxHeight: 300 }}>
                  {availableContacts.length === 0 ? (
                    <Text style={s.emptyText}>No additional contacts available for this company.</Text>
                  ) : (
                    availableContacts.map(c => (
                      <TouchableOpacity key={c._id} style={s.contactOption} onPress={() => handleAddContact(c._id, c.name, c.title)}>
                        <View>
                          <Text style={s.contactOptionName}>{c.name}</Text>
                          {c.title && <Text style={s.contactOptionTitle}>{c.title}</Text>}
                        </View>
                        <Ionicons name="add-circle" size={22} color={colors.primary} />
                      </TouchableOpacity>
                    ))
                  )}
                </ScrollView>
                <TouchableOpacity style={s.modalClose} onPress={() => setShowAddContact(false)}>
                  <Text style={s.modalCloseText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>

          {/* Override Modal */}
          <Modal visible={showOverride !== null} transparent animationType="fade">
            <View style={s.modalOverlay}>
              <View style={s.modalContent}>
                <Text style={s.modalTitle}>Manual Override</Text>
                {/* Stance */}
                <Text style={s.overrideLabel}>Stance</Text>
                <View style={s.overridePicker}>
                  {[-2, -1, 0, 1, 2].map(v => (
                    <TouchableOpacity key={v} style={[s.overrideOption, overrideValues.stance === v && { backgroundColor: stanceColor(v), borderColor: stanceColor(v) }]} onPress={() => setOverrideValues(prev => ({ ...prev, stance: v }))}>
                      <Text style={[s.overrideOptionText, overrideValues.stance === v && { color: '#fff' }]}>{STANCE_LABELS[v]?.substring(0, 4)}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                {/* Influence */}
                <Text style={s.overrideLabel}>Influence</Text>
                <View style={s.overridePicker}>
                  {[1, 2, 3].map(v => (
                    <TouchableOpacity key={v} style={[s.overrideOption, overrideValues.influence === v && { backgroundColor: colors.primary, borderColor: colors.primary }]} onPress={() => setOverrideValues(prev => ({ ...prev, influence: v }))}>
                      <Text style={[s.overrideOptionText, overrideValues.influence === v && { color: '#fff' }]}>{INFLUENCE_LABELS[v]}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                {/* Role */}
                <Text style={s.overrideLabel}>Role</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: spacing.sm }}>
                  {['Decision Maker', 'Economic Buyer', 'Technical Evaluator', 'Operational Owner', 'Influencer', 'Gatekeeper', 'Blocker'].map(r => (
                    <TouchableOpacity key={r} style={[s.overrideOption, { marginRight: 4 }, overrideValues.role === r && { backgroundColor: colors.primary, borderColor: colors.primary }]} onPress={() => setOverrideValues(prev => ({ ...prev, role: r }))}>
                      <Text style={[s.overrideOptionText, overrideValues.role === r && { color: '#fff' }]}>{r}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                {/* Relationship Strength */}
                <Text style={s.overrideLabel}>Relationship</Text>
                <View style={s.overridePicker}>
                  {['Weak', 'Medium', 'Strong'].map(v => (
                    <TouchableOpacity key={v} style={[s.overrideOption, overrideValues.relationshipStrength === v && { backgroundColor: strengthColor(v), borderColor: strengthColor(v) }]} onPress={() => setOverrideValues(prev => ({ ...prev, relationshipStrength: v }))}>
                      <Text style={[s.overrideOptionText, overrideValues.relationshipStrength === v && { color: '#fff' }]}>{v}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
                {/* Save / Cancel */}
                <View style={s.modalButtons}>
                  <TouchableOpacity style={[s.modalBtn, { backgroundColor: colors.textSecondary }]} onPress={() => setShowOverride(null)}>
                    <Text style={s.modalBtnText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[s.modalBtn, { backgroundColor: colors.primary }]} onPress={() => {
                    const a = assessments.find(x => x._id === showOverride);
                    if (a) handleSaveOverride(a);
                  }}>
                    <Text style={s.modalBtnText}>Save Override</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Modal>
        </View>
      )}
    </View>
  );
}

// ── Styles ───────────────────────────────────────────────────────
const s = StyleSheet.create({
  section: { backgroundColor: colors.card, borderRadius: radius.lg, marginBottom: spacing.md, overflow: 'hidden' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: spacing.md },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  headerTitle: { fontSize: fs.md, fontWeight: '700', color: colors.textPrimary },
  badge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 2 },
  badgeText: { fontSize: 11, fontWeight: '700', color: '#fff' },
  content: { paddingHorizontal: spacing.md, paddingBottom: spacing.md },
  summaryCard: { backgroundColor: colors.bg, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.sm },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-around' },
  summaryItem: { alignItems: 'center' },
  summaryLabel: { fontSize: 10, color: colors.textSecondary, marginBottom: 2 },
  summaryValue: { fontSize: fs.md, fontWeight: '700', color: colors.textPrimary },
  warningsBox: { marginTop: spacing.xs, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.xs },
  warningRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 2 },
  warningText: { fontSize: 11, color: '#92400e', flex: 1 },
  actionBar: { flexDirection: 'row', gap: spacing.xs, marginBottom: spacing.sm, flexWrap: 'wrap' },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: colors.primary, paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.md },
  actionBtnText: { fontSize: 12, fontWeight: '600', color: '#fff' },
  mapContainer: { backgroundColor: colors.bg, borderRadius: radius.md, padding: spacing.xs, marginBottom: spacing.sm },
  mapTitle: { fontSize: 12, fontWeight: '600', color: colors.textSecondary, marginBottom: 4, textAlign: 'center' },
  emptyState: { alignItems: 'center', paddingVertical: spacing.lg },
  emptyText: { fontSize: fs.sm, color: colors.textSecondary, marginTop: spacing.xs },
  card: { backgroundColor: colors.bg, borderRadius: radius.md, padding: spacing.sm, marginBottom: spacing.xs, borderWidth: 1, borderColor: colors.border },
  cardSelected: { borderColor: colors.primary },
  cardHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardHeaderLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, flex: 1 },
  impactBadge: { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  impactText: { fontSize: 12, fontWeight: '800', color: '#fff' },
  cardName: { fontSize: fs.sm, fontWeight: '600', color: colors.textPrimary },
  cardTitle: { fontSize: 11, color: colors.textSecondary },
  cardBadges: { flexDirection: 'row', gap: 4 },
  miniTag: { borderWidth: 1, borderRadius: radius.sm, paddingHorizontal: 6, paddingVertical: 2 },
  miniTagText: { fontSize: 10, fontWeight: '600' },
  metricsRow: { flexDirection: 'row', marginTop: spacing.xs, gap: spacing.xs },
  metric: { flex: 1, alignItems: 'center' },
  metricLabel: { fontSize: 9, color: colors.textSecondary },
  metricValue: { fontSize: 11, fontWeight: '600', color: colors.textPrimary },
  cardDetail: { marginTop: spacing.sm, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm },
  detailSection: { marginBottom: spacing.sm },
  detailLabel: { fontSize: 11, fontWeight: '700', color: colors.textSecondary, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 },
  detailText: { fontSize: 13, color: colors.textPrimary, lineHeight: 18 },
  signalRow: { flexDirection: 'row', gap: 4, paddingVertical: 1 },
  signalDot: { color: colors.textSecondary, fontSize: 13 },
  signalText: { fontSize: 12, color: colors.textPrimary, flex: 1 },
  alertRow: { flexDirection: 'row', gap: 8, padding: spacing.xs, borderRadius: radius.sm, marginBottom: 4, alignItems: 'flex-start' },
  alertType: { fontSize: 12, fontWeight: '600' },
  alertDetail: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  nextMove: { flexDirection: 'row', gap: spacing.xs, backgroundColor: colors.primary + '10', padding: spacing.xs, borderRadius: radius.sm, alignItems: 'flex-start' },
  nextMoveTitle: { fontSize: 13, fontWeight: '600', color: colors.primary },
  nextMoveDetail: { fontSize: 11, color: colors.textPrimary, marginTop: 2 },
  nextMoveMeta: { fontSize: 10, color: colors.textSecondary, marginTop: 2 },
  cardActions: { flexDirection: 'row', gap: spacing.xs, marginTop: spacing.sm },
  cardActionBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.sm },
  cardActionText: { fontSize: 11, fontWeight: '600', color: '#fff' },
  overrideBadge: { position: 'absolute', top: 4, right: 4, backgroundColor: '#f59e0b', borderRadius: 4, paddingHorizontal: 6, paddingVertical: 1 },
  overrideBadgeText: { fontSize: 9, fontWeight: '600', color: '#fff' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: spacing.lg },
  modalContent: { backgroundColor: colors.card, borderRadius: radius.lg, padding: spacing.md, width: '100%', maxWidth: 400 },
  modalTitle: { fontSize: fs.lg, fontWeight: '700', color: colors.textPrimary, marginBottom: spacing.md },
  modalClose: { marginTop: spacing.md, alignItems: 'center' },
  modalCloseText: { fontSize: fs.sm, color: colors.textSecondary },
  contactOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
  contactOptionName: { fontSize: fs.sm, fontWeight: '600', color: colors.textPrimary },
  contactOptionTitle: { fontSize: 12, color: colors.textSecondary },
  overrideLabel: { fontSize: 12, fontWeight: '600', color: colors.textSecondary, marginBottom: 4, marginTop: spacing.xs },
  overridePicker: { flexDirection: 'row', gap: 4, marginBottom: spacing.xs },
  overrideOption: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 6, minWidth: 44, alignItems: 'center' },
  overrideOptionText: { fontSize: 11, fontWeight: '500', color: colors.textPrimary },
  modalButtons: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.md },
  modalBtn: { flex: 1, alignItems: 'center', paddingVertical: 10, borderRadius: radius.md },
  modalBtnText: { fontSize: fs.sm, fontWeight: '600', color: '#fff' },
});