import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

const actionIcons: Record<string, string> = {
  follow_up: 'arrow-redo',
  schedule_meeting: 'calendar',
  send_proposal: 'document-text',
  research_company: 'search',
  update_pipeline: 'git-branch',
  add_contact: 'person-add',
  qualify_lead: 'checkmark-circle',
  close_opportunity: 'trophy',
  re_engage: 'refresh',
};

interface Props {
  actionType: string;
  title: string;
  description: string;
  score: number;
  engine: string;
  reasoning?: string;
  onExecute: () => void;
  onDismiss: () => void;
  selectable?: boolean;
  selected?: boolean;
  onToggle?: () => void;
}

export default function NbaCard({ actionType, title, description, score, engine, reasoning, onExecute, onDismiss, selectable, selected, onToggle }: Props) {
  const icon = actionIcons[actionType] || 'bulb';
  const scoreColor = score >= 70 ? colors.success : score >= 40 ? colors.warning : colors.textTertiary;

  return (
    <View style={styles.card}>
      <View style={styles.header}>
        {selectable && (
          <TouchableOpacity onPress={onToggle} style={styles.checkboxWrap}>
            <View style={[styles.checkbox, selected && styles.checkboxActive]}>
              {selected && <Ionicons name="checkmark" size={14} color={colors.white} />}
            </View>
          </TouchableOpacity>
        )}
        <View style={[styles.iconWrap, { backgroundColor: colors.primaryLight }]}>
          <Ionicons name={icon as any} size={18} color={colors.primary} />
        </View>
        <View style={styles.headerText}>
          <Text style={styles.title}>{title}</Text>
          <View style={styles.meta}>
            <View style={[styles.scoreBadge, { backgroundColor: scoreColor + '20' }]}>
              <Text style={[styles.scoreText, { color: scoreColor }]}>{score}</Text>
            </View>
            <Text style={styles.engineLabel}>{engine}</Text>
          </View>
        </View>
      </View>
      <Text style={styles.description}>{description}</Text>
      {reasoning && <Text style={styles.reasoning}>{reasoning}</Text>}
      <View style={styles.actions}>
        <TouchableOpacity style={styles.executeBtn} onPress={onExecute}>
          <Ionicons name="checkmark" size={16} color={colors.white} />
          <Text style={styles.executeBtnText}>Execute</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dismissBtn} onPress={onDismiss}>
          <Text style={styles.dismissText}>Dismiss</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg,
    marginBottom: spacing.md, ...shadow.md,
  },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.sm },
  checkboxWrap: { marginRight: spacing.sm },
  checkbox: {
    width: 22, height: 22, borderRadius: 4, borderWidth: 2, borderColor: colors.borderLight,
    justifyContent: 'center', alignItems: 'center',
  },
  checkboxActive: {
    backgroundColor: colors.primary, borderColor: colors.primary,
  },
  iconWrap: {
    width: 36, height: 36, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center',
  },
  headerText: { flex: 1, marginLeft: spacing.md },
  title: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  meta: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginTop: 2 },
  scoreBadge: { paddingHorizontal: spacing.sm, paddingVertical: 1, borderRadius: radius.sm },
  scoreText: { fontSize: fontSize.xs, fontWeight: '700' },
  engineLabel: { fontSize: fontSize.xs, color: colors.textTertiary },
  description: { fontSize: fontSize.sm, color: colors.textSecondary, marginBottom: spacing.sm },
  reasoning: { fontSize: fontSize.xs, color: colors.textTertiary, fontStyle: 'italic', marginBottom: spacing.sm },
  actions: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  executeBtn: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.primary,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: radius.md, gap: 4,
  },
  executeBtnText: { color: colors.white, fontSize: fontSize.sm, fontWeight: '600' },
  dismissBtn: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  dismissText: { color: colors.textTertiary, fontSize: fontSize.sm },
});