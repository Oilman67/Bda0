import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, Modal, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';
import NbaCard from './NbaCard';

type Tab = 'nba' | 'relations';

interface Props {
  visible: boolean;
  onClose: () => void;
  entryType: 'company' | 'contact' | 'opportunity';
  entryId: string;
  entityContext: string;
}

function stanceColor(stance: string): string {
  switch (stance) {
    case 'Champion': return '#16a34a';
    case 'Supportive': return '#65a30d';
    case 'Neutral': return '#9ca3af';
    case 'Skeptical': return '#ea580c';
    case 'Opposed': return '#dc2626';
    default: return '#9ca3af';
  }
}

function influenceColor(inf: string): string {
  switch (inf) {
    case 'High': return colors.primary;
    case 'Medium': return colors.textSecondary;
    case 'Low': return colors.textTertiary;
    default: return colors.textSecondary;
  }
}

function strengthColor(s: string): string {
  switch (s) {
    case 'Strong': return '#16a34a';
    case 'Medium': return '#d97706';
    case 'Weak': return '#dc2626';
    default: return '#9ca3af';
  }
}

function freshnessFromDate(date?: number): { label: string; color: string } {
  if (!date) return { label: 'Stale', color: '#dc2626' };
  const days = Math.floor((Date.now() - date) / (1000 * 60 * 60 * 24));
  if (days <= 14) return { label: 'Fresh', color: '#16a34a' };
  if (days <= 30) return { label: 'Aging', color: '#d97706' };
  return { label: 'Stale', color: '#dc2626' };
}

export default function ContextualEntry({ visible, onClose, entryType, entryId, entityContext }: Props) {
  const [tab, setTab] = useState<Tab>('nba');
  const [riLoading, setRiLoading] = useState(false);
  const [promotedIds, setPromotedIds] = useState<Set<string>>(new Set());
  const [editingTecops, setEditingTecops] = useState(false);
  const [editScores, setEditScores] = useState<Record<string, number>>({ T: 0, E: 0, C: 0, O: 0, P: 0, S: 0 });
  const [selectedNbas, setSelectedNbas] = useState<Set<string>>(new Set());
  const [pushingActions, setPushingActions] = useState(false);
  const isContact = entryType === 'contact';

  // Reset state when modal opens
  useEffect(() => {
    if (visible) {
      setPromotedIds(new Set());
      setSelectedNbas(new Set());
      setEditingTecops(false);
    }
  }, [visible]);

  const nbas = useQuery(api.nba.getNextActions, visible ? { entryType, entryId } : 'skip');
  const riKPIs = useQuery(
    api.relationshipIntelligence.getContactKPI,
    visible && isContact ? { contactId: entryId as any } : 'skip'
  );
  const contactTECOPS = useQuery(
    api.relationshipIntelligence.getContactTECOPS,
    visible && isContact ? { contactId: entryId as any } : 'skip'
  );

  // Clear RI loading when data arrives
  useEffect(() => {
    if (riLoading && (
      (riKPIs && riKPIs.length > 0) ||
      (contactTECOPS?.tecopsAnalyzedAt)
    )) {
      setRiLoading(false);
    }
  }, [riKPIs, contactTECOPS, riLoading]);

  const dismissNba = useMutation(api.nbaActions.dismiss);
  const executeNba = useMutation(api.nbaActions.execute);
  const requestRefresh = useMutation(api.nbaActions.requestRefresh);
  const requestRIAnalysis = useMutation(api.relationshipIntelligence.requestAnalysis);
  const promoteToAction = useMutation(api.relationshipIntelligence.promoteToAction);
  const updateUserTECOPS = useMutation(api.relationshipIntelligence.updateUserTECOPS);
  const resetUserOverrides = useMutation(api.relationshipIntelligence.resetUserOverrides);
  const createTask = useMutation(api.actions.create);

  // Derive primary/secondary drivers from scores
  const deriveTecopsDrivers = (scores: Record<string, number>) => {
    const dims = ['T', 'E', 'C', 'O', 'P', 'S'] as const;
    const sorted = [...dims].sort((a, b) => (scores[b] || 0) - (scores[a] || 0));
    return { primaryRiskDriver: sorted[0], secondaryRiskDriver: sorted[1] };
  };

  // Derive risk alignment heuristic (based on max score)
  const deriveAlignment = (scores: Record<string, number>): string => {
    const max = Math.max(...Object.values(scores));
    if (max >= 3) return 'High alignment';
    if (max >= 2) return 'Moderate alignment';
    return 'Low alignment';
  };

  const handleSaveTecops = async () => {
    try {
      const { primaryRiskDriver, secondaryRiskDriver } = deriveTecopsDrivers(editScores);
      const tecopsProfile = JSON.stringify({
        ...editScores,
        primaryRiskDriver,
        secondaryRiskDriver,
      });
      await updateUserTECOPS({ contactId: entryId as any, tecopsProfile });
      setEditingTecops(false);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to save TECOPS');
    }
  };

  const handleResetOverrides = async () => {
    Alert.alert(
      'Reset to AI',
      'This will clear all manual TECOPS overrides for this contact and re-run AI analysis. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset & Re-analyze',
          style: 'destructive',
          onPress: async () => {
            try {
              await resetUserOverrides({ contactId: entryId as any });
              setEditingTecops(false);
              setRiLoading(true);
              await requestRIAnalysis({ contactId: entryId as any });
              setTimeout(() => setRiLoading(false), 15000);
            } catch (e: any) {
              Alert.alert('Error', e.message || 'Failed to reset');
            }
          },
        },
      ]
    );
  };

  const handleRefresh = async () => {
    requestRefresh({ entryType, entryId, entityContext });
    if (isContact) {
      setRiLoading(true);
      try {
        await requestRIAnalysis({ contactId: entryId as any });
      } catch (e) {
        console.error('RI analysis error:', e);
      }
      // Loading will clear when riKPIs query updates
      setTimeout(() => setRiLoading(false), 15000);
    }
  };

  const handleRunRI = async () => {
    setRiLoading(true);
    try {
      await requestRIAnalysis({ contactId: entryId as any });
    } catch (e: any) {
      console.error('RI analysis error:', e);
      setRiLoading(false);
      Alert.alert('Analysis Failed', e.message || 'Could not run relationship analysis. Please try again.');
      return;
    }
    // Give the background action time to complete, then clear loading
    setTimeout(() => {
      setRiLoading(false);
    }, 20000);
  };

  const handlePromote = async (riId: string, title: string) => {
    try {
      await promoteToAction({ riId: riId as any });
      setPromotedIds(prev => new Set(prev).add(riId));
      // Switch to Actions tab to show the new action
      setTab('nba');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create action');
    }
  };

  const toggleNba = (id: string) => {
    setSelectedNbas((prev: Set<string>) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const handlePushNbas = async () => {
    if (!nbas || selectedNbas.size === 0) return;
    setPushingActions(true);
    try {
      let count = 0;
      let entityContext_parsed: any = {};
      try { entityContext_parsed = JSON.parse(entityContext); } catch {}
      for (const nbaId of selectedNbas) {
        const nba = nbas.find((n: any) => n._id === nbaId);
        if (nba) {
          await createTask({
            title: nba.title,
            description: nba.description || `From NBA for ${entityContext_parsed.name || entryType}`,
            ...(entryType === 'contact' ? { contactId: entryId } : {}),
            ...(entryType === 'company' ? { companyId: entryId } : {}),
            priority: nba.score >= 70 ? 'high' : nba.score >= 40 ? 'medium' : 'low',
          });
          await executeNba({ id: nba._id });
          count++;
        }
      }
      setSelectedNbas(new Set());
      Alert.alert('Actions Created', `${count} action${count > 1 ? 's' : ''} pushed to your Actions list.`);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to create actions.');
    } finally {
      setPushingActions(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Ionicons name="close" size={24} color={colors.textSecondary} />
          </TouchableOpacity>
          <Text style={styles.title}>Context</Text>
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshBtn}>
            <Ionicons name="refresh" size={18} color={colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={styles.tabs}>
          <TouchableOpacity
            style={[styles.tab, tab === 'nba' && styles.tabActive]}
            onPress={() => setTab('nba')}
          >
            <Ionicons name="sparkles" size={16} color={tab === 'nba' ? colors.primary : colors.textTertiary} />
            <Text style={[styles.tabText, tab === 'nba' && styles.tabTextActive]}>
              Actions{nbas && nbas.length > 0 ? ` (${nbas.length})` : ''}
            </Text>
          </TouchableOpacity>
          {isContact && (
            <TouchableOpacity
              style={[styles.tab, tab === 'relations' && styles.tabActive]}
              onPress={() => setTab('relations')}
            >
              <Ionicons name="people" size={16} color={tab === 'relations' ? colors.primary : colors.textTertiary} />
              <Text style={[styles.tabText, tab === 'relations' && styles.tabTextActive]}>
                Relations{riKPIs && riKPIs.length > 0 ? ` (${riKPIs.length})` : ''}
              </Text>
            </TouchableOpacity>
          )}
        </View>

        <ScrollView style={styles.body} contentContainerStyle={styles.bodyContent}>
          {tab === 'nba' && (
            <>
              {!nbas ? (
                <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
              ) : nbas.length === 0 ? (
                <View style={styles.emptyState}>
                  <Ionicons name="sparkles" size={40} color={colors.textTertiary} />
                  <Text style={styles.emptyTitle}>No actions yet</Text>
                  <Text style={styles.emptyText}>Tap refresh to generate AI-powered recommendations</Text>
                  <TouchableOpacity
                    style={styles.generateBtn}
                    onPress={() => requestRefresh({ entryType, entryId, entityContext })}
                  >
                    <Ionicons name="sparkles" size={16} color={colors.white} />
                    <Text style={styles.generateBtnText}>Generate Actions</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <>
                  {nbas.map((n) => (
                    <NbaCard
                      key={n._id}
                      actionType={n.actionType}
                      title={n.title}
                      description={n.description}
                      score={n.score}
                      engine={n.engine}
                      reasoning={n.reasoning}
                      selectable
                      selected={selectedNbas.has(n._id)}
                      onToggle={() => toggleNba(n._id)}
                      onExecute={() => executeNba({ id: n._id })}
                      onDismiss={() => dismissNba({ id: n._id })}
                    />
                  ))}
                  {selectedNbas.size > 0 && (
                    <TouchableOpacity
                      style={pushStyles.pushBtn}
                      onPress={handlePushNbas}
                      disabled={pushingActions}
                    >
                      {pushingActions ? (
                        <ActivityIndicator size="small" color={colors.white} />
                      ) : (
                        <>
                          <Ionicons name="arrow-forward" size={14} color={colors.white} />
                          <Text style={pushStyles.pushBtnText}>
                            Push {selectedNbas.size} Action{selectedNbas.size > 1 ? 's' : ''} to List
                          </Text>
                        </>
                      )}
                    </TouchableOpacity>
                  )}
                </>
              )}
            </>
          )}

          {tab === 'relations' && isContact && (
            <>
              {riLoading && !riKPIs && !contactTECOPS ? (
                <View style={styles.center}>
                  <ActivityIndicator color={colors.primary} />
                  <Text style={kpiStyles.loadingText}>Analyzing relationships...</Text>
                </View>
              ) : !riKPIs && !contactTECOPS ? (
                <View style={styles.center}><ActivityIndicator color={colors.primary} /></View>
              ) : (
                <>
                  {riLoading && (
                    <View style={kpiStyles.refreshingBanner}>
                      <ActivityIndicator size="small" color={colors.primary} />
                      <Text style={kpiStyles.refreshingText}>Refreshing analysis...</Text>
                    </View>
                  )}

                  {/* ── TECOPS: Contact-level profile (shown once) ── */}
                  {(() => {
                    const dims = ['T', 'E', 'C', 'O', 'P', 'S'] as const;
                    const dimLabels: Record<string, string> = { T: 'Tech', E: 'Econ', C: 'Comm', O: 'Ops', P: 'Pol', S: 'Sust' };
                    const dimColors: Record<string, string> = {
                      T: '#6366f1', E: '#059669', C: '#d97706',
                      O: '#2563eb', P: '#dc2626', S: '#16a34a',
                    };

                    let rs: any = { T: 0, E: 0, C: 0, O: 0, P: 0, S: 0, primaryRiskDriver: 'T', secondaryRiskDriver: 'E' };
                    try {
                      if (contactTECOPS?.tecopsProfile) rs = JSON.parse(contactTECOPS.tecopsProfile);
                    } catch {}

                    if (editingTecops) {
                      const { primaryRiskDriver, secondaryRiskDriver } = deriveTecopsDrivers(editScores);
                      return (
                        <View style={kpiStyles.tecopsSection}>
                          <View style={kpiStyles.tecopsHeader}>
                            <Text style={kpiStyles.tecopsTitle}>Edit TECOPS Profile</Text>
                            <TouchableOpacity onPress={() => setEditingTecops(false)}>
                              <Text style={{ fontSize: 12, color: colors.textTertiary, fontWeight: '600' }}>Cancel</Text>
                            </TouchableOpacity>
                          </View>
                          <View style={kpiStyles.tecopsGrid}>
                            {dims.map((d) => {
                              const score = editScores[d] || 0;
                              const isPrimary = primaryRiskDriver === d;
                              const isSecondary = secondaryRiskDriver === d;
                              return (
                                <View key={d} style={kpiStyles.tecopsRow}>
                                  <Text style={[kpiStyles.tecopsLabel, isPrimary && { fontWeight: '800', color: colors.textPrimary }]}>
                                    {dimLabels[d]}{isPrimary ? ' ★' : isSecondary ? ' ●' : ''}
                                  </Text>
                                  <View style={kpiStyles.scoreSelector}>
                                    {[0, 1, 2, 3].map((v) => (
                                      <TouchableOpacity
                                        key={v}
                                        style={[
                                          kpiStyles.scoreDot,
                                          score === v && { backgroundColor: dimColors[d], borderColor: dimColors[d] },
                                        ]}
                                        onPress={() => setEditScores((prev: Record<string, number>) => ({ ...prev, [d]: v }))}
                                      >
                                        <Text style={[
                                          kpiStyles.scoreDotText,
                                          score === v && { color: '#fff' },
                                        ]}>{v}</Text>
                                      </TouchableOpacity>
                                    ))}
                                  </View>
                                </View>
                              );
                            })}
                          </View>
                          <View style={kpiStyles.editActions}>
                            <TouchableOpacity style={kpiStyles.saveBtn} onPress={handleSaveTecops}>
                              <Ionicons name="checkmark" size={14} color={colors.white} />
                              <Text style={kpiStyles.saveBtnText}>Save Override</Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      );
                    }

                    // READ MODE — always show TECOPS
                    return (
                      <View style={kpiStyles.tecopsSection}>
                        <View style={kpiStyles.tecopsHeader}>
                          <Text style={kpiStyles.tecopsTitle}>TECOPS Stakeholder Lens</Text>
                          <TouchableOpacity
                            onPress={() => {
                              setEditScores({ T: Number(rs.T) || 0, E: Number(rs.E) || 0, C: Number(rs.C) || 0, O: Number(rs.O) || 0, P: Number(rs.P) || 0, S: Number(rs.S) || 0 });
                              setEditingTecops(true);
                            }}
                            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                          >
                            <Ionicons name="pencil" size={14} color={colors.textTertiary} />
                          </TouchableOpacity>
                        </View>
                        <View style={kpiStyles.tecopsGrid}>
                          {dims.map((d) => {
                            const score = Number(rs[d]) || 0;
                            const isPrimary = rs.primaryRiskDriver === d;
                            const isSecondary = rs.secondaryRiskDriver === d;
                            return (
                              <View key={d} style={kpiStyles.tecopsRow}>
                                <Text style={[kpiStyles.tecopsLabel, isPrimary && { fontWeight: '800', color: colors.textPrimary }]}>
                                  {dimLabels[d]}{isPrimary ? ' ★' : isSecondary ? ' ●' : ''}
                                </Text>
                                <View style={kpiStyles.tecopsBarBg}>
                                  <View style={[
                                    kpiStyles.tecopsBar,
                                    { width: `${(score / 3) * 100}%`, backgroundColor: dimColors[d] },
                                    isPrimary && { opacity: 1 },
                                  ]} />
                                </View>
                                <Text style={kpiStyles.tecopsScore}>{score}</Text>
                              </View>
                            );
                          })}
                        </View>
                        {contactTECOPS?.tecopsAnalyzedAt && (
                          <Text style={{ fontSize: 9, color: colors.textTertiary, marginTop: 4, textAlign: 'right' }}>
                            Analyzed {new Date(contactTECOPS.tecopsAnalyzedAt).toLocaleDateString()}
                          </Text>
                        )}
                      </View>
                    );
                  })()}

                  {/* ── Per-Opportunity Stance Cards ── */}
                  <Text style={kpiStyles.sectionLabel}>Per-Opportunity Stance</Text>
                  {riKPIs && riKPIs.length > 0 ? (
                    riKPIs.map((kpi) => {
                      const freshness = freshnessFromDate(kpi.lastAnalyzedAt);
                      return (
                        <View key={kpi._id} style={kpiStyles.card}>
                          {/* Line 1: Opportunity + source badge */}
                          <View style={kpiStyles.cardLine1}>
                            <Text style={kpiStyles.oppTitle} numberOfLines={1}>
                              {kpi.opportunityTitle}
                            </Text>
                            <View style={[
                              kpiStyles.sourceBadge,
                              { backgroundColor: kpi.isUserOverride ? colors.warningLight : colors.primaryLight }
                            ]}>
                              <Text style={[
                                kpiStyles.sourceBadgeText,
                                { color: kpi.isUserOverride ? colors.warning : colors.primary }
                              ]}>
                                {kpi.isUserOverride ? 'Manual' : 'AI'}
                              </Text>
                            </View>
                          </View>

                          {/* Line 2: Stance, Influence, Role badges */}
                          <View style={kpiStyles.badgeRow}>
                            <View style={[kpiStyles.badge, { backgroundColor: stanceColor(kpi.stance) }]}>
                              <Text style={kpiStyles.badgeTextLight}>{kpi.stance}</Text>
                            </View>
                            <View style={[kpiStyles.badge, { backgroundColor: influenceColor(kpi.influence), opacity: 0.9 }]}>
                              <Text style={kpiStyles.badgeTextLight}>{kpi.influence}</Text>
                            </View>
                            <View style={[kpiStyles.badgeOutline, { borderColor: colors.textTertiary }]}>
                              <Text style={kpiStyles.badgeTextDark}>{kpi.role}</Text>
                            </View>
                          </View>

                          {/* Line 3: Relationship Strength + Freshness */}
                          <View style={kpiStyles.metaRow}>
                            <View style={kpiStyles.metaItem}>
                              <View style={[kpiStyles.metaDot, { backgroundColor: strengthColor(kpi.relationshipStrength) }]} />
                              <Text style={kpiStyles.metaLabel}>{kpi.relationshipStrength}</Text>
                            </View>
                            <View style={kpiStyles.metaItem}>
                              <View style={[kpiStyles.metaDot, { backgroundColor: freshness.color }]} />
                              <Text style={kpiStyles.metaLabel}>{freshness.label}</Text>
                            </View>
                          </View>

                          {/* Line 4: Next Move */}
                          {kpi.nextMove && (
                            <TouchableOpacity
                              style={[
                                kpiStyles.nextMoveRow,
                                promotedIds.has(kpi._id) && kpiStyles.nextMovePromoted,
                              ]}
                              onPress={() => !promotedIds.has(kpi._id) && handlePromote(kpi._id, kpi.nextMove!)}
                              activeOpacity={promotedIds.has(kpi._id) ? 1 : 0.7}
                            >
                              <Ionicons
                                name={promotedIds.has(kpi._id) ? 'checkmark-circle' : 'arrow-forward-circle'}
                                size={14}
                                color={promotedIds.has(kpi._id) ? colors.success : colors.primary}
                              />
                              <Text
                                style={[
                                  kpiStyles.nextMoveText,
                                  promotedIds.has(kpi._id) && { color: colors.success },
                                ]}
                                numberOfLines={1}
                              >
                                {kpi.nextMove}
                              </Text>
                              {!promotedIds.has(kpi._id) ? (
                                <View style={kpiStyles.promoteBtn}>
                                  <Ionicons name="add" size={12} color={colors.primary} />
                                  <Text style={kpiStyles.promoteBtnText}>Action</Text>
                                </View>
                              ) : (
                                <Text style={kpiStyles.promotedLabel}>Added</Text>
                              )}
                            </TouchableOpacity>
                          )}
                        </View>
                      );
                    })
                  ) : (
                    <View style={{ paddingVertical: 16, alignItems: 'center' }}>
                      <Text style={{ fontSize: 12, color: colors.textTertiary, textAlign: 'center' }}>
                        No linked opportunities for stance analysis.{'\n'}Add opportunities to this contact's company to enable per-deal assessment.
                      </Text>
                    </View>
                  )}

                  {/* Action buttons */}
                  <View style={kpiStyles.actionRow}>
                    <TouchableOpacity style={styles.generateBtn} onPress={handleRunRI}>
                      <Ionicons name="sparkles" size={14} color={colors.white} />
                      <Text style={styles.generateBtnText}>
                        {riKPIs && riKPIs.length > 0 ? 'Re-run AI Analysis' : 'Run AI Analysis'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </>
          )}
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border, backgroundColor: colors.white,
  },
  title: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  refreshBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primaryLight,
    justifyContent: 'center', alignItems: 'center',
  },
  tabs: {
    flexDirection: 'row', backgroundColor: colors.white,
    borderBottomWidth: 1, borderBottomColor: colors.border,
  },
  tab: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: spacing.xs, paddingVertical: spacing.md,
    borderBottomWidth: 2, borderBottomColor: 'transparent',
  },
  tabActive: { borderBottomColor: colors.primary },
  tabText: { fontSize: fontSize.md, color: colors.textTertiary },
  tabTextActive: { color: colors.primary, fontWeight: '600' },
  body: { flex: 1 },
  bodyContent: { padding: spacing.lg, paddingBottom: 40 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', paddingTop: 60 },
  emptyState: { alignItems: 'center', paddingTop: 40 },
  emptyTitle: { fontSize: fontSize.lg, fontWeight: '600', color: colors.textPrimary, marginTop: spacing.lg },
  emptyText: { fontSize: fontSize.sm, color: colors.textSecondary, textAlign: 'center', marginTop: spacing.sm, maxWidth: 240 },
  generateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.xs,
    backgroundColor: colors.primary, paddingHorizontal: spacing.xl, paddingVertical: spacing.md,
    borderRadius: radius.md, marginTop: spacing.xl,
  },
  generateBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSize.md },
  linkCard: {
    backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.lg,
    marginBottom: spacing.md, ...shadow.md,
  },
  linkHeader: { flexDirection: 'row', alignItems: 'center' },
  linkIconWrap: {
    width: 36, height: 36, borderRadius: radius.md, backgroundColor: colors.accentLight,
    justifyContent: 'center', alignItems: 'center',
  },
  linkInfo: { flex: 1, marginLeft: spacing.md },
  linkName: { fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary },
  linkType: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: 2 },
  confidenceBadge: { paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm },
  confidenceText: { fontSize: fontSize.xs, fontWeight: '700' },
  linkReason: { fontSize: fontSize.sm, color: colors.textSecondary, marginTop: spacing.sm },
  linkActions: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginTop: spacing.md },
  acceptBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.success, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, borderRadius: radius.md,
  },
  acceptBtnText: { color: colors.white, fontSize: fontSize.sm, fontWeight: '600' },
  declineBtn: { paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  declineBtnText: { color: colors.textTertiary, fontSize: fontSize.sm },
});

const kpiStyles = StyleSheet.create({
  loadingText: {
    marginTop: spacing.md, fontSize: fontSize.sm, color: colors.textSecondary,
  },
  refreshingBanner: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.primaryLight, borderRadius: radius.md,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    marginBottom: spacing.md,
  },
  refreshingText: {
    fontSize: fontSize.sm, color: colors.primary, fontWeight: '500',
  },
  card: {
    backgroundColor: colors.white, borderRadius: radius.lg, padding: spacing.md,
    marginBottom: spacing.sm, ...shadow.sm,
  },
  cardLine1: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  oppTitle: {
    fontSize: fontSize.md, fontWeight: '600', color: colors.textPrimary, flex: 1, marginRight: spacing.sm,
  },
  sourceBadge: {
    paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: radius.sm,
  },
  sourceBadgeText: {
    fontSize: fontSize.xs, fontWeight: '700',
  },
  badgeRow: {
    flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6, marginBottom: spacing.sm,
  },
  badge: {
    paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.sm,
  },
  badgeTextLight: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.white,
  },
  badgeOutline: {
    paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.sm,
    borderWidth: 1,
  },
  badgeTextDark: {
    fontSize: fontSize.xs, fontWeight: '600', color: colors.textSecondary,
  },
  metaRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.lg, marginBottom: spacing.sm,
  },
  metaItem: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
  },
  metaDot: {
    width: 8, height: 8, borderRadius: 4,
  },
  metaLabel: {
    fontSize: fontSize.xs, color: colors.textSecondary, fontWeight: '500',
  },
  nextMoveRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.primaryLight, borderRadius: radius.sm,
    paddingHorizontal: spacing.sm, paddingVertical: 6,
  },
  nextMoveText: {
    fontSize: fontSize.xs, color: colors.primary, fontWeight: '600', flex: 1,
  },
  runAiBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    paddingVertical: spacing.md, borderRadius: radius.md,
    borderWidth: 1.5, borderColor: colors.primary, borderStyle: 'dashed',
    marginTop: spacing.sm,
  },
  runAiBtnText: {
    fontSize: fontSize.md, fontWeight: '600', color: colors.primary,
  },
  nextMovePromoted: {
    backgroundColor: colors.successLight,
  },
  promoteBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: colors.white, borderRadius: radius.sm,
    paddingHorizontal: 6, paddingVertical: 2,
    borderWidth: 1, borderColor: colors.primary,
  },
  promoteBtnText: {
    fontSize: 10, fontWeight: '700', color: colors.primary,
  },
  promotedLabel: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.success,
  },
  tecopsSection: {
    backgroundColor: colors.bg, borderRadius: radius.md,
    padding: spacing.sm, marginBottom: spacing.sm,
  },
  tecopsHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    marginBottom: 6,
  },
  tecopsTitle: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.textSecondary,
    textTransform: 'uppercase' as const, letterSpacing: 0.5,
  },
  alignmentBadge: {
    paddingHorizontal: 6, paddingVertical: 2, borderRadius: radius.sm,
  },
  alignmentText: {
    fontSize: 10, fontWeight: '700',
  },
  tecopsGrid: {
    gap: 3,
  },
  tecopsRow: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
  },
  tecopsLabel: {
    fontSize: 10, fontWeight: '600', color: colors.textTertiary, width: 38,
  },
  tecopsBarBg: {
    flex: 1, height: 6, backgroundColor: colors.border, borderRadius: 3,
    overflow: 'hidden' as const,
  },
  tecopsBar: {
    height: '100%', borderRadius: 3, opacity: 0.8,
  },
  tecopsScore: {
    fontSize: 10, fontWeight: '700', color: colors.textSecondary, width: 12,
    textAlign: 'right' as const,
  },
  scoreSelector: {
    flex: 1, flexDirection: 'row' as const, alignItems: 'center' as const,
    gap: 6, justifyContent: 'flex-end' as const,
  },
  scoreDot: {
    width: 26, height: 26, borderRadius: 13,
    borderWidth: 1.5, borderColor: colors.border,
    backgroundColor: colors.white,
    justifyContent: 'center' as const, alignItems: 'center' as const,
  },
  scoreDotText: {
    fontSize: 11, fontWeight: '700' as const, color: colors.textSecondary,
  },
  editActions: {
    flexDirection: 'row' as const, justifyContent: 'flex-end' as const,
    marginTop: spacing.sm, gap: spacing.sm,
  },
  saveBtn: {
    flexDirection: 'row' as const, alignItems: 'center' as const, gap: 4,
    backgroundColor: colors.primary, paddingHorizontal: spacing.md,
    paddingVertical: 6, borderRadius: radius.md,
  },
  saveBtnText: {
    fontSize: fontSize.xs, fontWeight: '700' as const, color: colors.white,
  },
  resetAiBtn: {
    flexDirection: 'row' as const, alignItems: 'center' as const, justifyContent: 'center' as const,
    gap: spacing.sm, paddingVertical: spacing.md, borderRadius: radius.md,
    borderWidth: 1.5, borderColor: colors.danger, borderStyle: 'dashed' as const,
    marginTop: spacing.xs,
  },
  resetAiBtnText: {
    fontSize: fontSize.md, fontWeight: '600' as const, color: colors.danger,
  },
  setTecopsBtn: {
    flexDirection: 'row' as const, alignItems: 'center' as const, gap: 6,
    backgroundColor: colors.primaryLight, borderRadius: radius.md,
    paddingHorizontal: spacing.sm, paddingVertical: 6, marginBottom: spacing.sm,
    alignSelf: 'flex-start' as const,
  },
  setTecopsBtnText: {
    fontSize: fontSize.xs, fontWeight: '600' as const, color: colors.primary,
  },
  sectionLabel: {
    fontSize: fontSize.sm, fontWeight: '600', color: colors.textPrimary, marginBottom: spacing.md,
  },
  actionRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    paddingVertical: spacing.md, borderRadius: radius.md,
    borderWidth: 1.5, borderColor: colors.primary, borderStyle: 'dashed',
    marginTop: spacing.sm,
  },
});

const pushStyles = StyleSheet.create({
  pushBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: colors.primary,
    paddingVertical: 10,
    borderRadius: radius.md,
    marginTop: spacing.sm,
  },
  pushBtnText: {
    color: colors.white,
    fontWeight: '600',
    fontSize: fontSize.sm,
  },
});