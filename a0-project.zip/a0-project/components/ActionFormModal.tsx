import React, { useState, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, TextInput, Modal, ScrollView, FlatList,
  StyleSheet, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius } from '../lib/theme';
import DateTimePicker from '@react-native-community/datetimepicker';

const priorityColors: Record<string, string> = {
  high: colors.danger,
  medium: colors.warning,
  low: colors.textTertiary,
};
const priorityOptions = ['low', 'medium', 'high'];
const entityTypeLabels: Record<string, string> = {
  contact: 'Contact',
  company: 'Company',
  opportunity: 'Opportunity',
};

interface Props {
  visible: boolean;
  onClose: () => void;
  /** Pre-link to a specific entity when opened from a detail screen */
  preLinkedType?: 'contact' | 'company' | 'opportunity';
  preLinkedId?: string;
  preLinkedLabel?: string;
}

export default function ActionFormModal({ visible, onClose, preLinkedType, preLinkedId, preLinkedLabel }: Props) {
  const createAction = useMutation(api.actions.create);

  // Form state
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formNotes, setFormNotes] = useState('');
  const [formPriority, setFormPriority] = useState('medium');
  const [formStartDate, setFormStartDate] = useState<Date | null>(null);
  const [formTargetDate, setFormTargetDate] = useState<Date | null>(null);
  const [formLinkedType, setFormLinkedType] = useState<string | null>(null);
  const [formLinkedId, setFormLinkedId] = useState<string | null>(null);
  const [formLinkedLabel, setFormLinkedLabel] = useState('');
  const [showEntityPicker, setShowEntityPicker] = useState(false);
  const [entitySearch, setEntitySearch] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Owner picker state
  const [formOwnerType, setFormOwnerType] = useState<'user' | 'contact' | 'custom'>('user');
  const [formOwnerLabel, setFormOwnerLabel] = useState('You');
  const [formOwnerId, setFormOwnerId] = useState<string | null>(null);
  const [formOwnerCustomName, setFormOwnerCustomName] = useState('');
  const [showOwnerPicker, setShowOwnerPicker] = useState(false);
  const [ownerSearch, setOwnerSearch] = useState('');
  const [ownerCustomInput, setOwnerCustomInput] = useState('');

  // Date picker visibility
  const [showStartPicker, setShowStartPicker] = useState(false);
  const [showTargetPicker, setShowTargetPicker] = useState(false);

  // Queries for pickers (only when visible)
  const contacts = useQuery(api.contacts.list, visible ? {} : 'skip');
  const companies = useQuery(api.companies.list, visible ? {} : 'skip');
  const opportunities = useQuery(api.opportunities.list, visible ? {} : 'skip');
  const orgMembers = useQuery(api.actions.listOrgMembers, visible ? {} : 'skip');

  // Initialize pre-linked entity when modal opens
  React.useEffect(() => {
    if (visible && preLinkedType && preLinkedId) {
      setFormLinkedType(preLinkedType);
      setFormLinkedId(preLinkedId);
      setFormLinkedLabel(preLinkedLabel || `${entityTypeLabels[preLinkedType]}: ${preLinkedId}`);
    }
  }, [visible, preLinkedType, preLinkedId, preLinkedLabel]);

  // Build entity list for picker
  const entityOptions = useMemo(() => {
    const items: { type: string; id: string; label: string; icon: string }[] = [];
    if (contacts) {
      for (const c of contacts) {
        items.push({ type: 'contact', id: c._id, label: `${c.firstName} ${c.lastName}`.trim(), icon: 'person' });
      }
    }
    if (companies) {
      for (const c of companies) {
        items.push({ type: 'company', id: c._id, label: c.name, icon: 'business' });
      }
    }
    if (opportunities) {
      for (const o of opportunities) {
        items.push({ type: 'opportunity', id: o._id, label: o.title, icon: 'trending-up' });
      }
    }
    return items;
  }, [contacts, companies, opportunities]);

  const filteredEntities = useMemo(() => {
    if (!entitySearch.trim()) return entityOptions;
    const q = entitySearch.toLowerCase();
    return entityOptions.filter(e => e.label.toLowerCase().includes(q));
  }, [entityOptions, entitySearch]);

  // Owner picker options
  const ownerOptions = useMemo(() => {
    const items: { section: string; type: 'user' | 'contact' | 'custom'; id: string | null; label: string; sub: string; icon: string; isCurrent?: boolean }[] = [];
    if (orgMembers) {
      for (const m of orgMembers) {
        items.push({
          section: 'Team', type: 'user', id: m.userId,
          label: m.isCurrentUser ? `${m.name} (You)` : m.name,
          sub: m.role.charAt(0).toUpperCase() + m.role.slice(1),
          icon: 'people', isCurrent: m.isCurrentUser,
        });
      }
    }
    if (contacts) {
      for (const c of contacts) {
        const name = `${c.firstName} ${c.lastName}`.trim();
        if (name) {
          items.push({
            section: 'Client', type: 'contact', id: c._id,
            label: name, sub: c.companyName || 'Contact', icon: 'person',
          });
        }
      }
    }
    return items;
  }, [orgMembers, contacts]);

  const filteredOwnerOptions = useMemo(() => {
    if (!ownerSearch.trim()) return ownerOptions;
    const q = ownerSearch.toLowerCase();
    return ownerOptions.filter(o => o.label.toLowerCase().includes(q) || o.sub.toLowerCase().includes(q));
  }, [ownerOptions, ownerSearch]);

  const resetForm = () => {
    setFormTitle(''); setFormDesc(''); setFormNotes(''); setFormPriority('medium');
    setFormStartDate(null); setFormTargetDate(null);
    setFormLinkedType(null); setFormLinkedId(null); setFormLinkedLabel('');
    setFormOwnerType('user'); setFormOwnerLabel('You'); setFormOwnerId(null);
    setFormOwnerCustomName('');
    setShowStartPicker(false); setShowTargetPicker(false);
    onClose();
  };

  const handleSubmit = async () => {
    if (!formTitle.trim()) return;
    setSubmitting(true);
    try {
      const linkArgs: any = {};
      if (formLinkedType === 'contact' && formLinkedId) linkArgs.contactId = formLinkedId;
      else if (formLinkedType === 'company' && formLinkedId) linkArgs.companyId = formLinkedId;
      else if (formLinkedType === 'opportunity' && formLinkedId) linkArgs.opportunityId = formLinkedId;

      const ownerArgs: any = { ownerType: formOwnerType };
      if (formOwnerType === 'user' && formOwnerId) {
        ownerArgs.assigneeId = formOwnerId;
      } else if (formOwnerType === 'contact' && formOwnerId) {
        ownerArgs.ownerContactId = formOwnerId;
      } else if (formOwnerType === 'custom' && formOwnerCustomName.trim()) {
        ownerArgs.ownerCustomName = formOwnerCustomName.trim();
      }

      await createAction({
        title: formTitle.trim(),
        description: formDesc.trim() || undefined,
        notes: formNotes.trim() || undefined,
        priority: formPriority,
        startDate: formStartDate ? formStartDate.getTime() : undefined,
        targetDate: formTargetDate ? formTargetDate.getTime() : undefined,
        ...linkArgs,
        ...ownerArgs,
      });
      resetForm();
    } catch (e) {
      console.error(e);
    } finally {
      setSubmitting(false);
    }
  };

  const entityIconForType = (type?: string) => {
    if (type === 'contact') return 'person';
    if (type === 'company') return 'business';
    if (type === 'opportunity') return 'trending-up';
    return 'link';
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <SafeAreaView style={styles.formContainer} edges={['top']}>
        {showEntityPicker ? (
          <>
            <View style={styles.formHeader}>
              <TouchableOpacity onPress={() => setShowEntityPicker(false)}>
                <Text style={styles.formCancel}>Back</Text>
              </TouchableOpacity>
              <Text style={styles.formTitle}>Link With</Text>
              <View style={{ width: 50 }} />
            </View>
            <TextInput
              style={styles.entitySearchInput}
              placeholder="Search contacts, companies, opportunities..."
              placeholderTextColor={colors.textTertiary}
              value={entitySearch}
              onChangeText={setEntitySearch}
              autoFocus
            />
            <FlatList
              data={filteredEntities}
              keyExtractor={(item) => `${item.type}-${item.id}`}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 40 }}
              renderItem={({ item: e }) => (
                <TouchableOpacity
                  style={styles.entityRow}
                  onPress={() => {
                    setFormLinkedType(e.type);
                    setFormLinkedId(e.id);
                    setFormLinkedLabel(`${entityTypeLabels[e.type]}: ${e.label}`);
                    setShowEntityPicker(false);
                  }}
                >
                  <View style={[styles.entityIcon, {
                    backgroundColor: e.type === 'contact' ? colors.primaryLight
                      : e.type === 'company' ? '#E8F5E9'
                      : colors.warningLight
                  }]}>
                    <Ionicons name={e.icon as any} size={16} color={
                      e.type === 'contact' ? colors.primary
                        : e.type === 'company' ? colors.success
                        : colors.warning
                    } />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.entityName}>{e.label}</Text>
                    <Text style={styles.entityType}>{entityTypeLabels[e.type]}</Text>
                  </View>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                <Text style={styles.entityEmpty}>No matches found</Text>
              }
            />
          </>
        ) : showOwnerPicker ? (
          <>
            <View style={styles.formHeader}>
              <TouchableOpacity onPress={() => setShowOwnerPicker(false)}>
                <Text style={styles.formCancel}>Back</Text>
              </TouchableOpacity>
              <Text style={styles.formTitle}>Action Owner</Text>
              <View style={{ width: 50 }} />
            </View>
            <TextInput
              style={styles.entitySearchInput}
              placeholder="Search team members, clients..."
              placeholderTextColor={colors.textTertiary}
              value={ownerSearch}
              onChangeText={setOwnerSearch}
            />
            <View style={styles.ownerCustomSection}>
              <Text style={styles.ownerSectionTitle}>Third Party / Other</Text>
              <View style={styles.ownerCustomRow}>
                <TextInput
                  style={styles.ownerCustomInput}
                  placeholder="Enter name (e.g. external partner)..."
                  placeholderTextColor={colors.textTertiary}
                  value={ownerCustomInput}
                  onChangeText={setOwnerCustomInput}
                />
                <TouchableOpacity
                  style={[styles.ownerCustomBtn, !ownerCustomInput.trim() && { opacity: 0.4 }]}
                  disabled={!ownerCustomInput.trim()}
                  onPress={() => {
                    setFormOwnerType('custom');
                    setFormOwnerLabel(ownerCustomInput.trim());
                    setFormOwnerCustomName(ownerCustomInput.trim());
                    setFormOwnerId(null);
                    setShowOwnerPicker(false);
                  }}
                >
                  <Ionicons name="checkmark" size={18} color={colors.white} />
                </TouchableOpacity>
              </View>
            </View>
            <FlatList
              data={filteredOwnerOptions}
              keyExtractor={(item) => `${item.type}-${item.id || 'current'}`}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ paddingHorizontal: spacing.lg, paddingBottom: 40 }}
              renderItem={({ item: o }) => {
                const isSelected = (formOwnerType === o.type && formOwnerId === o.id) ||
                  (o.isCurrent && formOwnerType === 'user' && !formOwnerId);
                return (
                  <TouchableOpacity
                    style={[styles.entityRow, isSelected && { backgroundColor: colors.primaryLight }]}
                    onPress={() => {
                      setFormOwnerType(o.type);
                      setFormOwnerId(o.id);
                      setFormOwnerLabel(o.label);
                      setFormOwnerCustomName('');
                      setShowOwnerPicker(false);
                    }}
                  >
                    <View style={[styles.entityIcon, {
                      backgroundColor: o.type === 'user' ? colors.primaryLight : '#E8F5E9'
                    }]}>
                      <Ionicons
                        name={o.icon as any}
                        size={16}
                        color={o.type === 'user' ? colors.primary : colors.success}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.entityName}>{o.label}</Text>
                      <Text style={styles.entityType}>{o.section} � {o.sub}</Text>
                    </View>
                    {isSelected && (
                      <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
                    )}
                  </TouchableOpacity>
                );
              }}
              ListHeaderComponent={
                filteredOwnerOptions.length > 0 ? (
                  <Text style={styles.ownerSectionTitle}>Team & Clients</Text>
                ) : null
              }
              ListEmptyComponent={
                <Text style={styles.entityEmpty}>No matches found</Text>
              }
            />
          </>
        ) : (
          <>
            <View style={styles.formHeader}>
              <TouchableOpacity onPress={resetForm}>
                <Text style={styles.formCancel}>Cancel</Text>
              </TouchableOpacity>
              <Text style={styles.formTitle}>New Action</Text>
              <TouchableOpacity onPress={handleSubmit} disabled={!formTitle.trim() || submitting}>
                <Text style={[styles.formSave, (!formTitle.trim() || submitting) && { opacity: 0.4 }]}>
                  {submitting ? 'Saving...' : 'Save'}
                </Text>
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.formScroll} contentContainerStyle={styles.formContent} keyboardShouldPersistTaps="handled">
              {/* Title */}
              <Text style={styles.inputLabel}>Action Title *</Text>
              <TextInput
                style={styles.input}
                placeholder="What needs to be done?"
                placeholderTextColor={colors.textTertiary}
                value={formTitle}
                onChangeText={setFormTitle}
              />

              {/* Description */}
              <Text style={styles.inputLabel}>Description</Text>
              <TextInput
                style={[styles.input, styles.inputMultiline]}
                placeholder="Add description..."
                placeholderTextColor={colors.textTertiary}
                value={formDesc}
                onChangeText={setFormDesc}
                multiline
              />

              {/* Notes */}
              <Text style={styles.inputLabel}>Notes</Text>
              <TextInput
                style={[styles.input, styles.inputMultiline]}
                placeholder="Free-form notes..."
                placeholderTextColor={colors.textTertiary}
                value={formNotes}
                onChangeText={setFormNotes}
                multiline
              />

              {/* Priority */}
              <Text style={styles.inputLabel}>Priority</Text>
              <View style={styles.priorityRow}>
                {priorityOptions.map(p => (
                  <TouchableOpacity
                    key={p}
                    style={[styles.priorityBtn, formPriority === p && styles.priorityBtnActive,
                      formPriority === p && { borderColor: priorityColors[p] }]}
                    onPress={() => setFormPriority(p)}
                  >
                    <View style={[styles.priorityDotForm, { backgroundColor: priorityColors[p] }]} />
                    <Text style={[styles.priorityBtnText, formPriority === p && styles.priorityBtnTextActive]}>
                      {p.charAt(0).toUpperCase() + p.slice(1)}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Linked With */}
              <Text style={styles.inputLabel}>Linked With</Text>
              <TouchableOpacity
                style={styles.linkedPicker}
                onPress={() => { setEntitySearch(''); setShowEntityPicker(true); }}
              >
                {formLinkedId ? (
                  <View style={styles.linkedSelected}>
                    <Ionicons name={entityIconForType(formLinkedType || undefined) as any} size={16} color={colors.primary} />
                    <Text style={styles.linkedSelectedText}>{formLinkedLabel}</Text>
                    <TouchableOpacity onPress={() => { setFormLinkedType(null); setFormLinkedId(null); setFormLinkedLabel(''); }}>
                      <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                    </TouchableOpacity>
                  </View>
                ) : (
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={[styles.linkedPlaceholder, { flex: 1 }]}>Select a contact, company, or opportunity...</Text>
                    <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} />
                  </View>
                )}
              </TouchableOpacity>

              {/* Owner */}
              <Text style={styles.inputLabel}>Action Owner</Text>
              <TouchableOpacity
                style={styles.ownerDisplay}
                onPress={() => { setOwnerSearch(''); setOwnerCustomInput(''); setShowOwnerPicker(true); }}
              >
                <View style={[styles.ownerAvatarSmall, formOwnerType === 'contact' && { backgroundColor: colors.success }, formOwnerType === 'custom' && { backgroundColor: colors.warning }]}>
                  <Ionicons name={formOwnerType === 'contact' ? 'person' : formOwnerType === 'custom' ? 'create' : 'people'} size={12} color={colors.white} />
                </View>
                <Text style={[styles.ownerDisplayText, formOwnerLabel !== 'You' && { color: colors.textPrimary, fontWeight: '500' }]}>
                  {formOwnerLabel}
                </Text>
                {formOwnerLabel !== 'You' && (
                  <TouchableOpacity onPress={() => { setFormOwnerType('user'); setFormOwnerLabel('You'); setFormOwnerId(null); setFormOwnerCustomName(''); }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                )}
                <Ionicons name="chevron-forward" size={16} color={colors.textTertiary} style={{ marginLeft: 'auto' }} />
              </TouchableOpacity>

              {/* Start By date */}
              <Text style={styles.inputLabel}>Start By</Text>
              <TouchableOpacity
                style={styles.dateFieldRow}
                onPress={() => {
                  if (!formStartDate) setFormStartDate(new Date());
                  setShowStartPicker(!showStartPicker);
                }}
                activeOpacity={0.7}
              >
                <Ionicons name="calendar-outline" size={18} color={formStartDate ? colors.primary : colors.textTertiary} />
                <Text style={[styles.datePlaceholder, formStartDate && styles.dateValueText]}>
                  {formStartDate ? formStartDate.toLocaleDateString() : 'Select start date...'}
                </Text>
                {formStartDate && (
                  <TouchableOpacity onPress={() => { setFormStartDate(null); setShowStartPicker(false); }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                )}
              </TouchableOpacity>
              {showStartPicker && (
                <DateTimePicker
                  value={formStartDate || new Date()}
                  mode="date"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={(event: any, date?: Date) => {
                    if (Platform.OS === 'android') setShowStartPicker(false);
                    if (date) setFormStartDate(date);
                  }}
                  style={{ alignSelf: 'center' }}
                />
              )}

              {/* Target Date */}
              <Text style={styles.inputLabel}>Target Date</Text>
              <TouchableOpacity
                style={styles.dateFieldRow}
                onPress={() => {
                  if (!formTargetDate) setFormTargetDate(new Date());
                  setShowTargetPicker(!showTargetPicker);
                }}
                activeOpacity={0.7}
              >
                <Ionicons name="flag-outline" size={18} color={formTargetDate ? colors.primary : colors.textTertiary} />
                <Text style={[styles.datePlaceholder, formTargetDate && styles.dateValueText]}>
                  {formTargetDate ? formTargetDate.toLocaleDateString() : 'Select target date...'}
                </Text>
                {formTargetDate && (
                  <TouchableOpacity onPress={() => { setFormTargetDate(null); setShowTargetPicker(false); }}>
                    <Ionicons name="close-circle" size={18} color={colors.textTertiary} />
                  </TouchableOpacity>
                )}
              </TouchableOpacity>
              {showTargetPicker && (
                <DateTimePicker
                  value={formTargetDate || new Date()}
                  mode="date"
                  display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                  onChange={(event: any, date?: Date) => {
                    if (Platform.OS === 'android') setShowTargetPicker(false);
                    if (date) setFormTargetDate(date);
                  }}
                  style={{ alignSelf: 'center' }}
                />
              )}
            </ScrollView>
          </>
        )}
      </SafeAreaView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  formContainer: { flex: 1, backgroundColor: colors.bg },
  formHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  formCancel: { fontSize: fontSize.md, color: colors.textSecondary },
  formTitle: { fontSize: fontSize.lg, fontWeight: '700', color: colors.textPrimary },
  formSave: { fontSize: fontSize.md, fontWeight: '600', color: colors.primary },
  formScroll: { flex: 1 },
  formContent: { padding: spacing.lg, paddingBottom: 60 },
  inputLabel: {
    fontSize: fontSize.sm, fontWeight: '600', color: colors.textSecondary,
    marginBottom: spacing.xs, marginTop: spacing.md,
  },
  input: {
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  inputMultiline: { minHeight: 80, textAlignVertical: 'top' },
  priorityRow: { flexDirection: 'row', gap: spacing.sm },
  priorityBtn: {
    flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.xs,
    paddingVertical: spacing.sm, borderRadius: radius.md,
    backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.border,
  },
  priorityBtnActive: { backgroundColor: colors.white },
  priorityDotForm: { width: 8, height: 8, borderRadius: 4 },
  priorityBtnText: { fontSize: fontSize.sm, color: colors.textTertiary },
  priorityBtnTextActive: { fontWeight: '700', color: colors.textPrimary },
  linkedPicker: {
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  linkedSelected: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  linkedSelectedText: { flex: 1, fontSize: fontSize.md, color: colors.textPrimary, fontWeight: '500' },
  linkedPlaceholder: { fontSize: fontSize.md, color: colors.textTertiary },
  ownerDisplay: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  ownerAvatarSmall: {
    width: 20, height: 20, borderRadius: 10, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
  ownerDisplayText: { fontSize: fontSize.md, color: colors.textSecondary },
  entitySearchInput: {
    backgroundColor: colors.white, marginHorizontal: spacing.lg, marginVertical: spacing.md,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
    paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  entityRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  entityIcon: {
    width: 36, height: 36, borderRadius: radius.md,
    justifyContent: 'center', alignItems: 'center',
  },
  entityName: { fontSize: fontSize.md, fontWeight: '500', color: colors.textPrimary },
  entityType: { fontSize: fontSize.xs, color: colors.textTertiary, marginTop: 1 },
  entityEmpty: {
    textAlign: 'center', color: colors.textTertiary, fontSize: fontSize.md,
    marginTop: spacing.xl,
  },
  dateFieldRow: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
    backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.md,
  },
  datePlaceholder: {
    flex: 1, fontSize: fontSize.md, color: colors.textTertiary,
  },
  dateValueText: {
    color: colors.textPrimary, fontWeight: '500',
  },
  ownerCustomSection: {
    paddingHorizontal: spacing.lg, paddingBottom: spacing.md,
    borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  ownerSectionTitle: {
    fontSize: fontSize.xs, fontWeight: '700', color: colors.textTertiary,
    textTransform: 'uppercase', letterSpacing: 0.5,
    marginTop: spacing.md, marginBottom: spacing.sm,
  },
  ownerCustomRow: {
    flexDirection: 'row', gap: spacing.sm, alignItems: 'center',
  },
  ownerCustomInput: {
    flex: 1, backgroundColor: colors.white, borderRadius: radius.md, borderWidth: 1,
    borderColor: colors.border, paddingHorizontal: spacing.md, paddingVertical: spacing.sm,
    fontSize: fontSize.md, color: colors.textPrimary,
  },
  ownerCustomBtn: {
    width: 36, height: 36, borderRadius: radius.full, backgroundColor: colors.primary,
    justifyContent: 'center', alignItems: 'center',
  },
});
