import React, { useState, useCallback, useMemo } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, TextInput,
  ActivityIndicator, ScrollView, Alert, Linking,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useAction } from 'convex/react';
import { api } from '../convex/_generated/api';
import { colors, spacing, fontSize, radius, shadow } from '../lib/theme';

// ─── Types ──────────────────────────────────────────────────────────────────

interface Evidence {
  type: string;
  bucket: string;
  source_url?: string;
  date?: string;
  strength: string;
}

interface PipelineContact {
  name: string;
  title: string;
  normalized_function: string;
  seniority: string;
  buying_role: string;
  confidence_data: number;
  confidence_role_match: number;
  confidence_current: number;
  influence_score: number;
  organizational_power: number;
  functional_relevance: number;
  practical_buying: number;
  reachability_score: number;
  email_guess_confidence: number;
  status: string;
  evidence: Evidence[];
  freshness_days: number;
  freshness_label: string;
  last_seen_date?: string;
  linkedin_search_url: string;
  email_guess?: string;
  surfaced_reason?: string;
  missing_info?: string;
  suggested_action?: string;
}

interface InferredRoleOutput {
  title: string;
  normalized_function: string;
  seniority: string;
  reason: string;
  suggested_queries: string[];
}

// ─── Constants ──────────────────────────────────────────────────────────────

const STATUS_CONFIG: Record<string, { color: string; bg: string; icon: string; label: string }> = {
  Verified: { color: '#059669', bg: '#D1FAE5', icon: 'checkmark-circle', label: 'Verified' },
  Probable: { color: '#D97706', bg: '#FEF3C7', icon: 'alert-circle', label: 'Probable' },
};

const SENIORITY_COLOR: Record<string, string> = {
  'C-Level': '#7C3AED', 'VP': '#2563EB', 'Director': '#0891B2', 'Manager': '#059669', 'Other': '#64748B',
};

const BUYING_ROLE_ICON: Record<string, string> = {
  'Decision Maker': 'key', 'Economic Buyer': 'card', 'Technical': 'construct',
  'Influencer': 'megaphone', 'User': 'person',
};

const EVIDENCE_LABELS: Record<string, string> = {
  company_site: 'Company Website', press_release: 'Press Release',
  filing: 'Filing', investor_doc: 'Investor Doc',
  grant_doc: 'Grant Doc', procurement_doc: 'Procurement',
  conference_page: 'Conference', podcast_page: 'Podcast',
  trade_publication: 'Trade Pub', partner_site: 'Partner Site',
  linkedin_serp: 'LinkedIn', github: 'GitHub',
  news: 'News', wikipedia: 'Wikipedia',
  job_posting: 'Job Posting', serp: 'Web Search',
  llm_inference: 'Org Inference',
};

const BUCKET_CONFIG: Record<string, { label: string; color: string; icon: string }> = {
  official: { label: 'Official', color: '#059669', icon: 'shield-checkmark' },
  self_declared: { label: 'Self-declared', color: '#2563EB', icon: 'person-circle' },
  exposure: { label: 'Exposure', color: '#7C3AED', icon: 'mic' },
  third_party: { label: 'Third-party', color: '#D97706', icon: 'people' },
  weak_web: { label: 'Web', color: '#94A3B8', icon: 'globe-outline' },
};

const FRESHNESS_CONFIG: Record<string, { label: string; color: string }> = {
  recent: { label: 'Recent', color: '#059669' },
  aging: { label: 'Aging', color: '#D97706' },
  stale: { label: 'Stale', color: '#DC2626' },
};

const STRENGTH_ICON: Record<string, { icon: string; color: string }> = {
  strong: { icon: 'shield-checkmark', color: '#059669' },
  medium: { icon: 'shield-half', color: '#D97706' },
  weak: { icon: 'shield-outline', color: '#94A3B8' },
};

// ─── Component ──────────────────────────────────────────────────────────────

interface Props { navigation: any; }

export default function ContactSeekerAI({ navigation }: Props) {
  const companies = useQuery(api.companies.list);
  const contacts = useQuery(api.contacts.list, {});
  const orgSettings = useQuery(api.orgSettings.get);
  const createContact = useMutation(api.contacts.create);
  const seekContacts = useAction(api.contactPipeline.seekContactsV2);

  const [expanded, setExpanded] = useState(false);
  const [targetCompanyId, setTargetCompanyId] = useState<string | null>(null);
  const [geoScope, setGeoScope] = useState('');
  const [seeking, setSeeking] = useState(false);
  const [phaseLabel, setPhaseLabel] = useState('');
  const [verifiedResults, setVerifiedResults] = useState<PipelineContact[] | null>(null);
  const [probableResults, setProbableResults] = useState<PipelineContact[] | null>(null);
  const [inferredRoles, setInferredRoles] = useState<InferredRoleOutput[] | null>(null);
  const [summary, setSummary] = useState('');
  const [selectedContacts, setSelectedContacts] = useState<Set<string>>(new Set());
  const [addingContacts, setAddingContacts] = useState(false);
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());

  const targetCompany = useMemo(() => {
    if (!targetCompanyId || !companies) return null;
    return companies.find((c: any) => c._id === targetCompanyId) || null;
  }, [targetCompanyId, companies]);

  const existingContactNames = useMemo(() => {
    if (!contacts || !targetCompanyId) return new Set<string>();
    return new Set(
      contacts
        .filter((c: any) => c.companyId === targetCompanyId)
        .map((c: any) => `${c.firstName} ${c.lastName}`.toLowerCase().trim())
    );
  }, [contacts, targetCompanyId]);

  const allContacts = useMemo(() => {
    if (!verifiedResults && !probableResults) return null;
    return [...(verifiedResults || []), ...(probableResults || [])];
  }, [verifiedResults, probableResults]);

  const handleSeek = useCallback(async () => {
    if (!targetCompanyId || !targetCompany) {
      Alert.alert('Select Company', 'Pick a company first.');
      return;
    }

    setSeeking(true);
    setVerifiedResults(null);
    setProbableResults(null);
    setInferredRoles(null);
    setSummary('');
    setSelectedContacts(new Set());
    setExpandedCards(new Set());
    setPhaseLabel('Collecting data...');

    try {
      const existing = (contacts || [])
        .filter((c: any) => c.companyId === targetCompanyId)
        .map((c: any) => `${c.firstName} ${c.lastName}`)
        .slice(0, 20);

      const companyDomain = (targetCompany as any).domain || undefined;

      const phaseTimer1 = setTimeout(() => setPhaseLabel('Extracting anchors...'), 8000);
      const phaseTimer2 = setTimeout(() => setPhaseLabel('Multi-channel discovery...'), 18000);
      const phaseTimer3 = setTimeout(() => setPhaseLabel('Validating & scoring...'), 28000);

      const result = await seekContacts({
        companyName: (targetCompany as any).name,
        domain: companyDomain,
        geoScope: geoScope || undefined,
        existingContacts: existing,
        ourOffering: orgSettings?.interests || undefined,
      });

      clearTimeout(phaseTimer1);
      clearTimeout(phaseTimer2);
      clearTimeout(phaseTimer3);

      // Filter already-existing contacts
      const filterExisting = (list: PipelineContact[]) =>
        list.filter(c => !existingContactNames.has(c.name.toLowerCase().trim()));

      const v = filterExisting(result.verifiedContacts);
      const p = filterExisting(result.probableContacts);

      setVerifiedResults(v);
      setProbableResults(p);
      setInferredRoles(result.inferredRoles);
      setSummary(result.summary);

      if (v.length === 0 && p.length === 0 && result.inferredRoles.length === 0) {
        Alert.alert('No New Contacts', 'All discovered contacts are already in your CRM, or no contacts met validation criteria.');
      }
    } catch (err: any) {
      Alert.alert('Error', err.name === 'AbortError' ? 'Timeout' : (err.message || 'Search failed.'));
      console.log('Seek error:', err);
    } finally {
      setSeeking(false);
      setPhaseLabel('');
    }
  }, [targetCompanyId, targetCompany, orgSettings, contacts, geoScope, existingContactNames, seekContacts]);

  const toggleContact = (key: string) => {
    setSelectedContacts((prev: Set<string>) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const toggleCardExpansion = (key: string) => {
    setExpandedCards((prev: Set<string>) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  };

  const handleAddSelected = async () => {
    if (!allContacts || selectedContacts.size === 0 || !targetCompanyId) return;
    setAddingContacts(true);
    try {
      let added = 0;
      for (const c of allContacts) {
        const key = `${c.status}-${c.name}`;
        if (!selectedContacts.has(key)) continue;

        const parts = c.name.split(' ');
        const firstName = parts[0] || '';
        const lastName = parts.slice(1).join(' ') || '';

        const buckets = [...new Set(c.evidence.map((e: Evidence) => e.bucket))];
        const evidenceSummary = c.evidence
          .map((e: Evidence) => `${EVIDENCE_LABELS[e.type] || e.type} [${e.bucket}] (${e.strength})`)
          .join(', ');

        await createContact({
          firstName,
          lastName,
          title: c.title,
          companyId: targetCompanyId as any,
          email: c.email_guess || undefined,
          linkedin: c.linkedin_search_url,
          notes: [
            `Function: ${c.normalized_function}`,
            `Seniority: ${c.seniority}`,
            `Buying Role: ${c.buying_role}`,
            `Status: ${c.status}`,
            `Confidence: data=${(c.confidence_data * 100).toFixed(0)}% role=${(c.confidence_role_match * 100).toFixed(0)}% current=${(c.confidence_current * 100).toFixed(0)}%`,
            `Influence: ${c.influence_score}/5 (Org:${c.organizational_power} Func:${c.functional_relevance} Buy:${c.practical_buying})`,
            `Buckets: ${buckets.join(', ')}`,
            `Evidence: ${evidenceSummary}`,
            c.email_guess ? `Email (guessed, ${(c.email_guess_confidence * 100).toFixed(0)}% conf): ${c.email_guess}` : '',
          ].filter(Boolean).join(' | '),
        });
        added++;
      }
      Alert.alert('Added', `${added} contact${added === 1 ? '' : 's'} added to CRM.`);
      setSelectedContacts(new Set());
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to add contacts.');
    } finally {
      setAddingContacts(false);
    }
  };

  const totalContacts = allContacts?.length || 0;
  const hasResults = allContacts !== null || (inferredRoles && inferredRoles.length > 0);

  return (
    <View style={s.panel}>
      <TouchableOpacity style={s.panelHeader} onPress={() => setExpanded(!expanded)} activeOpacity={0.7}>
        <View style={s.headerLeft}>
          <Ionicons name="search" size={14} color={colors.accent} />
          <Text style={s.headerTitle}>Contact Discovery</Text>
          {targetCompany && <Text style={s.headerTarget} numberOfLines={1}>{(targetCompany as any).name}</Text>}
        </View>
        <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={18} color={colors.textTertiary} />
      </TouchableOpacity>

      {expanded && (
        <View style={s.panelBody}>
          {/* Company Selector */}
          <View style={s.selectorSection}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={s.chipScroll} scrollEventThrottle={16}>
              {companies?.map((item: any) => {
                const sel = targetCompanyId === item._id;
                return (
                  <TouchableOpacity
                    key={item._id}
                    style={[s.chip, sel && s.chipSelected]}
                    onPress={() => {
                      setTargetCompanyId(item._id);
                      setVerifiedResults(null);
                      setProbableResults(null);
                      setInferredRoles(null);
                      setSelectedContacts(new Set());
                      setExpandedCards(new Set());
                    }}
                  >
                    <Text style={[s.chipText, sel && s.chipTextSelected]} numberOfLines={1}>{item.name}</Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>

          <TextInput
            style={s.geoInput}
            placeholder="Geographic focus (optional)"
            placeholderTextColor={colors.textTertiary}
            value={geoScope}
            onChangeText={setGeoScope}
          />

          <TouchableOpacity
            style={[s.seekBtn, (!targetCompanyId || seeking) && s.seekBtnDisabled]}
            onPress={handleSeek}
            disabled={!targetCompanyId || seeking}
          >
            {seeking ? <ActivityIndicator size="small" color={colors.white} /> : <Ionicons name="search" size={14} color={colors.white} />}
            <Text style={s.seekBtnText}>{seeking ? phaseLabel || 'Seeking...' : 'Discover Contacts'}</Text>
          </TouchableOpacity>

          {/* Summary */}
          {summary ? (
            <View style={s.summaryBar}>
              <Ionicons name="information-circle-outline" size={14} color={colors.info} />
              <Text style={s.summaryText}>{summary}</Text>
            </View>
          ) : null}

          {/* Results */}
          {hasResults && (
            <View style={s.resultsSection}>
              {/* Bulk actions */}
              {totalContacts > 0 && (
                <View style={s.resultsHeader}>
                  <Text style={s.resultsTitle}>{totalContacts} Contacts</Text>
                  <TouchableOpacity
                    onPress={() => {
                      if (!allContacts) return;
                      if (selectedContacts.size === totalContacts) {
                        setSelectedContacts(new Set());
                      } else {
                        setSelectedContacts(new Set(allContacts.map((c: PipelineContact) => `${c.status}-${c.name}`)));
                      }
                    }}
                    style={s.selectAllBtn}
                  >
                    <Text style={s.selectAllText}>
                      {selectedContacts.size === totalContacts ? 'Deselect all' : 'Select all'}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}

              {selectedContacts.size > 0 && (
                <TouchableOpacity style={[s.addBtn, addingContacts && { opacity: 0.6 }]} onPress={handleAddSelected} disabled={addingContacts}>
                  {addingContacts ? <ActivityIndicator size="small" color={colors.white} /> : <Ionicons name="person-add" size={14} color={colors.white} />}
                  <Text style={s.addBtnText}>Add {selectedContacts.size} to CRM</Text>
                </TouchableOpacity>
              )}

              <ScrollView style={s.resultsList} nestedScrollEnabled showsVerticalScrollIndicator>
                {/* Verified Tier */}
                {verifiedResults && verifiedResults.length > 0 && renderTier('Verified', verifiedResults)}
                {/* Probable Tier */}
                {probableResults && probableResults.length > 0 && renderTier('Probable', probableResults)}
                {/* Inferred Roles */}
                {inferredRoles && inferredRoles.length > 0 && renderInferredRoles(inferredRoles)}
              </ScrollView>

              {totalContacts > 4 && (
                <Text style={s.scrollHint}>Scroll to see all results</Text>
              )}
            </View>
          )}
        </View>
      )}
    </View>
  );

  // ─── Tier Renderer ──────────────────────────────────────────────────────

  function renderTier(status: string, items: PipelineContact[]) {
    if (items.length === 0) return null;
    const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.Probable;

    return (
      <View key={status} style={s.tierSection}>
        <View style={[s.tierHeader, { backgroundColor: cfg.bg }]}>
          <Ionicons name={cfg.icon as any} size={14} color={cfg.color} />
          <Text style={[s.tierLabel, { color: cfg.color }]}>{cfg.label}</Text>
          <Text style={[s.tierCount, { color: cfg.color }]}>{items.length}</Text>
        </View>

        {items.map((contact, i) => renderContactCard(contact, `${status}-${contact.name}`))}
      </View>
    );
  }

  // ─── Contact Card ─────────────────────────────────────────────────────

  function renderContactCard(c: PipelineContact, key: string) {
    const isSelected = selectedContacts.has(key);
    const isExpanded = expandedCards.has(key);
    const statusCfg = STATUS_CONFIG[c.status] || STATUS_CONFIG.Probable;
    const freshCfg = FRESHNESS_CONFIG[c.freshness_label] || FRESHNESS_CONFIG.aging;
    const buckets = [...new Set(c.evidence.map(e => e.bucket))];

    return (
      <TouchableOpacity
        key={key}
        style={[s.card, isSelected && s.cardSelected]}
        onPress={() => toggleContact(key)}
        activeOpacity={0.7}
      >
        {/* Row 1: Checkbox + Name + Title */}
        <View style={s.cardRow}>
          <Ionicons
            name={isSelected ? 'checkbox' : 'square-outline'}
            size={20}
            color={isSelected ? colors.accent : colors.textTertiary}
            style={{ marginRight: 8 }}
          />
          <View style={s.cardMain}>
            <Text style={s.cardName} numberOfLines={1}>{c.name}</Text>
            <Text style={s.cardTitle} numberOfLines={1}>{c.title}</Text>
          </View>

          {/* Influence dots */}
          <View style={s.influenceDots}>
            {[1, 2, 3, 4, 5].map(n => (
              <View key={n} style={[s.dot, n <= Math.round(c.influence_score) ? s.dotFilled : s.dotEmpty]} />
            ))}
          </View>
        </View>

        {/* Row 2: Badges */}
        <View style={s.badgeRow}>
          <View style={[s.badge, { backgroundColor: SENIORITY_COLOR[c.seniority] || '#64748B' }]}>
            <Text style={s.badgeText}>{c.seniority}</Text>
          </View>
          <View style={[s.badge, { backgroundColor: colors.primary + '20' }]}>
            <Ionicons
              name={(BUYING_ROLE_ICON[c.buying_role] || 'person') as any}
              size={9}
              color={colors.primary}
              style={{ marginRight: 2 }}
            />
            <Text style={[s.badgeText, { color: colors.primary }]}>{c.buying_role}</Text>
          </View>
          <View style={[s.badge, { backgroundColor: freshCfg.color + '18' }]}>
            <Text style={[s.badgeText, { color: freshCfg.color }]}>{freshCfg.label}</Text>
          </View>
        </View>

        {/* Row 3: Evidence buckets */}
        <View style={s.bucketRow}>
          {buckets.map(b => {
            const bcfg = BUCKET_CONFIG[b];
            if (!bcfg) return null;
            return (
              <View key={b} style={[s.bucketBadge, { backgroundColor: bcfg.color + '15' }]}>
                <Ionicons name={bcfg.icon as any} size={9} color={bcfg.color} />
                <Text style={[s.bucketText, { color: bcfg.color }]}>{bcfg.label}</Text>
              </View>
            );
          })}
          {c.last_seen_date && (
            <Text style={s.lastSeen}>Last seen: {c.last_seen_date}</Text>
          )}
        </View>

        {/* Row 4: Confidence triptych */}
        <View style={s.confRow}>
          <View style={s.confItem}>
            <Text style={s.confLabel}>Data</Text>
            <Text style={s.confValue}>{(c.confidence_data * 100).toFixed(0)}%</Text>
          </View>
          <View style={s.confItem}>
            <Text style={s.confLabel}>Role</Text>
            <Text style={s.confValue}>{(c.confidence_role_match * 100).toFixed(0)}%</Text>
          </View>
          <View style={s.confItem}>
            <Text style={s.confLabel}>Current</Text>
            <Text style={[s.confValue, c.confidence_current < 0.5 && { color: '#DC2626' }]}>
              {(c.confidence_current * 100).toFixed(0)}%
            </Text>
          </View>
        </View>

        {/* Surfaced reason */}
        {c.surfaced_reason && (
          <Text style={s.surfacedReason} numberOfLines={2}>{c.surfaced_reason}</Text>
        )}

        {/* Expand toggle */}
        <TouchableOpacity
          style={s.expandRow}
          onPress={() => toggleCardExpansion(key)}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <Ionicons name={isExpanded ? 'chevron-up' : 'chevron-down'} size={12} color={colors.textTertiary} />
          <Text style={s.expandText}>
            {isExpanded ? 'Hide details' : `${c.evidence.length} signal${c.evidence.length !== 1 ? 's' : ''} · Details`}
          </Text>
        </TouchableOpacity>

        {/* Expanded details */}
        {isExpanded && (
          <View style={s.detailsBox}>
            {/* Evidence list */}
            <Text style={s.detailLabel}>Evidence</Text>
            {c.evidence.map((e, i) => {
              const si = STRENGTH_ICON[e.strength] || STRENGTH_ICON.weak;
              const bcfg = BUCKET_CONFIG[e.bucket];
              return (
                <View key={i} style={s.evidenceRow}>
                  <Ionicons name={si.icon as any} size={12} color={si.color} />
                  <Text style={s.evidenceText}>
                    {EVIDENCE_LABELS[e.type] || e.type}
                    {bcfg ? ` [${bcfg.label}]` : ''}
                    {e.date ? ` (${e.date})` : ''}
                  </Text>
                </View>
              );
            })}

            {/* Influence decomposition */}
            <Text style={[s.detailLabel, { marginTop: 6 }]}>Influence Breakdown</Text>
            <View style={s.influenceBreakdown}>
              <Text style={s.breakdownItem}>Org Power: {c.organizational_power}/5</Text>
              <Text style={s.breakdownItem}>Func Relevance: {c.functional_relevance}/5</Text>
              <Text style={s.breakdownItem}>Buying Role: {c.practical_buying}/5</Text>
            </View>

            {/* Reachability */}
            <Text style={[s.detailLabel, { marginTop: 6 }]}>Reachability</Text>
            <View style={s.reachRow}>
              <View style={s.reachBar}>
                <View style={[s.reachFill, { width: `${c.reachability_score * 100}%` }]} />
              </View>
              <Text style={s.reachValue}>{(c.reachability_score * 100).toFixed(0)}%</Text>
            </View>

            {c.email_guess && (
              <View style={s.reachItem}>
                <Ionicons name="mail-outline" size={12} color={colors.textSecondary} />
                <Text style={s.reachText}>
                  {c.email_guess}
                  <Text style={s.guessedLabel}> (guessed, {(c.email_guess_confidence * 100).toFixed(0)}% conf)</Text>
                </Text>
              </View>
            )}

            {/* Missing info */}
            {c.missing_info && c.missing_info !== 'Good coverage' && (
              <View style={s.missingRow}>
                <Ionicons name="warning-outline" size={12} color={colors.warning} />
                <Text style={s.missingText}>{c.missing_info}</Text>
              </View>
            )}

            {/* Suggested action */}
            {c.suggested_action && (
              <View style={s.actionRow}>
                <Ionicons name="arrow-forward-circle-outline" size={12} color={colors.info} />
                <Text style={s.actionText}>{c.suggested_action}</Text>
              </View>
            )}

            {/* LinkedIn */}
            <TouchableOpacity
              style={s.linkedinBtn}
              onPress={() => Linking.openURL(c.linkedin_search_url)}
            >
              <Ionicons name="logo-linkedin" size={14} color="#0A66C2" />
              <Text style={s.linkedinText}>Search on LinkedIn</Text>
            </TouchableOpacity>
          </View>
        )}
      </TouchableOpacity>
    );
  }

  // ─── Inferred Roles Section ───────────────────────────────────────────

  function renderInferredRoles(roles: InferredRoleOutput[]) {
    return (
      <View key="inferred" style={s.tierSection}>
        <View style={[s.tierHeader, { backgroundColor: '#EDE9FE' }]}>
          <Ionicons name="help-circle" size={14} color="#6366F1" />
          <Text style={[s.tierLabel, { color: '#6366F1' }]}>Likely Roles (No Names Found)</Text>
          <Text style={[s.tierCount, { color: '#6366F1' }]}>{roles.length}</Text>
        </View>

        <View style={s.inferredNote}>
          <Ionicons name="information-circle-outline" size={12} color="#6D28D9" />
          <Text style={s.inferredNoteText}>
            These roles likely exist at this company but no specific names were found. Use the suggested searches to identify who fills each role.
          </Text>
        </View>

        {roles.map((role, i) => (
          <View key={i} style={s.inferredCard}>
            <View style={s.inferredHeader}>
              <View style={{ flex: 1 }}>
                <Text style={s.inferredRoleLabel}>ROLE</Text>
                <Text style={s.inferredTitle}>{role.title}</Text>
              </View>
              <View style={[s.badge, { backgroundColor: SENIORITY_COLOR[role.seniority] || '#64748B' }]}>
                <Text style={s.badgeText}>{role.seniority}</Text>
              </View>
            </View>

            <View style={s.inferredMeta}>
              <View style={[s.bucketBadge, { backgroundColor: '#6D28D9' + '15' }]}>
                <Ionicons name="briefcase-outline" size={9} color="#6D28D9" />
                <Text style={[s.bucketText, { color: '#6D28D9' }]}>{role.normalized_function}</Text>
              </View>
              <View style={[s.bucketBadge, { backgroundColor: '#94A3B8' + '15' }]}>
                <Ionicons name="person-outline" size={9} color="#94A3B8" />
                <Text style={[s.bucketText, { color: '#94A3B8' }]}>No name identified</Text>
              </View>
            </View>

            <Text style={s.inferredReason}>{role.reason}</Text>

            <Text style={[s.detailLabel, { marginTop: 6 }]}>Find This Person</Text>
            {role.suggested_queries.map((q, qi) => (
              <TouchableOpacity
                key={qi}
                style={s.queryRow}
                onPress={() => Linking.openURL(`https://www.google.com/search?q=${encodeURIComponent(q)}`)}
              >
                <Ionicons name="search-outline" size={10} color={colors.accent} />
                <Text style={s.queryText} numberOfLines={1}>{q}</Text>
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    );
  }
}

// ─── Styles ─────────────────────────────────────────────────────────────────

const s = StyleSheet.create({
  panel: { backgroundColor: colors.white, borderRadius: radius.lg, marginHorizontal: spacing.lg, marginBottom: spacing.md, borderWidth: 1, borderColor: colors.accent + '20', ...shadow.sm },
  panelHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: spacing.md, paddingVertical: spacing.sm },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 },
  headerTitle: { fontSize: 12, fontWeight: '700', color: colors.textPrimary },
  headerTarget: { fontSize: 10, color: colors.accent, fontWeight: '600', flex: 1, marginLeft: 4 },
  panelBody: { paddingHorizontal: spacing.md, paddingBottom: spacing.md, borderTopWidth: 1, borderTopColor: colors.border, paddingTop: spacing.sm, gap: spacing.sm },
  selectorSection: { marginBottom: 2 },
  chipScroll: { paddingVertical: 4, gap: 6 },
  chip: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 16, backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border },
  chipSelected: { backgroundColor: colors.accent, borderColor: colors.accent },
  chipText: { fontSize: 11, color: colors.textPrimary, fontWeight: '500' },
  chipTextSelected: { color: colors.white, fontWeight: '600' },
  geoInput: { backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 6, fontSize: 11, color: colors.textPrimary },
  seekBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: colors.accent, paddingVertical: 8, borderRadius: radius.sm },
  seekBtnDisabled: { opacity: 0.5 },
  seekBtnText: { color: colors.white, fontWeight: '600', fontSize: 12 },
  summaryBar: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: colors.infoLight, paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.sm },
  summaryText: { fontSize: 10, color: colors.info, flex: 1, fontWeight: '500' },
  resultsSection: { marginTop: spacing.xs },
  resultsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: spacing.xs },
  resultsTitle: { fontSize: 12, fontWeight: '700', color: colors.textPrimary },
  selectAllBtn: { paddingHorizontal: 6, paddingVertical: 2 },
  selectAllText: { fontSize: 10, color: colors.accent, fontWeight: '600' },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, backgroundColor: colors.success, paddingVertical: 8, borderRadius: radius.sm, marginBottom: spacing.sm },
  addBtnText: { color: colors.white, fontWeight: '600', fontSize: 11 },
  resultsList: { maxHeight: 500 },
  scrollHint: { fontSize: 10, color: colors.textTertiary, textAlign: 'center', marginTop: 4 },

  // Tier sections
  tierSection: { marginBottom: spacing.sm },
  tierHeader: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.sm, marginBottom: 4 },
  tierLabel: { fontSize: 11, fontWeight: '700', flex: 1 },
  tierCount: { fontSize: 11, fontWeight: '700' },

  // Contact cards
  card: { backgroundColor: colors.bg, borderRadius: radius.md, padding: spacing.sm, marginBottom: 6, borderWidth: 1, borderColor: colors.border },
  cardSelected: { borderColor: colors.accent, backgroundColor: colors.accent + '08' },
  cardRow: { flexDirection: 'row', alignItems: 'center' },
  cardMain: { flex: 1 },
  cardName: { fontSize: 13, fontWeight: '700', color: colors.textPrimary },
  cardTitle: { fontSize: 11, color: colors.textSecondary, marginTop: 1 },
  influenceDots: { flexDirection: 'row', gap: 2, marginLeft: 8 },
  dot: { width: 6, height: 6, borderRadius: 3 },
  dotFilled: { backgroundColor: colors.accent },
  dotEmpty: { backgroundColor: colors.border },
  badgeRow: { flexDirection: 'row', gap: 4, marginTop: 6, flexWrap: 'wrap' },
  badge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  badgeText: { fontSize: 9, fontWeight: '600', color: colors.white },

  // Bucket badges
  bucketRow: { flexDirection: 'row', gap: 4, marginTop: 4, flexWrap: 'wrap', alignItems: 'center' },
  bucketBadge: { flexDirection: 'row', alignItems: 'center', gap: 2, paddingHorizontal: 5, paddingVertical: 1, borderRadius: 4 },
  bucketText: { fontSize: 8, fontWeight: '600' },
  lastSeen: { fontSize: 8, color: colors.textTertiary, marginLeft: 4 },

  // Confidence triptych
  confRow: { flexDirection: 'row', gap: 8, marginTop: 5, paddingVertical: 3, paddingHorizontal: 4, backgroundColor: colors.white, borderRadius: 4 },
  confItem: { alignItems: 'center', flex: 1 },
  confLabel: { fontSize: 8, color: colors.textTertiary, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.3 },
  confValue: { fontSize: 11, fontWeight: '700', color: colors.textPrimary, marginTop: 1 },

  // Surfaced reason
  surfacedReason: { fontSize: 9, color: colors.textSecondary, marginTop: 4, fontStyle: 'italic' },

  expandRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 6 },
  expandText: { fontSize: 10, color: colors.textTertiary },

  // Details (expanded)
  detailsBox: { marginTop: 6, paddingTop: 6, borderTopWidth: 1, borderTopColor: colors.border },
  detailLabel: { fontSize: 10, fontWeight: '700', color: colors.textSecondary, marginBottom: 3, textTransform: 'uppercase', letterSpacing: 0.5 },
  evidenceRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 2 },
  evidenceText: { fontSize: 10, color: colors.textSecondary, flex: 1 },

  // Influence breakdown
  influenceBreakdown: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  breakdownItem: { fontSize: 9, color: colors.textSecondary, backgroundColor: colors.bg, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },

  // Reachability
  reachRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 4 },
  reachBar: { flex: 1, height: 4, backgroundColor: colors.border, borderRadius: 2, overflow: 'hidden' },
  reachFill: { height: '100%', backgroundColor: colors.success, borderRadius: 2 },
  reachValue: { fontSize: 10, fontWeight: '600', color: colors.textSecondary, width: 30 },
  reachItem: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 2 },
  reachText: { fontSize: 10, color: colors.textSecondary, flex: 1 },
  guessedLabel: { fontSize: 9, color: colors.warning, fontStyle: 'italic' },

  // Missing / Action
  missingRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4, backgroundColor: '#FEF3C7', paddingHorizontal: 6, paddingVertical: 3, borderRadius: 4 },
  missingText: { fontSize: 9, color: '#92400E', flex: 1 },
  actionRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3, backgroundColor: colors.infoLight, paddingHorizontal: 6, paddingVertical: 3, borderRadius: 4 },
  actionText: { fontSize: 9, color: colors.info, flex: 1, fontWeight: '500' },

  linkedinBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 6, marginTop: 4 },
  linkedinText: { fontSize: 11, color: '#0A66C2', fontWeight: '600' },

  // Inferred roles
  inferredCard: { backgroundColor: '#F5F3FF', borderRadius: radius.md, padding: spacing.sm, marginBottom: 6, borderWidth: 1, borderColor: '#DDD6FE' },
  inferredHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  inferredTitle: { fontSize: 12, fontWeight: '700', color: '#4C1D95' },
  inferredRoleLabel: { fontSize: 8, fontWeight: '700', color: '#7C3AED', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 1 },
  inferredMeta: { flexDirection: 'row', gap: 4, marginTop: 4 },
  inferredFunction: { fontSize: 10, color: '#6D28D9', fontWeight: '500' },
  inferredReason: { fontSize: 9, color: '#7C3AED', marginTop: 4, fontStyle: 'italic' },
  queryRow: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 2 },
  queryText: { fontSize: 9, color: colors.accent, textDecorationLine: 'underline', flex: 1 },
  inferredNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, backgroundColor: '#F5F3FF', paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.sm, marginBottom: 4, borderWidth: 1, borderColor: '#DDD6FE' },
  inferredNoteText: { fontSize: 9, color: '#6D28D9', flex: 1, lineHeight: 14 },
});