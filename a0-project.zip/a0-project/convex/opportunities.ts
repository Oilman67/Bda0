import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

// Generate serial reference: OPYYxxx (e.g., OP26001)
async function generateReference(ctx: any, orgId: any): Promise<string> {
  const year = new Date().getFullYear() % 100;
  const yearStr = year.toString().padStart(2, '0');
  const prefix = `OP${yearStr}`;

  const allOpps = await ctx.db
    .query("opportunities")
    .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
    .collect();

  let maxSerial = 0;
  for (const o of allOpps) {
    if (o.deletedAt || !o.reference || !o.reference.startsWith(prefix)) continue;
    const num = parseInt(o.reference.slice(4), 10);
    if (!isNaN(num) && num > maxSerial) maxSerial = num;
  }

  const nextSerial = (maxSerial + 1).toString().padStart(3, '0');
  return `${prefix}${nextSerial}`;
}

// Status definitions
const VALID_STATUSES = ['early_planning', 'rfi', 'rfp', 'rfq', 'won', 'lost'];

export const list = query({
  args: {
    pipelineId: v.optional(v.id("pipelines")),
    status: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
  },
  returns: v.array(v.object({
    _id: v.id("opportunities"),
    _creationTime: v.number(),
    reference: v.optional(v.string()),
    title: v.string(),
    value: v.optional(v.number()),
    currency: v.optional(v.string()),
    stageId: v.optional(v.id("pipelineStages")),
    stageName: v.optional(v.string()),
    stageColor: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    contactName: v.optional(v.string()),
    status: v.string(),
    closeDate: v.optional(v.number()),
    probability: v.optional(v.number()),
    location: v.optional(v.string()),
    lostCompetitor: v.optional(v.string()),
  })),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    let opps;
    if (args.companyId) {
      opps = await ctx.db
        .query("opportunities")
        .withIndex("by_org_and_company", (q: any) => q.eq("orgId", orgId).eq("companyId", args.companyId))
        .order("desc")
        .collect();
    } else if (args.status) {
      opps = await ctx.db
        .query("opportunities")
        .withIndex("by_org_and_status", (q: any) => q.eq("orgId", orgId).eq("status", args.status))
        .order("desc")
        .collect();
    } else if (args.pipelineId) {
      opps = await ctx.db
        .query("opportunities")
        .withIndex("by_org_and_pipeline", (q: any) => q.eq("orgId", orgId).eq("pipelineId", args.pipelineId))
        .order("desc")
        .collect();
    } else {
      opps = await ctx.db
        .query("opportunities")
        .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
        .order("desc")
        .collect();
    }

    const result = [];
    for (const o of opps) {
      if (o.deletedAt) continue;
      let stageName: string | undefined;
      let stageColor: string | undefined;
      if (o.stageId) {
        const stage = await ctx.db.get(o.stageId);
        if (stage) { stageName = stage.name; stageColor = stage.color; }
      }
      let companyName: string | undefined;
      if (o.companyId) {
        const company = await ctx.db.get(o.companyId);
        companyName = company?.name;
      }
      let contactName: string | undefined;
      if (o.contactId) {
        const contact = await ctx.db.get(o.contactId);
        if (contact) contactName = `${contact.firstName} ${contact.lastName}`;
      }
      result.push({
        _id: o._id,
        _creationTime: o._creationTime,
        reference: o.reference,
        title: o.title,
        value: o.value,
        currency: o.currency,
        stageId: o.stageId,
        stageName,
        stageColor,
        companyId: o.companyId,
        companyName,
        contactName,
        status: o.status || 'early_planning',
        closeDate: o.closeDate,
        probability: o.probability,
        location: o.location,
        lostCompetitor: o.lostCompetitor,
      });
    }
    return result;
  },
});

export const listByCompany = query({
  args: { companyId: v.id("companies") },
  returns: v.array(v.object({
    _id: v.id("opportunities"),
    _creationTime: v.number(),
    reference: v.optional(v.string()),
    title: v.string(),
    value: v.optional(v.number()),
    stageName: v.optional(v.string()),
    stageColor: v.optional(v.string()),
    status: v.string(),
  })),
  handler: async (ctx, { companyId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const opps = await ctx.db
      .query("opportunities")
      .withIndex("by_org_and_company", (q: any) => q.eq("orgId", orgId).eq("companyId", companyId))
      .order("desc")
      .collect();
    const result = [];
    for (const o of opps) {
      if (o.deletedAt) continue;
      let stageName: string | undefined;
      let stageColor: string | undefined;
      if (o.stageId) {
        const stage = await ctx.db.get(o.stageId);
        if (stage) { stageName = stage.name; stageColor = stage.color; }
      }
      result.push({
        _id: o._id,
        _creationTime: o._creationTime,
        reference: o.reference,
        title: o.title,
        value: o.value,
        stageName,
        stageColor,
        status: o.status || 'early_planning',
      });
    }
    return result;
  },
});

export const get = query({
  args: { id: v.id("opportunities") },
  returns: v.union(v.object({
    _id: v.id("opportunities"),
    _creationTime: v.number(),
    reference: v.optional(v.string()),
    title: v.string(),
    value: v.optional(v.number()),
    currency: v.optional(v.string()),
    pipelineId: v.optional(v.id("pipelines")),
    stageId: v.optional(v.id("pipelineStages")),
    stageName: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    contactId: v.optional(v.id("contacts")),
    contactName: v.optional(v.string()),
    ownerId: v.optional(v.id("users")),
    closeDate: v.optional(v.number()),
    probability: v.optional(v.number()),
    status: v.string(),
    location: v.optional(v.string()),
    lostCompetitor: v.optional(v.string()),
    notes: v.optional(v.string()),
    strategistReport: v.optional(v.string()),
    strategistGeneratedAt: v.optional(v.number()),
  }), v.null()),
  handler: async (ctx, { id }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return null;
    const { orgId } = auth;
    const o = await ctx.db.get(id);
    if (!o || o.orgId !== orgId || o.deletedAt) return null;
    let stageName: string | undefined;
    if (o.stageId) {
      const stage = await ctx.db.get(o.stageId);
      stageName = stage?.name;
    }
    let companyName: string | undefined;
    if (o.companyId) {
      const c = await ctx.db.get(o.companyId);
      companyName = c?.name;
    }
    let contactName: string | undefined;
    if (o.contactId) {
      const c = await ctx.db.get(o.contactId);
      if (c) contactName = `${c.firstName} ${c.lastName}`;
    }
    return {
      _id: o._id,
      _creationTime: o._creationTime,
      reference: o.reference,
      title: o.title,
      value: o.value,
      currency: o.currency,
      pipelineId: o.pipelineId,
      stageId: o.stageId,
      stageName,
      companyId: o.companyId,
      companyName,
      contactId: o.contactId,
      contactName,
      ownerId: o.ownerId,
      closeDate: o.closeDate,
      probability: o.probability,
      status: o.status || 'early_planning',
      location: o.location,
      lostCompetitor: o.lostCompetitor,
      notes: o.notes,
      strategistReport: o.strategistReport,
      strategistGeneratedAt: o.strategistGeneratedAt,
    };
  },
});

export const create = mutation({
  args: {
    title: v.string(),
    companyId: v.id("companies"), // required
    value: v.optional(v.number()),
    currency: v.optional(v.string()),
    pipelineId: v.optional(v.id("pipelines")),
    stageId: v.optional(v.id("pipelineStages")),
    contactId: v.optional(v.id("contacts")),
    closeDate: v.optional(v.number()),
    probability: v.optional(v.number()),
    status: v.optional(v.string()),
    location: v.optional(v.string()),
    lostCompetitor: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  returns: v.id("opportunities"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const reference = await generateReference(ctx, orgId);
    const status = args.status && VALID_STATUSES.includes(args.status) ? args.status : 'early_planning';

    const id = await ctx.db.insert("opportunities", {
      orgId,
      reference,
      title: args.title,
      companyId: args.companyId,
      value: args.value,
      currency: args.currency,
      pipelineId: args.pipelineId,
      stageId: args.stageId,
      contactId: args.contactId,
      closeDate: args.closeDate,
      probability: args.probability,
      status,
      location: args.location,
      lostCompetitor: args.lostCompetitor,
      notes: args.notes,
      ownerId: userId,
    });

    if (args.stageId) {
      await ctx.db.insert("opportunityStageChanges", {
        orgId, opportunityId: id, toStageId: args.stageId, userId, changedAt: Date.now(),
      });
    }
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "create", entityType: "opportunity", entityId: id, timestamp: Date.now(),
    });
    return id;
  },
});

export const update = mutation({
  args: {
    id: v.id("opportunities"),
    title: v.optional(v.string()),
    value: v.optional(v.number()),
    currency: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    stageId: v.optional(v.id("pipelineStages")),
    contactId: v.optional(v.id("contacts")),
    closeDate: v.optional(v.number()),
    probability: v.optional(v.number()),
    status: v.optional(v.string()),
    location: v.optional(v.string()),
    lostCompetitor: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, { id, ...updates }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const o = await ctx.db.get(id);
    if (!o || o.orgId !== orgId) throw new Error("Not found");

    if (updates.stageId && updates.stageId !== o.stageId) {
      await ctx.db.insert("opportunityStageChanges", {
        orgId,
        opportunityId: id,
        fromStageId: o.stageId,
        toStageId: updates.stageId,
        userId,
        changedAt: Date.now(),
      });
    }

    // Validate status
    if (updates.status && !VALID_STATUSES.includes(updates.status)) {
      delete updates.status;
    }

    const patch: any = {};
    for (const [k, val] of Object.entries(updates)) {
      if (val !== undefined) patch[k] = val;
    }
    if (Object.keys(patch).length > 0) await ctx.db.patch(id, patch);
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "update", entityType: "opportunity", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("opportunities") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const o = await ctx.db.get(id);
    if (!o || o.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, { deletedAt: Date.now() });
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "delete", entityType: "opportunity", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const moveStage = mutation({
  args: {
    id: v.id("opportunities"),
    stageId: v.id("pipelineStages"),
  },
  returns: v.null(),
  handler: async (ctx, { id, stageId }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const o = await ctx.db.get(id);
    if (!o || o.orgId !== orgId) throw new Error("Not found");
    if (o.stageId === stageId) return null;

    await ctx.db.insert("opportunityStageChanges", {
      orgId, opportunityId: id, fromStageId: o.stageId, toStageId: stageId, userId, changedAt: Date.now(),
    });
    await ctx.db.patch(id, { stageId });
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "stage_change", entityType: "opportunity", entityId: id,
      details: JSON.stringify({ from: o.stageId, to: stageId }),
      timestamp: Date.now(),
    });
    return null;
  },
});

export const getStageHistory = query({
  args: { opportunityId: v.id("opportunities") },
  returns: v.array(v.object({
    fromStage: v.optional(v.string()),
    toStage: v.string(),
    user: v.optional(v.string()),
    changedAt: v.number(),
  })),
  handler: async (ctx, { opportunityId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const changes = await ctx.db
      .query("opportunityStageChanges")
      .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", opportunityId))
      .order("asc")
      .collect();
    const result = [];
    for (const c of changes) {
      let fromStage: string | undefined;
      let toStage = "Unknown";
      if (c.fromStageId) {
        const s = await ctx.db.get(c.fromStageId);
        if (s) fromStage = s.name;
      }
      const ts = await ctx.db.get(c.toStageId);
      if (ts) toStage = ts.name;
      let userName: string | undefined;
      const u = await ctx.db.get(c.userId);
      if (u) userName = u.name || u.email;
      result.push({ fromStage, toStage, user: userName, changedAt: c.changedAt });
    }
    return result;
  },
});

export const saveStrategistReport = mutation({
  args: {
    id: v.id("opportunities"),
    report: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, { id, report }) => {
    const { orgId } = await getUserOrgId(ctx);
    const o = await ctx.db.get(id);
    if (!o || o.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, {
      strategistReport: report,
      strategistGeneratedAt: Date.now(),
    });
    return null;
  },
});