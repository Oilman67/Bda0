import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getOrCreateOrg, getUserId, safeGetUserOrgId } from "./helpers";

export const get = query({
  args: {},
  returns: v.union(
    v.object({
      _id: v.id("orgSettings"),
      companyName: v.string(),
      companyUrl: v.optional(v.string()),
      interests: v.string(),
      taxonomyProfile: v.optional(v.string()),
      businessContext: v.optional(v.string()),
    }),
    v.null()
  ),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return null;
    const { orgId } = auth;
    const settings = await ctx.db
      .query("orgSettings")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .unique();
    if (!settings) return null;
    return {
      _id: settings._id,
      companyName: settings.companyName,
      companyUrl: settings.companyUrl,
      interests: settings.interests,
      taxonomyProfile: settings.taxonomyProfile,
      businessContext: settings.businessContext,
    };
  },
});

export const upsert = mutation({
  args: {
    companyName: v.string(),
    companyUrl: v.optional(v.string()),
    interests: v.string(),
    taxonomyProfile: v.optional(v.string()),
    businessContext: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    const orgId = await getOrCreateOrg(ctx, userId);
    const existing = await ctx.db
      .query("orgSettings")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .unique();
    if (existing) {
      await ctx.db.patch(existing._id, {
        companyName: args.companyName,
        companyUrl: args.companyUrl,
        interests: args.interests,
        taxonomyProfile: args.taxonomyProfile,
        businessContext: args.businessContext,
      });
    } else {
      await ctx.db.insert("orgSettings", { orgId, ...args });
    }
    return null;
  },
});

export const saveBusinessContext = mutation({
  args: {
    businessContext: v.string(), // JSON string
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    const orgId = await getOrCreateOrg(ctx, userId);
    const existing = await ctx.db
      .query("orgSettings")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .unique();
    if (existing) {
      await ctx.db.patch(existing._id, { businessContext: args.businessContext });
    }
    return null;
  },
});