// BDBuddy Custom Industry Taxonomy
// 10 Sectors > ~35 Industries > ~70 Sub-Industries

export interface TaxonomySubIndustry {
  name: string;
}

export interface TaxonomyIndustry {
  name: string;
  children: TaxonomySubIndustry[];
}

export interface TaxonomySector {
  name: string;
  color: string;
  children: TaxonomyIndustry[];
}

export const SECTORS: TaxonomySector[] = [
  {
    name: "Energy & Natural Resources",
    color: "#D97706",
    children: [
      { name: "Oil & Gas", children: [
        { name: "Upstream Exploration & Production" },
        { name: "Midstream & Pipelines" },
        { name: "Downstream & Refining" },
        { name: "Integrated Oil & Gas" },
        { name: "LNG & Gas Processing" },
      ]},
      { name: "Mining & Metals", children: [
        { name: "Diversified Mining" },
        { name: "Precious Metals" },
        { name: "Base Metals & Steel" },
      ]},
      { name: "Renewables & Clean Energy", children: [
        { name: "Solar & Wind" },
        { name: "Hydrogen & Fuel Cells" },
        { name: "Carbon Capture & Storage" },
        { name: "Battery & Energy Storage" },
      ]},
      { name: "Power & Utilities", children: [
        { name: "Electric Utilities" },
        { name: "Gas Utilities" },
        { name: "Water & Wastewater" },
        { name: "Multi-Utilities" },
      ]},
    ],
  },
  {
    name: "Industrials & Manufacturing",
    color: "#2563EB",
    children: [
      { name: "Aerospace & Defense", children: [
        { name: "Commercial Aerospace" },
        { name: "Defense Systems & Services" },
        { name: "Space & Satellite" },
      ]},
      { name: "Construction & Engineering", children: [
        { name: "General Contractors & EPC" },
        { name: "Engineering & Design Services" },
        { name: "Specialty Construction" },
        { name: "Building Materials" },
      ]},
      { name: "Heavy Industry & Equipment", children: [
        { name: "Industrial Machinery" },
        { name: "Process Manufacturing" },
        { name: "Automation & Robotics" },
      ]},
      { name: "Transportation & Logistics", children: [
        { name: "Shipping & Marine" },
        { name: "Rail & Trucking" },
        { name: "Warehousing & Distribution" },
        { name: "Ports & Terminals" },
      ]},
    ],
  },
  {
    name: "Technology & Digital",
    color: "#6366F1",
    children: [
      { name: "Software & SaaS", children: [
        { name: "Enterprise Software" },
        { name: "Cloud & Infrastructure" },
        { name: "Cybersecurity" },
        { name: "Data & Analytics" },
      ]},
      { name: "IT Services & Consulting", children: [
        { name: "IT Consulting" },
        { name: "Managed Services" },
        { name: "System Integration" },
      ]},
      { name: "Hardware & Semiconductors", children: [
        { name: "Computing & Networking" },
        { name: "Semiconductors" },
        { name: "IoT & Edge Devices" },
      ]},
      { name: "Telecom & Communications", children: [
        { name: "Wireless Carriers" },
        { name: "Wireline & Fiber" },
        { name: "Tower & Infrastructure" },
      ]},
    ],
  },
  {
    name: "Financial Services",
    color: "#0D9488",
    children: [
      { name: "Banking", children: [
        { name: "Commercial Banking" },
        { name: "Investment Banking" },
        { name: "Private Banking & Wealth" },
      ]},
      { name: "Insurance", children: [
        { name: "Property & Casualty" },
        { name: "Life & Health" },
        { name: "Reinsurance" },
      ]},
      { name: "Asset Management & Investment", children: [
        { name: "Private Equity & Venture Capital" },
        { name: "Hedge Funds & Alternatives" },
        { name: "Wealth Management" },
      ]},
      { name: "Fintech & Payments", children: [
        { name: "Payment Processing" },
        { name: "Digital Banking" },
        { name: "Financial Infrastructure" },
      ]},
    ],
  },
  {
    name: "Healthcare & Life Sciences",
    color: "#DC2626",
    children: [
      { name: "Pharma & Biotech", children: [
        { name: "Pharmaceuticals" },
        { name: "Biotechnology" },
        { name: "Contract Research & Manufacturing" },
      ]},
      { name: "Medical Devices & Equipment", children: [
        { name: "Medical Devices" },
        { name: "Diagnostics & Lab Equipment" },
        { name: "Digital Health" },
      ]},
      { name: "Healthcare Services", children: [
        { name: "Hospitals & Health Systems" },
        { name: "Managed Care" },
        { name: "Home Health & Long-term Care" },
      ]},
    ],
  },
  {
    name: "Consumer & Retail",
    color: "#7C3AED",
    children: [
      { name: "Consumer Products", children: [
        { name: "Food & Beverage" },
        { name: "Personal Care & Household" },
        { name: "Apparel & Luxury" },
      ]},
      { name: "Retail & E-Commerce", children: [
        { name: "E-Commerce & Marketplace" },
        { name: "Specialty Retail" },
        { name: "Grocery & Mass Retail" },
      ]},
      { name: "Hospitality & Leisure", children: [
        { name: "Hotels & Resorts" },
        { name: "Restaurants & Food Service" },
        { name: "Travel & Tourism" },
      ]},
    ],
  },
  {
    name: "Real Estate & Infrastructure",
    color: "#9333EA",
    children: [
      { name: "Commercial Real Estate", children: [
        { name: "Office & Retail Properties" },
        { name: "Industrial & Logistics" },
        { name: "Data Centers" },
      ]},
      { name: "Residential Real Estate", children: [
        { name: "Real Estate Development" },
        { name: "Property Management" },
      ]},
      { name: "Infrastructure", children: [
        { name: "Airports & Ports" },
        { name: "Toll Roads & Rail" },
        { name: "Social Infrastructure" },
      ]},
    ],
  },
  {
    name: "Government & Public Sector",
    color: "#475569",
    children: [
      { name: "Federal & National Government", children: [
        { name: "Federal Agencies" },
        { name: "Defense & Intelligence" },
      ]},
      { name: "Municipal & Regional Government", children: [
        { name: "City & County" },
        { name: "State & Provincial" },
      ]},
      { name: "Regulatory & Compliance Bodies", children: [
        { name: "Industry Regulators" },
        { name: "Environmental Agencies" },
      ]},
    ],
  },
  {
    name: "Professional Services",
    color: "#0891B2",
    children: [
      { name: "Management Consulting", children: [
        { name: "Strategy Consulting" },
        { name: "Operations Consulting" },
        { name: "Technology Consulting" },
      ]},
      { name: "Legal & Accounting", children: [
        { name: "Legal Services" },
        { name: "Accounting & Audit" },
        { name: "Tax Advisory" },
      ]},
      { name: "Staffing & HR Services", children: [
        { name: "Staffing & Recruitment" },
        { name: "HR Outsourcing" },
      ]},
    ],
  },
  {
    name: "Agriculture & Environment",
    color: "#059669",
    children: [
      { name: "Agriculture & Food Production", children: [
        { name: "Farming & Crop Production" },
        { name: "Animal Agriculture" },
        { name: "AgTech & Precision Agriculture" },
      ]},
      { name: "Environmental Services", children: [
        { name: "Waste Management & Recycling" },
        { name: "Environmental Consulting" },
        { name: "Water Treatment" },
      ]},
    ],
  },
];

export const SECTOR_NAMES: string[] = SECTORS.map(s => s.name);

export function formatTaxonomyForPrompt(): string {
  const lines: string[] = [];
  for (const sector of SECTORS) {
    lines.push(sector.name + ":");
    for (const ind of sector.children) {
      const subs = ind.children.map(s => s.name).join(", ");
      lines.push("  " + ind.name + ": " + subs);
    }
  }
  return lines.join("\n");
}

export const COMPANY_ROLES: { value: string; label: string; description: string }[] = [
  { value: "primary_target", label: "Primary Target", description: "Main buyer / client you are selling to" },
  { value: "technical_influencer", label: "Technical Influencer", description: "Validates solution technically" },
  { value: "financial_gatekeeper", label: "Financial Gatekeeper", description: "Controls or approves budget" },
  { value: "infrastructure_partner", label: "Infrastructure Partner", description: "System integrator, utility, pipeline company" },
  { value: "regulatory", label: "Regulatory/Compliance", description: "Government or regulatory body" },
  { value: "vendor", label: "Vendor/Supplier", description: "Supplies products or services to the deal" },
  { value: "consortium_member", label: "Consortium Member", description: "Joint venture or consortium participant" },
  { value: "end_user", label: "End User", description: "Ultimate user of the product/service" },
  { value: "other", label: "Other", description: "Other stakeholder type" },
];
