// Default segment taxonomy for BDBuddy — BD-focused, custom structure
// Maps our taxonomy data into the segment seeding format
// L1 = Sector, L2 = Industry, L3 = Sub-Industry

import { SECTORS } from "./taxonomyData";

export interface DefaultSegmentL3 { name: string; }
export interface DefaultSegmentL2 { name: string; children: DefaultSegmentL3[]; }
export interface DefaultSegmentL1 { name: string; level: number; color: string; children: DefaultSegmentL2[]; }

export const DEFAULT_SEGMENTS: DefaultSegmentL1[] = SECTORS.map(sector => ({
  name: sector.name,
  level: 1,
  color: sector.color,
  children: sector.children.map(ind => ({
    name: ind.name,
    children: ind.children.map(sub => ({ name: sub.name })),
  })),
}));