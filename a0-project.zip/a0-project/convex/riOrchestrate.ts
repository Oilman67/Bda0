"use node";

import { internalAction } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

export const analyzeContact = internalAction({
  args: {
    orgId: v.id("orgs"),
    contactId: v.id("contacts"),
    context: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    // Parse the context
    let parsed: any = {};
    try {
      parsed = JSON.parse(args.context);
    } catch {
      console.error("[RI] Failed to parse context JSON");
      return null;
    }

    const contact = parsed.contact || {};
    const opportunities = parsed.opportunities || [];
    const allInteractions = parsed.allInteractions || [];

    if (opportunities.length === 0) {
      console.log("[RI] No opportunities in context — will run TECOPS only");
    }

    // ── Call 1: TECOPS (Contact-level profile from entire portfolio) ──
    console.log("[RI] Starting TECOPS analysis for contact", args.contactId);

    let tecopsMessage = `Profile the following stakeholder's professional lens and priorities based on their role, interactions, and notes across their entire portfolio.\n\n`;
    tecopsMessage += `CONTACT: ${contact.name || "Unknown"}`;
    if (contact.title) tecopsMessage += `, ${contact.title}`;
    if (contact.company) tecopsMessage += ` at ${contact.company}`;
    tecopsMessage += `\n`;
    if (contact.notes) tecopsMessage += `Contact Notes: ${contact.notes}\n`;
    if (contact.companyNotes) tecopsMessage += `Company Notes: ${contact.companyNotes}\n`;
    if (contact.companyRoleNotes) tecopsMessage += `Company Role Context: ${contact.companyRoleNotes}\n`;

    tecopsMessage += `\nPORTFOLIO OVERVIEW (${opportunities.length} opportunities):\n`;
    for (const opp of opportunities) {
      tecopsMessage += `- "${opp.title}" (${opp.status})`;
      if (opp.stage) tecopsMessage += ` | Stage: ${opp.stage}`;
      tecopsMessage += `\n`;
    }

    if (allInteractions.length > 0) {
      tecopsMessage += `\nALL INTERACTIONS WITH THIS CONTACT (${allInteractions.length} total):\n`;
      for (const i of allInteractions) {
        tecopsMessage += `- ${i.type}${i.subject ? `: ${i.subject}` : ""} (${i.date})`;
        if (i.body) tecopsMessage += `\n  ${i.body}`;
        tecopsMessage += `\n`;
      }
    }

    try {
      const tecopsResponse = await fetch("https://api.a0.dev/ai/llm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content: `You are a B2B stakeholder profiling analyst using the TECOPS framework. Analyze the stakeholder's PERSONAL LENS — what matters to them professionally, based on their title, role, interactions, and notes. This is about WHO THEY ARE as a professional, not about any specific deal.\n\nTECOPS dimensions:\n- T (Technical): technology, performance, integration, specs, reliability\n- E (Economical): ROI, cost, budget, financial impact\n- C (Commercial): market position, contracts, pricing, terms\n- O (Operational): execution, day-to-day operations, HSE, reliability\n- P (Political): regulatory, organizational politics, policy compliance\n- S (Sustainability): ESG, emissions, environmental, social responsibility\n\nScore each 0-3 (0=Not relevant to this person, 1=Secondary concern, 2=Important, 3=Primary driver). At least one dimension must be 3.`,
            },
            { role: "user", content: tecopsMessage },
          ],
          schema: {
            type: "object",
            properties: {
              T: { type: "number", description: "Technical score 0-3" },
              E: { type: "number", description: "Economical score 0-3" },
              C: { type: "number", description: "Commercial score 0-3" },
              O: { type: "number", description: "Operational score 0-3" },
              P: { type: "number", description: "Political score 0-3" },
              S: { type: "number", description: "Sustainability score 0-3" },
              primaryRiskDriver: { type: "string", description: "One of T, E, C, O, P, S" },
              secondaryRiskDriver: { type: "string", description: "One of T, E, C, O, P, S (different from primary)" },
            },
            required: ["T", "E", "C", "O", "P", "S", "primaryRiskDriver", "secondaryRiskDriver"],
          },
        }),
      });

      const tecopsData = await tecopsResponse.json();
      console.log("[RI] TECOPS LLM response status:", tecopsResponse.status, "has schema_data:", !!tecopsData.schema_data, "completion length:", (tecopsData.completion || "").length);

      let tecopsProfile: any = null;
      if (tecopsData.schema_data?.T !== undefined) {
        tecopsProfile = tecopsData.schema_data;
      } else if (tecopsData.completion) {
        try {
          tecopsProfile = JSON.parse(tecopsData.completion);
        } catch {
          console.error("[RI] Could not parse TECOPS completion as JSON");
        }
      }

      if (tecopsProfile && tecopsProfile.T !== undefined) {
        const profile = {
          T: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.T) || 0))),
          E: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.E) || 0))),
          C: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.C) || 0))),
          O: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.O) || 0))),
          P: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.P) || 0))),
          S: Math.max(0, Math.min(3, Math.round(Number(tecopsProfile.S) || 0))),
          primaryRiskDriver: String(tecopsProfile.primaryRiskDriver || "E"),
          secondaryRiskDriver: String(tecopsProfile.secondaryRiskDriver || "T"),
        };
        await ctx.runMutation(internal.relationshipIntelligence.upsertTECOPS, {
          contactId: args.contactId,
          tecopsProfile: JSON.stringify(profile),
        });
        console.log("[RI] Saved TECOPS profile on contact:", profile.primaryRiskDriver, "/", profile.secondaryRiskDriver);
      } else {
        console.error("[RI] No TECOPS data from LLM, using heuristic fallback");
        // Heuristic TECOPS fallback based on title
        const title = (contact.title || "").toLowerCase();
        let T = 1, E = 2, C = 1, O = 1, P = 0, S_ = 0;
        let primary = "E", secondary = "T";
        if (title.includes("tech") || title.includes("engineer") || title.includes("it")) {
          T = 3; E = 1; primary = "T"; secondary = "O";
        } else if (title.includes("financ") || title.includes("cfo") || title.includes("budget")) {
          E = 3; C = 2; primary = "E"; secondary = "C";
        } else if (title.includes("operat") || title.includes("hse") || title.includes("plant")) {
          O = 3; T = 2; primary = "O"; secondary = "T";
        } else if (title.includes("sustain") || title.includes("esg") || title.includes("environ")) {
          S_ = 3; P = 2; primary = "S"; secondary = "P";
        } else if (title.includes("commerc") || title.includes("sales") || title.includes("business dev")) {
          C = 3; E = 2; primary = "C"; secondary = "E";
        } else {
          E = 3; primary = "E"; secondary = "C"; C = 2;
        }
        await ctx.runMutation(internal.relationshipIntelligence.upsertTECOPS, {
          contactId: args.contactId,
          tecopsProfile: JSON.stringify({ T, E, C, O, P, S: S_, primaryRiskDriver: primary, secondaryRiskDriver: secondary }),
        });
        console.log("[RI] Saved heuristic TECOPS fallback:", primary, "/", secondary);
      }
    } catch (err) {
      console.error("[RI] TECOPS LLM call failed:", err);
    }

    // ── Call 2: Per-Opportunity Stance Assessment ──
    if (opportunities.length === 0) {
      console.log("[RI] No opportunities — skipping stance analysis");
      return null;
    }

    console.log("[RI] Starting per-opportunity stance analysis for contact", args.contactId);

    // Build a message with per-opportunity interaction context
    let stanceMessage = `Assess the following stakeholder's stance and role for each specific opportunity, based on the interactions and notes specific to each deal.\n\n`;
    stanceMessage += `CONTACT: ${contact.name || "Unknown"}`;
    if (contact.title) stanceMessage += `, ${contact.title}`;
    if (contact.company) stanceMessage += ` at ${contact.company}`;
    stanceMessage += `\n`;
    if (contact.notes) stanceMessage += `Contact Notes: ${contact.notes}\n`;

    stanceMessage += `\nOPPORTUNITIES:\n`;
    for (const opp of opportunities) {
      stanceMessage += `\n--- Opportunity ID: ${opp.id} ---\n`;
      stanceMessage += `Title: "${opp.title}" | Status: ${opp.status}`;
      if (opp.stage) stanceMessage += ` | Stage: ${opp.stage}`;
      if (opp.value) stanceMessage += ` | Value: ${opp.currency || ""}${opp.value}`;
      stanceMessage += `\n`;
      if (opp.notes) stanceMessage += `Opp Notes: ${opp.notes}\n`;
      const oppInteractions = opp.interactions || [];
      if (oppInteractions.length > 0) {
        stanceMessage += `Interactions on this deal (${oppInteractions.length}):\n`;
        for (const i of oppInteractions) {
          stanceMessage += `  - ${i.type}${i.subject ? `: ${i.subject}` : ""} (${i.date})`;
          if (i.body) stanceMessage += `\n    ${i.body}`;
          stanceMessage += `\n`;
        }
      } else {
        stanceMessage += `No direct interactions on this deal yet.\n`;
      }
    }

    let relationshipData: any = null;
    try {
      const relResponse = await fetch("https://api.a0.dev/ai/llm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content: `You are a B2B relationship analyst. For each opportunity, assess the stakeholder's STANCE (support/opposition toward your company's position on THIS specific deal) and their ROLE in the buying process. Base your assessment on the interactions and notes specific to each opportunity. Return opportunityId exactly as provided.`,
            },
            { role: "user", content: stanceMessage },
          ],
          schema: {
            type: "object",
            properties: {
              assessments: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    opportunityId: { type: "string" },
                    stance: { type: "number", description: "-2 Opposed, -1 Skeptical, 0 Neutral, 1 Supportive, 2 Champion" },
                    role: { type: "string", description: "One of: Decision Maker, Economic Buyer, Technical, User/Operational, Influencer, Gatekeeper, Blocker" },
                    influence: { type: "number", description: "1 Low, 2 Medium, 3 High" },
                    relationshipStrength: { type: "string", description: "Weak, Medium, or Strong" },
                    nextMoveTitle: { type: "string", description: "Short action, max 6 words" },
                    nextMoveDetails: { type: "string", description: "Brief explanation, 1-2 sentences" },
                  },
                  required: [
                    "opportunityId",
                    "stance",
                    "role",
                    "influence",
                    "relationshipStrength",
                    "nextMoveTitle",
                  ],
                },
              },
            },
            required: ["assessments"],
          },
        }),
      });

      const relData = await relResponse.json();
      console.log("[RI] Stance LLM response status:", relResponse.status, "has schema_data:", !!relData.schema_data, "completion length:", (relData.completion || "").length);

      if (relData.schema_data?.assessments && relData.schema_data.assessments.length > 0) {
        relationshipData = relData.schema_data.assessments;
      } else if (relData.completion) {
        try {
          const parsed = JSON.parse(relData.completion);
          if (parsed.assessments) relationshipData = parsed.assessments;
        } catch {
          console.error("[RI] Could not parse stance completion as JSON");
        }
      }

      if (relationshipData && relationshipData.length > 0) {
        await ctx.runMutation(internal.relationshipIntelligence.upsertFromAI, {
          orgId: args.orgId,
          contactId: args.contactId,
          assessments: relationshipData.map((a: any) => ({
            opportunityId: String(a.opportunityId),
            stance: Math.max(-2, Math.min(2, Math.round(Number(a.stance) || 0))),
            role: String(a.role || "Influencer"),
            influence: Math.max(1, Math.min(3, Math.round(Number(a.influence) || 2))),
            relationshipStrength: String(a.relationshipStrength || "Medium"),
            nextMoveTitle: String(a.nextMoveTitle || "Follow up"),
            nextMoveDetails: String(a.nextMoveDetails || ""),
          })),
        });
        console.log("[RI] Saved", relationshipData.length, "per-opportunity stance assessments");
      } else {
        console.error("[RI] No stance data from LLM, using heuristic fallback");
        // Heuristic fallback
        const fallback = opportunities.map((opp: any) => ({
          opportunityId: String(opp.id),
          stance: 0,
          role: contact.title?.toLowerCase().includes("director") || contact.title?.toLowerCase().includes("vp") || contact.title?.toLowerCase().includes("chief")
            ? "Decision Maker"
            : contact.title?.toLowerCase().includes("manager")
            ? "Influencer"
            : "User/Operational",
          influence: 2,
          relationshipStrength: (opp.interactions || []).length > 2 ? "Strong" : (opp.interactions || []).length > 0 ? "Medium" : "Weak",
          nextMoveTitle: (opp.interactions || []).length === 0 ? "Schedule intro meeting" : "Follow up this week",
          nextMoveDetails: (opp.interactions || []).length === 0
            ? "No interactions on this deal. Establish contact."
            : "Maintain engagement with a timely follow-up.",
        }));

        await ctx.runMutation(internal.relationshipIntelligence.upsertFromAI, {
          orgId: args.orgId,
          contactId: args.contactId,
          assessments: fallback,
        });
        console.log("[RI] Saved", fallback.length, "heuristic stance fallback assessments");
      }
    } catch (err) {
      console.error("[RI] Stance LLM call failed:", err);
    }

    return null;
  },
});