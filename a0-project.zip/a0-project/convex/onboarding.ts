import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getOrCreateOrg, getUserId, safeGetUserOrgId, createTeamWorkspace, joinTeamWorkspace } from "./helpers";
import { DEFAULT_SEGMENTS } from "./defaultSegments";

export const ensureOnboarded = mutation({
  args: {},
  returns: v.object({
    orgId: v.id("orgs"),
    userId: v.id("users"),
  }),
  handler: async (ctx) => {
    const userId = await getUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const orgId = await getOrCreateOrg(ctx, userId);

    // Guarantee segments exist — seed defaults if empty
    const hasSegments = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .first();

    if (!hasSegments) {
      for (const l1 of DEFAULT_SEGMENTS) {
        const l1Id = await ctx.db.insert("segments", {
          orgId,
          name: l1.name,
          level: 1,
          color: l1.color,
        });
        for (const l2 of l1.children) {
          const l2Id = await ctx.db.insert("segments", {
            orgId,
            name: l2.name,
            level: 2,
            parentId: l1Id,
          });
          for (const l3 of l2.children) {
            await ctx.db.insert("segments", {
              orgId,
              name: l3.name,
              level: 3,
              parentId: l2Id,
            });
          }
        }
      }
    }

    return { orgId, userId };
  },
});

export const createTeamAccount = mutation({
  args: {},
  returns: v.object({
    orgId: v.id("orgs"),
    teamCode: v.string(),
  }),
  handler: async (ctx) => {
    const userId = await getUserId(ctx);
    return await createTeamWorkspace(ctx, userId);
  },
});

export const joinTeamAccount = mutation({
  args: {
    teamCode: v.string(),
  },
  returns: v.object({
    orgId: v.id("orgs"),
  }),
  handler: async (ctx, args) => {
    const userId = await getUserId(ctx);
    return await joinTeamWorkspace(ctx, userId, args.teamCode);
  },
});

export const getMyOrg = query({
  args: {},
  returns: v.union(
    v.object({
      orgId: v.id("orgs"),
      userId: v.id("users"),
      orgName: v.string(),
      role: v.string(),
      accountType: v.optional(v.union(v.literal("solo"), v.literal("team"))),
      teamCode: v.optional(v.string()),
    }),
    v.null()
  ),
  handler: async (ctx) => {
    const result = await safeGetUserOrgId(ctx);
    if (!result) return null;

    const org = await ctx.db.get(result.orgId);
    if (!org) return null;

    const membership = await ctx.db
      .query("orgMembers")
      .withIndex("by_org_and_user", (q: any) => q.eq("orgId", result.orgId).eq("userId", result.userId))
      .unique();

    return {
      orgId: result.orgId,
      userId: result.userId,
      orgName: org.name,
      role: membership?.role || "owner",
      accountType: org.accountType,
      teamCode: org.teamCode,
    };
  },
});