"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";
import { DEFAULT_SEGMENTS } from "./defaultSegments";
import { SECTORS, formatTaxonomyForPrompt, SECTOR_NAMES } from "./taxonomyData";

// Server-side action: fetch website, extract content, match to segment
export const suggestSegmentFromUrl = action({
  args: {
    companyName: v.string(),
    companyDomain: v.string(),
  },
  returns: v.union(
    v.object({
      segmentId: v.optional(v.id("segments")),
      segmentPath: v.string(),
      reason: v.string(),
      keywords: v.array(v.string()),
      websiteSnippet: v.string(),
      emails: v.array(v.string()),
      phones: v.array(v.string()),
      isProposal: v.boolean(),
      confidence: v.number(),
      proposedSector: v.optional(v.string()),
      proposedSubSector: v.optional(v.string()),
      proposedNiche: v.optional(v.string()),
      proposedColor: v.optional(v.string()),
      fallbackSegmentId: v.optional(v.id("segments")),
      fallbackSegmentPath: v.optional(v.string()),
      companyDimensions: v.optional(v.object({
        revenue: v.optional(v.string()),
        employees: v.optional(v.string()),
        sites: v.optional(v.string()),
        capitalization: v.optional(v.string()),
        headquarters: v.optional(v.string()),
        founded: v.optional(v.string()),
        description: v.optional(v.string()),
      })),
    }),
    v.null()
  ),
  handler: async (ctx, args) => {
    // 1. Get segments from database
    const segPaths = await ctx.runQuery(internal.segments.getPathsForAi);
    console.log("[AI] Segments loaded:", segPaths.length);
    const hasExistingSegments = segPaths.length > 0;

    // 2. Fetch website content
    const fetchResult = await fetchAndExtract(args.companyDomain, args.companyName);
    const { content: websiteContent, fetchedOk, emails: extractedEmails, phones: extractedPhones, metaDescription, pageTitle } = fetchResult;
    console.log("[AI] Content length:", websiteContent.length, "fetchedOk:", fetchedOk);

    // Determine if we got meaningful content from the website
    const hasRichContent = websiteContent.length > 500;
    const knowledgeFallback = !hasRichContent
      ? `\n\nIMPORTANT: The website returned very little content (likely a JavaScript SPA). USE YOUR OWN KNOWLEDGE about "${args.companyName}" (domain: ${args.companyDomain}) to classify and describe this company. You likely know this company from your training data.`
      : "";

    // 3. Prepare both LLM calls to run in PARALLEL
    const segmentList = hasExistingSegments
      ? segPaths.map((s) => `ID="${s.id}" PATH="${s.path}"`).join("\n")
      : "";

    const sectorList = SECTOR_NAMES.join(", ");

    const classifyPrompt = hasExistingSegments
      ? `Classify this company into an industry taxonomy. Pick the best match from existing segments AND propose an ideal 3-level path (Sector > Industry > Sub-Industry).

Existing segments:
${segmentList}

Available Sectors: ${sectorList}

Confidence rules: 9-10=exact match, 7-8=same industry, 4-6=related, 1-3=completely different industry.
If company is in a totally different industry than all segments, confidence MUST be 1-3.${knowledgeFallback}`
      : `Classify this company into a 3-level industry path: Sector > Industry > Sub-Industry. Available Sectors: ${sectorList}. Set confidence to 0 and matchId to empty.${knowledgeFallback}`;

    const classifyUserMsg = `Company: "${args.companyName}" Domain: ${args.companyDomain}\n\n${websiteContent.slice(0, 2000)}`;
    const dimUserMsg = hasRichContent
      ? `Company: "${args.companyName}"\n\n${websiteContent.slice(0, 1500)}`
      : `Company: "${args.companyName}" (domain: ${args.companyDomain})\n\nThe website didn't return useful content. Please provide what you know about this company from your training data.`;

    const dimSystemPrompt = hasRichContent
      ? `Extract company business dimensions from website content. Use 'Unknown' if not found.`
      : `Provide business dimensions for the company "${args.companyName}" (${args.companyDomain}) based on your knowledge. Include revenue, employee count, headquarters, founding year, number of global sites/countries, market capitalization, and a one-sentence description. Use 'Unknown' ONLY if you truly don't know.`;

    // Launch classification and dimensions calls in PARALLEL
    console.log("[AI] Launching classification + dimensions in parallel...");

    const classifyPromise = callLlmWithRetry(classifyPrompt, classifyUserMsg, {
      type: "object",
      properties: {
        confidence: { type: "number", description: "1-10 match confidence" },
        matchId: { type: "string", description: "Best existing segment ID or empty" },
        sector: { type: "string", description: "L1 sector name" },
        subSector: { type: "string", description: "L2 industry name" },
        niche: { type: "string", description: "L3 sub-industry name" },
        reason: { type: "string", description: "Brief classification reason" },
        keywords: { type: "array", items: { type: "string" }, description: "3-5 industry keywords" },
      },
      required: ["confidence", "matchId", "sector", "subSector", "niche", "reason", "keywords"],
    });

    const dimPromise = callLlmWithRetry(dimSystemPrompt, dimUserMsg, {
      type: "object",
      properties: {
        revenue: { type: "string" },
        employees: { type: "string" },
        sites: { type: "string" },
        capitalization: { type: "string" },
        headquarters: { type: "string" },
        founded: { type: "string" },
        description: { type: "string" },
      },
      required: ["description"],
    });

    const [classResult, dimResult] = await Promise.all([classifyPromise, dimPromise]);

    // 4. Process classification result
    let confidence = 0;
    let bestExistingId = "";
    let proposedSector = "";
    let proposedSubSector = "";
    let proposedNiche = "";
    let reason = "";
    let keywords: string[] = [];

    if (classResult) {
      console.log("[AI] Classification:", classResult.sector, ">", classResult.subSector, ">", classResult.niche, "confidence:", classResult.confidence);
      confidence = Number(classResult.confidence) || 0;
      bestExistingId = classResult.matchId || "";
      proposedSector = classResult.sector || "";
      proposedSubSector = classResult.subSector || "";
      proposedNiche = classResult.niche || "";
      reason = classResult.reason || "";
      keywords = classResult.keywords || [];
    }

    // If LLM returned nothing, use keyword matching against DEFAULT_SEGMENTS
    if (!proposedSector || !proposedSubSector || !proposedNiche) {
      console.log("[AI] LLM returned empty — falling back to keyword matching");
      const kw = keywordMatchDefaults(args.companyName, websiteContent, keywords);
      proposedSector = proposedSector || kw.sector;
      proposedSubSector = proposedSubSector || kw.subSector;
      proposedNiche = proposedNiche || kw.niche;
      if (!reason) reason = "Classified via keyword matching against reference taxonomy";
    }

    console.log("[AI] Classification result:", proposedSector, ">", proposedSubSector, ">", proposedNiche, "confidence:", confidence);

    // 5. Process dimensions
    let companyDimensions: {
      revenue?: string; employees?: string; sites?: string;
      capitalization?: string; headquarters?: string; founded?: string; description?: string;
    } = {};

    // Always start with HTML-extracted baseline (no LLM needed)
    const htmlInfo = extractInfoFromContent(websiteContent, metaDescription, pageTitle, args.companyName);
    companyDimensions = { ...htmlInfo };
    console.log("[AI] HTML-extracted baseline:", JSON.stringify(companyDimensions));

    // Merge LLM dimension results on top
    if (dimResult) {
      console.log("[AI] Dimensions from LLM:", JSON.stringify(dimResult).slice(0, 300));
      if (cleanUnknown(dimResult.revenue)) companyDimensions.revenue = cleanUnknown(dimResult.revenue);
      if (cleanUnknown(dimResult.employees)) companyDimensions.employees = cleanUnknown(dimResult.employees);
      if (cleanUnknown(dimResult.sites)) companyDimensions.sites = cleanUnknown(dimResult.sites);
      if (cleanUnknown(dimResult.capitalization)) companyDimensions.capitalization = cleanUnknown(dimResult.capitalization);
      if (cleanUnknown(dimResult.headquarters)) companyDimensions.headquarters = cleanUnknown(dimResult.headquarters);
      if (cleanUnknown(dimResult.founded)) companyDimensions.founded = cleanUnknown(dimResult.founded);
      if (cleanUnknown(dimResult.description)) companyDimensions.description = cleanUnknown(dimResult.description);
    }
    console.log("[AI] Final dimensions:", JSON.stringify(companyDimensions));

    const hasDimensions = Object.values(companyDimensions).some(v => v !== undefined);

    // 6. Resolve existing segment match
    let matchedSegmentId: string | undefined;
    let matchedSegmentPath = "";

    if (bestExistingId && hasExistingSegments) {
      const found = segPaths.find(s => s.id === bestExistingId);
      if (found) {
        matchedSegmentId = found.id;
        matchedSegmentPath = found.path;
      }
    }

    // If no ID match, try to find by path overlap
    if (!matchedSegmentId && hasExistingSegments && proposedSector) {
      const searchTerms = [proposedSector, proposedSubSector, proposedNiche]
        .filter(Boolean)
        .map(t => t.toLowerCase());
      let bestOverlap = 0;
      for (const seg of segPaths) {
        const pathLower = seg.path.toLowerCase();
        let overlap = 0;
        for (const term of searchTerms) {
          if (pathLower.includes(term)) overlap++;
        }
        if (overlap > bestOverlap) {
          bestOverlap = overlap;
          matchedSegmentId = seg.id;
          matchedSegmentPath = seg.path;
        }
      }
      // If matched by overlap, boost confidence proportionally
      if (matchedSegmentId && bestOverlap >= 2) {
        confidence = Math.max(confidence, 8);
      }
    }

    // Determine if this is a proposal or existing match
    const isProposal = confidence < 7 && proposedSector && proposedSubSector && proposedNiche;

    // Find color from DEFAULT_SEGMENTS for proposed sector
    const defaultSector = DEFAULT_SEGMENTS.find(s =>
      s.name.toLowerCase() === (proposedSector || "").toLowerCase()
    );
    const proposedColor = defaultSector?.color || "#6366F1";

    // Build return
    const snippetParts: string[] = [];
    if (fetchResult.metaDescription) snippetParts.push(fetchResult.metaDescription);
    if (fetchResult.pageTitle) snippetParts.push(`Title: ${fetchResult.pageTitle}`);
    const websiteSnippet = snippetParts.join("\n") || websiteContent.slice(0, 300);

    if (isProposal) {
      console.log("[AI] Returning PROPOSAL:", proposedSector, ">", proposedSubSector, ">", proposedNiche);
      return {
        segmentId: undefined,
        segmentPath: `${proposedSector} > ${proposedSubSector} > ${proposedNiche}`,
        reason,
        keywords,
        websiteSnippet,
        emails: extractedEmails,
        phones: extractedPhones,
        isProposal: true,
        confidence,
        proposedSector,
        proposedSubSector,
        proposedNiche,
        proposedColor,
        fallbackSegmentId: matchedSegmentId as any,
        fallbackSegmentPath: matchedSegmentPath || undefined,
        companyDimensions: hasDimensions ? companyDimensions : undefined,
      };
    }

    // Existing match
    if (matchedSegmentId) {
      console.log("[AI] Using existing:", matchedSegmentPath, "confidence:", confidence);
      return {
        segmentId: matchedSegmentId as any,
        segmentPath: matchedSegmentPath,
        reason,
        keywords,
        websiteSnippet,
        emails: extractedEmails,
        phones: extractedPhones,
        isProposal: false,
        confidence,
        proposedSector,
        proposedSubSector,
        proposedNiche,
        proposedColor,
        companyDimensions: hasDimensions ? companyDimensions : undefined,
      };
    }

    // No match at all — return as proposal
    console.log("[AI] No existing match, returning as proposal");
    return {
      segmentId: undefined,
      segmentPath: `${proposedSector} > ${proposedSubSector} > ${proposedNiche}`,
      reason: reason || "No matching segment found — proposed new segment",
      keywords,
      websiteSnippet,
      emails: extractedEmails,
      phones: extractedPhones,
      isProposal: true,
      confidence: Math.min(confidence, 3),
      proposedSector,
      proposedSubSector,
      proposedNiche,
      proposedColor,
      companyDimensions: hasDimensions ? companyDimensions : undefined,
    };
  },
});

// --- Helper functions ---

function tryParse(text: string): any {
  try {
    return JSON.parse(text.replace(/```json?\n?/g, "").replace(/```/g, "").trim());
  } catch { return null; }
}

function cleanUnknown(val: string | undefined): string | undefined {
  if (!val || val.toLowerCase() === "unknown" || val.trim() === "") return undefined;
  return val.trim();
}

// Extract basic company info directly from HTML content (no LLM needed)
function extractInfoFromContent(
  content: string,
  metaDescription: string,
  pageTitle: string,
  companyName: string
): {
  description?: string;
  employees?: string;
  revenue?: string;
  headquarters?: string;
  founded?: string;
  sites?: string;
  capitalization?: string;
} {
  const result: Record<string, string | undefined> = {};
  const text = content.toLowerCase();

  // Description: use meta description, or OG description, or page title
  if (metaDescription && metaDescription.length > 10) {
    result.description = metaDescription;
  } else if (pageTitle && pageTitle.length > 5) {
    result.description = pageTitle;
  }

  // Employee count patterns: "86,000 employees", "over 100,000 people"
  const empMatch = content.match(/(\d[\d,\.]+)\s*(?:employees|people|staff|workers|associates)/i)
    || content.match(/(?:employees|people|staff|workforce)[:\s]*(?:approximately|about|over|~)?\s*(\d[\d,\.]+)/i);
  if (empMatch) {
    result.employees = empMatch[1].replace(/\.$/, '');
  }

  // Revenue patterns: "$280B", "$50 billion", "revenue of $12.5 million"
  const revMatch = content.match(/(?:revenue|turnover|sales)[:\s]*(?:of\s+)?(?:approximately|about|over|~)?\s*\$?([\d,.]+\s*(?:billion|million|B|M|bn|mn|trillion|T))/i)
    || content.match(/\$\s*([\d,.]+\s*(?:billion|million|B|M|bn|mn|trillion|T))/i);
  if (revMatch) {
    result.revenue = '$' + revMatch[1].trim();
  }

  // Founded year: "founded in 1907", "established 1952", "since 1985"
  const foundedMatch = content.match(/(?:founded|established|since|incorporated)\s*(?:in\s+)?(\d{4})/i);
  if (foundedMatch && Number(foundedMatch[1]) > 1700 && Number(foundedMatch[1]) <= new Date().getFullYear()) {
    result.founded = foundedMatch[1];
  }

  // Headquarters: "headquartered in The Hague", "based in Houston"
  const hqMatch = content.match(/(?:headquartered|based|headquarters)\s*(?:in|:)\s*([A-Z][a-zA-Z\s,]{3,40})/);
  if (hqMatch) {
    result.headquarters = hqMatch[1].replace(/[,.\s]+$/, '').trim();
  }

  // Locations/sites: "operations in 70+ countries", "50 locations"
  const sitesMatch = content.match(/(?:operations?\s*in|present\s*in|across)\s+(\d+\+?\s*(?:countries|locations|offices|sites|markets))/i)
    || content.match(/(\d+\+?)\s*(?:locations|offices|sites|countries|markets)/i);
  if (sitesMatch) {
    result.sites = sitesMatch[1] || sitesMatch[0];
  }

  // Market cap: "$200 billion market cap", "market capitalization of $150B"
  const capMatch = content.match(/(?:market\s*cap(?:italization)?)[:\s]*(?:of\s+)?\$?\s*([\d,.]+\s*(?:billion|million|B|M|bn|mn|trillion|T))/i);
  if (capMatch) {
    result.capitalization = '$' + capMatch[1].trim();
  }

  return result;
}

function keywordMatchDefaults(companyName: string, websiteContent: string, keywords: string[]): { sector: string; subSector: string; niche: string } {
  const searchText = [companyName, ...keywords, websiteContent.slice(0, 500)].join(" ").toLowerCase();
  let bestScore = 0;
  let bestL1 = DEFAULT_SEGMENTS[0];
  let bestL2 = DEFAULT_SEGMENTS[0].children[0];
  let bestL3 = DEFAULT_SEGMENTS[0].children[0].children[0];

  for (const l1 of DEFAULT_SEGMENTS) {
    for (const l2 of l1.children) {
      for (const l3 of l2.children) {
        const terms = [l1.name, l2.name, l3.name].join(" ").toLowerCase().split(/[\s/&(),]+/).filter(w => w.length > 2);
        let score = 0;
        for (const term of terms) {
          if (searchText.includes(term)) score += 3;
        }
        if (score > bestScore) {
          bestScore = score;
          bestL1 = l1;
          bestL2 = l2;
          bestL3 = l3;
        }
      }
    }
  }

  return { sector: bestL1.name, subSector: bestL2.name, niche: bestL3.name };
}

async function fetchAndExtract(domain: string, companyName: string): Promise<{
  content: string; fetchedOk: boolean; emails: string[]; phones: string[]; metaDescription: string; pageTitle: string;
}> {
  try {
    const cleanDomain = domain.replace(/^(https?:\/\/)?(www\.)?/, "");
    const baseUrl = `https://www.${cleanDomain}`;

    // Fetch homepage + additional pages in parallel for richer content
    const pagePaths = ["", "/about", "/about-us", "/careers", "/investors", "/investor-relations", "/company"];
    console.log("[AI] Fetching", pagePaths.length, "pages for:", baseUrl);

    const fetchPage = async (path: string): Promise<string> => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 12000);
        const res = await fetch(`${baseUrl}${path}`, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
          redirect: "follow",
          signal: controller.signal,
        });
        clearTimeout(timeout);
        if (!res.ok) return "";
        return await res.text();
      } catch {
        return "";
      }
    };

    const htmlResults = await Promise.all(pagePaths.map(p => fetchPage(p)));

    // Combine all fetched HTML
    const allEmails: Set<string> = new Set();
    const allPhones: Set<string> = new Set();
    const allHeadings: string[] = [];
    const bodyTexts: string[] = [];
    let mainTitle = "";
    let mainMetaDesc = "";
    let mainOgDesc = "";

    for (let i = 0; i < htmlResults.length; i++) {
      const fullHtml = htmlResults[i];
      if (!fullHtml || fullHtml.length < 100) continue;

      // Extract emails
      const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
      const emails = (fullHtml.match(emailRegex) || [])
        .filter(e => !e.match(/\.(png|jpg|gif|svg|css|js)$/i) && !e.includes("example.com") && !e.includes("sentry"));
      emails.forEach(e => allEmails.add(e));

      // Extract phones
      const textOnly = fullHtml.replace(/<script[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]*>/g, " ");
      const phoneRegex = /(?:\+?1[-.\s]?)?(?:\(?[0-9]{3}\)?[-.\s]?)?[0-9]{3}[-.\s]?[0-9]{4}/g;
      const phones = (textOnly.match(phoneRegex) || []).map(p => p.trim()).filter(p => p.replace(/\D/g, "").length >= 10);
      phones.forEach(p => allPhones.add(p));

      // Extract title/meta from homepage only
      if (i === 0) {
        mainTitle = fullHtml.match(/<title[^>]*>(.*?)<\/title>/is)?.[1]?.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim() || "";
        mainMetaDesc = fullHtml.match(/<meta[^>]*name=["']description["'][^>]*content=["'](.*?)["']/is)?.[1]?.trim() || "";
        mainOgDesc = fullHtml.match(/<meta[^>]*property=["']og:description["'][^>]*content=["'](.*?)["']/is)?.[1]?.trim() || "";
      }

      // Extract headings from all pages
      const hRegex = /<h[1-3][^>]*>(.*?)<\/h[1-3]>/gis;
      let m;
      while ((m = hRegex.exec(fullHtml)) !== null && allHeadings.length < 30) {
        const text = m[1].replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
        if (text.length > 2 && !allHeadings.includes(text)) allHeadings.push(text);
      }

      // Extract body text from all pages
      const bodyMatch = fullHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/is);
      if (bodyMatch) {
        const bt = bodyMatch[1]
          .replace(/<script[\s\S]*?<\/script>/gi, "")
          .replace(/<style[\s\S]*?<\/style>/gi, "")
          .replace(/<nav[\s\S]*?<\/nav>/gi, "")
          .replace(/<footer[\s\S]*?<\/footer>/gi, "")
          .replace(/<[^>]*>/g, " ")
          .replace(/&[a-z]+;/gi, " ")
          .replace(/\s+/g, " ")
          .trim();
        if (bt.length > 50) {
          const label = pagePaths[i] || "/";
          bodyTexts.push(`[${label}]: ${bt.slice(0, 1500)}`);
        }
      }
    }

    // Build combined content
    const content = [
      mainTitle && `Title: ${mainTitle}`,
      mainMetaDesc && `Description: ${mainMetaDesc}`,
      mainOgDesc && `OG: ${mainOgDesc}`,
      allHeadings.length > 0 && `Headings: ${allHeadings.join(" | ")}`,
      ...bodyTexts,
    ].filter(Boolean).join("\n");

    console.log("[AI] Combined content from", bodyTexts.length, "pages,", content.length, "total chars");

    return {
      content,
      fetchedOk: content.length > 50,
      emails: [...allEmails].slice(0, 5),
      phones: [...allPhones].slice(0, 5),
      metaDescription: mainMetaDesc || mainOgDesc,
      pageTitle: mainTitle,
    };
  } catch (e: any) {
    console.log("[AI] Fetch failed:", e.message);
    return {
      content: `Company: "${companyName}", domain: "${domain}". Use your knowledge to classify.`,
      fetchedOk: false, emails: [], phones: [], metaDescription: "", pageTitle: "",
    };
  }
}

// Generate personalized taxonomy during onboarding — SIMPLIFIED
// LLM just picks sector names from a flat list, we map to DEFAULT_SEGMENTS hierarchy
export const generateTaxonomy = action({
  args: {
    companyName: v.string(),
    companyUrl: v.optional(v.string()),
    interests: v.string(),
  },
  returns: v.object({
    segments: v.array(v.object({
      sector: v.string(),
      sectorColor: v.string(),
      subSectors: v.array(v.object({
        name: v.string(),
        niches: v.array(v.string()),
      })),
    })),
    buyerTypes: v.array(v.string()),
    offerTypes: v.array(v.string()),
    problemThemes: v.array(v.string()),
    keywords: v.array(v.string()),
    confidence: v.string(),
  }),
  handler: async (ctx, args) => {
    console.log("[TaxonomyGen] Starting for:", args.companyName, "interests:", args.interests);

    // 1. Optionally scrape company website (short content)
    let websiteContent = "";
    if (args.companyUrl) {
      try {
        const result = await fetchAndExtract(args.companyUrl, args.companyName);
        websiteContent = result.content;
        console.log("[TaxonomyGen] Scraped", websiteContent.length, "chars");
      } catch {
        console.log("[TaxonomyGen] Scrape failed");
      }
    }

    // 2. SIMPLE flat LLM call — just pick sector names + generate metadata
    const sectorList = SECTOR_NAMES.join(", ");

    console.log("[TaxonomyGen] Calling LLM with flat schema...");

    let selectedSectors: string[] = [];
    let buyerTypes: string[] = [];
    let offerTypes: string[] = [];
    let problemThemes: string[] = [];
    let llmKeywords: string[] = [];
    let llmConfidence = "medium";

    try {
      const systemPrompt = `You help companies set up their CRM. Pick 2-5 market sectors most relevant to this company's target markets.

Available sectors: ${sectorList}

Also generate buyer personas, offer types, and problem themes.`;

      const userMsg = `Company: "${args.companyName}"
Services/Opportunities: "${args.interests}"
${websiteContent ? `\nWebsite excerpt:\n${websiteContent.slice(0, 1000)}` : ""}

Pick the most relevant sectors for this company's CRM.`;

      const schema = {
        type: "object",
        properties: {
          sectors: { type: "array", items: { type: "string" }, description: "2-5 sector names from the available list" },
          buyerTypes: { type: "array", items: { type: "string" }, description: "Target buyer job titles" },
          offerTypes: { type: "array", items: { type: "string" }, description: "What this company offers" },
          problemThemes: { type: "array", items: { type: "string" }, description: "Client problems solved" },
          keywords: { type: "array", items: { type: "string" }, description: "Industry keywords" },
        },
        required: ["sectors", "buyerTypes", "offerTypes", "problemThemes", "keywords"],
      };

      const d = await callLlmWithRetry(systemPrompt, userMsg, schema);

      if (d && d.sectors && d.sectors.length > 0) {
        selectedSectors = d.sectors;
        buyerTypes = d.buyerTypes || [];
        offerTypes = d.offerTypes || [];
        problemThemes = d.problemThemes || [];
        llmKeywords = d.keywords || [];
        llmConfidence = "high";
        console.log("[TaxonomyGen] LLM selected sectors:", selectedSectors);
      } else {
        console.log("[TaxonomyGen] LLM returned empty/invalid data");
      }
    } catch (e: any) {
      console.log("[TaxonomyGen] LLM call failed:", e.message);
    }

    // 3. If LLM failed, use keyword matching to pick sectors
    if (selectedSectors.length === 0) {
      console.log("[TaxonomyGen] Falling back to keyword matching...");
      llmConfidence = "low";

      const searchText = [args.companyName, args.interests, websiteContent.slice(0, 500)].join(" ").toLowerCase();

      // Score each sector by keyword overlap
      const sectorScores: { name: string; score: number }[] = [];
      for (const l1 of DEFAULT_SEGMENTS) {
        let score = 0;
        const allTerms = [l1.name, ...l1.children.map(c => c.name), ...l1.children.flatMap(c => c.children.map(x => x.name))]
          .join(" ").toLowerCase().split(/[\s/&(),]+/).filter(w => w.length > 2);
        for (const term of allTerms) {
          if (searchText.includes(term)) score += 1;
        }
        sectorScores.push({ name: l1.name, score });
      }

      sectorScores.sort((a, b) => b.score - a.score);
      // Pick top 3 with score > 0, or first 3 as absolute fallback
      const matched = sectorScores.filter(s => s.score > 0).slice(0, 3);
      selectedSectors = matched.length > 0
        ? matched.map(s => s.name)
        : DEFAULT_SEGMENTS.slice(0, 3).map(s => s.name);

      buyerTypes = ["CEO", "VP Sales", "VP Operations", "Business Unit Leader"];
      offerTypes = ["Consulting", "Advisory", "Project Development"];
      problemThemes = ["Need for growth", "New market access", "Low pipeline visibility"];
      llmKeywords = [args.companyName.toLowerCase()];

      console.log("[TaxonomyGen] Keyword fallback sectors:", selectedSectors);
    }

    // 4. Map selected sector names to full DEFAULT_SEGMENTS hierarchy
    const segments = selectedSectors
      .map(name => {
        const match = DEFAULT_SEGMENTS.find(s =>
          s.name.toLowerCase() === name.toLowerCase() ||
          s.name.toLowerCase().includes(name.toLowerCase()) ||
          name.toLowerCase().includes(s.name.toLowerCase())
        );
        if (!match) return null;
        return {
          sector: match.name,
          sectorColor: match.color,
          subSectors: match.children.map(l2 => ({
            name: l2.name,
            niches: l2.children.map(x => x.name),
          })),
        };
      })
      .filter((s): s is NonNullable<typeof s> => s !== null);

    // Ensure we have at least 2 sectors
    if (segments.length < 2) {
      for (const ds of DEFAULT_SEGMENTS) {
        if (!segments.find(s => s.sector === ds.name)) {
          segments.push({
            sector: ds.name,
            sectorColor: ds.color,
            subSectors: ds.children.map(l2 => ({ name: l2.name, niches: l2.children.map(x => x.name) })),
          });
          if (segments.length >= 3) break;
        }
      }
    }

    console.log("[TaxonomyGen] Final:", segments.length, "sectors, confidence:", llmConfidence);

    return {
      segments,
      buyerTypes: buyerTypes.slice(0, 10),
      offerTypes: offerTypes.slice(0, 10),
      problemThemes: problemThemes.slice(0, 10),
      keywords: llmKeywords.slice(0, 15),
      confidence: llmConfidence,
    };
  },
});

// Helper function to call LLM with retry logic
// Attempt 1: with schema. Attempt 2: without schema, asking for JSON in prompt.
async function callLlmWithRetry(systemPrompt: string, userMsg: string, schema: any): Promise<any> {
  // Attempt 1: with schema
  try {
    const res = await fetch("https://api.a0.dev/ai/llm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userMsg },
        ],
        schema,
      }),
    });
    const data = await res.json();
    const result = data.schema_data || (data.completion ? tryParse(data.completion) : null);
    if (result) {
      console.log("[AI] LLM schema attempt succeeded");
      return result;
    }
    console.log("[AI] LLM schema attempt returned null, retrying without schema...");
  } catch (e: any) {
    console.log("[AI] LLM schema attempt failed:", e.message);
  }

  // Attempt 2: without schema — embed JSON format in prompt
  try {
    // Build a compact JSON template from the schema properties
    const props = schema?.properties || {};
    const templateParts: string[] = [];
    for (const [key, val] of Object.entries(props) as any[]) {
      if (val.type === "array") {
        templateParts.push(`"${key}": ["string"]`);
      } else if (val.type === "number") {
        templateParts.push(`"${key}": number`);
      } else {
        templateParts.push(`"${key}": "string"`);
      }
    }
    const jsonTemplate = `{${templateParts.join(", ")}}`;

    const retryRes = await fetch("https://api.a0.dev/ai/llm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemPrompt + `\n\nRespond with ONLY valid JSON matching this format: ${jsonTemplate}` },
          { role: "user", content: userMsg },
        ],
      }),
    });
    const retryData = await retryRes.json();
    const result = retryData.schema_data || tryParse(retryData.completion);
    if (result) {
      console.log("[AI] LLM retry without schema succeeded");
      return result;
    }
    console.log("[AI] LLM retry also returned null");
  } catch (e: any) {
    console.log("[AI] LLM retry failed:", e.message);
  }

  return null;
}

// ─── Opportunity Scout: live web intelligence gathering ────────────────────────
export const scoutCompanyIntel = action({
  args: {
    companyDomain: v.string(),
    companyName: v.string(),
  },
  handler: async (_ctx, args) => {
    const { companyDomain, companyName } = args;

    // 1) Scrape target pages from the company's own website
    const cleanDomain = companyDomain.replace(/^(https?:\/\/)?(www\.)?/, "").replace(/\/+$/, "");
    const baseUrl = `https://www.${cleanDomain}`;

    const scoutPaths = [
      "/news", "/newsroom", "/press", "/press-releases",
      "/media", "/blog",
      "/investors", "/investor-relations", "/ir",
    ];

    console.log("[ScoutIntel] Scraping", scoutPaths.length, "pages on", baseUrl);

    const fetchPage = async (url: string): Promise<{ url: string; text: string }> => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 12000);
        const res = await fetch(url, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
          },
          redirect: "follow",
          signal: controller.signal,
        });
        clearTimeout(timeout);
        if (!res.ok) return { url, text: "" };
        const html = await res.text();
        if (html.length < 200) return { url, text: "" };

        // Extract meaningful text from HTML
        const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/is);
        if (!bodyMatch) return { url, text: "" };

        const cleaned = bodyMatch[1]
          .replace(/<script[\s\S]*?<\/script>/gi, "")
          .replace(/<style[\s\S]*?<\/style>/gi, "")
          .replace(/<nav[\s\S]*?<\/nav>/gi, "")
          .replace(/<footer[\s\S]*?<\/footer>/gi, "")
          .replace(/<[^>]*>/g, " ")
          .replace(/&[a-z]+;/gi, " ")
          .replace(/\s+/g, " ")
          .trim();

        // Also extract headings for structure
        const hRegex = /<h[1-4][^>]*>(.*?)<\/h[1-4]>/gis;
        const headings: string[] = [];
        let m;
        while ((m = hRegex.exec(html)) !== null && headings.length < 20) {
          const t = m[1].replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
          if (t.length > 3) headings.push(t);
        }

        const combined = (headings.length > 0 ? `Headings: ${headings.join(" | ")}\n` : "") + cleaned.slice(0, 3000);
        return { url, text: combined };
      } catch {
        return { url, text: "" };
      }
    };

    const siteResults = await Promise.all(
      scoutPaths.map(path => fetchPage(`${baseUrl}${path}`))
    );

    const siteContent = siteResults
      .filter(r => r.text.length > 50)
      .map(r => `[${r.url}]:\n${r.text}`)
      .join("\n\n---\n\n");

    console.log("[ScoutIntel] Got", siteResults.filter(r => r.text.length > 50).length, "pages with content,", siteContent.length, "chars");

    // 2) Fetch recent news via Google News RSS
    let newsContent = "";
    try {
      const query = encodeURIComponent(`"${companyName}"`);
      const rssUrl = `https://news.google.com/rss/search?q=${query}&hl=en-US&gl=US&ceid=US:en`;
      console.log("[ScoutIntel] Fetching Google News RSS for:", companyName);

      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 10000);
      const rssRes = await fetch(rssUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
          Accept: "application/rss+xml,application/xml,text/xml,*/*",
        },
        signal: controller.signal,
      });
      clearTimeout(timeout);

      if (rssRes.ok) {
        const rssXml = await rssRes.text();
        // Extract items from RSS: <item><title>...</title><pubDate>...</pubDate><source>...</source></item>
        const items: string[] = [];
        const itemRegex = /<item>([\s\S]*?)<\/item>/gi;
        let match;
        while ((match = itemRegex.exec(rssXml)) !== null && items.length < 15) {
          const itemXml = match[1];
          const title = itemXml.match(/<title>(.*?)<\/title>/is)?.[1]?.replace(/<!\[CDATA\[(.*?)\]\]>/s, "$1").trim() || "";
          const pubDate = itemXml.match(/<pubDate>(.*?)<\/pubDate>/is)?.[1]?.trim() || "";
          const source = itemXml.match(/<source[^>]*>(.*?)<\/source>/is)?.[1]?.replace(/<!\[CDATA\[(.*?)\]\]>/s, "$1").trim() || "";
          if (title) {
            items.push(`- ${title}${source ? ` (${source})` : ""}${pubDate ? ` [${pubDate}]` : ""}`);
          }
        }
        if (items.length > 0) {
          newsContent = `RECENT NEWS HEADLINES (from Google News):\n${items.join("\n")}`;
          console.log("[ScoutIntel] Got", items.length, "news headlines");
        }
      }
    } catch (e: any) {
      console.log("[ScoutIntel] Google News RSS fetch failed:", e.message);
    }

    // 3) Combine everything
    const sections: string[] = [];

    if (siteContent) {
      sections.push(`COMPANY WEBSITE — LIVE SCRAPED CONTENT:\n${siteContent}`);
    }
    if (newsContent) {
      sections.push(newsContent);
    }

    const combined = sections.join("\n\n===\n\n");
    console.log("[ScoutIntel] Total intel:", combined.length, "chars");

    return {
      siteContent: siteContent.slice(0, 12000),
      newsContent: newsContent.slice(0, 4000),
      totalChars: combined.length,
      pagesScraped: siteResults.filter(r => r.text.length > 50).length,
    };
  },
});

// ─── Contact Seeker: multi-source intelligence for contact discovery ────────
export const seekContactIntel = action({
  args: {
    companyName: v.string(),
    domain: v.optional(v.string()),
    geoScope: v.optional(v.string()),
  },
  returns: v.object({
    teamContent: v.string(),
    wikipediaContent: v.string(),
    newsContent: v.string(),
    totalChars: v.number(),
  }),
  handler: async (_ctx, { companyName, domain, geoScope }) => {
    const results = { teamContent: "", wikipediaContent: "", newsContent: "" };

    // All sources in parallel with aggressive timeouts (fail fast)
    const tasks: Promise<void>[] = [];

    // Source A: Company website — only top 6 team/leadership paths
    if (domain) {
      tasks.push((async () => {
        const base = domain.startsWith("http") ? domain : `https://${domain}`;
        const paths = ["/team", "/leadership", "/about", "/our-team", "/about-us", "/people"];
        const pages = await Promise.all(paths.map(async (p) => {
          try {
            const res = await fetch(`${base}${p}`, {
              headers: { "User-Agent": "Mozilla/5.0 (compatible; BDBuddy/1.0)" },
              redirect: "follow",
              signal: AbortSignal.timeout(6000),
            });
            if (!res.ok) return "";
            const html = await res.text();
            return html.replace(/<script[\s\S]*?<\/script>/gi, "")
              .replace(/<style[\s\S]*?<\/style>/gi, "")
              .replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().slice(0, 3000);
          } catch { return ""; }
        }));
        results.teamContent = pages.filter(Boolean).join("\n---\n").slice(0, 8000);
      })());
    }

    // Source B: Wikipedia — quick search + extract (skip for very short company names that would give false matches)
    if (companyName.length > 3) {
      tasks.push((async () => {
        try {
          const UA = "BDBuddy/1.0 (contact@bdbuddy.app)";
          const cleanName = companyName.replace(/\s*\(.*?\)\s*/g, "").trim();
          const searchRes = await fetch(
            `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(cleanName)}&limit=3&format=json`,
            { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(5000) }
          );
          if (!searchRes.ok) return;
          const [, titles] = await searchRes.json();
          if (!titles?.length) return;
          const pageRes = await fetch(
            `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(titles[0])}&prop=extracts&explaintext=true&format=json`,
            { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(6000) }
          );
          if (!pageRes.ok) return;
          const pageData = await pageRes.json();
          const extract = Object.values(pageData?.query?.pages || {}).map((p: any) => p.extract || "").join("\n");
          results.wikipediaContent = extract.slice(0, 10000);
        } catch {}
      })());
    }

    // Source C: Google News RSS — personnel mentions
    tasks.push((async () => {
      try {
        const cleanName = companyName.replace(/\s*\(.*?\)\s*/g, "").trim();
        const geo = geoScope ? ` ${geoScope}` : "";
        const q = encodeURIComponent(`"${cleanName}"${geo} CEO OR president OR VP OR director OR appointed`);
        const rssRes = await fetch(
          `https://news.google.com/rss/search?q=${q}&hl=en&gl=CA&ceid=CA:en`,
          { signal: AbortSignal.timeout(6000) }
        );
        if (!rssRes.ok) return;
        const rss = await rssRes.text();
        const titles: string[] = [];
        const re = /<title>([\s\S]*?)<\/title>/g;
        let m;
        while ((m = re.exec(rss)) !== null) {
          const t = m[1].replace(/<!\[CDATA\[|\]\]>/g, "").trim();
          if (t && !t.includes("Google News") && t.length > 10) titles.push(t);
        }
        results.newsContent = titles.slice(0, 15).join("\n");
      } catch {}
    })());

    await Promise.allSettled(tasks);

    const totalChars = results.teamContent.length + results.wikipediaContent.length + results.newsContent.length;
    console.log(`[SeekContact] wiki=${results.wikipediaContent.length} team=${results.teamContent.length} news=${results.newsContent.length} total=${totalChars}`);
    return { ...results, totalChars };
  },
});