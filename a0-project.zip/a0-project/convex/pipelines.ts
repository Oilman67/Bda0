import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

export const list = query({
  args: {},
  returns: v.array(v.object({
    _id: v.id("pipelines"),
    name: v.string(),
    isDefault: v.boolean(),
  })),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const pipelines = await ctx.db
      .query("pipelines")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    return pipelines
      .filter((p: any) => !p.deletedAt)
      .map((p: any) => ({
        _id: p._id,
        name: p.name,
        isDefault: p.isDefault,
      }));
  },
});

export const getStages = query({
  args: { pipelineId: v.id("pipelines") },
  returns: v.array(v.object({
    _id: v.id("pipelineStages"),
    name: v.string(),
    position: v.number(),
    color: v.optional(v.string()),
  })),
  handler: async (ctx, { pipelineId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const stages = await ctx.db
      .query("pipelineStages")
      .withIndex("by_org_and_pipeline", (q: any) => q.eq("orgId", orgId).eq("pipelineId", pipelineId))
      .collect();
    return stages
      .filter((s: any) => !s.deletedAt)
      .sort((a: any, b: any) => a.position - b.position)
      .map((s: any) => ({
        _id: s._id,
        name: s.name,
        position: s.position,
        color: s.color,
      }));
  },
});

export const getDefaultPipeline = query({
  args: {},
  returns: v.union(v.object({
    _id: v.id("pipelines"),
    name: v.string(),
  }), v.null()),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return null;
    const { orgId } = auth;
    const pipelines = await ctx.db
      .query("pipelines")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    const def = pipelines.find((p: any) => p.isDefault && !p.deletedAt);
    if (!def) return null;
    return { _id: def._id, name: def.name };
  },
});