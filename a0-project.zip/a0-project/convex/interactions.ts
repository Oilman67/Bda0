import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

const interactionReturn = v.object({
  _id: v.id("interactions"),
  _creationTime: v.number(),
  type: v.string(),
  subject: v.optional(v.string()),
  body: v.optional(v.string()),
  date: v.number(),
  userName: v.optional(v.string()),
});

export const listByEntity = query({
  args: {
    entityType: v.string(),
    entityId: v.string(),
  },
  returns: v.array(interactionReturn),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    let interactions;
    if (args.entityType === "company") {
      interactions = await ctx.db
        .query("interactions")
        .withIndex("by_company", (q: any) => q.eq("companyId", args.entityId))
        .order("desc")
        .collect();
    } else if (args.entityType === "contact") {
      interactions = await ctx.db
        .query("interactions")
        .withIndex("by_contact", (q: any) => q.eq("contactId", args.entityId))
        .order("desc")
        .collect();
    } else {
      interactions = await ctx.db
        .query("interactions")
        .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", args.entityId))
        .order("desc")
        .collect();
    }
    const result = [];
    for (const i of interactions) {
      if (i.deletedAt || i.orgId !== orgId) continue;
      const user = await ctx.db.get(i.userId);
      result.push({
        _id: i._id,
        _creationTime: i._creationTime,
        type: i.type,
        subject: i.subject,
        body: i.body,
        date: i.date,
        userName: user?.name,
      });
    }
    return result;
  },
});

export const create = mutation({
  args: {
    type: v.string(),
    subject: v.optional(v.string()),
    body: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    opportunityId: v.optional(v.id("opportunities")),
  },
  returns: v.id("interactions"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    return await ctx.db.insert("interactions", {
      ...args,
      orgId,
      userId,
      date: Date.now(),
    });
  },
});

export const listAll = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("interactions"),
      _creationTime: v.number(),
      type: v.string(),
      subject: v.optional(v.string()),
      body: v.optional(v.string()),
      date: v.number(),
      userName: v.optional(v.string()),
      companyId: v.optional(v.string()),
      companyName: v.optional(v.string()),
      contactId: v.optional(v.string()),
      contactName: v.optional(v.string()),
    })
  ),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    const interactions = await ctx.db
      .query("interactions")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .order("desc")
      .take(100);

    const result = [];
    for (const i of interactions) {
      if (i.deletedAt) continue;
      const user = await ctx.db.get(i.userId);
      const company = i.companyId ? await ctx.db.get(i.companyId) : null;
      const contact = i.contactId ? await ctx.db.get(i.contactId) : null;
      result.push({
        _id: i._id,
        _creationTime: i._creationTime,
        type: i.type,
        subject: i.subject,
        body: i.body,
        date: i.date,
        userName: user?.name,
        companyId: i.companyId as string | undefined,
        companyName: company?.name,
        contactId: i.contactId as string | undefined,
        contactName: contact
          ? `${contact.firstName} ${contact.lastName}`
          : undefined,
      });
    }
    return result;
  },
});