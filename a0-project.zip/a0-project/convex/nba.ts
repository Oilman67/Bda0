import { query, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { safeGetUserOrgId } from "./helpers";

// Public query: get NBAs for an entity
export const getNextActions = query({
  args: {
    entryType: v.string(),
    entryId: v.string(),
  },
  returns: v.array(v.object({
    _id: v.id("nextBestActions"),
    actionType: v.string(),
    title: v.string(),
    description: v.string(),
    score: v.number(),
    reasoning: v.optional(v.string()),
    engine: v.string(),
    dismissedAt: v.optional(v.number()),
    executedAt: v.optional(v.number()),
  })),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];

    const nbas = await ctx.db
      .query("nextBestActions")
      .withIndex("by_entry", (q: any) =>
        q.eq("orgId", auth.orgId).eq("entryType", args.entryType).eq("entryId", args.entryId)
      )
      .collect();

    return nbas
      .filter((n: any) => !n.dismissedAt && !n.executedAt && (!n.expiresAt || n.expiresAt > Date.now()))
      .sort((a: any, b: any) => b.score - a.score)
      .map((n: any) => ({
        _id: n._id,
        actionType: n.actionType,
        title: n.title,
        description: n.description,
        score: n.score,
        reasoning: n.reasoning,
        engine: n.engine,
        dismissedAt: n.dismissedAt,
        executedAt: n.executedAt,
      }));
  },
});

// Upsert NBAs (internal)
export const upsertNbas = internalMutation({
  args: {
    orgId: v.id("orgs"),
    entryType: v.string(),
    entryId: v.string(),
    nbas: v.array(v.object({
      actionType: v.string(),
      title: v.string(),
      description: v.string(),
      score: v.number(),
      reasoning: v.optional(v.string()),
      engine: v.string(),
    })),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    for (const nba of args.nbas) {
      const existing = await ctx.db
        .query("nextBestActions")
        .withIndex("by_dedupe", (q: any) =>
          q.eq("orgId", args.orgId)
            .eq("entryType", args.entryType)
            .eq("entryId", args.entryId)
            .eq("actionType", nba.actionType)
        )
        .first();

      if (existing) {
        await ctx.db.patch(existing._id, {
          title: nba.title,
          description: nba.description,
          score: nba.score,
          reasoning: nba.reasoning,
          engine: nba.engine,
          expiresAt: Date.now() + 24 * 60 * 60 * 1000,
          dismissedAt: undefined,
          executedAt: undefined,
        });
      } else {
        await ctx.db.insert("nextBestActions", {
          orgId: args.orgId,
          entryType: args.entryType,
          entryId: args.entryId,
          ...nba,
          expiresAt: Date.now() + 24 * 60 * 60 * 1000,
        });
      }
    }
    return null;
  },
});