import { Id } from "./_generated/dataModel";

// getAuthUserId equivalent — avoids importing @convex-dev/auth/server
// which pulls in @auth/core → crypto (crashes React Native client bundler).
// Looks up the session from tokenIdentifier to get the real userId.
async function getAuthUserId(ctx: any): Promise<Id<"users"> | null> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;

  // tokenIdentifier format: "issuer|sessionId"
  const tokenId: string = identity.tokenIdentifier;
  const sep = tokenId.lastIndexOf("|");
  if (sep === -1) return null;

  const sessionIdStr = tokenId.substring(sep + 1);
  const session = await ctx.db.get(sessionIdStr as Id<"authSessions">);
  if (!session || !session.userId) return null;

  return session.userId as Id<"users">;
}

function makeTeamCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i += 1) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

async function makeUniqueTeamCode(ctx: any): Promise<string> {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const candidate = makeTeamCode();
    const existing = await ctx.db
      .query("orgs")
      .withIndex("by_teamCode", (q: any) => q.eq("teamCode", candidate))
      .first();
    if (!existing) {
      return candidate;
    }
  }
  throw new Error("Unable to generate a unique team code");
}

export async function getUserId(ctx: any): Promise<Id<"users">> {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");
  return userId;
}

export async function getOrCreateOrg(
  ctx: any,
  userId: Id<"users">
): Promise<Id<"orgs">> {
  const membership = await ctx.db
    .query("orgMembers")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .first();
  if (membership) return membership.orgId;

  const user = await ctx.db.get(userId);
  const orgId = await ctx.db.insert("orgs", {
    name: user?.name ? `${user.name}'s Workspace` : "My Workspace",
    ownerId: userId,
    accountType: "solo",
  });
  await ctx.db.insert("orgMembers", { orgId, userId, role: "owner" });

  const pipelineId = await ctx.db.insert("pipelines", {
    orgId, name: "Sales Pipeline", isDefault: true,
  });
  const stages = [
    { name: "Lead", position: 0, color: "#6366F1" },
    { name: "Qualified", position: 1, color: "#8B5CF6" },
    { name: "Proposal", position: 2, color: "#EC4899" },
    { name: "Negotiation", position: 3, color: "#F59E0B" },
    { name: "Closed Won", position: 4, color: "#10B981" },
  ];
  for (const s of stages) {
    await ctx.db.insert("pipelineStages", { orgId, pipelineId, ...s });
  }
  return orgId;
}

export async function createTeamWorkspace(
  ctx: any,
  userId: Id<"users">
): Promise<{ orgId: Id<"orgs">; teamCode: string }> {
  const membership = await ctx.db
    .query("orgMembers")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .first();
  if (membership) {
    const org = await ctx.db.get(membership.orgId);
    if (org) {
      let teamCode = org.teamCode || "";
      if (org.accountType !== "team") {
        teamCode = await makeUniqueTeamCode(ctx);
        await ctx.db.patch(org._id, { accountType: "team", teamCode, teamCodeCreatedAt: Date.now() });
      } else if (!teamCode) {
        teamCode = await makeUniqueTeamCode(ctx);
        await ctx.db.patch(org._id, { teamCode, teamCodeCreatedAt: Date.now() });
      }
      return { orgId: org._id, teamCode };
    }
  }

  const user = await ctx.db.get(userId);
  const teamCode = await makeUniqueTeamCode(ctx);
  const orgId = await ctx.db.insert("orgs", {
    name: user?.name ? `${user.name}'s Team` : "My Team",
    ownerId: userId,
    accountType: "team",
    teamCode,
    teamCodeCreatedAt: Date.now(),
  });
  await ctx.db.insert("orgMembers", { orgId, userId, role: "owner" });

  const pipelineId = await ctx.db.insert("pipelines", {
    orgId, name: "Sales Pipeline", isDefault: true,
  });
  const stages = [
    { name: "Lead", position: 0, color: "#6366F1" },
    { name: "Qualified", position: 1, color: "#8B5CF6" },
    { name: "Proposal", position: 2, color: "#EC4899" },
    { name: "Negotiation", position: 3, color: "#F59E0B" },
    { name: "Closed Won", position: 4, color: "#10B981" },
  ];
  for (const s of stages) {
    await ctx.db.insert("pipelineStages", { orgId, pipelineId, ...s });
  }

  return { orgId, teamCode };
}

export async function joinTeamWorkspace(
  ctx: any,
  userId: Id<"users">,
  teamCode: string
): Promise<{ orgId: Id<"orgs"> }> {
  const normalizedCode = teamCode.trim().toUpperCase();
  if (!normalizedCode) {
    throw new Error("Team code is required");
  }

  const existingMembership = await ctx.db
    .query("orgMembers")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .first();
  if (existingMembership) {
    return { orgId: existingMembership.orgId };
  }

  const org = await ctx.db
    .query("orgs")
    .withIndex("by_teamCode", (q: any) => q.eq("teamCode", normalizedCode))
    .first();
  if (!org || org.deletedAt) {
    throw new Error("Invalid team code");
  }

  await ctx.db.insert("orgMembers", { orgId: org._id, userId, role: "member" });
  return { orgId: org._id };
}

// For mutations — throws if no org (correct behavior for writes)
export async function getUserOrgId(
  ctx: any
): Promise<{ userId: Id<"users">; orgId: Id<"orgs"> }> {
  const userId = await getAuthUserId(ctx);
  if (!userId) throw new Error("Not authenticated");

  const membership = await ctx.db
    .query("orgMembers")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .first();
  if (!membership) throw new Error("No org membership");

  return { userId, orgId: membership.orgId };
}

// For queries — returns null instead of throwing (handles race condition)
export async function safeGetUserOrgId(
  ctx: any
): Promise<{ userId: Id<"users">; orgId: Id<"orgs"> } | null> {
  const userId = await getAuthUserId(ctx);
  if (!userId) return null;

  const membership = await ctx.db
    .query("orgMembers")
    .withIndex("by_user", (q: any) => q.eq("userId", userId))
    .first();
  if (!membership) return null;

  return { userId, orgId: membership.orgId };
}