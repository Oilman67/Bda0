"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";

declare const fetch: any;
declare const AbortSignal: any;

// ─── Types ──────────────────────────────────────────────────────────────────

interface Evidence {
  type: string;
  bucket: string;   // self_declared | official | exposure | third_party | weak_web
  source_url?: string;
  date?: string;
  strength: string;  // strong | medium | weak
}

interface PipelineContact {
  name: string;
  title: string;
  normalized_function: string;
  seniority: string;
  buying_role: string;
  confidence_data: number;
  confidence_role_match: number;
  confidence_current: number;
  influence_score: number;
  organizational_power: number;
  functional_relevance: number;
  practical_buying: number;
  reachability_score: number;
  email_guess_confidence: number;
  status: string;
  evidence: Evidence[];
  freshness_days: number;
  freshness_label: string;   // recent | aging | stale
  last_seen_date?: string;
  linkedin_search_url: string;
  email_guess?: string;
  surfaced_reason?: string;
  missing_info?: string;
  suggested_action?: string;
}

interface InferredRoleOutput {
  title: string;
  normalized_function: string;
  seniority: string;
  reason: string;
  suggested_queries: string[];
}

type CompanySize = "enterprise" | "mid_market" | "smb";

interface RawData {
  websiteTeam: string;
  newsroom: string;
  wikipedia: string;
  news: string;
}

interface Anchor {
  name: string;
  title: string;
  function: string;
  seniority: string;
  evidence: Evidence[];
}

interface InferredRole {
  title: string;
  function: string;
  seniority: string;
  rationale: string;
  reason_category: string;
}

interface SerpCandidate {
  name: string;
  role: string;
  occurrences: number;
  evidence: Evidence[];
  buckets_seen: Set<string>;
}

// ─── Source → Bucket Mapping ────────────────────────────────────────────────

const TYPE_TO_BUCKET: Record<string, string> = {
  company_site: "official",
  press_release: "official",
  filing: "official",
  investor_doc: "official",
  grant_doc: "official",
  procurement_doc: "official",
  conference_page: "exposure",
  podcast_page: "exposure",
  trade_publication: "third_party",
  partner_site: "third_party",
  linkedin_serp: "self_declared",
  github: "self_declared",
  news: "weak_web",
  wikipedia: "weak_web",
  job_posting: "weak_web",
  serp: "weak_web",
  llm_inference: "weak_web",
};

// ─── Validators ─────────────────────────────────────────────────────────────

const evidenceValidator = v.object({
  type: v.string(),
  bucket: v.string(),
  source_url: v.optional(v.string()),
  date: v.optional(v.string()),
  strength: v.string(),
});

const contactValidator = v.object({
  name: v.string(),
  title: v.string(),
  normalized_function: v.string(),
  seniority: v.string(),
  buying_role: v.string(),
  confidence_data: v.number(),
  confidence_role_match: v.number(),
  confidence_current: v.number(),
  influence_score: v.number(),
  organizational_power: v.number(),
  functional_relevance: v.number(),
  practical_buying: v.number(),
  reachability_score: v.number(),
  email_guess_confidence: v.number(),
  status: v.string(),
  evidence: v.array(evidenceValidator),
  freshness_days: v.number(),
  freshness_label: v.string(),
  last_seen_date: v.optional(v.string()),
  linkedin_search_url: v.string(),
  email_guess: v.optional(v.string()),
  surfaced_reason: v.optional(v.string()),
  missing_info: v.optional(v.string()),
  suggested_action: v.optional(v.string()),
});

const inferredRoleValidator = v.object({
  title: v.string(),
  normalized_function: v.string(),
  seniority: v.string(),
  reason: v.string(),
  suggested_queries: v.array(v.string()),
});

// ─── Pipeline Orchestrator ──────────────────────────────────────────────────

export const seekContactsV2 = action({
  args: {
    companyName: v.string(),
    domain: v.optional(v.string()),
    geoScope: v.optional(v.string()),
    existingContacts: v.optional(v.array(v.string())),
    ourOffering: v.optional(v.string()),
  },
  returns: v.object({
    verifiedContacts: v.array(contactValidator),
    probableContacts: v.array(contactValidator),
    inferredRoles: v.array(inferredRoleValidator),
    summary: v.string(),
    phases_completed: v.number(),
  }),
  handler: async (_ctx, args) => {
    const { companyName, domain, geoScope, existingContacts, ourOffering } = args;
    let phasesCompleted = 0;

    // ── Phase 1 ──
    console.log(`[Pipeline] Phase 1: Data collection for "${companyName}"`);
    const rawData = await collectData(companyName, domain, geoScope);
    phasesCompleted = 1;
    console.log(
      `[Pipeline] Phase 1 done: site=${rawData.websiteTeam.length}ch wiki=${rawData.wikipedia.length}ch news=${rawData.news.length}ch newsroom=${rawData.newsroom.length}ch`
    );

    const companySize = estimateCompanySize(rawData);
    console.log(`[Pipeline] Company size estimate: ${companySize}`);

    // ── Phase 2 ──
    console.log(`[Pipeline] Phase 2: Anchor extraction + role inference`);
    const { anchors, inferredRoles } = await extractAnchorsAndRoles(
      companyName, rawData, companySize, geoScope, existingContacts
    );
    phasesCompleted = 2;
    console.log(`[Pipeline] Phase 2 done: ${anchors.length} anchors, ${inferredRoles.length} inferred roles`);

    // ── Phase 3 ──
    console.log(`[Pipeline] Phase 3: Multi-channel candidate discovery`);
    const serpCandidates = await discoverCandidatesMultiChannel(
      companyName, inferredRoles, domain, companySize
    );
    phasesCompleted = 3;
    console.log(`[Pipeline] Phase 3 done: ${serpCandidates.length} candidates`);

    // ── Merge Phase 2 anchors into candidate pool ──
    // Anchors are high-quality: they come from actual source data, not SERP
    const anchorCandidates: Array<SerpCandidate> = anchors.map(a => ({
      name: a.name,
      role: a.title,
      occurrences: 1,
      evidence: a.evidence,
      buckets_seen: new Set(a.evidence.map(e => e.bucket)),
    }));

    // Merge: anchors first, then SERP candidates (anchors take priority)
    const allCandidates: Array<SerpCandidate> = [];
    const seenNames = new Set<string>();
    for (const a of anchorCandidates) {
      const key = a.name.toLowerCase();
      seenNames.add(key);
      // Check if SERP also found this person — merge evidence
      const serpMatch = serpCandidates.find(s => s.name.toLowerCase() === key);
      if (serpMatch) {
        a.evidence.push(...serpMatch.evidence);
        a.occurrences += serpMatch.occurrences;
        for (const b of serpMatch.buckets_seen) a.buckets_seen.add(b);
      }
      allCandidates.push(a);
    }
    // Add remaining SERP candidates not already covered by anchors
    for (const s of serpCandidates) {
      if (!seenNames.has(s.name.toLowerCase())) {
        allCandidates.push(s);
      }
    }
    console.log(`[Pipeline] Merged candidates: ${anchorCandidates.length} anchors + ${serpCandidates.length} SERP = ${allCandidates.length} total`);

    // ── Phase 4 ──
    // Brief delay to avoid LLM API rate limiting after Phase 2/3 LLM calls
    await new Promise(resolve => setTimeout(resolve, 2000));
    console.log(`[Pipeline] Phase 4: Validation + scoring`);
    const scored = await validateAndScore(
      allCandidates, companyName, ourOffering, domain
    );
    phasesCompleted = 4;
    console.log(`[Pipeline] Phase 4 done: ${scored.length} scored contacts`);
    console.log('[Pipeline] Phase 4 detailed:', scored.slice(0, 3).map(c => ({ name: c.name, evidence: c.evidence?.length || 0 })));

    // ── Phase 5 ──
    console.log(`[Pipeline] Phase 5: Bucket-aware validation gates`);
    const { verified, probable, rejected, inferredOutput } = applyBucketAwareValidation(
      scored, inferredRoles, companyName, domain
    );
    phasesCompleted = 5;

    const sortFn = (a: PipelineContact, b: PipelineContact) =>
      (b.influence_score * b.confidence_data) - (a.influence_score * a.confidence_data);
    verified.sort(sortFn);
    probable.sort(sortFn);

    console.log(`[Pipeline] Phase 5 done: ${verified.length}V ${probable.length}P ${inferredOutput.length}I (rejected ${rejected})`);

    const summary = buildSummary(verified, probable, inferredOutput, rawData, companySize);

    return {
      verifiedContacts: verified,
      probableContacts: probable,
      inferredRoles: inferredOutput,
      summary,
      phases_completed: phasesCompleted,
    };
  },
});

// ─── Phase 1: Parallel Data Collection ──────────────────────────────────────

async function collectData(
  companyName: string,
  domain: string | undefined,
  geoScope: string | undefined
): Promise<RawData> {
  const results: RawData = { websiteTeam: "", newsroom: "", wikipedia: "", news: "" };
  const tasks: Array<Promise<void>> = [];

  if (domain) {
    const base = domain.startsWith("http") ? domain : `https://${domain}`;

    tasks.push((async () => {
      const paths = ["/team", "/leadership", "/about", "/our-team", "/about-us", "/people", "/executives"];
      const pages = await Promise.all(paths.map(p => safeFetch(`${base}${p}`, 6000)));
      results.websiteTeam = pages.filter(Boolean).map(stripHtml).join("\n---\n").slice(0, 10000);
    })());

    tasks.push((async () => {
      const paths = ["/news", "/newsroom", "/press", "/press-releases", "/media"];
      const pages = await Promise.all(paths.map(p => safeFetch(`${base}${p}`, 6000)));
      results.newsroom = pages.filter(Boolean).map(stripHtml).join("\n---\n").slice(0, 8000);
    })());
  }

  if (companyName.length > 3) {
    tasks.push((async () => {
      try {
        const UA = "BDBuddy/2.0 (contact@bdbuddy.app)";
        const clean = companyName.replace(/\s*\(.*?\)\s*/g, "").trim();
        const sr = await fetch(
          `https://en.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(clean)}&limit=3&format=json`,
          { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(5000) }
        );
        if (!sr.ok) return;
        const [, titles] = await sr.json();
        if (!titles?.length) return;
        const pr = await fetch(
          `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(titles[0])}&prop=extracts&explaintext=true&format=json`,
          { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(6000) }
        );
        if (!pr.ok) return;
        const d = await pr.json();
        const rawExtract = Object.values(d?.query?.pages || {})
          .map((p: any) => p.extract || "").join("\n").slice(0, 12000);
        // Relevance check: verify the article is actually about this company
        const extractLower = rawExtract.slice(0, 800).toLowerCase();
        const nameWords = companyName.toLowerCase().replace(/[^a-z0-9\s]/g, "").split(/\s+/).filter(w => w.length > 2);
        const matchCount = nameWords.filter(w => extractLower.includes(w)).length;
        const isRelevant = matchCount >= Math.ceil(nameWords.length * 0.5) ||
          extractLower.includes("company") || extractLower.includes("corporation") ||
          extractLower.includes("founded") || extractLower.includes("headquartered") ||
          extractLower.includes("business") || extractLower.includes("entreprise") ||
          extractLower.includes("société") || extractLower.includes("inc.");
        if (isRelevant) {
          results.wikipedia = rawExtract;
        } else {
          console.log(`[Pipeline P1] Wikipedia EN discarded — article not relevant to "${companyName}"`);
        }
      } catch { /* timeout or network */ }
    })());
  }

  // French Wikipedia (critical for Quebec companies)
  if (companyName.length > 3) {
    tasks.push((async () => {
      try {
        const UA = "BDBuddy/2.0 (contact@bdbuddy.app)";
        const clean = companyName.replace(/\s*\(.*?\)\s*/g, "").trim();
        const sr = await fetch(
          `https://fr.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(clean)}&limit=3&format=json`,
          { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(5000) }
        );
        if (!sr.ok) return;
        const [, titles] = await sr.json();
        if (!titles?.length) return;
        const pr = await fetch(
          `https://fr.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(titles[0])}&prop=extracts&explaintext=true&format=json`,
          { headers: { "User-Agent": UA }, signal: AbortSignal.timeout(6000) }
        );
        if (!pr.ok) return;
        const d = await pr.json();
        const frText = Object.values(d?.query?.pages || {})
          .map((p: any) => p.extract || "").join("\n").slice(0, 8000);
        if (frText.length > 100) {
          // Relevance check for French Wikipedia
          const frLower = frText.slice(0, 800).toLowerCase();
          const frNameWords = companyName.toLowerCase().replace(/[^a-z0-9\s]/g, "").split(/\s+/).filter((w: string) => w.length > 2);
          const frMatchCount = frNameWords.filter((w: string) => frLower.includes(w)).length;
          const frIsRelevant = frMatchCount >= Math.ceil(frNameWords.length * 0.5) ||
            frLower.includes("company") || frLower.includes("corporation") ||
            frLower.includes("founded") || frLower.includes("entreprise") ||
            frLower.includes("société") || frLower.includes("inc.") ||
            frLower.includes("business") || frLower.includes("headquartered");
          if (frIsRelevant) {
            results.wikipedia = (results.wikipedia + "\n\n--- FRENCH WIKIPEDIA ---\n" + frText).slice(0, 15000);
          } else {
            console.log(`[Pipeline P1] Wikipedia FR discarded — article not relevant to "${companyName}"`);
          }
        }
      } catch { /* timeout or network */ }
    })());
  }

  tasks.push((async () => {
    try {
      const clean = companyName.replace(/\s*\(.*?\)\s*/g, "").trim();
      const geo = geoScope ? ` ${geoScope}` : "";
      const q = encodeURIComponent(`"${clean}"${geo} CEO OR president OR VP OR director OR appointed OR named`);
      const r = await fetch(
        `https://news.google.com/rss/search?q=${q}&hl=en&gl=CA&ceid=CA:en`,
        { signal: AbortSignal.timeout(6000) }
      );
      if (!r.ok) return;
      const xml = await r.text();
      const items: Array<string> = [];
      const re = /<item>([\s\S]*?)<\/item>/g;
      let m;
      while ((m = re.exec(xml)) !== null && items.length < 20) {
        const t = m[1].match(/<title>([\s\S]*?)<\/title>/)?.[1]?.replace(/<!\[CDATA\[|\]\]>/g, "").trim() || "";
        const pd = m[1].match(/<pubDate>([\s\S]*?)<\/pubDate>/)?.[1]?.trim() || "";
        if (t && !t.includes("Google News") && t.length > 10) items.push(`${t} [${pd}]`);
      }
      results.news = items.join("\n");
    } catch { /* timeout */ }
  })());

  await Promise.allSettled(tasks);
  return results;
}

// ─── Phase 2: Anchor Extraction + Role Inference ────────────────────────────

async function extractAnchorsAndRoles(
  companyName: string,
  rawData: RawData,
  companySize: CompanySize,
  geoScope: string | undefined,
  existingContacts: string[] | undefined
): Promise<{ anchors: Array<Anchor>; inferredRoles: Array<InferredRole> }> {
  const sections: Array<string> = [];
  if (rawData.websiteTeam) sections.push(`COMPANY WEBSITE (team/leadership):\n${rawData.websiteTeam.slice(0, 4000)}`);
  if (rawData.newsroom) sections.push(`COMPANY NEWSROOM/PRESS:\n${rawData.newsroom.slice(0, 2000)}`);
  if (rawData.wikipedia) sections.push(`WIKIPEDIA:\n${rawData.wikipedia.slice(0, 4000)}`);
  if (rawData.news) sections.push(`RECENT NEWS:\n${rawData.news.slice(0, 2000)}`);

  if (sections.length === 0) {
    sections.push("No external data found. Rely on structural inference ONLY — do NOT invent names.");
  }

  const exclude = existingContacts?.length
    ? `\nEXCLUDE these known contacts: ${existingContacts.join(", ")}` : "";

  const depth = companySize === "enterprise"
    ? "Large enterprise. Extract up to 15 anchors, infer up to 10 adjacent roles."
    : companySize === "mid_market"
    ? "Mid-market company. Extract up to 8 anchors, infer up to 6 adjacent roles."
    : "Small company. Extract up to 4 anchors (CEO, Ops, Sales). Infer up to 3 roles.";

  const sys = `You are a B2B intelligence analyst. TWO tasks:

PART 1 — ANCHOR EXTRACTION:
Extract ONLY explicitly named individuals from the data. Each MUST have:
- A real name that appears verbatim in the source data
- Their title as stated
- source_type: "company_site" | "press_release" | "news" | "wikipedia"
- evidence_strength: "strong" (official page) or "medium" (news, Wikipedia)

STRICT RULES:
- Do NOT invent or fabricate names. Only use names found verbatim in the source data.
- Do NOT treat your prior knowledge as evidence.
- Wikipedia evidence is always "medium" strength, never "strong".
- ONLY extract people who are CURRENT EMPLOYEES or EXECUTIVES of this BUSINESS ENTITY.
- Do NOT extract historical figures, monarchs, politicians, military leaders, founders who are deceased, or anyone who is not currently working at the company.
- If the source data appears to be about a different entity (historical, governmental, etc.), return EMPTY anchors.

PART 2 — ROLE INFERENCE:
From the anchors + typical org structure, infer roles that likely exist but were NOT found.
- Output role titles ONLY — NO names
- Brief rationale for each
- reason_category MUST be one of: "existing_leaders" | "company_size" | "industry" | "project_context" | "job_posting"

Function taxonomy:
Operations | Engineering | Procurement | Sustainability | Finance | Commercial/Sales | Strategy | Manufacturing | Supply Chain | IT/Digital | HR | Legal/External Affairs | Marketing | Executive | Other

${depth}
${geoScope ? `Geographic focus: ${geoScope}. Prioritize regional leadership.` : ""}${exclude}`;

  const usr = `Company: "${companyName}"\nSize: ${companySize}\n\n${sections.join("\n\n===\n\n")}`;

  const schema = {
    type: "object",
    properties: {
      anchors: {
        type: "array",
        items: {
          type: "object",
          properties: {
            name: { type: "string" },
            title: { type: "string" },
            function: { type: "string" },
            seniority: { type: "string", description: "C-Level|VP|Director|Manager|Other" },
            source_type: { type: "string" },
            evidence_strength: { type: "string" },
          },
          required: ["name", "title", "function", "seniority", "source_type", "evidence_strength"],
        },
      },
      inferred_roles: {
        type: "array",
        items: {
          type: "object",
          properties: {
            title: { type: "string" },
            function: { type: "string" },
            seniority: { type: "string" },
            rationale: { type: "string" },
            reason_category: { type: "string", description: "existing_leaders|company_size|industry|project_context|job_posting" },
          },
          required: ["title", "function", "seniority", "rationale", "reason_category"],
        },
      },
    },
    required: ["anchors", "inferred_roles"],
  };

  const result = await callLlm(sys, usr, schema);
  if (!result) {
    console.log(`[Pipeline P2] LLM returned null — prompt was ${usr.length} chars. Attempting simpler retry...`);
    // Try a simpler prompt with less data
    const shortUsr = `Company: "${companyName}" (${companySize})\n\n${sections.map(s => s.slice(0, 1500)).join("\n\n===\n\n")}`;
    const simpleSchema = {
      type: "object",
      properties: {
        anchors: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              title: { type: "string" },
              function: { type: "string" },
              seniority: { type: "string" },
            },
            required: ["name", "title", "function", "seniority"],
          },
        },
        inferred_roles: {
          type: "array",
          items: {
            type: "object",
            properties: {
              title: { type: "string" },
              function: { type: "string" },
              seniority: { type: "string" },
              rationale: { type: "string" },
            },
            required: ["title", "function", "seniority", "rationale"],
          },
        },
      },
      required: ["anchors", "inferred_roles"],
    };
    const retryResult = await callLlm(
      "Extract named people and infer missing roles for this company. Return JSON with anchors (real names found) and inferred_roles (likely roles, no names). Do NOT invent names.",
      shortUsr,
      simpleSchema
    );
    if (retryResult) {
      console.log(`[Pipeline P2] Simplified retry succeeded: ${retryResult.anchors?.length || 0} anchors, ${retryResult.inferred_roles?.length || 0} roles`);
      const retryAnchors: Array<Anchor> = (retryResult.anchors || [])
        .map((a: any) => ({
          name: a.name || "",
          title: a.title || "",
          function: a.function || "Other",
          seniority: a.seniority || "Other",
          evidence: [{ type: "company_site", bucket: "official", strength: "medium" }] as Array<Evidence>,
        }))
        .filter((a: Anchor) => a.name && a.name !== "Unknown" && a.name !== "To be identified");
      const retryRoles: Array<InferredRole> = (retryResult.inferred_roles || []).map((r: any) => ({
        title: r.title || "",
        function: r.function || "Other",
        seniority: r.seniority || "Other",
        rationale: r.rationale || "",
        reason_category: "company_size",
      }));
      return { anchors: retryAnchors, inferredRoles: retryRoles };
    }
    console.log(`[Pipeline P2] Simplified retry also failed`);
    return { anchors: [], inferredRoles: [] };
  }
  console.log(`[Pipeline P2] LLM succeeded: anchors=${result.anchors?.length || 0}, roles=${result.inferred_roles?.length || 0}`);

  const anchors: Array<Anchor> = (result.anchors || [])
    .map((a: any) => {
      const sourceType = a.source_type || "company_site";
      return {
        name: a.name || "",
        title: a.title || "",
        function: a.function || "Other",
        seniority: a.seniority || "Other",
        evidence: [{
          type: sourceType,
          bucket: TYPE_TO_BUCKET[sourceType] || "weak_web",
          strength: a.evidence_strength || "medium",
        }] as Array<Evidence>,
      };
    })
    .filter((a: Anchor) => a.name && a.name !== "Unknown" && a.name !== "To be identified");

  const inferredRoles: Array<InferredRole> = (result.inferred_roles || []).map((r: any) => ({
    title: r.title || "",
    function: r.function || "Other",
    seniority: r.seniority || "Other",
    rationale: r.rationale || "",
    reason_category: r.reason_category || "company_size",
  }));

  return { anchors, inferredRoles };
}

// ─── Phase 3: Multi-Channel Candidate Discovery ────────────────────────────

interface QueryFamily {
  evidenceType: string;
  bucket: string;
  strength: string;
  buildQuery: (company: string, role: string, func: string, domain?: string) => string;
}

const QUERY_FAMILIES: Record<string, QueryFamily> = {
  linkedin_serp: {
    evidenceType: "linkedin_serp",
    bucket: "self_declared",
    strength: "medium",
    buildQuery: (co, role) => `site:linkedin.com/in "${co}" "${role}"`,
  },
  pdf_document: {
    evidenceType: "investor_doc",
    bucket: "official",
    strength: "medium",
    buildQuery: (co, role) => `"${co}" filetype:pdf "${role}"`,
  },
  conference_exposure: {
    evidenceType: "conference_page",
    bucket: "exposure",
    strength: "medium",
    buildQuery: (co, _role, func) => `"${co}" speaker ${func} conference OR webinar`,
  },
  official_docs: {
    evidenceType: "procurement_doc",
    bucket: "official",
    strength: "medium",
    buildQuery: (co, role) => `"${co}" procurement OR grant OR regulatory "${role}"`,
  },
  partner_third_party: {
    evidenceType: "partner_site",
    bucket: "third_party",
    strength: "medium",
    buildQuery: (co, _role, func) => `"${co}" partner OR collaboration ${func}`,
  },
  generic_serp: {
    evidenceType: "serp",
    bucket: "weak_web",
    strength: "weak",
    buildQuery: (co, role) => `"${co}" "${role}"`,
  },
};

const FAMILIES_BY_SIZE: Record<CompanySize, string[]> = {
  enterprise: ["linkedin_serp", "pdf_document", "conference_exposure", "official_docs", "partner_third_party", "generic_serp"],
  mid_market: ["linkedin_serp", "conference_exposure", "partner_third_party", "generic_serp"],
  smb: ["linkedin_serp", "generic_serp"],
};

async function discoverCandidatesMultiChannel(
  companyName: string,
  inferredRoles: Array<InferredRole>,
  domain: string | undefined,
  companySize: CompanySize
): Promise<Array<SerpCandidate>> {
  const families = FAMILIES_BY_SIZE[companySize];
  const maxRoles = companySize === "enterprise" ? 5 : companySize === "mid_market" ? 4 : 3;
  const rolesToSearch = inferredRoles.slice(0, maxRoles);

  if (rolesToSearch.length === 0) return [];

  // Top 2 roles get all families; rest get linkedin + generic only
  const queryPlan: Array<{ role: InferredRole; familyKey: string; family: QueryFamily }> = [];
  for (let i = 0; i < rolesToSearch.length; i++) {
    const role = rolesToSearch[i];
    const fams = i < 2 ? families : families.filter(f => f === "linkedin_serp" || f === "generic_serp");
    for (const fKey of fams) {
      const family = QUERY_FAMILIES[fKey];
      if (family) queryPlan.push({ role, familyKey: fKey, family });
    }
  }

  const maxQueries = companySize === "enterprise" ? 16 : companySize === "mid_market" ? 12 : 6;
  const plan = queryPlan.slice(0, maxQueries);
  console.log(`[Pipeline P3] ${plan.length} queries across ${new Set(plan.map(p => p.familyKey)).size} families`);

  const candidateMap = new Map<string, {
    name: string; role: string; occurrences: number;
    evidence: Evidence[]; buckets_seen: Set<string>;
  }>();
  const allSnippets: string[] = [];

  // Batched execution (4 at a time) to avoid rate limits
  for (let batch = 0; batch < plan.length; batch += 4) {
    const batchItems = plan.slice(batch, batch + 4);
    const tasks = batchItems.map(async ({ role, family }) => {
      try {
        const query = family.buildQuery(companyName, role.title, role.function, domain);
        const html = await safeFetch(
          `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
          8000
        );
        if (!html) return;

        const text = extractDdgSnippets(html);
        if (text.length > 20) allSnippets.push(text);
        const names = extractNamesFromText(text, companyName);

        for (const [name, count] of Object.entries(names)) {
          if (count < 1) continue;
          const key = name.toLowerCase();
          const existing = candidateMap.get(key);

          const ev: Evidence = {
            type: family.evidenceType,
            bucket: family.bucket,
            strength: count >= 2 ? "medium" : family.strength,
          };

          if (existing) {
            existing.occurrences += count;
            existing.evidence.push(ev);
            existing.buckets_seen.add(family.bucket);
          } else {
            candidateMap.set(key, {
              name,
              role: role.title,
              occurrences: count,
              evidence: [ev],
              buckets_seen: new Set([family.bucket]),
            });
          }
        }
      } catch { /* non-fatal */ }
    });

    await Promise.allSettled(tasks);
  }

  // If regex-based extraction found very few candidates, try LLM-based extraction
  if (candidateMap.size < 3 && allSnippets.length > 0) {
    console.log(`[Pipeline P3] Only ${candidateMap.size} regex candidates. Trying LLM extraction on ${allSnippets.length} snippets...`);
    const snippetText = allSnippets.slice(0, 30).join("\n");
    const llmResult = await callLlm(
      `Extract all real person names mentioned in these search result snippets for "${companyName}". Return ONLY names that appear to be employees or leaders at "${companyName}". Do NOT invent names.`,
      snippetText,
      {
        type: "object",
        properties: {
          people: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                title: { type: "string", description: "Their role/title if mentioned" },
              },
              required: ["name"],
            },
          },
        },
        required: ["people"],
      }
    );
    if (llmResult?.people) {
      console.log(`[Pipeline P3] LLM found ${llmResult.people.length} additional candidates`);
      for (const p of llmResult.people) {
        if (!p.name || !looksLikeRealName(p.name)) continue;
        const key = p.name.toLowerCase();
        if (!candidateMap.has(key)) {
          candidateMap.set(key, {
            name: p.name,
            role: p.title || rolesToSearch[0]?.title || "Unknown",
            occurrences: 1,
            evidence: [{ type: "serp", bucket: "weak_web", strength: "weak" }],
            buckets_seen: new Set(["weak_web"]),
          });
        }
      }
    }
  }

  return Array.from(candidateMap.values()).map(c => ({
    name: c.name,
    role: c.role,
    occurrences: c.occurrences,
    evidence: c.evidence,
    buckets_seen: c.buckets_seen,
  }));
}

// ─── Phase 4: Validation + Scoring ──────────────────────────────────────────

async function validateAndScore(
  serpCandidates: Array<SerpCandidate>,
  companyName: string,
  ourOffering: string | undefined,
  domain: string | undefined
): Promise<Array<PipelineContact>> {
  const merged = new Map<string, {
    name: string; title: string; function: string; seniority: string;
    evidence: Array<Evidence>; fromAnchor: boolean; fromSerp: boolean;
    buckets_seen: Set<string>;
  }>();

  for (const s of serpCandidates) {
    const key = s.name.toLowerCase();
    const ex = merged.get(key);
    if (ex) {
      ex.evidence.push(...s.evidence);
      for (const b of s.buckets_seen) ex.buckets_seen.add(b);
      ex.fromSerp = true;
    } else {
      merged.set(key, {
        name: s.name, title: s.role, function: "Other", seniority: "Other",
        evidence: [...s.evidence], fromAnchor: false, fromSerp: true,
        buckets_seen: new Set(s.buckets_seen),
      });
    }
  }

  const mergedList = Array.from(merged.values());
  const contacts: Array<PipelineContact> = [];

  if (mergedList.length > 0) {
    const sys = `You are a B2B intelligence validator. For each candidate:

1. buying_role: "Decision Maker" | "Economic Buyer" | "Technical" | "Influencer" | "User"
2. normalized_function: Executive | Operations | Sales | Engineering | Finance | Legal | Marketing | HR | Strategy | IT | Procurement | Sustainability | Manufacturing | Supply Chain | Other
3. seniority: C-Level | VP | Director | Manager | Other
4. role_match_confidence: 0-1 (how sure title matches role at THIS company)
5. functional_relevance: 1-5 (how directly their function relates to our offering — 5=direct problem owner, 3=adjacent, 1=distant)
6. practical_buying: 1-5 (likely role in purchase: 5=budget owner, 4=technical evaluator, 3=user sponsor, 2=implementation lead, 1=distant)

STRICT RULES:
- Do NOT invent names or upgrade weak evidence.
- Do NOT use your prior knowledge as evidence.
- Assessments must be grounded in the evidence types listed for each candidate.

${ourOffering ? `Our offering: ${ourOffering}` : ""}`;

    const list = mergedList
      .map((c, i) => {
        const bkts = Array.from(c.buckets_seen).join(", ");
        return `${i + 1}. ${c.name} — ${c.title} (evidence: ${c.evidence.map(e => e.type).join(", ")}) [buckets: ${bkts}]`;
      })
      .join("\n");

    const schema = {
      type: "object",
      properties: {
        assessments: {
          type: "array",
          items: {
            type: "object",
            properties: {
              index: { type: "number" },
              buying_role: { type: "string" },
              normalized_function: { type: "string" },
              seniority: { type: "string" },
              role_match_confidence: { type: "number" },
              functional_relevance: { type: "number" },
              practical_buying: { type: "number" },
            },
            required: ["index", "buying_role", "normalized_function", "seniority", "role_match_confidence", "functional_relevance", "practical_buying"],
          },
        },
      },
      required: ["assessments"],
    };

    const userPrompt = `Company: "${companyName}"\n\nCandidates:\n${list}`;
    console.log(`[Pipeline P4] LLM call: sys=${sys.length}ch usr=${userPrompt.length}ch candidates=${mergedList.length}`);
    const result = await callLlm(sys, userPrompt, schema);
    console.log(`[Pipeline P4] LLM result: ${result ? `got ${result.assessments?.length || 0} assessments` : 'FAILED (null)'}`);
    
    let assessments: Array<any> = result?.assessments || [];
    
    // If LLM returned empty assessments but didn't fail, try a simpler prompt
    if (result && assessments.length === 0 && mergedList.length > 0) {
      console.log(`[Pipeline P4] LLM returned empty assessments. Raw keys: ${JSON.stringify(Object.keys(result))}. Trying simplified retry...`);
      const simpleList = mergedList.map((c, i) => `${i + 1}. ${c.name} — ${c.title}`).join("\n");
      const simpleResult = await callLlm(
        `For each person at "${companyName}", classify their buying_role (Decision Maker/Economic Buyer/Technical/Influencer/User), normalized_function (Executive/Operations/Sales/Engineering/Finance/Legal/Marketing/HR/IT/Other), seniority (C-Level/VP/Director/Manager/Other). Return JSON.`,
        simpleList,
        {
          type: "object",
          properties: {
            assessments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  index: { type: "number" },
                  buying_role: { type: "string" },
                  normalized_function: { type: "string" },
                  seniority: { type: "string" },
                },
                required: ["index", "buying_role", "normalized_function", "seniority"],
              },
            },
          },
          required: ["assessments"],
        }
      );
      if (simpleResult?.assessments?.length > 0) {
        console.log(`[Pipeline P4] Simplified retry got ${simpleResult.assessments.length} assessments`);
        assessments = simpleResult.assessments;
      }
    }

    // If LLM validation failed entirely, apply strict heuristic filtering
    const llmFailed = assessments.length === 0;
    if (llmFailed) {
      console.log(`[Pipeline P4] LLM validation failed — applying STRICT heuristic filter on ${mergedList.length} candidates`);
    }

    for (let i = 0; i < mergedList.length; i++) {
      const cand = mergedList[i];
      const assess = assessments.find((a: any) => a.index === i + 1) || {};

      // Always validate the name looks like a real person name
      if (!looksLikeRealName(cand.name)) {
        console.log(`[Pipeline P4] Name REJECT: "${cand.name}" — does not look like a real person name`);
        continue;
      }

      // When LLM failed: be VERY strict — only keep names with strong multi-bucket evidence
      if (llmFailed) {
        const nonWeakBuckets = new Set(
          cand.evidence.filter(e => e.bucket !== "weak_web").map(e => e.bucket)
        );
        const hasNonWeakEvidence = nonWeakBuckets.size > 0;
        const bucketCount = cand.buckets_seen.size;
        const evidenceCount = cand.evidence.length;

        // Without LLM: require non-weak evidence OR 3+ evidence from 2+ buckets
        if (!hasNonWeakEvidence && (evidenceCount < 3 || bucketCount < 2)) {
          console.log(`[Pipeline P4] Heuristic REJECT: "${cand.name}" — LLM failed, only weak_web evidence (${evidenceCount}ev, ${bucketCount}bkt)`);
          continue;
        }
      }

      const confData = computeDataConfidence(cand.evidence);
      const confRole = typeof assess.role_match_confidence === "number" ? assess.role_match_confidence : 0.5;
      const freshness = computeFreshness(cand.evidence);
      const freshnessLabel = freshness < 180 ? "recent" : freshness <= 540 ? "aging" : "stale";
      const lastSeenDate = computeLastSeenDate(cand.evidence);
      const confCurrent = computeCurrentConfidence(cand.evidence, freshness, cand.buckets_seen);

      const sen = assess.seniority && assess.seniority !== "Other" ? assess.seniority : (cand.seniority || "Other");
      const orgPower = SENIORITY_INFLUENCE[sen] || 1;
      const funcRel = Math.min(5, Math.max(1, assess.functional_relevance || 3));
      const practBuy = Math.min(5, Math.max(1, assess.practical_buying || 2));
      const influence = Number(((orgPower * 0.35) + (funcRel * 0.35) + (practBuy * 0.3)).toFixed(1));

      const reachability = computeReachability(cand.name, domain);
      const emailGuessConf = computeEmailGuessConfidence(cand.name, domain);
      const linkedIn = buildLinkedInUrl(cand.name, companyName);
      const email = domain ? guessEmail(cand.name, domain) : undefined;

      const bucketsHit = Array.from(cand.buckets_seen);
      const surfacedReason = buildSurfacedReason(cand.evidence, bucketsHit);
      const missingInfo = buildMissingInfo(bucketsHit, email, confCurrent);
      const suggestedAction = buildSuggestedAction(bucketsHit, cand.name, companyName, confCurrent);

      // Prefer LLM's function, but fall back to Phase 2's original classification
      const normalizedFunc = (assess.normalized_function && assess.normalized_function !== "Other")
        ? assess.normalized_function
        : (cand.function && cand.function !== "Other" ? cand.function : (assess.normalized_function || "Other"));

      contacts.push({
        name: cand.name,
        title: cand.title,
        normalized_function: normalizedFunc,
        seniority: sen,
        buying_role: assess.buying_role || "Influencer",
        confidence_data: confData,
        confidence_role_match: confRole,
        confidence_current: confCurrent,
        influence_score: influence,
        organizational_power: orgPower,
        functional_relevance: funcRel,
        practical_buying: practBuy,
        reachability_score: reachability,
        email_guess_confidence: emailGuessConf,
        status: "Probable",
        evidence: cand.evidence,
        freshness_days: freshness,
        freshness_label: freshnessLabel,
        last_seen_date: lastSeenDate,
        linkedin_search_url: linkedIn,
        email_guess: email,
        surfaced_reason: surfacedReason,
        missing_info: missingInfo,
        suggested_action: suggestedAction,
      });
    }
  }

  return contacts;
}

// ─── Phase 5: Bucket-Aware Validation Gates ─────────────────────────────────

function applyBucketAwareValidation(
  contacts: Array<PipelineContact>,
  inferredRoles: Array<InferredRole>,
  companyName: string,
  domain: string | undefined
): {
  verified: Array<PipelineContact>;
  probable: Array<PipelineContact>;
  rejected: number;
  inferredOutput: Array<InferredRoleOutput>;
} {
  const verified: Array<PipelineContact> = [];
  const probable: Array<PipelineContact> = [];
  let rejected = 0;

  for (const c of contacts) {
    const buckets = new Set((c.evidence || []).map(e => e.bucket));
    const bucketCount = buckets.size;
    const hasStrongOfficial = (c.evidence || []).some(e => e.bucket === "official" && e.strength === "strong");
    const hasStrongCompany = (c.evidence || []).some(e => e.type === "company_site" && e.strength === "strong");
    const hasMediumPlus = (c.evidence || []).some(e => e.strength === "strong" || e.strength === "medium");
    const onlyWeakWeb = (c.evidence || []).every(e => e.bucket === "weak_web");
    const onlyLlmInference = (c.evidence || []).every(e => e.type === "llm_inference");
    const isStale = c.freshness_label === "stale";
    const hasRecentEvidence = (c.evidence || []).some(e => {
      if (!e.date) return false;
      try { return Math.floor((Date.now() - new Date(e.date).getTime()) / 86400000) < 180; } catch { return false; }
    });

    // REJECT
    if (onlyLlmInference) { rejected++; continue; }
    if (onlyWeakWeb && !hasMediumPlus) { rejected++; continue; }
    if (bucketCount <= 1 && (c.evidence || []).length === 1 && (c.evidence || [])[0].strength === "weak") { rejected++; continue; }

    // VERIFIED: strong official/company + different bucket + not stale (or recent corroboration)
    if (
      (hasStrongOfficial || hasStrongCompany) &&
      bucketCount >= 2 &&
      (!isStale || hasRecentEvidence)
    ) {
      verified.push({ ...c, status: "Verified" });
      continue;
    }

    // PROBABLE: 2+ buckets with at least 1 medium signal
    if (bucketCount >= 2 && hasMediumPlus) {
      const penalty = isStale && !hasRecentEvidence ? 0.7 : 1;
      probable.push({
        ...c,
        status: "Probable",
        confidence_data: Number((c.confidence_data * penalty).toFixed(2)),
      });
      continue;
    }

    // PROBABLE fallback: strong official even if single bucket
    if (hasStrongOfficial || hasStrongCompany) {
      const penalty = isStale ? 0.7 : 1;
      probable.push({
        ...c,
        status: "Probable",
        confidence_data: Number((c.confidence_data * penalty).toFixed(2)),
      });
      continue;
    }

    // Everything else rejected
    rejected++;
  }

  // Build inferred role output
  const coveredFunctions = new Set([
    ...verified.map(c => c.normalized_function.toLowerCase()),
    ...probable.map(c => c.normalized_function.toLowerCase()),
  ]);

  const inferredOutput: Array<InferredRoleOutput> = inferredRoles
    .filter(r => !coveredFunctions.has(r.function.toLowerCase()))
    .map(r => ({
      title: r.title,
      normalized_function: r.function,
      seniority: r.seniority,
      reason: `${r.rationale} (${r.reason_category.replace(/_/g, " ")})`,
      suggested_queries: [
        `site:linkedin.com/in "${companyName}" "${r.title}"`,
        `"${companyName}" "${r.title}" announcement OR appointed`,
        domain ? `site:${domain} ${r.title}` : `"${companyName}" ${r.function} leader`,
      ].filter(Boolean) as string[],
    }));

  return { verified, probable, rejected, inferredOutput };
}

// ─── Scoring Helpers ────────────────────────────────────────────────────────

const SENIORITY_INFLUENCE: Record<string, number> = {
  "C-Level": 5, "VP": 4, "Director": 3, "Manager": 2, "Other": 1,
};

const SOURCE_WEIGHTS: Record<string, number> = {
  company_site: 0.9, press_release: 0.85, filing: 0.9,
  investor_doc: 0.85, grant_doc: 0.8, procurement_doc: 0.8,
  conference_page: 0.7, podcast_page: 0.65,
  trade_publication: 0.7, partner_site: 0.65,
  linkedin_serp: 0.75, github: 0.5,
  news: 0.55, wikipedia: 0.45, job_posting: 0.4,
  serp: 0.35, llm_inference: 0.15,
};

const STRENGTH_MULT: Record<string, number> = {
  strong: 1.0, medium: 0.7, weak: 0.4,
};

function computeDataConfidence(evidence: Array<Evidence>): number {
  if (!evidence || evidence.length === 0) return 0;
  let total = 0;
  for (const e of evidence) {
    total += (SOURCE_WEIGHTS[e.type] || 0.3) * (STRENGTH_MULT[e.strength] || 0.5);
  }
  const uniqueBuckets = new Set(evidence.map(e => e.bucket)).size;
  const uniqueTypes = new Set(evidence.map(e => e.type)).size;
  const bucketBonus = Math.min(0.15, (uniqueBuckets - 1) * 0.06);
  const typeBonus = Math.min(0.1, (uniqueTypes - 1) * 0.03);
  return Math.min(1, Number(((total / evidence.length) + bucketBonus + typeBonus).toFixed(2)));
}

function computeCurrentConfidence(
  evidence: Array<Evidence>, freshnessDays: number, buckets: Set<string>
): number {
  if (!evidence || evidence.length === 0) return 0.3;
  let score = 0.5;
  if (freshnessDays < 180) score += 0.3;
  else if (freshnessDays < 540) score += 0.1;
  else score -= 0.2;

  if (buckets.has("self_declared")) score += 0.15;

  const recentCount = evidence.filter(e => {
    if (!e.date) return false;
    try { return Math.floor((Date.now() - new Date(e.date).getTime()) / 86400000) < 365; } catch { return false; }
  }).length;
  if (recentCount >= 2) score += 0.1;

  return Math.min(1, Math.max(0, Number(score.toFixed(2))));
}

function computeFreshness(evidence: Array<Evidence>): number {
  if (!evidence || evidence.length === 0) return 999;
  const now = Date.now();
  let min = 999;
  for (const e of evidence) {
    if (e.date) {
      try {
        const days = Math.floor((now - new Date(e.date).getTime()) / 86400000);
        if (days >= 0 && days < min) min = days;
      } catch { /* ignore */ }
    }
  }
  return min;
}

function computeLastSeenDate(evidence: Array<Evidence>): string | undefined {
  if (!evidence || evidence.length === 0) return undefined;
  let latest: Date | null = null;
  for (const e of evidence) {
    if (e.date) {
      try {
        const d = new Date(e.date);
        if (!latest || d > latest) latest = d;
      } catch { /* ignore */ }
    }
  }
  return latest ? latest.toISOString().split("T")[0] : undefined;
}

function computeReachability(name: string, domain: string | undefined): number {
  let s = 0.2;
  if (domain && !name.startsWith("[")) s += 0.4;
  if (!name.startsWith("[")) s += 0.3;
  return Math.min(1, Number(s.toFixed(2)));
}

function computeEmailGuessConfidence(name: string, domain: string | undefined): number {
  if (!domain || name.startsWith("[")) return 0;
  let score = 0.3;
  if (domain && !domain.includes("gmail") && !domain.includes("yahoo")) score += 0.2;
  const parts = name.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
  if (parts.length >= 2) score += 0.2;
  const commonFirst = new Set(["john", "david", "michael", "james", "robert", "william"]);
  if (parts.length >= 1 && !commonFirst.has(parts[0])) score += 0.1;
  return Math.min(1, Number(score.toFixed(2)));
}

// ─── Explanation Builders ───────────────────────────────────────────────────

const BUCKET_LABELS: Record<string, string> = {
  self_declared: "Self-declared",
  official: "Official",
  exposure: "Exposure",
  third_party: "Third-party",
  weak_web: "Web",
};

const EVIDENCE_TYPE_LABELS: Record<string, string> = {
  company_site: "Company Website", press_release: "Press Release",
  filing: "Filing", investor_doc: "Investor Document",
  grant_doc: "Grant Document", procurement_doc: "Procurement Document",
  conference_page: "Conference Page", podcast_page: "Podcast",
  trade_publication: "Trade Publication", partner_site: "Partner Site",
  linkedin_serp: "LinkedIn", github: "GitHub",
  news: "News", wikipedia: "Wikipedia",
  job_posting: "Job Posting", serp: "Web Search",
  llm_inference: "Org Inference",
};

function buildSurfacedReason(evidence: Evidence[], bucketsHit: string[]): string {
  const types = [...new Set(evidence.map(e => EVIDENCE_TYPE_LABELS[e.type] || e.type))].slice(0, 3);
  const bkts = bucketsHit.map(b => BUCKET_LABELS[b] || b).slice(0, 3);
  return `Found in ${types.join(" + ")} (${bkts.join(", ")} sources)`;
}

function buildMissingInfo(bucketsHit: string[], email: string | undefined, confCurrent: number): string {
  const missing: string[] = [];
  if (!bucketsHit.includes("self_declared")) missing.push("no LinkedIn signal");
  if (!email) missing.push("no email guess");
  if (confCurrent < 0.5) missing.push("low current-role confidence");
  if (!bucketsHit.includes("official")) missing.push("no official company source");
  return missing.length > 0 ? missing.slice(0, 2).join("; ") : "Good coverage";
}

function buildSuggestedAction(bucketsHit: string[], name: string, company: string, confCurrent: number): string {
  if (!bucketsHit.includes("self_declared")) return `Search LinkedIn for ${name} at ${company}`;
  if (confCurrent < 0.5) return "Verify current role in company newsroom";
  if (!bucketsHit.includes("official")) return `Check company website for ${name}`;
  return "Ready for outreach";
}

// ─── Summary Builder ────────────────────────────────────────────────────────

function buildSummary(
  verified: Array<PipelineContact>,
  probable: Array<PipelineContact>,
  inferred: Array<InferredRoleOutput>,
  rawData: RawData,
  size: CompanySize
): string {
  const src: Array<string> = [];
  if (rawData.websiteTeam) src.push("website");
  if (rawData.newsroom) src.push("newsroom");
  if (rawData.wikipedia) src.push("Wikipedia");
  if (rawData.news) src.push("news");
  const total = verified.length + probable.length;
  return `${total} contacts (${verified.length} verified, ${probable.length} probable) + ${inferred.length} inferred roles. Sources: ${src.length ? src.join(", ") : "limited"} + multi-channel SERP. Size: ${size}.`;
}

// ─── Utility ────────────────────────────────────────────────────────────────

async function safeFetch(url: string, timeoutMs: number): Promise<string> {
  try {
    const res = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
      redirect: "follow",
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!res.ok) return "";
    return await res.text();
  } catch { return ""; }
}

function stripHtml(html: string): string {
  if (!html) return "";
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?<\/style>/gi, "")
    .replace(/<nav[\s\S]*?<\/nav>/gi, "")
    .replace(/<footer[\s\S]*?<\/footer>/gi, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/&[a-z]+;/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// Extract just the result titles and snippets from DuckDuckGo HTML (not nav, ads, boilerplate)
function extractDdgSnippets(html: string): string {
  if (!html) return "";

  // Strip DDG filter bars, dropdowns, nav elements before extracting
  let cleaned = html
    .replace(/<select[\s\S]*?<\/select>/gi, "") // Remove all dropdowns (time filter, region, etc.)
    .replace(/<nav[\s\S]*?<\/nav>/gi, "")
    .replace(/<header[\s\S]*?<\/header>/gi, "")
    .replace(/<footer[\s\S]*?<\/footer>/gi, "")
    .replace(/class="[^"]*(?:filters|dropdown|menu|modal|toolbar|header|footer|sidebar)[^"]*"[\s\S]*?<\/(?:div|section|aside|ul)>/gi, "");

  const snippets: string[] = [];

  // DuckDuckGo HTML results use class="result__snippet" and "result__a"
  const snippetRe = /class="result__snippet"[^>]*>([\s\S]*?)<\/(?:td|div|span|a)>/gi;
  const titleRe = /class="result__a"[^>]*>([\s\S]*?)<\/a>/gi;

  let m;
  while ((m = snippetRe.exec(cleaned)) !== null) {
    const clean = m[1].replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/gi, " ").replace(/\s+/g, " ").trim();
    if (clean.length > 10 && !isDdgUiText(clean)) snippets.push(clean);
  }
  while ((m = titleRe.exec(cleaned)) !== null) {
    const clean = m[1].replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/gi, " ").replace(/\s+/g, " ").trim();
    if (clean.length > 5 && !isDdgUiText(clean)) snippets.push(clean);
  }

  // Also try to extract from result__url for LinkedIn-style results
  const urlTextRe = /class="result__url"[^>]*>([\s\S]*?)<\/(?:td|div|span|a)>/gi;
  while ((m = urlTextRe.exec(cleaned)) !== null) {
    const clean = m[1].replace(/<[^>]+>/g, " ").replace(/&[a-z]+;/gi, " ").replace(/\s+/g, " ").trim();
    if (clean.length > 5 && !isDdgUiText(clean)) snippets.push(clean);
  }

  // Fallback: if no structured results found, use stripped HTML but limit to body content
  if (snippets.length === 0) {
    return stripHtml(cleaned).slice(0, 3000);
  }

  return snippets.join("\n");
}

// Filter out DuckDuckGo UI text that's not actual search result content
function isDdgUiText(text: string): boolean {
  const lower = text.toLowerCase().trim();
  if (lower.startsWith("suggested") || lower.startsWith("related")) return true;
  if (lower.includes("suggested searches") || lower.includes("related searches")) return true;
  if (lower.includes("see results for") || lower.includes("did you mean")) return true;
  if (lower.includes("safe search") || lower.includes("privacy") || lower.includes("settings")) return true;
  if (lower.includes("next page") || lower.includes("previous page")) return true;
  if (lower.includes("feedback") || lower.includes("advertise")) return true;
  if (lower.startsWith("page ") || lower.startsWith("showing results")) return true;
  // DuckDuckGo time filter dropdown: "Any time", "Past day", "Past week", "Past month", "Past year"
  if (/\b(any\s*time|past\s*(day|week|month|year)|all\s*regions?)\b/i.test(lower)) return true;
  // DDG region/country filter dropdown
  if (/\b(all\s*time|safe\s*search|strict|moderate|off)\b/i.test(lower)) return true;
  // DDG filter bar text
  if (/^\s*(web|images|videos|news|maps|all)\s*$/i.test(lower)) return true;
  // Skip very short generic text
  if (lower.length < 15 && !lower.includes(" - ") && !lower.includes(",")) return true;
  return false;
}

function extractNamesFromText(text: string, companyName: string): Record<string, number> {
  const pat = /\b([A-Z][a-z]+(?:\s+[A-Z]\.?)?\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\b/g;
  const counts: Record<string, number> = {};
  const coWords = new Set(companyName.toLowerCase().split(/\s+/));

  let m;
  while ((m = pat.exec(text)) !== null) {
    const n = m[1].trim();
    const words = n.toLowerCase().split(/\s+/);
    // Skip if all words are from the company name
    if (words.every(w => coWords.has(w))) continue;
    // Skip known non-names (countries, cities, business terms, etc.)
    if (isNonName(n)) continue;
    // Must be 2-3 words
    if (words.length < 2 || words.length > 3) continue;
    // Each word must be 2+ chars (filter out initials-only matches)
    if (words.some(w => w.length < 2)) continue;
    // Skip if any word is a common non-name word
    if (words.some(w => NON_NAME_WORDS.has(w))) continue;
    // Skip if it looks like a title fragment or business term
    if (TITLE_FRAGMENTS.has(words[0]) || TITLE_FRAGMENTS.has(words[words.length - 1])) continue;
    // Validate first word looks like a plausible first name
    if (!isPlausibleFirstName(words[0])) continue;
    counts[n] = (counts[n] || 0) + 1;
  }
  return counts;
}

function isNonName(candidate: string): boolean {
  const lower = candidate.toLowerCase();
  if (COMMON_NON_NAMES.has(lower)) return true;
  // Check if any word is a country or major city
  const words = lower.split(/\s+/);
  for (const w of words) {
    if (COUNTRIES_AND_REGIONS.has(w)) return true;
    if (MAJOR_CITIES.has(w)) return true;
  }
  // Check 2-word combos against geographic pairs
  if (words.length >= 2) {
    const twoWord = `${words[0]} ${words[1]}`;
    if (GEO_PAIRS.has(twoWord)) return true;
    if (COMMON_NON_NAMES.has(twoWord)) return true;
  }
  return false;
}

// Countries and sovereign regions
const COUNTRIES_AND_REGIONS = new Set([
  "afghanistan", "albania", "algeria", "andorra", "angola", "argentina", "armenia",
  "australia", "austria", "azerbaijan", "bahamas", "bahrain", "bangladesh", "barbados",
  "belarus", "belgium", "belize", "benin", "bhutan", "bolivia", "bosnia", "botswana",
  "brazil", "brunei", "bulgaria", "burkina", "burundi", "cambodia", "cameroon", "canada",
  "chad", "chile", "china", "colombia", "comoros", "congo", "croatia", "cuba", "cyprus",
  "czech", "denmark", "djibouti", "dominica", "ecuador", "egypt", "eritrea", "estonia",
  "eswatini", "ethiopia", "fiji", "finland", "france", "gabon", "gambia", "georgia",
  "germany", "ghana", "greece", "grenada", "guatemala", "guinea", "guyana", "haiti",
  "honduras", "hungary", "iceland", "india", "indonesia", "iran", "iraq", "ireland",
  "israel", "italy", "jamaica", "japan", "jordan", "kazakhstan", "kenya", "kiribati",
  "korea", "kosovo", "kuwait", "kyrgyzstan", "laos", "latvia", "lebanon", "lesotho",
  "liberia", "libya", "liechtenstein", "lithuania", "luxembourg", "madagascar", "malawi",
  "malaysia", "maldives", "mali", "malta", "mauritania", "mauritius", "mexico", "micronesia",
  "moldova", "monaco", "mongolia", "montenegro", "morocco", "mozambique", "myanmar",
  "namibia", "nauru", "nepal", "netherlands", "nicaragua", "niger", "nigeria", "norway",
  "oman", "pakistan", "palau", "palestine", "panama", "paraguay", "peru", "philippines",
  "poland", "portugal", "qatar", "romania", "russia", "rwanda", "samoa", "senegal",
  "serbia", "seychelles", "singapore", "slovakia", "slovenia", "somalia", "spain",
  "sudan", "suriname", "sweden", "switzerland", "syria", "taiwan", "tajikistan",
  "tanzania", "thailand", "togo", "tonga", "trinidad", "tunisia", "turkey", "turkmenistan",
  "tuvalu", "uganda", "ukraine", "uruguay", "uzbekistan", "vanuatu", "vatican",
  "venezuela", "vietnam", "yemen", "zambia", "zimbabwe",
  // Common references
  "europe", "asia", "africa", "americas", "oceania", "caribbean", "pacific",
  "atlantic", "arctic", "antarctic", "scandinavia", "balkans", "mediterranean",
  "middle", "east", "west", "north", "south", "central", "latin",
]);

const MAJOR_CITIES = new Set([
  "london", "paris", "tokyo", "beijing", "shanghai", "delhi", "mumbai", "moscow",
  "istanbul", "cairo", "lagos", "sydney", "melbourne", "toronto", "montreal",
  "vancouver", "ottawa", "quebec", "calgary", "edmonton", "winnipeg", "halifax",
  "chicago", "houston", "phoenix", "dallas", "austin", "boston", "seattle",
  "denver", "atlanta", "miami", "detroit", "portland", "orlando", "charlotte",
  "berlin", "madrid", "rome", "amsterdam", "brussels", "vienna", "zurich",
  "geneva", "munich", "hamburg", "dubai", "bangkok", "seoul", "manila",
  "jakarta", "hanoi", "taipei", "osaka", "singapore", "stockholm", "oslo",
  "copenhagen", "helsinki", "dublin", "lisbon", "warsaw", "prague", "budapest",
  "bucharest", "sofia", "zagreb", "belgrade", "athens",
]);

// Two-word geographic/political terms
const GEO_PAIRS = new Set([
  "north america", "south america", "central america", "latin america",
  "north korea", "south korea", "south africa", "south sudan",
  "new zealand", "new york", "new jersey", "new delhi", "new orleans",
  "san francisco", "san diego", "san jose", "san antonio", "san juan",
  "los angeles", "las vegas", "el salvador", "costa rica", "puerto rico",
  "sierra leone", "sri lanka", "hong kong", "saudi arabia", "united states",
  "united kingdom", "united arab", "united nations", "czech republic",
  "dominican republic", "british columbia", "nova scotia",
  "buenos aires", "rio janeiro", "sao paulo", "mexico city",
  "kuala lumpur", "ho chi", "tel aviv", "cape town",
]);

// Individual words that are never first/last names
const NON_NAME_WORDS = new Set([
  // Business terms that capitalize
  "company", "corporation", "enterprise", "group", "holdings", "limited",
  "international", "global", "national", "regional", "digital", "technology",
  "solutions", "services", "industries", "partners", "associates", "consulting",
  "management", "marketing", "financial", "capital", "investment", "insurance",
  "systems", "software", "network", "media", "communications", "development",
  "research", "institute", "foundation", "university", "college", "academy",
  "hospital", "medical", "health", "energy", "power", "electric",
  "automotive", "aviation", "aerospace", "defense", "security",
  // Common English words that are NEVER first names
  "any", "all", "the", "this", "that", "these", "those", "some", "many", "much",
  "few", "most", "each", "every", "both", "other", "another", "such",
  "time", "past", "day", "week", "month", "year", "hour", "minute", "second",
  "today", "yesterday", "tomorrow", "ago", "since", "until", "before", "after",
  "about", "above", "below", "between", "into", "through", "during", "under",
  "over", "again", "further", "then", "once", "here", "there", "when", "where",
  "why", "how", "what", "which", "who", "whom", "whose", "only", "same",
  "just", "also", "very", "often", "always", "never", "still", "already",
  "even", "back", "well", "long", "right", "left", "part", "good", "great",
  "big", "small", "old", "young", "new", "free", "full", "early", "late",
  "hard", "easy", "fast", "slow", "true", "false", "sure", "able",
  "way", "case", "point", "place", "world", "life", "work", "home",
  "hand", "head", "body", "side", "line", "end", "number", "word",
  "fact", "thing", "name", "kind", "area", "state", "city", "type",
  "level", "order", "rate", "form", "role", "plan", "team", "goal",
  "idea", "step", "based", "using", "like", "made", "used", "being",
  "make", "take", "give", "come", "know", "think", "want", "need",
  "look", "find", "tell", "ask", "show", "try", "call", "keep",
  "help", "talk", "turn", "start", "run", "move", "play", "pay",
  "meet", "include", "continue", "set", "seem", "follow", "serve",
  // Web/document terms
  "click", "view", "read", "learn", "download", "subscribe", "submit",
  "search", "browse", "explore", "discover", "select", "choose",
  "page", "site", "website", "article", "report", "document",
  "section", "chapter", "appendix", "table", "figure",
  "january", "february", "march", "april", "may", "june",
  "july", "august", "september", "october", "november", "december",
  "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
  // Adjectives
  "executive", "senior", "junior", "chief", "deputy", "assistant",
  "general", "special", "acting", "interim", "former", "current",
  "annual", "quarterly", "monthly", "weekly", "daily",
  "fiscal", "corporate", "strategic", "operational",
  // Common phrases that look like names
  "best", "top", "leading", "premier", "first", "last", "next",
  "real", "estate", "supply", "chain", "human", "resources",
  "public", "private", "open", "close", "high", "low",
  // Search engine / UI terms
  "suggested", "related", "searches", "results", "showing", "feedback",
  "settings", "privacy", "advertise", "previous", "more", "less",
  "filter", "sort", "share", "print", "save", "copy", "edit",
  // Tech/industry terms that capitalize in text
  "cloud", "data", "analytics", "platform", "infrastructure", "cyber",
  "innovation", "transformation", "automation", "intelligence", "learning",
  "machine", "artificial", "virtual", "remote", "hybrid",
  "revenue", "profit", "growth", "market", "stock", "share",
  "federal", "provincial", "municipal", "government", "ministry",
  // IT company-specific terms
  "consulting", "outsourcing", "managed", "integration", "implementation",
  "advisory", "assurance", "audit", "compliance", "governance",
]);

// Title-like words that appear at start/end of false matches
const TITLE_FRAGMENTS = new Set([
  "president", "director", "manager", "officer", "chairman", "chairwoman",
  "secretary", "treasurer", "commissioner", "governor", "minister",
  "ambassador", "chancellor", "superintendent", "administrator",
  "coordinator", "supervisor", "specialist", "analyst", "consultant",
  "advisor", "counsel", "attorney", "professor", "doctor",
  "lieutenant", "sergeant", "captain", "colonel", "commander",
]);

const COMMON_NON_NAMES = new Set([
  "united states", "new york", "los angeles", "san francisco", "north america",
  "south america", "chief executive", "vice president", "managing director",
  "general manager", "press release", "annual report", "board directors",
  "privacy policy", "terms service", "read more", "learn more", "contact us",
  "about us", "our team", "join us", "sign up", "log in", "all rights",
  "click here", "find out", "get started", "view more", "see all",
  "hong kong", "sri lanka", "costa rica", "saudi arabia", "south africa",
  "new zealand", "puerto rico", "el salvador", "north korea", "south korea",
  "sierra leone", "united kingdom", "dominican republic",
  "artificial intelligence", "machine learning", "deep learning",
  "social media", "real estate", "supply chain", "human resources",
  "customer service", "data science", "product management",
  "project management", "business development", "public relations",
  "information technology", "intellectual property",
  "terms conditions", "cookie policy", "data protection",
  "reserved rights", "copyright reserved", "web design",
  "powered by", "built with", "made with",
  "thank you", "please note", "note that",
  // Search engine UI
  "suggested searches", "related searches", "see results",
  "search results", "showing results", "did you",
  "next page", "previous page", "more results",
  "safe search", "web search", "image search",
  // DuckDuckGo time filter UI elements
  "any time", "any time past", "time past", "past day", "past week",
  "past month", "past year", "day past", "day past week", "week past",
  "month past", "past month past", "time past day", "time past week",
  "time past month", "time past year",
  // IT/consulting industry terms
  "cloud computing", "digital transformation", "managed services",
  "business process", "application services", "systems integration",
  "cyber security", "data analytics", "business intelligence",
  "client success", "global delivery", "service desk",
  "help desk", "end user", "full stack", "front end", "back end",
  "open source", "third party", "best practices",
  "case study", "white paper", "thought leadership",
  "market share", "revenue growth", "fiscal year",
  "quarterly results", "annual revenue", "net income",
  // Generic title fragments that look like names
  "senior vice", "chief financial", "chief technology",
  "chief operating", "chief information", "chief marketing",
  "chief human", "chief revenue", "chief strategy",
  "general counsel", "corporate secretary", "board member",
  "independent director", "non executive",
]);

function isPlausibleFirstName(word: string): boolean {
  if (!word || word.length < 2) return false;
  const lower = word.toLowerCase();
  // Check against common first names list
  if (COMMON_FIRST_NAMES.has(lower)) return true;
  // Heuristic: if 3-10 chars, starts with consonant/vowel pattern, and not in blocklists, allow it
  // This catches non-English names not in the list
  if (lower.length >= 3 && lower.length <= 12) {
    // Must not be a non-name word
    if (NON_NAME_WORDS.has(lower)) return false;
    if (COUNTRIES_AND_REGIONS.has(lower)) return false;
    if (MAJOR_CITIES.has(lower)) return false;
    if (TITLE_FRAGMENTS.has(lower)) return false;
    // Allow if it looks like a name (no unusual character patterns)
    if (/^[a-z\u00C0-\u024F]+([-'][a-z\u00C0-\u024F]+)*$/.test(lower)) return true;
  }
  return false;
}

function looksLikeRealName(name: string): boolean {
  if (!name || name.length < 3) return false;
  const words = name.toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length < 2 || words.length > 4) return false;
  // Each word should be alphabetic (allow hyphens for compound names)
  if (words.some(w => !/^[a-z\u00C0-\u024F]+([-'][a-z\u00C0-\u024F]+)*$/.test(w))) return false;
  // First word must be a plausible first name
  if (!isPlausibleFirstName(words[0])) return false;
  // No word should be a country, city, or non-name word
  for (const w of words) {
    if (COUNTRIES_AND_REGIONS.has(w)) return false;
    if (MAJOR_CITIES.has(w)) return false;
    if (NON_NAME_WORDS.has(w)) return false;
  }
  // Check two-word combos
  for (let i = 0; i < words.length - 1; i++) {
    const pair = `${words[i]} ${words[i + 1]}`;
    if (GEO_PAIRS.has(pair)) return false;
    if (COMMON_NON_NAMES.has(pair)) return false;
  }
  return true;
}

function buildLinkedInUrl(name: string, company: string): string {
  const clean = name.replace(/^\[|\]$/g, "").trim();
  const kw = [clean, company].filter(Boolean).join(" ");
  return `https://www.linkedin.com/search/results/people/?keywords=${encodeURIComponent(kw)}&origin=GLOBAL_SEARCH_HEADER`;
}

function guessEmail(name: string, domain: string): string | undefined {
  if (name.startsWith("[")) return undefined;
  const parts = name.toLowerCase().replace(/[^a-z\s]/g, "").split(/\s+/).filter(Boolean);
  if (parts.length < 2) return undefined;
  const cleanDomain = domain.replace(/^(https?:\/\/)?(www\.)?/, "").replace(/\/+$/, "");
  return `${parts[0]}.${parts[parts.length - 1]}@${cleanDomain}`;
}

function estimateCompanySize(rawData: RawData): CompanySize {
  const all = [rawData.websiteTeam, rawData.newsroom, rawData.wikipedia, rawData.news].join(" ");
  const lo = all.toLowerCase();
  if (/fortune\s*\d+|s&p\s*500|nasdaq|nyse|tsx|\d{2,3},?\d{3}\+?\s*employees|billion|multinational/i.test(lo)) return "enterprise";
  if (/startup|small\s*business|\d{1,2}\s*employees|team\s*of\s*\d{1,2}/i.test(lo)) return "smb";
  if (rawData.wikipedia.length > 500) return "mid_market";
  return "mid_market";
}

async function callLlm(sys: string, usr: string, schema: any): Promise<any> {
  try {
    const r = await fetch("https://api.a0.dev/ai/llm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [{ role: "system", content: sys }, { role: "user", content: usr }],
        schema,
      }),
    });
    if (!r.ok) {
      console.log(`[Pipeline LLM] HTTP error: ${r.status}`);
      // Try once more after brief delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      const r2 = await fetch("https://api.a0.dev/ai/llm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [{ role: "system", content: sys }, { role: "user", content: usr }],
          schema,
        }),
      });
      if (!r2.ok) {
        console.log(`[Pipeline LLM] Retry also failed: ${r2.status}`);
        return null;
      }
      const d2text = await r2.text();
      try {
        const d2 = JSON.parse(d2text);
        return d2.schema_data || tryParse(d2.completion);
      } catch {
        console.log(`[Pipeline LLM] Retry response not JSON: ${d2text.substring(0, 120)}`);
        return null;
      }
    }
    const responseText = await r.text();
    let d: any;
    try {
      d = JSON.parse(responseText);
    } catch {
      console.log(`[Pipeline LLM] Response not JSON: ${responseText.substring(0, 120)}`);
      return null;
    }
    const out = d.schema_data || tryParse(d.completion);
    if (out) return out;

    // Retry without schema
    const r2 = await fetch("https://api.a0.dev/ai/llm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: sys + "\n\nRespond with ONLY valid JSON." },
          { role: "user", content: usr },
        ],
      }),
    });
    if (!r2.ok) return null;
    const d2text = await r2.text();
    try {
      const d2 = JSON.parse(d2text);
      return d2.schema_data || tryParse(d2.completion);
    } catch {
      console.log(`[Pipeline LLM] Retry response not JSON: ${d2text.substring(0, 120)}`);
      return null;
    }
  } catch (e: any) {
    console.log("[Pipeline LLM] Error:", e.message);
    return null;
  }
}

function tryParse(text: string): any {
  if (!text) return null;
  try {
    return JSON.parse(text.replace(/```json?\n?/g, "").replace(/```/g, "").trim());
  } catch {
    const first = text.indexOf("{");
    const last = text.lastIndexOf("}");
    if (first !== -1 && last > first) {
      try { return JSON.parse(text.substring(first, last + 1)); } catch { /* */ }
    }
    return null;
  }
}

// Comprehensive set of common first names (English + French + international)
const COMMON_FIRST_NAMES = new Set([
  // English male
  "james", "john", "robert", "michael", "david", "william", "richard", "joseph",
  "thomas", "charles", "christopher", "daniel", "matthew", "anthony", "mark",
  "donald", "steven", "paul", "andrew", "joshua", "kenneth", "kevin", "brian",
  "george", "timothy", "ronald", "edward", "jason", "jeffrey", "ryan", "jacob",
  "gary", "nicholas", "eric", "jonathan", "stephen", "larry", "justin", "scott",
  "brandon", "benjamin", "samuel", "raymond", "gregory", "frank", "alexander",
  "patrick", "jack", "dennis", "jerry", "tyler", "aaron", "jose", "adam",
  "nathan", "henry", "peter", "zachary", "douglas", "harold", "kyle", "noah",
  "carl", "arthur", "gerald", "roger", "keith", "lawrence", "albert", "bruce",
  "terry", "sean", "christian", "austin", "jesse", "dylan", "billy", "harry",
  "ralph", "roy", "eugene", "louis", "russell", "bobby", "philip", "johnny",
  "wayne", "martin", "craig", "alan", "shawn", "clarence", "travis", "todd",
  // English female
  "mary", "patricia", "jennifer", "linda", "barbara", "elizabeth", "susan",
  "jessica", "sarah", "karen", "lisa", "nancy", "betty", "margaret", "sandra",
  "ashley", "dorothy", "kimberly", "emily", "donna", "michelle", "carol",
  "amanda", "melissa", "deborah", "stephanie", "rebecca", "sharon", "laura",
  "cynthia", "kathleen", "amy", "angela", "shirley", "anna", "brenda",
  "pamela", "emma", "nicole", "helen", "samantha", "katherine", "christine",
  "debra", "rachel", "carolyn", "janet", "catherine", "maria", "heather",
  "diane", "ruth", "julie", "olivia", "joyce", "virginia", "victoria",
  "kelly", "lauren", "christina", "joan", "evelyn", "judith", "megan",
  "andrea", "cheryl", "hannah", "jacqueline", "martha", "gloria", "teresa",
  "ann", "sara", "madison", "frances", "kathryn", "janice", "jean", "abigail",
  "alice", "judy", "sophia", "grace", "denise", "amber", "doris", "marilyn",
  "danielle", "beverly", "isabella", "theresa", "diana", "natalie", "brittany",
  "charlotte", "marie", "kayla", "alexis", "lori",
  // French
  "pierre", "jean", "jacques", "francois", "françois", "claude", "michel",
  "alain", "philippe", "andre", "andré", "bernard", "marcel", "louis",
  "rene", "rené", "yves", "raymond", "roger", "lucien", "henri", "robert",
  "gilles", "denis", "benoit", "benoît", "marc", "serge", "gaston",
  "fernand", "luc", "maurice", "sylvain", "normand", "guy", "réal",
  "christian", "stéphane", "stephane", "martin", "dominique", "patrice",
  "mathieu", "maxime", "antoine", "julien", "nicolas", "olivier", "simon",
  "thierry", "eric", "éric", "frédéric", "frederic", "pascal", "fabien",
  "sébastien", "sebastien", "damien", "vincent", "cédric", "cedric",
  "marie", "jeanne", "nathalie", "isabelle", "sylvie", "christine", "monique",
  "francine", "josée", "josee", "louise", "anne", "chantal", "julie",
  "sophie", "caroline", "genevieve", "geneviève", "madeleine", "nicole",
  "danielle", "colette", "hélène", "helene", "valérie", "valerie",
  "véronique", "veronique", "brigitte", "catherine", "céline", "celine",
  "élise", "elise", "manon", "audrey", "mélanie", "melanie", "karine",
  // International common
  "mohammed", "muhammad", "ali", "ahmed", "hassan", "omar", "fatima",
  "wei", "ming", "jing", "yan", "hong", "lei", "yong", "chen",
  "raj", "priya", "amit", "anita", "arun", "sunita", "vikram", "deepak",
  "carlos", "pablo", "miguel", "juan", "ana", "maria", "jorge", "luis",
  "marco", "giovanni", "giuseppe", "alessandro", "francesca", "giulia",
  "hans", "franz", "wolfgang", "klaus", "stefan", "andreas", "petra", "monika",
  "kenji", "takeshi", "hiroshi", "yuki", "akira", "tomoko", "yoko",
  "ivan", "vladimir", "sergei", "dmitri", "olga", "natasha", "anna",
  "sven", "erik", "lars", "nils", "ingrid", "astrid", "karin",
]);