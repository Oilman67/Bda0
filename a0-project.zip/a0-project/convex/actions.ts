import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

// Generate next action number: A + YY + 4-digit sequential
async function getNextActionNumber(ctx: any, orgId: any): Promise<string> {
  const year = new Date().getFullYear().toString().slice(-2); // "26"
  const prefix = `A${year}`;

  // Get all actions for this org to find the highest number this year
  const actions = await ctx.db
    .query("actions")
    .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
    .collect();

  let maxSeq = 0;
  for (const a of actions) {
    if (a.actionNumber && a.actionNumber.startsWith(prefix)) {
      const seq = parseInt(a.actionNumber.slice(prefix.length), 10);
      if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
    }
  }

  const nextSeq = (maxSeq + 1).toString().padStart(4, "0");
  return `${prefix}${nextSeq}`;
}

export const list = query({
  args: { status: v.optional(v.string()) },
  returns: v.array(v.object({
    _id: v.id("actions"),
    _creationTime: v.number(),
    actionNumber: v.optional(v.string()),
    title: v.string(),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    startDate: v.optional(v.number()),
    targetDate: v.optional(v.number()),
    completedDate: v.optional(v.number()),
    dueDate: v.optional(v.number()),
    status: v.string(),
    priority: v.string(),
    precursors: v.optional(v.array(v.string())),
    deepLink: v.optional(v.string()),
    entityType: v.optional(v.string()),
    entityLabel: v.optional(v.string()),
    ownerName: v.optional(v.string()),
    ownerType: v.optional(v.string()),
  })),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    let tasks;
    if (args.status) {
      tasks = await ctx.db
        .query("actions")
        .withIndex("by_org_and_status", (q: any) => q.eq("orgId", orgId).eq("status", args.status))
        .order("desc")
        .collect();
    } else {
      tasks = await ctx.db
        .query("actions")
        .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
        .order("desc")
        .collect();
    }

    const result = [];
    for (const t of tasks) {
      if (t.deletedAt) continue;
      let entityLabel: string | undefined;
      let entityType: string | undefined;
      if (t.opportunityId) {
        entityType = 'opportunity';
        const o = await ctx.db.get(t.opportunityId);
        if (o) entityLabel = o.title;
      } else if (t.companyId) {
        entityType = 'company';
        const c = await ctx.db.get(t.companyId);
        if (c) entityLabel = c.name;
      } else if (t.contactId) {
        entityType = 'contact';
        const c = await ctx.db.get(t.contactId);
        if (c) entityLabel = `${c.firstName} ${c.lastName}`;
      } else if (t.segmentId) {
        entityType = 'segment';
        const s = await ctx.db.get(t.segmentId);
        if (s) entityLabel = s.name;
      } else if (t.interactionId) {
        entityType = 'interaction';
        const i = await ctx.db.get(t.interactionId);
        if (i) entityLabel = i.subject || i.type;
      }
      // Resolve owner name based on ownerType
      let ownerName: string | undefined;
      const ownerType = t.ownerType || 'user';
      if (ownerType === 'contact' && t.ownerContactId) {
        const contact = await ctx.db.get(t.ownerContactId);
        if (contact) ownerName = `${contact.firstName} ${contact.lastName}`.trim();
      } else if (ownerType === 'custom' && t.ownerCustomName) {
        ownerName = t.ownerCustomName;
      } else if (t.assigneeId) {
        const user = await ctx.db.get(t.assigneeId);
        if (user) ownerName = user.name || user.email;
      }
      result.push({
        _id: t._id,
        _creationTime: t._creationTime,
        actionNumber: t.actionNumber,
        title: t.title,
        description: t.description,
        notes: t.notes,
        startDate: t.startDate,
        targetDate: t.targetDate,
        completedDate: t.completedDate,
        dueDate: t.dueDate,
        status: t.status,
        priority: t.priority,
        precursors: t.precursors,
        deepLink: t.deepLink,
        entityType,
        entityLabel,
        ownerName,
        ownerType: t.ownerType,
      });
    }
    return result;
  },
});

export const listByEntity = query({
  args: { entityType: v.string(), entityId: v.string() },
  returns: v.array(v.object({
    _id: v.id("actions"),
    _creationTime: v.number(),
    actionNumber: v.optional(v.string()),
    title: v.string(),
    dueDate: v.optional(v.number()),
    status: v.string(),
    priority: v.string(),
  })),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    let tasks;
    if (args.entityType === "company") {
      tasks = await ctx.db.query("actions").withIndex("by_company", (q: any) => q.eq("companyId", args.entityId)).collect();
    } else if (args.entityType === "contact") {
      tasks = await ctx.db.query("actions").withIndex("by_contact", (q: any) => q.eq("contactId", args.entityId)).collect();
    } else if (args.entityType === "segment") {
      tasks = await ctx.db.query("actions").withIndex("by_segment", (q: any) => q.eq("segmentId", args.entityId)).collect();
    } else if (args.entityType === "interaction") {
      tasks = await ctx.db.query("actions").withIndex("by_interaction", (q: any) => q.eq("interactionId", args.entityId)).collect();
    } else {
      tasks = await ctx.db.query("actions").withIndex("by_opportunity", (q: any) => q.eq("opportunityId", args.entityId)).collect();
    }
    return tasks
      .filter((t: any) => !t.deletedAt && t.orgId === orgId)
      .map((t: any) => ({
        _id: t._id,
        _creationTime: t._creationTime,
        actionNumber: t.actionNumber,
        title: t.title,
        dueDate: t.dueDate,
        status: t.status,
        priority: t.priority,
      }));
  },
});

export const create = mutation({
  args: {
    title: v.string(),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    startDate: v.optional(v.number()),
    targetDate: v.optional(v.number()),
    dueDate: v.optional(v.number()),
    priority: v.optional(v.string()),
    precursors: v.optional(v.array(v.string())),
    deepLink: v.optional(v.string()),
    segmentId: v.optional(v.id("segments")),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    opportunityId: v.optional(v.id("opportunities")),
    interactionId: v.optional(v.id("interactions")),
    ownerType: v.optional(v.string()),
    ownerContactId: v.optional(v.id("contacts")),
    ownerCustomName: v.optional(v.string()),
    assigneeId: v.optional(v.id("users")),
  },
  returns: v.id("actions"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const actionNumber = await getNextActionNumber(ctx, orgId);
    return await ctx.db.insert("actions", {
      ...args,
      orgId,
      actionNumber,
      assigneeId: args.assigneeId ?? userId,
      ownerType: args.ownerType ?? "user",
      status: "todo",
      priority: args.priority ?? "medium",
      startDate: args.startDate ?? Date.now(),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("actions"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    notes: v.optional(v.string()),
    startDate: v.optional(v.number()),
    targetDate: v.optional(v.number()),
    status: v.optional(v.string()),
    priority: v.optional(v.string()),
    precursors: v.optional(v.array(v.string())),
    ownerType: v.optional(v.string()),
    ownerContactId: v.optional(v.id("contacts")),
    ownerCustomName: v.optional(v.string()),
    assigneeId: v.optional(v.id("users")),
  },
  returns: v.null(),
  handler: async (ctx, { id, ...updates }) => {
    const { orgId } = await getUserOrgId(ctx);
    const t = await ctx.db.get(id);
    if (!t || t.orgId !== orgId) throw new Error("Not found");
    const patch: any = {};
    for (const [k, val] of Object.entries(updates)) {
      if (val !== undefined) patch[k] = val;
    }
    if (Object.keys(patch).length > 0) {
      await ctx.db.patch(id, patch);
    }
    return null;
  },
});

export const updateStatus = mutation({
  args: { id: v.id("actions"), status: v.string() },
  returns: v.null(),
  handler: async (ctx, { id, status }) => {
    const { orgId } = await getUserOrgId(ctx);
    const t = await ctx.db.get(id);
    if (!t || t.orgId !== orgId) throw new Error("Not found");
    const patch: any = { status };
    if (status === 'done') {
      patch.completedDate = Date.now();
    } else {
      patch.completedDate = undefined;
    }
    await ctx.db.patch(id, patch);
    return null;
  },
});

export const deleteByDeepLink = mutation({
  args: { deepLink: v.string() },
  returns: v.null(),
  handler: async (ctx, { deepLink }) => {
    const { orgId } = await getUserOrgId(ctx);
    const actions = await ctx.db
      .query("actions")
      .withIndex("by_org_and_deepLink", (q: any) => q.eq("orgId", orgId).eq("deepLink", deepLink))
      .collect();
    for (const a of actions) {
      await ctx.db.patch(a._id, { deletedAt: Date.now() });
    }
    return null;
  },
});

// List org members for the owner picker
export const listOrgMembers = query({
  args: {},
  returns: v.array(v.object({
    userId: v.id("users"),
    name: v.string(),
    email: v.string(),
    role: v.string(),
    isCurrentUser: v.boolean(),
  })),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId, userId } = auth;
    const members = await ctx.db
      .query("orgMembers")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    const result = [];
    for (const m of members) {
      const user = await ctx.db.get(m.userId);
      if (user) {
        result.push({
          userId: m.userId,
          name: user.name || user.email || "Unknown",
          email: user.email || "",
          role: m.role,
          isCurrentUser: m.userId === userId,
        });
      }
    }
    return result;
  },
});