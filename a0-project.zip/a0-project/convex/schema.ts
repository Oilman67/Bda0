import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

export default defineSchema({
  ...authTables,

  // Extended users table
  users: defineTable({
    name: v.optional(v.string()),
    image: v.optional(v.string()),
    email: v.optional(v.string()),
    emailVerificationTime: v.optional(v.number()),
    phone: v.optional(v.string()),
    phoneVerificationTime: v.optional(v.number()),
    isAnonymous: v.optional(v.boolean()),
    role: v.optional(v.string()), // 'admin' | 'member'
  }).index("email", ["email"]),

  // Organizations (multi-tenant)
  orgs: defineTable({
    name: v.string(),
    ownerId: v.id("users"),
    accountType: v.optional(v.union(v.literal("solo"), v.literal("team"))),
    teamCode: v.optional(v.string()),
    teamCodeCreatedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_owner", ["ownerId"])
    .index("by_teamCode", ["teamCode"]),

  // Org membership
  orgMembers: defineTable({
    orgId: v.id("orgs"),
    userId: v.id("users"),
    role: v.string(), // 'owner' | 'admin' | 'member'
  })
    .index("by_org", ["orgId"])
    .index("by_user", ["userId"])
    .index("by_org_and_user", ["orgId", "userId"]),

  // Org-level settings (user's company profile for AI)
  orgSettings: defineTable({
    orgId: v.id("orgs"),
    companyName: v.string(),
    companyUrl: v.optional(v.string()),
    interests: v.string(),
    taxonomyProfile: v.optional(v.string()), // JSON: { buyerTypes, offerTypes, problemThemes, keywords, confidence }
    businessContext: v.optional(v.string()), // JSON: { targetIndustries, clientTypes, regions, dealComplexity, companyRoles }
  }).index("by_org", ["orgId"]),

  // CRM: Companies
  companies: defineTable({
    orgId: v.id("orgs"),
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
    ownerId: v.optional(v.id("users")),
    segmentId: v.optional(v.id("segments")),
    companyRole: v.optional(v.string()), // primary_target | technical_influencer | financial_gatekeeper | infrastructure_partner | regulatory | vendor | consortium_member | end_user | other
    companyRoleNotes: v.optional(v.string()),
    insightsReport: v.optional(v.string()), // JSON string of BdAnalysis
    insightsGeneratedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_name", ["orgId", "name"])
    .index("by_org_and_owner", ["orgId", "ownerId"])
    .index("by_org_and_segment", ["orgId", "segmentId"]),

  // CRM: Contacts
  contacts: defineTable({
    orgId: v.id("orgs"),
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    linkedin: v.optional(v.string()),
    title: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    pendingCompanyName: v.optional(v.string()),
    ownerId: v.optional(v.id("users")),
    notes: v.optional(v.string()),
    tecopsProfile: v.optional(v.string()), // JSON: { T, E, C, O, P, S, primaryRiskDriver, secondaryRiskDriver }
    tecopsAnalyzedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_company", ["orgId", "companyId"])
    .index("by_org_and_owner", ["orgId", "ownerId"]),

  // CRM: Pipelines
  pipelines: defineTable({
    orgId: v.id("orgs"),
    name: v.string(),
    isDefault: v.boolean(),
    deletedAt: v.optional(v.number()),
  }).index("by_org", ["orgId"]),

  // CRM: Pipeline Stages
  pipelineStages: defineTable({
    orgId: v.id("orgs"),
    pipelineId: v.id("pipelines"),
    name: v.string(),
    position: v.number(),
    color: v.optional(v.string()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_pipeline", ["pipelineId"])
    .index("by_org_and_pipeline", ["orgId", "pipelineId"]),

  // CRM: Opportunities
  opportunities: defineTable({
    orgId: v.id("orgs"),
    reference: v.optional(v.string()), // "OP26001" — auto-generated serial
    title: v.string(),
    value: v.optional(v.number()),
    currency: v.optional(v.string()), // ISO 4217
    pipelineId: v.optional(v.id("pipelines")),
    stageId: v.optional(v.id("pipelineStages")),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    ownerId: v.optional(v.id("users")),
    closeDate: v.optional(v.number()),
    probability: v.optional(v.number()),
    status: v.string(), // 'early_planning' | 'pushed_assessment' | 'pushed_scoping' | 'pushed_proposal' | 'pushed_negotiation' | 'rfi' | 'rfp' | 'rfq' | 'won' | 'lost'
    location: v.optional(v.string()), // JSON: { lat, lng, address }
    lostCompetitor: v.optional(v.string()), // competitor who won, if status is 'lost'
    notes: v.optional(v.string()),
    strategistReport: v.optional(v.string()), // JSON string of strategist analysis
    strategistGeneratedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_pipeline", ["orgId", "pipelineId"])
    .index("by_org_and_stage", ["orgId", "stageId"])
    .index("by_org_and_owner", ["orgId", "ownerId"])
    .index("by_org_and_status", ["orgId", "status"])
    .index("by_org_and_company", ["orgId", "companyId"])
    .index("by_contact", ["contactId"]),

  // CRM: Interactions (timeline events)
  interactions: defineTable({
    orgId: v.id("orgs"),
    type: v.string(), // 'note' | 'email' | 'call' | 'meeting'
    subject: v.optional(v.string()),
    body: v.optional(v.string()),
    date: v.number(),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    opportunityId: v.optional(v.id("opportunities")),
    userId: v.id("users"),
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_company", ["companyId"])
    .index("by_contact", ["contactId"])
    .index("by_opportunity", ["opportunityId"]),

  // CRM: Actions (Tasks)
  actions: defineTable({
    orgId: v.id("orgs"),
    actionNumber: v.optional(v.string()), // "A260001" — auto-generated serial
    title: v.string(),
    description: v.optional(v.string()),
    notes: v.optional(v.string()), // free text notes
    startDate: v.optional(v.number()),
    targetDate: v.optional(v.number()),
    dueDate: v.optional(v.number()), // kept for backwards compat
    status: v.string(), // 'todo' | 'in_progress' | 'done'
    priority: v.string(), // 'low' | 'medium' | 'high'
    assigneeId: v.optional(v.id("users")),
    ownerType: v.optional(v.string()), // 'user' | 'contact' | 'custom'
    ownerContactId: v.optional(v.id("contacts")), // when owner is a client/contact
    ownerCustomName: v.optional(v.string()), // when owner is a third party
    segmentId: v.optional(v.id("segments")),
    companyId: v.optional(v.id("companies")),
    contactId: v.optional(v.id("contacts")),
    opportunityId: v.optional(v.id("opportunities")),
    interactionId: v.optional(v.id("interactions")),
    precursors: v.optional(v.array(v.string())), // action numbers that must complete first
    deepLink: v.optional(v.string()), // e.g. "contacts:pending"
    completedDate: v.optional(v.number()), // timestamp when status changed to 'done'
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_status", ["orgId", "status"])
    .index("by_org_and_assignee", ["orgId", "assigneeId"])
    .index("by_opportunity", ["opportunityId"])
    .index("by_company", ["companyId"])
    .index("by_contact", ["contactId"])
    .index("by_segment", ["segmentId"])
    .index("by_interaction", ["interactionId"])
    .index("by_org_and_deepLink", ["orgId", "deepLink"]),

  // Stage change history
  opportunityStageChanges: defineTable({
    orgId: v.id("orgs"),
    opportunityId: v.id("opportunities"),
    fromStageId: v.optional(v.id("pipelineStages")),
    toStageId: v.id("pipelineStages"),
    userId: v.id("users"),
    changedAt: v.number(),
  }).index("by_opportunity", ["opportunityId"]),

  // Opportunity stakeholders (multi-party deals: many companies per opportunity)
  opportunityStakeholders: defineTable({
    orgId: v.id("orgs"),
    opportunityId: v.id("opportunities"),
    companyId: v.id("companies"),
    role: v.string(), // primary_target | technical_influencer | financial_gatekeeper | infrastructure_partner | regulatory | vendor | consortium_member | end_user | other
    notes: v.optional(v.string()),
    isPrimary: v.optional(v.boolean()), // true for the main target company
    deletedAt: v.optional(v.number()),
  })
    .index("by_opportunity", ["opportunityId"])
    .index("by_company", ["companyId"])
    .index("by_org", ["orgId"])
    .index("by_opp_company", ["opportunityId", "companyId"]),

  // Audit log
  auditLog: defineTable({
    orgId: v.id("orgs"),
    userId: v.id("users"),
    action: v.string(),
    entityType: v.string(),
    entityId: v.string(),
    details: v.optional(v.string()),
    timestamp: v.number(),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_entity", ["orgId", "entityType", "entityId"]),

  // Report shares
  reportShares: defineTable({
    orgId: v.id("orgs"),
    type: v.string(), // 'pipeline'
    token: v.string(),
    filters: v.string(), // JSON string
    createdBy: v.id("users"),
    expiresAt: v.number(),
    lastAccessedAt: v.optional(v.number()),
    revokedAt: v.optional(v.number()),
  })
    .index("by_token", ["token"])
    .index("by_org", ["orgId"]),

  // Next Best Actions
  nextBestActions: defineTable({
    orgId: v.id("orgs"),
    entryType: v.string(), // 'company' | 'contact' | 'opportunity'
    entryId: v.string(), // polymorphic ID
    actionType: v.string(),
    title: v.string(),
    description: v.string(),
    score: v.number(),
    reasoning: v.optional(v.string()),
    engine: v.string(), // 'heuristic' | 'llm'
    metadata: v.optional(v.string()), // JSON
    expiresAt: v.optional(v.number()),
    dismissedAt: v.optional(v.number()),
    executedAt: v.optional(v.number()),
  })
    .index("by_entry", ["orgId", "entryType", "entryId"])
    .index("by_dedupe", ["orgId", "entryType", "entryId", "actionType"]),

  // Market Segments (3-level taxonomy: L1 Sector > L2 Industry > L3 Sub-Industry)
  segments: defineTable({
    orgId: v.id("orgs"),
    name: v.string(),
    level: v.number(), // 1, 2, or 3
    parentId: v.optional(v.id("segments")),
    description: v.optional(v.string()),
    color: v.optional(v.string()),
    companyCount: v.optional(v.number()), // denormalized count
    deletedAt: v.optional(v.number()),
  })
    .index("by_org", ["orgId"])
    .index("by_org_and_level", ["orgId", "level"])
    .index("by_parent", ["parentId"])
    .index("by_org_and_parent", ["orgId", "parentId"]),

  // Relationship Intelligence (per contact-opportunity pair)
  relationshipIntelligence: defineTable({
    orgId: v.id("orgs"),
    opportunityId: v.id("opportunities"),
    contactId: v.id("contacts"),
    stance: v.number(), // -2 to +2
    role: v.string(), // Decision Maker | Economic Buyer | Technical Evaluator | Operational Owner | Influencer | Gatekeeper | Blocker
    roleConfidence: v.optional(v.string()), // Low | Medium | High
    influence: v.number(), // 1-3
    confidence: v.string(), // Low | Medium | High
    relationshipStrength: v.string(), // Weak | Medium | Strong
    aiReasoning: v.optional(v.string()),
    signals: v.optional(v.string()), // JSON array of strings
    risks: v.optional(v.string()), // JSON array of { type, severity, details }
    opportunities: v.optional(v.string()), // JSON array of { type, details }
    nextMoveTitle: v.optional(v.string()),
    nextMoveDetails: v.optional(v.string()),
    nextMovePriority: v.optional(v.string()),
    nextMoveDeadline: v.optional(v.string()),
    riskSensitivity: v.optional(v.string()), // JSON: { T, E, C, O, P, S, primaryRiskDriver, secondaryRiskDriver }
    riskAlignment: v.optional(v.string()), // "High alignment" | "Moderate alignment" | "Low alignment"
    isUserOverride: v.optional(v.boolean()),
    lastAnalyzedAt: v.optional(v.number()),
    deletedAt: v.optional(v.number()),
  })
    .index("by_opportunity", ["opportunityId"])
    .index("by_contact", ["contactId"])
    .index("by_opp_contact", ["opportunityId", "contactId"]),
});