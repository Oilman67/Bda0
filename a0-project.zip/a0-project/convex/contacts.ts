import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

export const list = query({
  args: { companyId: v.optional(v.id("companies")) },
  returns: v.array(v.object({
    _id: v.id("contacts"),
    _creationTime: v.number(),
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    linkedin: v.optional(v.string()),
    title: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    pendingCompanyName: v.optional(v.string()),
    lastInteraction: v.optional(v.object({
      date: v.number(),
      type: v.string(),
      subject: v.optional(v.string()),
    })),
    riKPI: v.optional(v.object({
      stance: v.string(),
      influence: v.string(),
      role: v.string(),
      relationshipStrength: v.string(),
      nextMove: v.optional(v.string()),
      isUserOverride: v.boolean(),
      assessmentCount: v.number(),
    })),
  })),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    let contacts;
    if (args.companyId) {
      contacts = await ctx.db
        .query("contacts")
        .withIndex("by_org_and_company", (q: any) => q.eq("orgId", orgId).eq("companyId", args.companyId))
        .order("desc")
        .collect();
    } else {
      contacts = await ctx.db
        .query("contacts")
        .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
        .order("desc")
        .collect();
    }
    const result = [];
    for (const c of contacts) {
      if (c.deletedAt) continue;
      let companyName: string | undefined;
      if (c.companyId) {
        const company = await ctx.db.get(c.companyId);
        companyName = company?.name;
      }
      // Get last interaction
      let lastInteraction: { date: number; type: string; subject?: string } | undefined;
      const recentInteractions = await ctx.db
        .query("interactions")
        .withIndex("by_contact", (q: any) => q.eq("contactId", c._id))
        .order("desc")
        .take(1);
      if (recentInteractions.length > 0 && !recentInteractions[0].deletedAt) {
        const i = recentInteractions[0];
        lastInteraction = { date: i.date, type: i.type, subject: i.subject };
      }
      // Get lean RI KPI (most recent assessment)
      const stanceLabelMap: Record<number, string> = {
        [-2]: "Opposed", [-1]: "Skeptical", 0: "Neutral", 1: "Supportive", 2: "Champion",
      };
      const influenceLabelMap: Record<number, string> = {
        1: "Low", 2: "Medium", 3: "High",
      };
      let riKPI: { stance: string; influence: string; role: string; relationshipStrength: string; nextMove?: string; isUserOverride: boolean; assessmentCount: number } | undefined;
      const riRows = await ctx.db
        .query("relationshipIntelligence")
        .withIndex("by_contact", (q: any) => q.eq("contactId", c._id))
        .collect();
      const activeRi = riRows.filter((r: any) => !r.deletedAt);
      if (activeRi.length > 0) {
        const sorted = activeRi.sort((a: any, b: any) => (b.lastAnalyzedAt || b._creationTime) - (a.lastAnalyzedAt || a._creationTime));
        const primary = sorted[0];
        riKPI = {
          stance: stanceLabelMap[primary.stance] || "Neutral",
          influence: influenceLabelMap[primary.influence] || "Medium",
          role: primary.role,
          relationshipStrength: primary.relationshipStrength,
          nextMove: primary.nextMoveTitle,
          isUserOverride: primary.isUserOverride || false,
          assessmentCount: activeRi.length,
        };
      }
      result.push({
        _id: c._id,
        _creationTime: c._creationTime,
        firstName: c.firstName,
        lastName: c.lastName,
        email: c.email,
        phone: c.phone,
        linkedin: c.linkedin,
        title: c.title,
        companyId: c.companyId,
        companyName,
        pendingCompanyName: c.pendingCompanyName,
        lastInteraction,
        riKPI,
      });
    }
    return result;
  },
});

export const get = query({
  args: { id: v.id("contacts") },
  returns: v.union(v.object({
    _id: v.id("contacts"),
    _creationTime: v.number(),
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    linkedin: v.optional(v.string()),
    title: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    companyName: v.optional(v.string()),
    pendingCompanyName: v.optional(v.string()),
    notes: v.optional(v.string()),
    ownerId: v.optional(v.id("users")),
    lastInteraction: v.optional(v.object({
      date: v.number(),
      type: v.string(),
      subject: v.optional(v.string()),
    })),
  }), v.null()),
  handler: async (ctx, { id }) => {
    const { orgId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId || c.deletedAt) return null;
    let companyName: string | undefined;
    if (c.companyId) {
      const company = await ctx.db.get(c.companyId);
      companyName = company?.name;
    }
    // Get last interaction
    let lastInteraction: { date: number; type: string; subject?: string } | undefined;
    const recentInteractions = await ctx.db
      .query("interactions")
      .withIndex("by_contact", (q: any) => q.eq("contactId", c._id))
      .order("desc")
      .take(1);
    if (recentInteractions.length > 0 && !recentInteractions[0].deletedAt) {
      const i = recentInteractions[0];
      lastInteraction = { date: i.date, type: i.type, subject: i.subject };
    }
    return {
      _id: c._id,
      _creationTime: c._creationTime,
      firstName: c.firstName,
      lastName: c.lastName,
      email: c.email,
      phone: c.phone,
      linkedin: c.linkedin,
      title: c.title,
      companyId: c.companyId,
      companyName,
      pendingCompanyName: c.pendingCompanyName,
      notes: c.notes,
      ownerId: c.ownerId,
      lastInteraction,
    };
  },
});

export const create = mutation({
  args: {
    firstName: v.string(),
    lastName: v.string(),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    linkedin: v.optional(v.string()),
    title: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    pendingCompanyName: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  returns: v.id("contacts"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const id = await ctx.db.insert("contacts", {
      ...args,
      orgId,
      ownerId: userId,
    });
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "create", entityType: "contact", entityId: id, timestamp: Date.now(),
    });
    return id;
  },
});

export const batchCreate = mutation({
  args: {
    contacts: v.array(v.object({
      firstName: v.string(),
      lastName: v.string(),
      email: v.optional(v.string()),
      phone: v.optional(v.string()),
      linkedin: v.optional(v.string()),
      title: v.optional(v.string()),
      companyId: v.optional(v.id("companies")),
      pendingCompanyName: v.optional(v.string()),
      notes: v.optional(v.string()),
    })),
  },
  returns: v.array(v.id("contacts")),
  handler: async (ctx, { contacts }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const ids: any[] = [];
    for (const c of contacts) {
      const id = await ctx.db.insert("contacts", {
        ...c,
        orgId,
        ownerId: userId,
      });
      await ctx.db.insert("auditLog", {
        orgId, userId, action: "create", entityType: "contact", entityId: id,
        details: JSON.stringify({ source: "device_import" }),
        timestamp: Date.now(),
      });
      ids.push(id);
    }
    return ids;
  },
});

export const update = mutation({
  args: {
    id: v.id("contacts"),
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    email: v.optional(v.string()),
    phone: v.optional(v.string()),
    linkedin: v.optional(v.string()),
    title: v.optional(v.string()),
    companyId: v.optional(v.id("companies")),
    pendingCompanyName: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, { id, ...updates }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId) throw new Error("Not found");
    const patch: any = {};
    for (const [k, val] of Object.entries(updates)) {
      if (val !== undefined) patch[k] = val;
    }
    // Clear pendingCompanyName when linking to a company
    if (patch.companyId) {
      patch.pendingCompanyName = undefined;
    }
    if (Object.keys(patch).length > 0) await ctx.db.patch(id, patch);
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "update", entityType: "contact", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("contacts") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, { deletedAt: Date.now() });
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "delete", entityType: "contact", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const scanAndMatch = mutation({
  args: {},
  returns: v.object({
    matched: v.number(),
    pending: v.number(),
    pendingNames: v.array(v.string()),
  }),
  handler: async (ctx) => {
    const { orgId, userId } = await getUserOrgId(ctx);

    // Get all companies for matching
    const allCompanies = await ctx.db
      .query("companies")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    const activeCompanies = allCompanies.filter((c: any) => !c.deletedAt);

    // Get all contacts
    const allContacts = await ctx.db
      .query("contacts")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();

    let matched = 0;
    const pendingNames: string[] = [];

    for (const contact of allContacts) {
      if (contact.deletedAt) continue;
      if (contact.companyId) continue; // Already matched

      let companyName = contact.pendingCompanyName;

      // Extract company name from notes if not in pendingCompanyName
      if (!companyName && contact.notes) {
        const match = contact.notes.match(/^Company:\s*(.+)$/m);
        if (match) {
          companyName = match[1].trim();
          // Move to pendingCompanyName field
          await ctx.db.patch(contact._id, { pendingCompanyName: companyName });
        }
      }

      if (!companyName) continue;

      // Try case-insensitive match
      const matchedCompany = activeCompanies.find(
        (c: any) => c.name.toLowerCase().trim() === companyName!.toLowerCase().trim()
      );

      if (matchedCompany) {
        // Clean up notes if company was stored there
        let cleanedNotes = contact.notes;
        if (cleanedNotes) {
          cleanedNotes = cleanedNotes.replace(/^Company:\s*.+$/m, '').trim() || undefined;
        }
        await ctx.db.patch(contact._id, {
          companyId: matchedCompany._id,
          pendingCompanyName: undefined,
          notes: cleanedNotes,
        });
        matched++;
      } else {
        if (!pendingNames.includes(companyName)) {
          pendingNames.push(companyName);
        }
      }
    }

    // If all contacts are matched, delete the "contacts:pending" action
    if (pendingNames.length === 0 && matched > 0) {
      const pendingActions = await ctx.db
        .query("actions")
        .withIndex("by_org_and_deepLink", (q: any) => q.eq("orgId", orgId).eq("deepLink", "contacts:pending"))
        .collect();
      for (const a of pendingActions) {
        if (!a.deletedAt) {
          await ctx.db.patch(a._id, { deletedAt: Date.now() });
        }
      }
    }

    return { matched, pending: pendingNames.length, pendingNames };
  },
});

export const linkByPendingCompanyName = mutation({
  args: {
    companyId: v.id("companies"),
    companyName: v.string(),
  },
  returns: v.number(),
  handler: async (ctx, { companyId, companyName }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const nameLower = companyName.toLowerCase().trim();

    const allContacts = await ctx.db
      .query("contacts")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();

    let linked = 0;
    for (const contact of allContacts) {
      if (contact.deletedAt) continue;
      if (contact.companyId) continue;
      if (!contact.pendingCompanyName) continue;
      if (contact.pendingCompanyName.toLowerCase().trim() !== nameLower) continue;

      await ctx.db.patch(contact._id, {
        companyId,
        pendingCompanyName: undefined,
      });
      await ctx.db.insert("auditLog", {
        orgId,
        userId,
        action: "update",
        entityType: "contact",
        entityId: contact._id,
        details: JSON.stringify({ autoLinkedToCompany: companyName }),
        timestamp: Date.now(),
      });
      linked++;
    }

    // If no more pending contacts remain, clean up the pending action
    if (linked > 0) {
      const remaining = allContacts.filter(
        (c: any) => !c.deletedAt && !c.companyId && c.pendingCompanyName
          && c.pendingCompanyName.toLowerCase().trim() !== nameLower
      );
      if (remaining.length === 0) {
        const pendingActions = await ctx.db
          .query("actions")
          .withIndex("by_org_and_deepLink", (q: any) => q.eq("orgId", orgId).eq("deepLink", "contacts:pending"))
          .collect();
        for (const a of pendingActions) {
          if (!a.deletedAt) {
            await ctx.db.patch(a._id, { deletedAt: Date.now() });
          }
        }
      }
    }

    return linked;
  },
});