import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

export const listByOpportunity = query({
  args: { opportunityId: v.id("opportunities") },
  returns: v.array(v.object({
    _id: v.id("opportunityStakeholders"),
    companyId: v.id("companies"),
    companyName: v.string(),
    role: v.string(),
    notes: v.optional(v.string()),
    isPrimary: v.optional(v.boolean()),
  })),
  handler: async (ctx, { opportunityId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    const stakes = await ctx.db
      .query("opportunityStakeholders")
      .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", opportunityId))
      .collect();

    const results = [];
    for (const s of stakes.filter((s: any) => !s.deletedAt && s.orgId === orgId)) {
      const company = await ctx.db.get(s.companyId);
      if (!company || company.deletedAt) continue;
      results.push({
        _id: s._id,
        companyId: s.companyId,
        companyName: company.name,
        role: s.role,
        notes: s.notes,
        isPrimary: s.isPrimary,
      });
    }
    // Sort: primary first, then alphabetical
    results.sort((a, b) => {
      if (a.isPrimary && !b.isPrimary) return -1;
      if (!a.isPrimary && b.isPrimary) return 1;
      return a.companyName.localeCompare(b.companyName);
    });
    return results;
  },
});

export const listByCompany = query({
  args: { companyId: v.id("companies") },
  returns: v.array(v.object({
    _id: v.id("opportunityStakeholders"),
    opportunityId: v.id("opportunities"),
    opportunityTitle: v.string(),
    role: v.string(),
    notes: v.optional(v.string()),
    isPrimary: v.optional(v.boolean()),
  })),
  handler: async (ctx, { companyId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    const stakes = await ctx.db
      .query("opportunityStakeholders")
      .withIndex("by_company", (q: any) => q.eq("companyId", companyId))
      .collect();

    const results = [];
    for (const s of stakes.filter((s: any) => !s.deletedAt && s.orgId === orgId)) {
      const opp = await ctx.db.get(s.opportunityId);
      if (!opp || opp.deletedAt) continue;
      results.push({
        _id: s._id,
        opportunityId: s.opportunityId,
        opportunityTitle: opp.title,
        role: s.role,
        notes: s.notes,
        isPrimary: s.isPrimary,
      });
    }
    return results;
  },
});

export const add = mutation({
  args: {
    opportunityId: v.id("opportunities"),
    companyId: v.id("companies"),
    role: v.string(),
    notes: v.optional(v.string()),
    isPrimary: v.optional(v.boolean()),
  },
  returns: v.id("opportunityStakeholders"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);

    // Verify opportunity and company belong to org
    const opp = await ctx.db.get(args.opportunityId);
    if (!opp || opp.orgId !== orgId) throw new Error("Opportunity not found");
    const company = await ctx.db.get(args.companyId);
    if (!company || company.orgId !== orgId) throw new Error("Company not found");

    // Check for duplicate (same company on same opportunity)
    const existing = await ctx.db
      .query("opportunityStakeholders")
      .withIndex("by_opp_company", (q: any) =>
        q.eq("opportunityId", args.opportunityId).eq("companyId", args.companyId)
      )
      .first();
    if (existing && !existing.deletedAt) {
      throw new Error("This company is already a stakeholder on this opportunity");
    }

    // If reusing a soft-deleted record, restore it
    if (existing) {
      await ctx.db.patch(existing._id, {
        role: args.role,
        notes: args.notes,
        isPrimary: args.isPrimary,
        deletedAt: undefined,
      });
      return existing._id;
    }

    // If marking as primary, clear other primaries
    if (args.isPrimary) {
      const others = await ctx.db
        .query("opportunityStakeholders")
        .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", args.opportunityId))
        .collect();
      for (const o of others.filter((o: any) => o.isPrimary && !o.deletedAt)) {
        await ctx.db.patch(o._id, { isPrimary: false });
      }
      // Also sync to opportunity.companyId
      await ctx.db.patch(args.opportunityId, { companyId: args.companyId });
    }

    const id = await ctx.db.insert("opportunityStakeholders", {
      orgId,
      opportunityId: args.opportunityId,
      companyId: args.companyId,
      role: args.role,
      notes: args.notes,
      isPrimary: args.isPrimary,
    });

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "add_stakeholder", entityType: "opportunity",
      entityId: args.opportunityId, timestamp: Date.now(),
      details: JSON.stringify({ companyId: args.companyId, role: args.role }),
    });

    return id;
  },
});

export const update = mutation({
  args: {
    id: v.id("opportunityStakeholders"),
    role: v.optional(v.string()),
    notes: v.optional(v.string()),
    isPrimary: v.optional(v.boolean()),
  },
  returns: v.null(),
  handler: async (ctx, { id, ...updates }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const s = await ctx.db.get(id);
    if (!s || s.orgId !== orgId) throw new Error("Not found");

    // If setting as primary, clear others
    if (updates.isPrimary) {
      const others = await ctx.db
        .query("opportunityStakeholders")
        .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", s.opportunityId))
        .collect();
      for (const o of others.filter((o: any) => o.isPrimary && !o.deletedAt && o._id !== id)) {
        await ctx.db.patch(o._id, { isPrimary: false });
      }
      // Sync to opportunity.companyId
      await ctx.db.patch(s.opportunityId, { companyId: s.companyId });
    }

    const patch: any = {};
    for (const [k, val] of Object.entries(updates)) {
      if (val !== undefined) patch[k] = val;
    }
    if (Object.keys(patch).length > 0) {
      await ctx.db.patch(id, patch);
    }

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "update_stakeholder", entityType: "opportunity",
      entityId: s.opportunityId, timestamp: Date.now(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("opportunityStakeholders") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const s = await ctx.db.get(id);
    if (!s || s.orgId !== orgId) throw new Error("Not found");

    await ctx.db.patch(id, { deletedAt: Date.now() });

    // If this was primary, clear opportunity.companyId
    if (s.isPrimary) {
      await ctx.db.patch(s.opportunityId, { companyId: undefined });
    }

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "remove_stakeholder", entityType: "opportunity",
      entityId: s.opportunityId, timestamp: Date.now(),
    });
    return null;
  },
});
