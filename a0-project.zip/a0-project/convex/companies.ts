import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

export const list = query({
  args: {},
  returns: v.array(v.object({
    _id: v.id("companies"),
    _creationTime: v.number(),
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    notes: v.optional(v.string()),
    segmentId: v.optional(v.id("segments")),
    segmentName: v.optional(v.string()),
    segmentPath: v.optional(v.string()),
    companyRole: v.optional(v.string()),
    companyRoleNotes: v.optional(v.string()),
  })),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const companies = await ctx.db
      .query("companies")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .order("desc")
      .collect();

    const results = [];
    for (const c of companies.filter((c: any) => !c.deletedAt)) {
      let segmentName: string | undefined;
      let segmentPath: string | undefined;
      if (c.segmentId) {
        // Build full path: L1 > L2 > L3
        const path: string[] = [];
        let seg: any = await ctx.db.get(c.segmentId);
        while (seg) {
          path.unshift(seg.name);
          seg = seg.parentId ? await ctx.db.get(seg.parentId) : null;
        }
        segmentName = path[path.length - 1];
        segmentPath = path.join(" > ");
      }
      results.push({
        _id: c._id,
        _creationTime: c._creationTime,
        name: c.name,
        domain: c.domain,
        industry: c.industry,
        size: c.size,
        phone: c.phone,
        email: c.email,
        notes: c.notes,
        segmentId: c.segmentId,
        segmentName,
        segmentPath,
        companyRole: c.companyRole,
        companyRoleNotes: c.companyRoleNotes,
      });
    }
    return results;
  },
});

export const get = query({
  args: { id: v.id("companies") },
  returns: v.union(v.object({
    _id: v.id("companies"),
    _creationTime: v.number(),
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
    ownerId: v.optional(v.id("users")),
    segmentId: v.optional(v.id("segments")),
    segmentPath: v.optional(v.string()),
    companyRole: v.optional(v.string()),
    companyRoleNotes: v.optional(v.string()),
    insightsReport: v.optional(v.string()),
    insightsGeneratedAt: v.optional(v.number()),
  }), v.null()),
  handler: async (ctx, { id }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return null;
    const { orgId } = auth;
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId || c.deletedAt) return null;

    let segmentPath: string | undefined;
    if (c.segmentId) {
      const path: string[] = [];
      let seg: any = await ctx.db.get(c.segmentId);
      while (seg) {
        path.unshift(seg.name);
        seg = seg.parentId ? await ctx.db.get(seg.parentId) : null;
      }
      segmentPath = path.join(" > ");
    }

    return {
      _id: c._id,
      _creationTime: c._creationTime,
      name: c.name,
      domain: c.domain,
      industry: c.industry,
      size: c.size,
      phone: c.phone,
      email: c.email,
      address: c.address,
      notes: c.notes,
      ownerId: c.ownerId,
      segmentId: c.segmentId,
      segmentPath,
      companyRole: c.companyRole,
      companyRoleNotes: c.companyRoleNotes,
      insightsReport: c.insightsReport,
      insightsGeneratedAt: c.insightsGeneratedAt,
    };
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
    segmentId: v.optional(v.id("segments")),
    companyRole: v.optional(v.string()),
    companyRoleNotes: v.optional(v.string()),
  },
  returns: v.id("companies"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    // Validate segment if provided
    if (args.segmentId) {
      const seg = await ctx.db.get(args.segmentId);
      if (!seg || seg.orgId !== orgId) throw new Error("Invalid segment");
    }
    const id = await ctx.db.insert("companies", {
      ...args,
      orgId,
      ownerId: userId,
    });
    await ctx.db.insert("auditLog", {
      orgId,
      userId,
      action: "create",
      entityType: "company",
      entityId: id,
      timestamp: Date.now(),
    });
    return id;
  },
});

export const update = mutation({
  args: {
    id: v.id("companies"),
    name: v.optional(v.string()),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
    size: v.optional(v.string()),
    phone: v.optional(v.string()),
    email: v.optional(v.string()),
    address: v.optional(v.string()),
    notes: v.optional(v.string()),
    segmentId: v.optional(v.id("segments")),
    companyRole: v.optional(v.string()),
    companyRoleNotes: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, { id, ...updates }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId) throw new Error("Not found");
    // Validate segment if provided
    if (updates.segmentId) {
      const seg = await ctx.db.get(updates.segmentId);
      if (!seg || seg.orgId !== orgId) throw new Error("Invalid segment");
    }
    const patch: any = {};
    for (const [k, val] of Object.entries(updates)) {
      if (val !== undefined) patch[k] = val;
    }
    if (Object.keys(patch).length > 0) {
      await ctx.db.patch(id, patch);
    }
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "update", entityType: "company", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("companies") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, { deletedAt: Date.now() });
    await ctx.db.insert("auditLog", {
      orgId, userId, action: "delete", entityType: "company", entityId: id, timestamp: Date.now(),
    });
    return null;
  },
});

export const saveInsights = mutation({
  args: {
    id: v.id("companies"),
    insightsReport: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, { id, insightsReport }) => {
    const { orgId } = await getUserOrgId(ctx);
    const c = await ctx.db.get(id);
    if (!c || c.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, {
      insightsReport,
      insightsGeneratedAt: Date.now(),
    });
    return null;
  },
});