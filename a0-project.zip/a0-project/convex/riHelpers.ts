import { internalQuery, internalMutation } from "./_generated/server";
import { v } from "convex/values";

// Internal query: gather all opportunities + context for a contact
export const getContactOpportunities = internalQuery({
  args: {
    contactId: v.id("contacts"),
    orgId: v.id("orgs"),
  },
  returns: v.array(v.object({
    id: v.id("opportunities"),
    title: v.string(),
    status: v.string(),
    value: v.optional(v.number()),
    companyName: v.optional(v.string()),
    notes: v.optional(v.string()),
    interactions: v.array(v.object({
      type: v.string(),
      subject: v.optional(v.string()),
      date: v.number(),
    })),
  })),
  handler: async (ctx, args) => {
    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.deletedAt) return [];

    // Find opportunities directly linked to this contact
    const directOpps = await ctx.db
      .query("opportunities")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .collect();

    // Find opportunities linked to the contact's company
    let companyOpps: any[] = [];
    if (contact.companyId) {
      companyOpps = await ctx.db
        .query("opportunities")
        .withIndex("by_org_and_company", (q: any) =>
          q.eq("orgId", args.orgId).eq("companyId", contact.companyId)
        )
        .collect();
    }

    // Also find opportunities that already have RI records for this contact
    const existingRi = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .collect();
    const riOppIds = new Set(existingRi.filter((r: any) => !r.deletedAt).map((r: any) => r.opportunityId.toString()));

    // Merge and deduplicate
    const allOpps = [...directOpps, ...companyOpps];
    const seen = new Set<string>();
    const uniqueOpps = [];
    for (const opp of allOpps) {
      if (opp.deletedAt || seen.has(opp._id.toString())) continue;
      seen.add(opp._id.toString());
      uniqueOpps.push(opp);
    }

    // Also add opportunities from existing RI records
    for (const oppIdStr of riOppIds) {
      if (!seen.has(oppIdStr)) {
        const opp = await ctx.db.get(oppIdStr as any);
        if (opp && !(opp as any).deletedAt) {
          seen.add(oppIdStr);
          uniqueOpps.push(opp as any);
        }
      }
    }

    // Gather context for each opportunity
    const results = [];
    for (const opp of uniqueOpps) {
      let companyName: string | undefined;
      if (opp.companyId) {
        const co = await ctx.db.get(opp.companyId);
        companyName = co?.name;
      }

      // Get recent interactions for this contact + opportunity
      const contactInteractions = await ctx.db
        .query("interactions")
        .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
        .order("desc")
        .take(5);

      const oppInteractions = await ctx.db
        .query("interactions")
        .withIndex("by_opportunity", (q: any) => q.eq("opportunityId", opp._id))
        .order("desc")
        .take(5);

      // Merge and dedupe interactions
      const allInteractions = [...contactInteractions, ...oppInteractions];
      const seenInt = new Set<string>();
      const interactions = [];
      for (const i of allInteractions) {
        if (i.deletedAt || seenInt.has(i._id.toString())) continue;
        seenInt.add(i._id.toString());
        interactions.push({ type: i.type, subject: i.subject, date: i.date });
      }
      interactions.sort((a, b) => b.date - a.date);

      results.push({
        id: opp._id,
        title: opp.title,
        status: opp.status,
        value: opp.value,
        companyName,
        notes: opp.notes,
        interactions: interactions.slice(0, 5),
      });
    }

    return results;
  },
});

// Internal mutation: save RI assessment from AI (no auth check)
export const saveRiFromAI = internalMutation({
  args: {
    orgId: v.id("orgs"),
    opportunityId: v.id("opportunities"),
    contactId: v.id("contacts"),
    stance: v.number(),
    influence: v.number(),
    role: v.string(),
    confidence: v.string(),
    relationshipStrength: v.string(),
    nextMoveTitle: v.optional(v.string()),
    aiReasoning: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const existing = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_opp_contact", (q: any) =>
        q.eq("opportunityId", args.opportunityId).eq("contactId", args.contactId)
      )
      .first();

    // Don't overwrite manual overrides
    if (existing && !existing.deletedAt && existing.isUserOverride) {
      return null;
    }

    if (existing && !existing.deletedAt) {
      await ctx.db.patch(existing._id, {
        stance: args.stance,
        influence: args.influence,
        role: args.role,
        confidence: args.confidence,
        relationshipStrength: args.relationshipStrength,
        nextMoveTitle: args.nextMoveTitle,
        aiReasoning: args.aiReasoning,
        isUserOverride: false,
        lastAnalyzedAt: Date.now(),
      });
    } else {
      await ctx.db.insert("relationshipIntelligence", {
        orgId: args.orgId,
        opportunityId: args.opportunityId,
        contactId: args.contactId,
        stance: args.stance,
        influence: args.influence,
        role: args.role,
        confidence: args.confidence,
        relationshipStrength: args.relationshipStrength,
        nextMoveTitle: args.nextMoveTitle,
        aiReasoning: args.aiReasoning,
        isUserOverride: false,
        lastAnalyzedAt: Date.now(),
      });
    }

    return null;
  },
});