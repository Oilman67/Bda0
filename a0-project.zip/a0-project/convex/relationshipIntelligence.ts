import { query, mutation, internalMutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";
import { internal } from "./_generated/api";

// List all assessments for an opportunity
export const listByOpportunity = query({
  args: { opportunityId: v.id("opportunities") },
  returns: v.array(v.object({
    _id: v.id("relationshipIntelligence"),
    _creationTime: v.number(),
    opportunityId: v.id("opportunities"),
    contactId: v.id("contacts"),
    contactName: v.string(),
    contactTitle: v.optional(v.string()),
    contactCompany: v.optional(v.string()),
    stance: v.number(),
    role: v.string(),
    roleConfidence: v.optional(v.string()),
    influence: v.number(),
    confidence: v.string(),
    relationshipStrength: v.string(),
    riskSensitivity: v.optional(v.string()),
    riskAlignment: v.optional(v.string()),
    aiReasoning: v.optional(v.string()),
    signals: v.optional(v.string()),
    risks: v.optional(v.string()),
    opportunities: v.optional(v.string()),
    nextMoveTitle: v.optional(v.string()),
    nextMoveDetails: v.optional(v.string()),
    nextMovePriority: v.optional(v.string()),
    nextMoveDeadline: v.optional(v.string()),
    isUserOverride: v.optional(v.boolean()),
    lastAnalyzedAt: v.optional(v.number()),
  })),
  handler: async (ctx, args) => {
    const opp = await ctx.db.get(args.opportunityId);
    if (!opp) return [];
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const rows = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_opportunity", (q) => q.eq("opportunityId", args.opportunityId))
      .collect();

    const results = [];
    for (const r of rows) {
      if (r.deletedAt) continue;
      const contact = await ctx.db.get(r.contactId);
      if (!contact || contact.deletedAt) continue;
      let companyName: string | undefined;
      if (contact.companyId) {
        const co = await ctx.db.get(contact.companyId);
        companyName = co?.name;
      }
      results.push({
        _id: r._id,
        _creationTime: r._creationTime,
        opportunityId: r.opportunityId,
        contactId: r.contactId,
        contactName: `${contact.firstName} ${contact.lastName}`.trim(),
        contactTitle: contact.title,
        contactCompany: companyName,
        stance: r.stance,
        role: r.role,
        roleConfidence: r.roleConfidence,
        influence: r.influence,
        confidence: r.confidence,
        relationshipStrength: r.relationshipStrength,
        riskSensitivity: r.riskSensitivity,
        riskAlignment: r.riskAlignment,
        aiReasoning: r.aiReasoning,
        signals: r.signals,
        risks: r.risks,
        opportunities: r.opportunities,
        nextMoveTitle: r.nextMoveTitle,
        nextMoveDetails: r.nextMoveDetails,
        nextMovePriority: r.nextMovePriority,
        nextMoveDeadline: r.nextMoveDeadline,
        isUserOverride: r.isUserOverride,
        lastAnalyzedAt: r.lastAnalyzedAt,
      });
    }
    return results;
  },
});

// List all assessments for a contact (across all opportunities)
export const listByContact = query({
  args: { contactId: v.id("contacts") },
  returns: v.array(v.object({
    _id: v.id("relationshipIntelligence"),
    opportunityId: v.id("opportunities"),
    opportunityTitle: v.string(),
    opportunityStatus: v.string(),
    stance: v.number(),
    role: v.string(),
    roleConfidence: v.optional(v.string()),
    influence: v.number(),
    confidence: v.string(),
    relationshipStrength: v.string(),
    riskSensitivity: v.optional(v.string()),
    riskAlignment: v.optional(v.string()),
    aiReasoning: v.optional(v.string()),
    signals: v.optional(v.string()),
    risks: v.optional(v.string()),
    opportunities: v.optional(v.string()),
    nextMoveTitle: v.optional(v.string()),
    nextMoveDetails: v.optional(v.string()),
    nextMovePriority: v.optional(v.string()),
    nextMoveDeadline: v.optional(v.string()),
    isUserOverride: v.optional(v.boolean()),
    lastAnalyzedAt: v.optional(v.number()),
  })),
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    const rows = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_contact", (q) => q.eq("contactId", args.contactId))
      .collect();

    const results = [];
    for (const r of rows) {
      if (r.deletedAt) continue;
      const opp = await ctx.db.get(r.opportunityId);
      if (!opp || opp.deletedAt) continue;
      results.push({
        _id: r._id,
        opportunityId: r.opportunityId,
        opportunityTitle: opp.title,
        opportunityStatus: opp.status,
        stance: r.stance,
        role: r.role,
        roleConfidence: r.roleConfidence,
        influence: r.influence,
        confidence: r.confidence,
        relationshipStrength: r.relationshipStrength,
        riskSensitivity: r.riskSensitivity,
        riskAlignment: r.riskAlignment,
        aiReasoning: r.aiReasoning,
        signals: r.signals,
        risks: r.risks,
        opportunities: r.opportunities,
        nextMoveTitle: r.nextMoveTitle,
        nextMoveDetails: r.nextMoveDetails,
        nextMovePriority: r.nextMovePriority,
        nextMoveDeadline: r.nextMoveDeadline,
        isUserOverride: r.isUserOverride,
        lastAnalyzedAt: r.lastAnalyzedAt,
      });
    }
    return results;
  },
});

// Save (upsert) an assessment
export const save = mutation({
  args: {
    opportunityId: v.id("opportunities"),
    contactId: v.id("contacts"),
    stance: v.number(),
    role: v.string(),
    roleConfidence: v.optional(v.string()),
    influence: v.number(),
    confidence: v.string(),
    relationshipStrength: v.string(),
    aiReasoning: v.optional(v.string()),
    signals: v.optional(v.string()),
    risks: v.optional(v.string()),
    opportunities: v.optional(v.string()),
    nextMoveTitle: v.optional(v.string()),
    nextMoveDetails: v.optional(v.string()),
    nextMovePriority: v.optional(v.string()),
    nextMoveDeadline: v.optional(v.string()),
    isUserOverride: v.optional(v.boolean()),
  },
  returns: v.id("relationshipIntelligence"),
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Not authenticated");
    const opp = await ctx.db.get(args.opportunityId);
    if (!opp) throw new Error("Opportunity not found");

    // Check for existing assessment
    const existing = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_opp_contact", (q) =>
        q.eq("opportunityId", args.opportunityId).eq("contactId", args.contactId)
      )
      .first();

    if (existing && !existing.deletedAt) {
      await ctx.db.patch(existing._id, {
        stance: args.stance,
        role: args.role,
        roleConfidence: args.roleConfidence,
        influence: args.influence,
        confidence: args.confidence,
        relationshipStrength: args.relationshipStrength,
        aiReasoning: args.aiReasoning,
        signals: args.signals,
        risks: args.risks,
        opportunities: args.opportunities,
        nextMoveTitle: args.nextMoveTitle,
        nextMoveDetails: args.nextMoveDetails,
        nextMovePriority: args.nextMovePriority,
        nextMoveDeadline: args.nextMoveDeadline,
        isUserOverride: args.isUserOverride,
        lastAnalyzedAt: Date.now(),
      });
      return existing._id;
    }

    return await ctx.db.insert("relationshipIntelligence", {
      orgId: opp.orgId,
      opportunityId: args.opportunityId,
      contactId: args.contactId,
      stance: args.stance,
      role: args.role,
      roleConfidence: args.roleConfidence,
      influence: args.influence,
      confidence: args.confidence,
      relationshipStrength: args.relationshipStrength,
      aiReasoning: args.aiReasoning,
      signals: args.signals,
      risks: args.risks,
      opportunities: args.opportunities,
      nextMoveTitle: args.nextMoveTitle,
      nextMoveDetails: args.nextMoveDetails,
      nextMovePriority: args.nextMovePriority,
      nextMoveDeadline: args.nextMoveDeadline,
      isUserOverride: args.isUserOverride,
      lastAnalyzedAt: Date.now(),
    });
  },
});

// Remove an assessment
export const remove = mutation({
  args: { id: v.id("relationshipIntelligence") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new Error("Not authenticated");
    await ctx.db.patch(args.id, { deletedAt: Date.now() });
    return null;
  },
});

// Manual TECOPS override – save user-defined risk scores on the CONTACT record
export const updateUserTECOPS = mutation({
  args: {
    contactId: v.id("contacts"),
    tecopsProfile: v.string(), // JSON: { T, E, C, O, P, S, primaryRiskDriver, secondaryRiskDriver }
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const { orgId } = await getUserOrgId(ctx);
    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.orgId !== orgId || contact.deletedAt)
      throw new Error("Contact not found");

    await ctx.db.patch(args.contactId, {
      tecopsProfile: args.tecopsProfile,
      tecopsAnalyzedAt: Date.now(),
    });
    return null;
  },
});

// Reset manual overrides for a contact — clears TECOPS profile and RI overrides so next AI run overwrites
export const resetUserOverrides = mutation({
  args: { contactId: v.id("contacts") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const { orgId } = await getUserOrgId(ctx);
    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.orgId !== orgId || contact.deletedAt)
      throw new Error("Contact not found");

    // Clear contact-level TECOPS
    await ctx.db.patch(args.contactId, {
      tecopsProfile: undefined,
      tecopsAnalyzedAt: undefined,
    });

    // Clear per-opp RI overrides
    const rows = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .collect();

    for (const r of rows) {
      if (!r.deletedAt && r.isUserOverride) {
        await ctx.db.patch(r._id, {
          isUserOverride: false,
        });
      }
    }
    return null;
  },
});

// Get contacts available to add (company contacts not yet assessed for this opportunity)
export const getAvailableContacts = query({
  args: { opportunityId: v.id("opportunities") },
  returns: v.array(v.object({
    _id: v.id("contacts"),
    name: v.string(),
    title: v.optional(v.string()),
  })),
  handler: async (ctx, args) => {
    const opp = await ctx.db.get(args.opportunityId);
    if (!opp) return [];
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];

    // Get existing assessments
    const existing = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_opportunity", (q) => q.eq("opportunityId", args.opportunityId))
      .collect();
    const assessedIds = new Set(existing.filter(r => !r.deletedAt).map(r => r.contactId.toString()));

    // Get contacts from the same company
    const contacts: Array<{ _id: typeof opp._id extends never ? never : any; name: string; title?: string }> = [];
    if (opp.companyId) {
      const companyContacts = await ctx.db
        .query("contacts")
        .withIndex("by_org_and_company", (q) => q.eq("orgId", opp.orgId).eq("companyId", opp.companyId!))
        .collect();
      for (const c of companyContacts) {
        if (!c.deletedAt && !assessedIds.has(c._id.toString())) {
          contacts.push({
            _id: c._id,
            name: `${c.firstName} ${c.lastName}`.trim(),
            title: c.title,
          });
        }
      }
    }

    // Also include the primary contact if not already included
    if (opp.contactId && !assessedIds.has(opp.contactId.toString())) {
      const pc = await ctx.db.get(opp.contactId);
      if (pc && !pc.deletedAt) {
        const alreadyAdded = contacts.some(c => c._id.toString() === pc._id.toString());
        if (!alreadyAdded) {
          contacts.push({
            _id: pc._id,
            name: `${pc.firstName} ${pc.lastName}`.trim(),
            title: pc.title,
          });
        }
      }
    }

    return contacts;
  },
});

// Request AI analysis for a contact across all linked opportunities
export const requestAnalysis = mutation({
  args: { contactId: v.id("contacts") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const { orgId } = await getUserOrgId(ctx);
    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.orgId !== orgId || contact.deletedAt)
      throw new Error("Contact not found");

    let companyName = "";
    let companyNotes = "";
    let companyRoleNotes = "";
    if (contact.companyId) {
      const company = await ctx.db.get(contact.companyId);
      companyName = company?.name || "";
      companyNotes = company?.notes || "";
      companyRoleNotes = (company as any)?.companyRoleNotes || "";
    }

    // Find linked opportunities (direct + company)
    const directOpps = await ctx.db
      .query("opportunities")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .collect();

    const companyOpps = contact.companyId
      ? await ctx.db
          .query("opportunities")
          .withIndex("by_org_and_company", (q: any) =>
            q.eq("orgId", orgId).eq("companyId", contact.companyId!)
          )
          .collect()
      : [];

    // Merge and deduplicate
    const oppMap = new Map<string, any>();
    for (const o of [...directOpps, ...companyOpps]) {
      if (!o.deletedAt) oppMap.set(o._id.toString(), o);
    }

    const allOpps = Array.from(oppMap.values());
    // Note: we proceed even with 0 opportunities — TECOPS can be inferred from title/notes alone

    // Get ALL interactions for this contact (for TECOPS portfolio analysis)
    const allInteractions = await ctx.db
      .query("interactions")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .order("desc")
      .take(50);

    const activeInteractions = allInteractions.filter((i: any) => !i.deletedAt);

    // Group interactions by opportunity for per-opp stance analysis
    const interactionsByOpp = new Map<string, any[]>();
    for (const i of activeInteractions) {
      if (i.opportunityId) {
        const key = i.opportunityId.toString();
        if (!interactionsByOpp.has(key)) interactionsByOpp.set(key, []);
        interactionsByOpp.get(key)!.push(i);
      }
    }

    // Get pipeline stage names for context
    const stageNames = new Map<string, string>();
    for (const o of allOpps) {
      if (o.stageId && !stageNames.has(o.stageId.toString())) {
        const stage = await ctx.db.get(o.stageId);
        if (stage) stageNames.set(o.stageId.toString(), stage.name);
      }
    }

    const truncate = (s: string | undefined, max: number) =>
      s && s.length > max ? s.slice(0, max) + "..." : s;

    const context = JSON.stringify({
      contact: {
        name: `${contact.firstName} ${contact.lastName}`,
        title: contact.title,
        company: companyName,
        notes: contact.notes,
        companyNotes: companyNotes ? truncate(companyNotes, 300) : undefined,
        companyRoleNotes: companyRoleNotes ? truncate(companyRoleNotes, 200) : undefined,
      },
      opportunities: allOpps.map((o: any) => ({
        id: o._id,
        title: o.title,
        status: o.status,
        stage: o.stageId ? stageNames.get(o.stageId.toString()) : undefined,
        value: o.value,
        currency: o.currency,
        notes: truncate(o.notes, 500),
        interactions: (interactionsByOpp.get(o._id.toString()) || []).map((i: any) => ({
          type: i.type,
          subject: i.subject,
          body: truncate(i.body, 300),
          date: new Date(i.date).toISOString(),
        })),
      })),
      allInteractions: activeInteractions.map((i: any) => ({
        type: i.type,
        subject: i.subject,
        body: truncate(i.body, 300),
        date: new Date(i.date).toISOString(),
        opportunityId: i.opportunityId,
      })),
    });

    await ctx.scheduler.runAfter(0, internal.riOrchestrate.analyzeContact, {
      orgId,
      contactId: args.contactId,
      context,
    });

    return null;
  },
});

// Internal mutation to save AI analysis results
export const upsertFromAI = internalMutation({
  args: {
    orgId: v.id("orgs"),
    contactId: v.id("contacts"),
    assessments: v.array(
      v.object({
        opportunityId: v.string(),
        stance: v.number(),
        role: v.string(),
        influence: v.number(),
        relationshipStrength: v.string(),
        nextMoveTitle: v.string(),
        nextMoveDetails: v.optional(v.string()),
      })
    ),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    for (const a of args.assessments) {
      // Validate the opportunity exists
      const opp = await ctx.db.get(a.opportunityId as any);
      if (!opp || opp.deletedAt) continue;

      const existing = await ctx.db
        .query("relationshipIntelligence")
        .withIndex("by_opp_contact", (q: any) =>
          q
            .eq("opportunityId", a.opportunityId as any)
            .eq("contactId", args.contactId)
        )
        .first();

      const data = {
        stance: a.stance,
        role: a.role,
        influence: a.influence,
        confidence: "Medium",
        relationshipStrength: a.relationshipStrength,
        nextMoveTitle: a.nextMoveTitle,
        nextMoveDetails: a.nextMoveDetails,
        lastAnalyzedAt: Date.now(),
        isUserOverride: false,
      };

      if (existing && !existing.deletedAt) {
        // Don't overwrite manual overrides
        if (!existing.isUserOverride) {
          await ctx.db.patch(existing._id, data);
        }
      } else {
        await ctx.db.insert("relationshipIntelligence", {
          orgId: args.orgId,
          opportunityId: a.opportunityId as any,
          contactId: args.contactId,
          ...data,
        });
      }
    }
    return null;
  },
});

// Internal mutation to save TECOPS profile on the CONTACT record (contact-level, not per-opportunity)
export const upsertTECOPS = internalMutation({
  args: {
    contactId: v.id("contacts"),
    tecopsProfile: v.string(), // JSON: { T, E, C, O, P, S, primaryRiskDriver, secondaryRiskDriver }
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.deletedAt) return null;

    // Don't overwrite if user has manually set TECOPS (check if tecopsProfile exists and was manually set)
    // For now, always update from AI since there's no explicit "isManualTecops" flag
    await ctx.db.patch(args.contactId, {
      tecopsProfile: args.tecopsProfile,
      tecopsAnalyzedAt: Date.now(),
    });
    return null;
  },
});

// Promote a RI next move to an action in the Actions tab
export const promoteToAction = mutation({
  args: { riId: v.id("relationshipIntelligence") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const ri = await ctx.db.get(args.riId);
    if (!ri || ri.orgId !== orgId || ri.deletedAt)
      throw new Error("Assessment not found");

    if (!ri.nextMoveTitle) throw new Error("No next move to promote");

    // Generate action number
    const year = new Date().getFullYear().toString().slice(-2);
    const prefix = `A${year}`;
    const allActions = await ctx.db
      .query("actions")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    let maxSeq = 0;
    for (const a of allActions) {
      if (a.actionNumber && a.actionNumber.startsWith(prefix)) {
        const seq = parseInt(a.actionNumber.slice(prefix.length), 10);
        if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
      }
    }
    const actionNumber = `${prefix}${(maxSeq + 1).toString().padStart(4, "0")}`;

    // Get contact name for description context
    const contact = await ctx.db.get(ri.contactId);
    const contactName = contact
      ? `${contact.firstName} ${contact.lastName}`.trim()
      : "Contact";

    // Get opportunity title
    const opp = await ctx.db.get(ri.opportunityId);
    const oppTitle = opp?.title || "Opportunity";

    await ctx.db.insert("actions", {
      orgId,
      actionNumber,
      title: ri.nextMoveTitle,
      description: ri.nextMoveDetails || undefined,
      notes: `From Relationship Intelligence: ${contactName} on ${oppTitle}`,
      assigneeId: userId,
      status: "todo",
      priority: ri.nextMovePriority === "high" ? "high" : ri.nextMovePriority === "low" ? "low" : "medium",
      startDate: Date.now(),
      contactId: ri.contactId,
      opportunityId: ri.opportunityId,
    });

    return null;
  },
});

// Get TECOPS profile for a contact (stored on the contact record)
export const getContactTECOPS = query({
  args: { contactId: v.id("contacts") },
  returns: v.object({
    tecopsProfile: v.optional(v.string()),
    tecopsAnalyzedAt: v.optional(v.number()),
  }),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return { tecopsProfile: undefined, tecopsAnalyzedAt: undefined };

    const contact = await ctx.db.get(args.contactId);
    if (!contact || contact.deletedAt)
      return { tecopsProfile: undefined, tecopsAnalyzedAt: undefined };

    return {
      tecopsProfile: contact.tecopsProfile,
      tecopsAnalyzedAt: contact.tecopsAnalyzedAt,
    };
  },
});

// Get lean KPI data for a contact (used in Context modal Relations tab)
export const getContactKPI = query({
  args: { contactId: v.id("contacts") },
  returns: v.array(
    v.object({
      _id: v.id("relationshipIntelligence"),
      opportunityId: v.id("opportunities"),
      opportunityTitle: v.string(),
      stance: v.string(),
      stanceValue: v.number(),
      influence: v.string(),
      influenceValue: v.number(),
      role: v.string(),
      relationshipStrength: v.string(),
      nextMove: v.optional(v.string()),
      isUserOverride: v.boolean(),
      lastAnalyzedAt: v.optional(v.number()),
    })
  ),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];

    const rows = await ctx.db
      .query("relationshipIntelligence")
      .withIndex("by_contact", (q: any) => q.eq("contactId", args.contactId))
      .collect();

    const stanceLabelMap: Record<number, string> = {
      [-2]: "Opposed",
      [-1]: "Skeptical",
      0: "Neutral",
      1: "Supportive",
      2: "Champion",
    };
    const influenceLabelMap: Record<number, string> = {
      1: "Low",
      2: "Medium",
      3: "High",
    };

    const results = [];
    for (const r of rows) {
      if (r.deletedAt) continue;
      const opp = await ctx.db.get(r.opportunityId);
      if (!opp || opp.deletedAt) continue;
      results.push({
        _id: r._id,
        opportunityId: r.opportunityId,
        opportunityTitle: opp.title,
        stance: stanceLabelMap[r.stance] || "Neutral",
        stanceValue: r.stance,
        influence: influenceLabelMap[r.influence] || "Medium",
        influenceValue: r.influence,
        role: r.role,
        relationshipStrength: r.relationshipStrength,
        nextMove: r.nextMoveTitle,
        isUserOverride: r.isUserOverride || false,
        lastAnalyzedAt: r.lastAnalyzedAt,
      });
    }
    return results;
  },
});