import { query, mutation, internalQuery } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId, getOrCreateOrg, getUserId } from "./helpers";
import { DEFAULT_SEGMENTS } from "./defaultSegments";

// Re-export for other modules
export { DEFAULT_SEGMENTS };


// Seed default segments for a new org
export const seedDefaults = mutation({
  args: {},
  returns: v.null(),
  handler: async (ctx) => {
    const userId = await getUserId(ctx);
    const orgId = await getOrCreateOrg(ctx, userId);

    // Check if segments already exist
    const existing = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .first();
    if (existing) return null;

    for (const l1 of DEFAULT_SEGMENTS) {
      const l1Id = await ctx.db.insert("segments", {
        orgId,
        name: l1.name,
        level: 1,
        color: l1.color,
      });
      for (const l2 of l1.children) {
        const l2Id = await ctx.db.insert("segments", {
          orgId,
          name: l2.name,
          level: 2,
          parentId: l1Id,
        });
        for (const l3 of l2.children) {
          await ctx.db.insert("segments", {
            orgId,
            name: l3.name,
            level: 3,
            parentId: l2Id,
          });
        }
      }
    }
    return null;
  },
});

// Seed segments from a personalized AI-generated taxonomy
export const seedFromTaxonomy = mutation({
  args: {
    segments: v.array(v.object({
      sector: v.string(),
      sectorColor: v.string(),
      subSectors: v.array(v.object({
        name: v.string(),
        niches: v.array(v.string()),
      })),
    })),
  },
  returns: v.null(),
  handler: async (ctx, { segments }) => {
    const userId = await getUserId(ctx);
    const orgId = await getOrCreateOrg(ctx, userId);

    // Check if segments already exist
    const existing = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .first();
    if (existing) return null; // Don't double-seed

    for (const sector of segments) {
      const l1Id = await ctx.db.insert("segments", {
        orgId,
        name: sector.sector,
        level: 1,
        color: sector.sectorColor,
      });
      for (const sub of sector.subSectors) {
        const l2Id = await ctx.db.insert("segments", {
          orgId,
          name: sub.name,
          level: 2,
          parentId: l1Id,
        });
        for (const niche of sub.niches) {
          await ctx.db.insert("segments", {
            orgId,
            name: niche,
            level: 3,
            parentId: l2Id,
          });
        }
      }
    }
    return null;
  },
});

// Regenerate taxonomy: soft-delete all existing segments and re-seed from new taxonomy
export const regenerate = mutation({
  args: {
    taxonomy: v.array(v.object({
      sector: v.string(),
      sectorColor: v.string(),
      subSectors: v.array(v.object({
        name: v.string(),
        niches: v.array(v.string()),
      })),
    })),
  },
  returns: v.null(),
  handler: async (ctx, { taxonomy }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const now = Date.now();

    // 1. Soft-delete all existing segments
    const existing = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    for (const seg of existing) {
      if (!seg.deletedAt) {
        await ctx.db.patch(seg._id, { deletedAt: now });
      }
    }

    // 2. Clear segmentId from all companies (they'll need reclassification)
    const companies = await ctx.db
      .query("companies")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    for (const c of companies) {
      if (c.segmentId && !c.deletedAt) {
        await ctx.db.patch(c._id, { segmentId: undefined });
      }
    }

    // 3. Seed new segments from taxonomy
    for (const sector of taxonomy) {
      const l1Id = await ctx.db.insert("segments", {
        orgId,
        name: sector.sector,
        level: 1,
        color: sector.sectorColor,
      });
      for (const sub of sector.subSectors) {
        const l2Id = await ctx.db.insert("segments", {
          orgId,
          name: sub.name,
          level: 2,
          parentId: l1Id,
        });
        for (const niche of sub.niches) {
          await ctx.db.insert("segments", {
            orgId,
            name: niche,
            level: 3,
            parentId: l2Id,
          });
        }
      }
    }

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "regenerate_taxonomy", entityType: "segment", entityId: "all", timestamp: now,
    });

    return null;
  },
});

// Get all segments for the org (flat list)
export const list = query({
  args: {},
  returns: v.array(v.object({
    _id: v.id("segments"),
    name: v.string(),
    level: v.number(),
    parentId: v.optional(v.id("segments")),
    color: v.optional(v.string()),
    description: v.optional(v.string()),
  })),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const segs = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    return segs
      .filter((s: any) => !s.deletedAt)
      .map((s: any) => ({
        _id: s._id,
        name: s.name,
        level: s.level,
        parentId: s.parentId,
        color: s.color,
        description: s.description,
      }));
  },
});

// Get children of a segment
export const getChildren = query({
  args: { parentId: v.optional(v.id("segments")) },
  returns: v.array(v.object({
    _id: v.id("segments"),
    name: v.string(),
    level: v.number(),
    parentId: v.optional(v.id("segments")),
    color: v.optional(v.string()),
    description: v.optional(v.string()),
    childCount: v.number(),
    companyCount: v.number(),
  })),
  handler: async (ctx, { parentId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    let children;
    if (parentId) {
      children = await ctx.db
        .query("segments")
        .withIndex("by_org_and_parent", (q: any) => q.eq("orgId", orgId).eq("parentId", parentId))
        .collect();
    } else {
      // Root level (L1)
      children = await ctx.db
        .query("segments")
        .withIndex("by_org_and_level", (q: any) => q.eq("orgId", orgId).eq("level", 1))
        .collect();
    }

    const results = [];
    for (const seg of children.filter((s: any) => !s.deletedAt)) {
      // Count direct children
      const kids = await ctx.db
        .query("segments")
        .withIndex("by_org_and_parent", (q: any) => q.eq("orgId", orgId).eq("parentId", seg._id))
        .collect();
      const childCount = kids.filter((k: any) => !k.deletedAt).length;

      // Count companies in this segment
      const companies = await ctx.db
        .query("companies")
        .withIndex("by_org_and_segment", (q: any) => q.eq("orgId", orgId).eq("segmentId", seg._id))
        .collect();
      const companyCount = companies.filter((c: any) => !c.deletedAt).length;

      results.push({
        _id: seg._id,
        name: seg.name,
        level: seg.level,
        parentId: seg.parentId,
        color: seg.color,
        description: seg.description,
        childCount,
        companyCount,
      });
    }

    return results.sort((a: any, b: any) => a.name.localeCompare(b.name));
  },
});

// Get full breadcrumb path for a segment
export const getBreadcrumb = query({
  args: { segmentId: v.id("segments") },
  returns: v.array(v.object({
    _id: v.id("segments"),
    name: v.string(),
    level: v.number(),
  })),
  handler: async (ctx, { segmentId }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const path: any[] = [];
    let current: any = await ctx.db.get(segmentId);

    while (current && current.orgId === orgId) {
      path.unshift({ _id: current._id, name: current.name, level: current.level });
      if (current.parentId) {
        current = await ctx.db.get(current.parentId);
      } else {
        break;
      }
    }
    return path;
  },
});

// Get companies in a specific segment (and optionally its descendants)
export const getCompanies = query({
  args: { segmentId: v.id("segments"), includeDescendants: v.optional(v.boolean()) },
  returns: v.array(v.object({
    _id: v.id("companies"),
    name: v.string(),
    domain: v.optional(v.string()),
    industry: v.optional(v.string()),
  })),
  handler: async (ctx, { segmentId, includeDescendants }) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;

    // Collect all segment IDs to search
    const segmentIds = [segmentId];
    if (includeDescendants) {
      // Get children
      const l2s = await ctx.db
        .query("segments")
        .withIndex("by_org_and_parent", (q: any) => q.eq("orgId", orgId).eq("parentId", segmentId))
        .collect();
      for (const l2 of l2s.filter((s: any) => !s.deletedAt)) {
        segmentIds.push(l2._id);
        const l3s = await ctx.db
          .query("segments")
          .withIndex("by_org_and_parent", (q: any) => q.eq("orgId", orgId).eq("parentId", l2._id))
          .collect();
        for (const l3 of l3s.filter((s: any) => !s.deletedAt)) {
          segmentIds.push(l3._id);
        }
      }
    }

    const allCompanies: any[] = [];
    for (const sid of segmentIds) {
      const companies = await ctx.db
        .query("companies")
        .withIndex("by_org_and_segment", (q: any) => q.eq("orgId", orgId).eq("segmentId", sid))
        .collect();
      allCompanies.push(...companies.filter((c: any) => !c.deletedAt));
    }

    return allCompanies.map((c: any) => ({
      _id: c._id,
      name: c.name,
      domain: c.domain,
      industry: c.industry,
    }));
  },
});

// Create a custom segment
export const create = mutation({
  args: {
    name: v.string(),
    level: v.number(),
    parentId: v.optional(v.id("segments")),
    description: v.optional(v.string()),
    color: v.optional(v.string()),
  },
  returns: v.id("segments"),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);

    // Validate parent if provided
    if (args.parentId) {
      const parent = await ctx.db.get(args.parentId);
      if (!parent || parent.orgId !== orgId) throw new Error("Invalid parent");
      if (parent.level >= args.level) throw new Error("Child level must be greater than parent level");
    }

    const id = await ctx.db.insert("segments", {
      orgId,
      name: args.name,
      level: args.level,
      parentId: args.parentId,
      description: args.description,
      color: args.color,
    });

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "create", entityType: "segment", entityId: id, timestamp: Date.now(),
    });

    return id;
  },
});

// Delete a segment (soft delete) — cascades to all descendants
export const remove = mutation({
  args: { id: v.id("segments") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const seg = await ctx.db.get(id);
    if (!seg || seg.orgId !== orgId) throw new Error("Not found");

    const now = Date.now();

    // Collect all descendant IDs to soft-delete
    const toDelete = [id];
    const queue = [id];
    while (queue.length > 0) {
      const parentId = queue.shift()!;
      const children = await ctx.db
        .query("segments")
        .withIndex("by_org_and_parent", (q: any) => q.eq("orgId", orgId).eq("parentId", parentId))
        .collect();
      for (const child of children) {
        if (!child.deletedAt) {
          toDelete.push(child._id);
          queue.push(child._id);
        }
      }
    }

    // Soft-delete all collected segments
    for (const segId of toDelete) {
      await ctx.db.patch(segId, { deletedAt: now });
    }

    await ctx.db.insert("auditLog", {
      orgId, userId, action: "delete", entityType: "segment", entityId: id, timestamp: now,
    });
    return null;
  },
});

// Internal query used by AI action to get segment paths
export const getPathsForAi = internalQuery({
  args: {},
  returns: v.array(v.object({
    id: v.id("segments"),
    path: v.string(),
    level: v.number(),
    name: v.string(),
  })),
  handler: async (ctx) => {
    // Use same auth pattern as the rest of the app
    const userId = await getUserId(ctx);

    const membership = await ctx.db
      .query("orgMembers")
      .withIndex("by_user", (q: any) => q.eq("userId", userId))
      .first();
    if (!membership) {
      console.log("[getPathsForAi] No org membership for user:", userId);
      return [];
    }

    const orgId = membership.orgId;
    const segs = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();

    const active = segs.filter((s: any) => !s.deletedAt);
    console.log("[getPathsForAi] Found", active.length, "active segments for org:", orgId);

    const segMap = new Map<string, any>();
    active.forEach((s: any) => segMap.set(s._id, s));

    const result = active.map((s: any) => {
      const parts: string[] = [];
      let cur: any = s;
      while (cur) {
        parts.unshift(cur.name);
        cur = cur.parentId ? segMap.get(cur.parentId) : undefined;
      }
      return { id: s._id, path: parts.join(" > "), level: s.level, name: s.name };
    });

    return result;
  },
});

// Create a segment chain (L1 > L2 > L3), reusing existing parents
export const createChain = mutation({
  args: {
    sectorName: v.string(),
    subSectorName: v.string(),
    nicheName: v.string(),
    sectorColor: v.optional(v.string()),
  },
  returns: v.object({
    segmentId: v.id("segments"),
    segmentPath: v.string(),
  }),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);

    const allSegs = await ctx.db
      .query("segments")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    const active = allSegs.filter((s: any) => !s.deletedAt);

    // Find or create L1 (Sector)
    let l1 = active.find(
      (s: any) => s.level === 1 && s.name.toLowerCase() === args.sectorName.toLowerCase()
    );
    let l1Id: any;
    let l1Name: string;
    if (l1) {
      l1Id = l1._id;
      l1Name = l1.name;
    } else {
      l1Id = await ctx.db.insert("segments", {
        orgId,
        name: args.sectorName,
        level: 1,
        color: args.sectorColor || "#6366F1",
      });
      l1Name = args.sectorName;
    }

    // Find or create L2 (Sub-sector)
    let l2 = active.find(
      (s: any) =>
        s.level === 2 &&
        s.parentId === l1Id &&
        s.name.toLowerCase() === args.subSectorName.toLowerCase()
    );
    let l2Id: any;
    let l2Name: string;
    if (l2) {
      l2Id = l2._id;
      l2Name = l2.name;
    } else {
      l2Id = await ctx.db.insert("segments", {
        orgId,
        name: args.subSectorName,
        level: 2,
        parentId: l1Id,
      });
      l2Name = args.subSectorName;
    }

    // Find or create L3 (Niche)
    let l3 = active.find(
      (s: any) =>
        s.level === 3 &&
        s.parentId === l2Id &&
        s.name.toLowerCase() === args.nicheName.toLowerCase()
    );
    let l3Id: any;
    let l3Name: string;
    if (l3) {
      l3Id = l3._id;
      l3Name = l3.name;
    } else {
      l3Id = await ctx.db.insert("segments", {
        orgId,
        name: args.nicheName,
        level: 3,
        parentId: l2Id,
      });
      l3Name = args.nicheName;
    }

    const path = `${l1Name} > ${l2Name} > ${l3Name}`;

    await ctx.db.insert("auditLog", {
      orgId,
      userId,
      action: "create",
      entityType: "segment",
      entityId: l3Id,
      timestamp: Date.now(),
    });

    return { segmentId: l3Id, segmentPath: path };
  },
});