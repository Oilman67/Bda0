"use node";

import { internalAction } from "./_generated/server";
import { v } from "convex/values";
import { internal } from "./_generated/api";

export const orchestrate = internalAction({
  args: {
    orgId: v.id("orgs"),
    entryType: v.string(),
    entryId: v.string(),
    userId: v.id("users"),
    context: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const response = await fetch("https://api.a0.dev/ai/llm", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: `You are a BD copilot for a CRM. Analyze the entity context and suggest 3-5 Next Best Actions.
Each action should be practical, specific, and prioritized by impact score (0-100).
Action types: follow_up, schedule_meeting, send_proposal, research_company, update_pipeline, add_contact, qualify_lead, close_opportunity, re_engage.`,
          },
          {
            role: "user",
            content: `Entity type: ${args.entryType}\nContext: ${args.context}`,
          },
        ],
        schema: {
          type: "object",
          properties: {
            actions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  actionType: { type: "string" },
                  title: { type: "string" },
                  description: { type: "string" },
                  score: { type: "number" },
                  reasoning: { type: "string" },
                },
                required: ["actionType", "title", "description", "score"],
              },
            },
          },
          required: ["actions"],
        },
      }),
    });

    const data = await response.json();
    let nbas: Array<{
      actionType: string;
      title: string;
      description: string;
      score: number;
      reasoning?: string;
      engine: string;
    }> = [];

    if (data.schema_data?.actions) {
      nbas = data.schema_data.actions.map((a: any) => ({
        ...a,
        engine: "llm",
      }));
    } else {
      nbas = [
        {
          actionType: "follow_up",
          title: "Follow up",
          description: `Follow up on this ${args.entryType} to keep momentum`,
          score: 75,
          engine: "heuristic",
        },
        {
          actionType: "add_contact",
          title: "Add key contacts",
          description: "Ensure all relevant stakeholders are linked",
          score: 60,
          engine: "heuristic",
        },
      ];
    }

    await ctx.runMutation(internal.nba.upsertNbas, {
      orgId: args.orgId,
      entryType: args.entryType,
      entryId: args.entryId,
      nbas,
    });

    return null;
  },
});