import { mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId } from "./helpers";
import { internal } from "./_generated/api";

export const dismiss = mutation({
  args: { id: v.id("nextBestActions") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId } = await getUserOrgId(ctx);
    const nba = await ctx.db.get(id);
    if (!nba || nba.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, { dismissedAt: Date.now() });
    return null;
  },
});

export const execute = mutation({
  args: { id: v.id("nextBestActions") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const nba = await ctx.db.get(id);
    if (!nba || nba.orgId !== orgId) throw new Error("Not found");

    // Mark NBA as executed
    await ctx.db.patch(id, { executedAt: Date.now() });

    // Generate action number
    const year = new Date().getFullYear().toString().slice(-2);
    const prefix = `A${year}`;
    const allActions = await ctx.db
      .query("actions")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .collect();
    let maxSeq = 0;
    for (const a of allActions) {
      if (a.actionNumber && a.actionNumber.startsWith(prefix)) {
        const seq = parseInt(a.actionNumber.slice(prefix.length), 10);
        if (!isNaN(seq) && seq > maxSeq) maxSeq = seq;
      }
    }
    const actionNumber = `${prefix}${(maxSeq + 1).toString().padStart(4, "0")}`;

    // Map NBA score to action priority
    const actionPriority = (nba.score ?? 50) >= 80 ? "high" : (nba.score ?? 50) >= 50 ? "medium" : "low";

    // Link to same entity as the NBA
    const linkFields: any = {};
    if (nba.entryType === "company") linkFields.companyId = nba.entryId;
    else if (nba.entryType === "contact") linkFields.contactId = nba.entryId;
    else if (nba.entryType === "opportunity") linkFields.opportunityId = nba.entryId;

    await ctx.db.insert("actions", {
      orgId,
      actionNumber,
      title: nba.title,
      description: nba.description || undefined,
      notes: nba.reasoning || undefined,
      assigneeId: userId,
      status: "todo",
      priority: actionPriority,
      startDate: Date.now(),
      ...linkFields,
    });

    return null;
  },
});

export const requestRefresh = mutation({
  args: {
    entryType: v.string(),
    entryId: v.string(),
    entityContext: v.string(),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    await ctx.scheduler.runAfter(0, internal.nbaOrchestrate.orchestrate, {
      orgId,
      entryType: args.entryType,
      entryId: args.entryId,
      userId,
      context: args.entityContext,
    });
    return null;
  },
});