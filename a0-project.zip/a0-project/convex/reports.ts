import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getUserOrgId, safeGetUserOrgId } from "./helpers";

export const pipelineReport = query({
  args: {
    pipelineId: v.optional(v.id("pipelines")),
    stageIds: v.optional(v.array(v.id("pipelineStages"))),
    groupBy: v.optional(v.string()),
    rangeField: v.optional(v.string()),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    currency: v.optional(v.string()),
  },
  returns: v.object({
    totalValue: v.number(),
    totalCount: v.number(),
    currencies: v.array(v.string()),
    breakdown: v.array(v.object({
      label: v.string(),
      color: v.optional(v.string()),
      count: v.number(),
      value: v.number(),
    })),
    hasMixedCurrency: v.boolean(),
  }),
  handler: async (ctx, args) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return { totalValue: 0, totalCount: 0, currencies: [], breakdown: [], hasMixedCurrency: false };
    const { orgId } = auth;
    const groupBy = args.groupBy ?? "stage";
    const rangeField = args.rangeField ?? "created";

    // Get pipeline
    let pipelineId = args.pipelineId;
    if (!pipelineId) {
      const pipelines = await ctx.db
        .query("pipelines")
        .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
        .collect();
      const def = pipelines.find((p: any) => p.isDefault && !p.deletedAt);
      if (!def) return { totalValue: 0, totalCount: 0, currencies: [], breakdown: [], hasMixedCurrency: false };
      pipelineId = def._id;
    }

    // Validate date range
    if (args.startDate && args.endDate) {
      if (args.startDate > args.endDate) throw new Error("invalid_filters: start must be before end");
      const maxWindow = 180 * 24 * 60 * 60 * 1000;
      if (args.endDate - args.startDate > maxWindow) throw new Error("invalid_filters: window must be <= 180 days");
    }

    // Fetch opportunities
    let opps = await ctx.db
      .query("opportunities")
      .withIndex("by_org_and_pipeline", (q: any) => q.eq("orgId", orgId).eq("pipelineId", pipelineId))
      .collect();

    opps = opps.filter((o: any) => !o.deletedAt);

    // Filter by stage
    if (args.stageIds && args.stageIds.length > 0) {
      const stageSet = new Set(args.stageIds);
      opps = opps.filter((o: any) => stageSet.has(o.stageId));
    }

    // Filter by date range
    if (args.startDate || args.endDate) {
      opps = opps.filter((o: any) => {
        const dateVal = rangeField === "close" ? o.closeDate : o._creationTime;
        if (!dateVal) return false;
        if (args.startDate && dateVal < args.startDate) return false;
        if (args.endDate && dateVal >= args.endDate) return false;
        return true;
      });
    }

    // Collect currencies
    const currencySet = new Set<string>();
    for (const o of opps) {
      if (o.currency) currencySet.add(o.currency);
      else currencySet.add("USD");
    }
    const currencies = Array.from(currencySet);

    // Multi-currency guard
    if (currencies.length > 1 && !args.currency) {
      return {
        totalValue: 0,
        totalCount: opps.length,
        currencies,
        breakdown: [],
        hasMixedCurrency: true,
      };
    }

    // Filter by currency if specified
    if (args.currency) {
      opps = opps.filter((o: any) => (o.currency || "USD") === args.currency);
    }

    // Group
    const breakdownMap = new Map<string, { label: string; color?: string; count: number; value: number; position: number }>();

    if (groupBy === "stage") {
      const stages = await ctx.db
        .query("pipelineStages")
        .withIndex("by_org_and_pipeline", (q: any) => q.eq("orgId", orgId).eq("pipelineId", pipelineId))
        .collect();
      const stageMap = new Map<string, { name: string; color?: string; position: number }>();
      for (const s of stages) {
        if (!s.deletedAt) stageMap.set(s._id, { name: s.name, color: s.color, position: s.position });
      }
      for (const o of opps) {
        const sInfo = stageMap.get(o.stageId) || { name: "Unknown", position: 99 };
        const key = o.stageId;
        const existing = breakdownMap.get(key);
        if (existing) {
          existing.count++;
          existing.value += o.value || 0;
        } else {
          breakdownMap.set(key, { label: sInfo.name, color: sInfo.color, count: 1, value: o.value || 0, position: sInfo.position });
        }
      }
    } else {
      // Group by owner
      for (const o of opps) {
        const key = o.ownerId || "unassigned";
        if (!breakdownMap.has(key)) {
          let label = "Unassigned";
          if (o.ownerId) {
            const user = await ctx.db.get(o.ownerId);
            label = user?.name || "Unknown";
          }
          breakdownMap.set(key, { label, count: 0, value: 0, position: 0 });
        }
        const e = breakdownMap.get(key)!;
        e.count++;
        e.value += o.value || 0;
      }
    }

    const breakdown = Array.from(breakdownMap.values())
      .sort((a, b) => groupBy === "stage" ? a.position - b.position : a.label.localeCompare(b.label))
      .map(({ label, color, count, value }) => ({ label, color, count, value }));

    const totalValue = breakdown.reduce((s, b) => s + b.value, 0);
    const totalCount = breakdown.reduce((s, b) => s + b.count, 0);

    return { totalValue, totalCount, currencies, breakdown, hasMixedCurrency: false };
  },
});

export const createShareLink = mutation({
  args: {
    pipelineId: v.optional(v.id("pipelines")),
    groupBy: v.optional(v.string()),
    rangeField: v.optional(v.string()),
    startDate: v.optional(v.number()),
    endDate: v.optional(v.number()),
    currency: v.optional(v.string()),
  },
  returns: v.object({ token: v.string() }),
  handler: async (ctx, args) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const token = Array.from({ length: 32 }, () =>
      Math.random().toString(36)[2]
    ).join("");
    await ctx.db.insert("reportShares", {
      orgId,
      type: "pipeline",
      token,
      filters: JSON.stringify(args),
      createdBy: userId,
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000, // 7 days
    });
    await ctx.db.insert("auditLog", {
      orgId,
      userId,
      action: "create_share",
      entityType: "report",
      entityId: token,
      timestamp: Date.now(),
    });
    return { token };
  },
});

export const listShares = query({
  args: {},
  returns: v.array(
    v.object({
      _id: v.id("reportShares"),
      token: v.string(),
      type: v.string(),
      expiresAt: v.number(),
      lastAccessedAt: v.optional(v.number()),
      revokedAt: v.optional(v.number()),
      _creationTime: v.number(),
    })
  ),
  handler: async (ctx) => {
    const auth = await safeGetUserOrgId(ctx);
    if (!auth) return [];
    const { orgId } = auth;
    const shares = await ctx.db
      .query("reportShares")
      .withIndex("by_org", (q: any) => q.eq("orgId", orgId))
      .order("desc")
      .collect();
    return shares
      .filter((s: any) => !s.revokedAt)
      .map((s: any) => ({
        _id: s._id,
        token: s.token,
        type: s.type,
        expiresAt: s.expiresAt,
        lastAccessedAt: s.lastAccessedAt,
        revokedAt: s.revokedAt,
        _creationTime: s._creationTime,
      }));
  },
});

export const revokeShare = mutation({
  args: { id: v.id("reportShares") },
  returns: v.null(),
  handler: async (ctx, { id }) => {
    const { orgId, userId } = await getUserOrgId(ctx);
    const s = await ctx.db.get(id);
    if (!s || s.orgId !== orgId) throw new Error("Not found");
    await ctx.db.patch(id, { revokedAt: Date.now() });
    await ctx.db.insert("auditLog", {
      orgId,
      userId,
      action: "revoke_share",
      entityType: "report",
      entityId: s.token,
      timestamp: Date.now(),
    });
    return null;
  },
});