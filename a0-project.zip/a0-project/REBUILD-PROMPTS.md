# BDBuddy — Rebuild Prompts

Use these 5 prompts **sequentially** in a0.dev sessions. Each one builds on the previous session's output.

---

## PROMPT 1: Foundation — Schema, Auth, Theme & Navigation Shell

```
Build a mobile CRM app called "BDBuddy" for business development teams. This is the foundation session — set up the database, auth, theme, and navigation shell.

### Authentication
Use Convex Auth with Password, Anonymous, and A0Social providers. Create a LoginScreen with email/password sign-in (with sign-up toggle) and Google/Apple social login buttons using a0-sdk. Style: clean card layout, primary blue (#2563EB) branding, "BDBuddy" title with briefcase icon.

### Database Schema (Convex)
Create schema.ts with these tables (all include soft-delete via optional deletedAt field unless noted):

**Auth & Org (multi-tenant)**
- users: extend authTables — name, image, email, emailVerificationTime, phone, phoneVerificationTime, isAnonymous, role. Index: email.
- orgs: name, ownerId (ref users), deletedAt. Index: by_owner.
- orgMembers: orgId (ref orgs), userId (ref users), role ('owner'|'admin'|'member'). Indexes: by_org, by_user, by_org_and_user.
- orgSettings: orgId (ref orgs), companyName, companyUrl?, interests, taxonomyProfile? (JSON string). Index: by_org.

**CRM Core**
- companies: orgId, name, domain?, industry?, size?, phone?, email?, address?, notes?, ownerId? (ref users), segmentId (ref segments, **required** — key to Segments), deletedAt. Indexes: by_org, by_org_and_name, by_org_and_owner, by_org_and_segment.
- contacts: orgId, firstName, lastName, email?, phone?, linkedin?, title?, companyId (ref companies, **required** — key to Companies), ownerId?, notes?, deletedAt. Indexes: by_org, by_org_and_company, by_org_and_owner.
- pipelines: orgId, name, isDefault (boolean), deletedAt. Index: by_org.
- pipelineStages: orgId, pipelineId (ref pipelines), name, position (number), color?, deletedAt. Indexes: by_pipeline, by_org_and_pipeline.
- opportunities: orgId, reference? (auto-generated like "OP26001"), title, value?, currency? (ISO 4217), pipelineId?, stageId? (ref pipelineStages), companyId (ref companies, **required** — driving company of opportunity), contactId?, ownerId?, closeDate?, probability?, status ('early_planning'|'rfi'|'rfp'|'rfq'|'won'|'lost'), location? (JSON string), lostCompetitor?, notes?, deletedAt. Indexes: by_org, by_org_and_pipeline, by_org_and_stage, by_org_and_owner, by_org_and_status, by_org_and_company.
- interactions: orgId, type ('note'|'email'|'call'|'meeting'), subject?, body?, date (number), companyId?, contactId?, opportunityId?, userId (ref users), deletedAt. Note: at least one of contactId or opportunityId is **required** when creating. Indexes: by_org, by_company, by_contact, by_opportunity.
- actions: orgId, title, description?, dueDate?, status ('todo'|'in_progress'|'done'), priority ('low'|'medium'|'high'), assigneeId?, segmentId?, companyId?, contactId?, opportunityId?, interactionId?, deletedAt. Indexes: by_org, by_org_and_status, by_org_and_assignee, by_opportunity, by_company, by_contact.

**Intelligence**
- segments: orgId, name, level (1|2|3), parentId? (ref segments), description?, color?, companyCount?, deletedAt. Indexes: by_org, by_org_and_level, by_parent, by_org_and_parent.
- nextBestActions: orgId, entryType, entryId (string), actionType, title, description, score (number), reasoning?, engine ('heuristic'|'llm'), metadata? (JSON string), expiresAt?, dismissedAt?, executedAt?. Indexes: by_entry [orgId, entryType, entryId], by_dedupe [orgId, entryType, entryId, actionType].

**Audit & Sharing**
- opportunityStageChanges: orgId, opportunityId, fromStageId?, toStageId, userId, changedAt. Index: by_opportunity.
- auditLog: orgId, userId, action, entityType, entityId (string), details?, timestamp. Indexes: by_org, by_org_and_entity [orgId, entityType, entityId].
- reportShares: orgId, type ('pipeline'), token, filters (JSON string), createdBy, expiresAt, lastAccessedAt?, revokedAt?. Indexes: by_token, by_org.

### Theme (lib/theme.ts)
Create a design system with:
- colors: primary #2563EB, primaryLight #DBEAFE, primaryDark #1D4ED8, accent #7C3AED, accentLight #EDE9FE, success #059669, warning #D97706, danger #DC2626, info #0891B2, plus light variants, 5 stage colors, and neutrals (bg #F8FAFC, card white, border #E2E8F0, textPrimary #0F172A, textSecondary #475569, textTertiary #94A3B8).
- spacing: xs=4, sm=8, md=12, lg=16, xl=20, xxl=24, xxxl=32
- radius: sm=6, md=8, lg=12, xl=16, full=999
- fontSize: xs=11, sm=13, md=15, lg=17, xl=20, xxl=24, xxxl=30
- shadow: sm/md/lg with appropriate elevation

### Navigation Shell (App.tsx)
Set up a custom bottom tab bar with TWO sections:
1. **Carousel tabs** (horizontally scrollable): Segments, Companies, Opportunities, Contacts, Interactions — each with Ionicon icons and active state (blue filled icon circle).
2. **Utility column** (right side, stacked vertically): Actions, Reports, Settings — smaller icons, compact.

Each tab should have its own Stack navigator for drill-down screens. Use SafeAreaProvider. Wrap with Authenticated/Unauthenticated/AuthLoading from convex/react.

### Onboarding Backend
Create convex/onboarding.ts:
- ensureOnboarded mutation: get authenticated user, check if they have an org (via orgMembers), if not create org + orgMembers record. Return {orgId, userId}.
- getMyOrg query: return current user's org.

Create a helper function getUserOrgId (and safeGetUserOrgId) that all mutations/queries use to scope data to the current user's org — enforcing multi-tenancy.

DON'T build any screens yet besides LoginScreen and empty placeholder screens for each tab. The navigation and auth flow should work end-to-end.
```

---

## PROMPT 2: CRM Core — Backend CRUD & Primary Screens

```
Continue building BDBuddy. The database schema, auth, theme, and navigation shell are already set up. Now build all CRM CRUD operations and their corresponding screens.

### Default Segments Data
Create convex/defaultSegments.ts — a pure data file (no server imports) exporting DEFAULT_SEGMENTS. This is a 3-level hierarchy: 7 L1 sectors, each with 2-5 L2 sub-sectors, each with 3-5 L3 niches. Sectors with colors:
- Industry (#6366F1): Oil & Gas (Upstream/Midstream/Downstream/Retail), Cement & Materials (Portland Cement/Concrete/Aggregate/Ready-Mix), Manufacturing (Automotive/Aerospace/Electronics/Food & Beverage/Textiles), Mining & Metals, Chemicals
- Wholesale & Distribution (#0891B2): Industrial Supply, Building Materials, Food & Beverage
- Services (#059669): Professional Services, IT & Technology Services, Facility & Field Services
- Technology (#7C3AED): Software, Hardware & Infrastructure
- Healthcare (#DC2626): Providers, Pharma & Biotech
- Energy & Utilities (#D97706): Renewables, Traditional Energy
- Financial Services (#0D9488): Banking, Insurance

### Segments Backend (convex/segments.ts)
Queries:
- list: all segments for org (flat)
- getChildren(parentId?): children of segment (or L1 roots), include childCount and companyCount per segment
- getBreadcrumb(segmentId): full path array from L1 to current segment
- getCompanies(segmentId, includeDescendants?): companies in segment

Mutations:
- seedDefaults: seed org with all DEFAULT_SEGMENTS hierarchy
- seedFromTaxonomy(taxonomy): seed from AI-generated taxonomy array [{sector, sectorColor, subSectors: [{name, niches}]}]
- create(name, level, parentId?, description?, color?): create segment
- remove(id): soft-delete segment + cascade to all descendants
- createChain(sectorName, subSectorName, nicheName, sectorColor?): create full L1>L2>L3 chain, reusing existing parents. Return {segmentId, segmentPath}.

### Companies Backend (convex/companies.ts)
- list query: all companies with segment path resolved
- get(id) query
- create mutation: standard CRUD + audit log
- update mutation: patch fields + audit log
- remove mutation: soft delete + audit log

### Contacts Backend (convex/contacts.ts)
- list(companyId?) query: optionally filter by company
- get(id) query: include last interaction info
- create/update/remove mutations with audit logging

### Opportunities Backend (convex/opportunities.ts)
- list(pipelineId?, status?, companyId?) query: include stage name, company name, contact name
- listByCompany(companyId) query
- get(id) query
- create mutation: auto-generate reference like "OP" + YY + NNN (e.g. OP26001)
- update mutation
- remove mutation: soft delete
- moveStage(id, stageId) mutation: update stage + record in opportunityStageChanges

### Pipelines Backend (convex/pipelines.ts)
- list query, getStages(pipelineId) query (sorted by position), getDefaultPipeline query

### Interactions Backend (convex/interactions.ts)
- listByEntity(entityType, entityId) query
- listAll query: last 100 interactions
- create mutation

### Actions/Tasks Backend (convex/actions.ts)
- list(status?) query: optionally filter by status
- listByEntity(entityType, entityId) query
- create mutation (defaults: status=todo, priority=medium)
- updateStatus(id, status) mutation

### Screens to Build

**SegmentsScreen**: Hierarchical 3-level browser. Show L1 sectors as color-coded cards with child count and company count. Tap to drill into L2, then L3. Breadcrumb navigation at top. Search bar that searches across all segment names. "+" button to create segments at current level. Swipe-to-delete on segments.

**SegmentCompaniesScreen**: List companies within a specific segment. Show company name, industry, email. Navigate to CompanyDetail.

**CompaniesScreen**: Searchable list of all companies. Each row shows name, industry, email, segment path badge. "+" FAB to add company. Tap row to navigate to CompanyDetail.

**AddCompanyScreen**: Form with fields: name (required), domain, industry, size, phone, email, address, notes. Segment picker (optional). Save button.

**CompanyDetailScreen**: Header card with company name, domain, industry. Tabs or sections for: Details, Contacts (linked), Opportunities (linked), Interactions timeline, Actions. Edit button in header. Show segment path.

**ContactsScreen**: Searchable list of contacts. Show name, title, company name, email. "+" button to add contact.

**ContactDetailScreen**: Header with name, title, company link. Sections for details, interactions, linked opportunities. Edit capability.

**PipelineScreen (Opportunities)**: Show opportunities grouped by pipeline stage. Each opportunity card shows: title, reference, company name, value + currency, status badge. Tap to navigate to OpportunityDetail. "+" FAB to create opportunity.

**OpportunityDetailScreen**: Header with title, reference, status badge, value. Sections: details, stage (with move-stage picker), company/contact links, interactions, actions. Edit capability.

**InteractionsScreen**: Chronological list of all interactions. Filter tabs: All, Notes, Emails, Calls, Meetings. Each row shows type icon, subject, body preview, relative date ("Today", "Yesterday", "3d ago"), linked company/contact. "+" button to log new interaction with type picker, subject, body, entity links.

**TasksScreen (Actions)**: Filter tabs: All, To-Do, In Progress, Done. Each task card shows: checkbox (to toggle done), title, priority badge (color-coded), due date with overdue indicator (red if past due). "+" button to create task with title, description, due date picker, priority picker.

**SettingsScreen**: Placeholder for now with just a sign-out button.

All screens should use the theme system (colors, spacing, radius, shadow from lib/theme.ts). Use SafeAreaView with proper insets. All data fetched via useQuery, mutations via useMutation. Every screen should handle loading states (ActivityIndicator) and empty states (friendly message + icon).
```

---

## PROMPT 3: AI Intelligence Layer

```
Continue building BDBuddy. The CRM schema, CRUD operations, and all screens are working. Now add the AI intelligence layer.

### Segment Classification from URL (convex/ai.ts — "use node" action)

Create suggestSegmentFromUrl(companyName, companyDomain) action:

1. **Fetch website content**: Hit the company's homepage + /about, /about-us, /careers, /investors, /company pages in parallel. Extract:
   - Page title, meta description, OG description
   - All h1-h3 headings (up to 30)
   - Body text from each page (up to 1500 chars each, excluding nav/footer/scripts)
   - Email addresses (regex, filter out image/asset emails)
   - Phone numbers (10+ digits)

2. **Parallel LLM calls** using POST https://api.a0.dev/ai/llm:

   Call A — Classification: If org has existing segments, ask LLM to pick best match AND propose ideal 3-level path. Include confidence rules (9-10=exact match, 7-8=same industry, 4-6=related, 1-3=different industry). If no segments exist, just classify. If website returned little content (<500 chars), instruct LLM to use its own knowledge about the company. Schema: {confidence: number, matchId: string, sector: string, subSector: string, niche: string, reason: string, keywords: string[]}.

   Call B — Dimensions: Extract company business dimensions from content (or LLM knowledge if content sparse). Schema: {revenue, employees, sites, capitalization, headquarters, founded, description} — all strings.

3. **Fallback**: If LLM returns empty classification, use keyword matching against DEFAULT_SEGMENTS (score each L1>L2>L3 path by term overlap with company name + website content + keywords).

4. **HTML extraction baseline**: Before LLM dimensions, extract what you can directly from HTML via regex: employee counts ("86,000 employees"), revenue ("$280B"), founded year, headquarters ("headquartered in Houston"), locations/sites, market cap.

5. **Resolution**: If confidence >= 7 and existing segment found, return existing segment. If confidence < 7, return as "proposal" with proposed sector/subsector/niche + a fallback existing segment. Include color from DEFAULT_SEGMENTS.

6. **LLM retry logic**: Attempt 1 with schema. If fails, Attempt 2 without schema but with JSON format instruction in prompt.

Return type: {segmentId?, segmentPath, reason, keywords[], websiteSnippet, emails[], phones[], isProposal, confidence, proposedSector?, proposedSubSector?, proposedNiche?, proposedColor?, fallbackSegmentId?, fallbackSegmentPath?, companyDimensions?}

### Taxonomy Generation (convex/ai.ts)

Create generateTaxonomy(companyName, companyUrl?, interests) action:

1. Optionally scrape company website (reuse fetch logic)
2. Call LLM: "Pick 2-5 market sectors most relevant to this company's target markets" from the DEFAULT_SEGMENTS sector names. Also generate buyerTypes, offerTypes, problemThemes, keywords.
3. Map selected sector names to full DEFAULT_SEGMENTS hierarchy (sector + all sub-sectors + all niches).
4. Fallback: keyword matching to pick top 3 sectors by term overlap. Default buyer types, offer types, problem themes.
5. Ensure at least 2 sectors in result.
6. Return: {segments[], buyerTypes[], offerTypes[], problemThemes[], keywords[], confidence}.

### Next Best Actions System

Create convex/nba.ts:
- getNextActions(entryType, entryId) query: return non-dismissed, non-executed, non-expired NBAs sorted by score descending
- upsertNbas(orgId, entryType, entryId, nbas[]) internal mutation: for each NBA, check dedupe index — if exists, update score/description/reasoning; if new, insert with 7-day expiry

Create convex/nbaActions.ts:
- dismiss(id) mutation: set dismissedAt
- execute(id) mutation: set executedAt
- requestRefresh(entryType, entryId, entityContext) mutation: trigger internal action nbaOrchestrate.orchestrate

Create convex/nbaOrchestrate.ts ("use node" internalAction):
- orchestrate(orgId, entryType, entryId, userId, context): Call LLM as "BD copilot" to suggest 3-5 Next Best Actions with actionTypes (follow_up, schedule_meeting, send_proposal, research_company, update_pipeline, add_contact, qualify_lead, close_opportunity, re_engage), each with title, description, score (0-100), reasoning. Fallback to 2 heuristic actions if LLM fails.

### Integration Points
- In AddCompanyScreen: when user enters a domain, offer a button "Auto-classify with AI" that calls suggestSegmentFromUrl. Show results: proposed segment path, confidence, extracted emails/phones/dimensions. If isProposal, show "Create New Segment" button (calls createChain). If existing match, auto-select it. Market Segment is **mandatory** — Save is disabled until segment is selected.
- In CompanyDetailScreen: show Next Best Actions section with selectable checkboxes to push actions to Actions tab.
- In OpportunityDetailScreen: show Next Best Actions section with refresh button and selectable checkboxes.
- In ContactDetailScreen: show Next Best Actions section with selectable checkboxes to push actions to Actions tab.
- In ContactsScreen: Company is **mandatory** when creating a contact. Include "Create New Company" option that navigates to AddCompanyScreen (which requires segment — cascading creation).
- In InteractionsScreen: Either Contact or Opportunity is **mandatory** when logging an interaction. Include searchable pickers for both.

### Relational Key Chain
All databases are linked with specific keys:
1. **Segments** — Entry from AI and user (top of hierarchy)
2. **Companies** — key to Segments via segmentId (required)
3. **Opportunities** — key to Companies via companyId (required, "driving company")
4. **Contacts** — key to Companies via companyId (required)
5. **Interactions** — key to Contacts via contactId OR Opportunities via opportunityId (at least one required)
6. **Actions** — reference back to any triggering entity via segmentId/companyId/contactId/opportunityId/interactionId

If a required key is missing during creation, the user is cascaded through creation of the parent entity (e.g., new contact needs company → new company needs segment).
```

---

## PROMPT 4: Onboarding Flow & Reports

```
Continue building BDBuddy. Schema, CRUD, screens, and AI layer are all working. Now build the onboarding flow and reports system.

### Onboarding Modal (in App.tsx)

Build an OnboardingModal component shown to first-time users (when orgSettings is null):

**Form step**: Full-screen modal with:
- Hero section: briefcase icon in blue circle, "Welcome to BDBuddy" title, subtitle explaining AI will build personalized market taxonomy
- Fields: Company Name (required), Company Website (optional, with hint "We'll analyze your website"), Types of Opportunities & Services (required, multiline textarea with example placeholder about industrial consulting)
- "Generate My Taxonomy" button with sparkles icon
- Footer hint about AI analysis

**Generating step**: Shows animated state with sparkles icon, "Building Your Taxonomy" title, status messages that update through the flow, spinner, "This may take 10-20 seconds..."

**Flow**:
1. ensureOnboarded() — create org if needed
2. upsertSettings() — save company profile
3. generateTaxonomy() — AI generates personalized taxonomy (race against 25s timeout)
4. If taxonomy succeeded: seedFromTaxonomy() + save taxonomyProfile metadata
5. If taxonomy failed/timed out: seedDefaults() as fallback
6. Always complete — never block the user

**Safety net** (in AuthenticatedApp): If orgSettings exists but segments array is empty and onboarding isn't showing, auto-seed defaults. This catches edge cases where seeding partially failed.

### Reports System (convex/reports.ts)

**pipelineReport query** with args: pipelineId?, stageIds?, groupBy ('stage'|'owner'), rangeField ('created'|'close'), startDate?, endDate?, currency?

Logic:
1. Fetch all non-deleted opportunities for org
2. Filter by pipeline, date range (using _creationTime or closeDate based on rangeField)
3. If currency filter specified, filter to that currency only
4. Detect if remaining opportunities have mixed currencies — if so, set a mixedCurrency flag and don't sum values
5. Group by stage (resolve stage names) or by owner (resolve user names)
6. Return: {groups: [{key, label, count, totalValue, currency}], summary: {totalCount, totalValue, currency, mixedCurrency, currencies[]}}

**createShareLink mutation**: Generate a random token (16 hex chars), store with filters as JSON string, 7-day expiry. Return {token}.

**revokeShare mutation**: Set revokedAt timestamp.

**listShares query**: All non-revoked, non-expired share links for org.

### ReportsScreen

Build a full analytics screen:
- **Header**: "Pipeline Report" title
- **Controls row**: GroupBy toggle (Stage/Owner), Date Field picker (Created/Close), Currency filter dropdown (show all unique currencies from data)
- **Summary cards**: Total opportunities count, Total value (with currency), "Mixed currencies" warning badge when applicable
- **Bar chart**: Horizontal bars showing each group's value or count. Color-coded bars. Label + value on each bar.
- **Share section**: "Share Report" button that creates a share link. List of active share links with copy-link and revoke buttons. Show expiry date and last accessed date.

### OrgSettings Backend (convex/orgSettings.ts)
- get query: return orgSettings for current user's org (or null)
- upsert mutation: create or update orgSettings (find by orgId, patch if exists, create if not)

### Settings Screen Update
Update SettingsScreen to show:
- Company profile section (company name, website, interests from orgSettings)
- Edit profile button that re-opens a settings form
- Sign out button
- App version info

### Audit Logging
Ensure ALL create/update/delete mutations across companies, contacts, opportunities, segments write to the auditLog table with: orgId, userId, action ('create'|'update'|'delete'|'stage_change'), entityType, entityId, details (optional JSON string with changed fields), timestamp.
```

---

## PROMPT 5: Polish, Edge Cases & Detail Screens

```
Continue building BDBuddy. Everything is functional. Now polish the UI, handle edge cases, and ensure production quality.

### Audit Logging
Ensure ALL create/update/delete mutations across companies, contacts, opportunities, segments write to the auditLog table with: orgId, userId, action ('create'|'update'|'delete'|'stage_change'), entityType, entityId, details (optional JSON string with changed fields), timestamp.

### Opportunity Stage Tracking
When moveStage is called, always write to opportunityStageChanges with fromStageId, toStageId, userId, changedAt. Show stage change history in OpportunityDetailScreen as a timeline.

### Push Notifications (convex/notifications.ts)
Create an internal action sendNotification(to, title, body, data?, badge?) that POSTs to the a0 push notification API. Wire it up to:
- Opportunity stage changes (notify owner)
- Task due date approaching
- New NBA generated

### UI Polish Checklist
For EVERY screen, ensure:
- SafeAreaView with proper edges=['top'] or edges=['top','bottom']
- Loading states: centered ActivityIndicator with subtle label
- Empty states: relevant Ionicon (72px, tertiary color) + friendly message + action button where applicable (e.g. "No companies yet" + "Add your first company")
- Error handling: try/catch on all mutations with Alert.alert for user feedback
- Keyboard handling: KeyboardAvoidingView on all form screens (behavior='padding' on iOS)
- Pull-to-refresh where applicable (FlatList with onRefresh)
- Consistent spacing using theme.spacing (never hardcode numbers)
- All colors from theme.colors (never hardcode hex)
- Card shadows using theme.shadow.sm or .md
- Touch feedback on all interactive elements (TouchableOpacity with activeOpacity=0.7)
- Text truncation: numberOfLines on list items to prevent overflow
- Relative dates on all timestamps: "Today", "Yesterday", "3d ago", "2w ago", then full date

### Navigation Edge Cases
- All detail screens (Company, Contact, Opportunity) should be accessible from ANY stack (Segments, Companies, Pipeline, Contacts, Interactions). Ensure each Stack navigator includes the detail screens it needs.
- Back button behavior should work correctly in all cases.
- Deep linking between entities: CompanyDetail should link to its contacts and opportunities, ContactDetail should link to their company, etc.

### Multi-Currency Handling
- Opportunity creation defaults to USD but allows any ISO 4217 currency
- Reports: when mixed currencies detected, show warning and allow filtering by single currency
- Display format: value + currency code (e.g. "150,000 USD")

### Performance
- Use FlatList (not ScrollView) for all lists with many items
- Implement proper keyExtractor on all lists
- Memoize expensive computations where appropriate

### Default Pipeline
On first org creation (in ensureOnboarded), if no pipelines exist, create a default pipeline named "Main Pipeline" with stages:
- Prospecting (position 0, color #6366F1)
- Qualification (position 1, color #8B5CF6)
- Proposal (position 2, color #EC4899)
- Negotiation (position 3, color #F59E0B)
- Closed Won (position 4, color #10B981)
```

---

## Usage Notes

- **Run prompts in order** (1 → 2 → 3 → 4 → 5) in the same a0.dev project
- Each prompt assumes the previous one's output exists
- Prompt 1 takes ~5 min, Prompt 2 is the heaviest (~15 min), Prompts 3-5 are ~10 min each
- After each prompt, deploy and verify before moving to the next
- If a session runs out of context, start a new session and say "Continue from where Prompt N left off — the schema, auth, and [list what's done] are already built"